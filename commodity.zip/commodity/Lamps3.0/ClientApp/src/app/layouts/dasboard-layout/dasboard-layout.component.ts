import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dasboard-layout',
  templateUrl: './dasboard-layout.component.html',
  styleUrls: ['./dasboard-layout.component.css']
})
export class DasboardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
