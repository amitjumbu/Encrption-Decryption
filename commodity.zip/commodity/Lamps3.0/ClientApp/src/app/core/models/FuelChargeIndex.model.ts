import { PaginationModel } from "./Pagination.Model";
import { DecimalPipe } from "@angular/common";

export class FuelChargeIndex extends PaginationModel {
  isSelected: boolean;
 Id: number;
 FuelPriceTypeId: number;
 FromFuelPrice: number;
 ToFuelPrice: number;
 FuelPriceUomid: number;
 ChargeRatePerMile: number;
 ChargeRateUomid: number;
 EffectiveStartDate: Date;
 EffectiveEndDate: Date;
 IsDeleted: boolean; 
 ClientId: number;
 SourceSystemId: number;
 updatedBy: string;
 updateDateTimeServer: Date;
 updateDateTimeBrowser: Date;
 createdBy: string;
 createDateTimeBrowser: Date;
 createDateTimeServer: Date;
 id: any;
 selectRow: string;


  


}


