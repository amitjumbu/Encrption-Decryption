export interface PreferenceType {
  Id: number;
  GroupName: string;
  Code: string;  
  Description: string;
  TypeValue: string;
  Uomid: number;
  IsEditable: boolean;
  PreferenceTypeCategoryId: number;
  PreferenceDetailDescription: string;
  IsDeleted: boolean;
  ClientId: number;
  SourceSystemId: number;
  UpdatedBy: string;
  UpdateDateTimeServer: Date;
  UpdateDateTimeBrowser: Date;
  CreatedBy: string;
  CreateDateTimeBrowser: Date;
  CreateDateTimeServer: Date;
  responseMessageCode: number;
  responseMessage: string;
  pageNo: number;
  pageSize: number;
}

export interface PreferenceTypeViewModel {
  groupName: string;
  code: string;
  description: string;
  typeValue: string;
  uomid: number;
  isEditable: boolean;
  preferenceTypeCategoryId: number;
  preferenceDetailDescription: string;
  isDeleted: boolean;
  clientId: number;
  sourceSystemId: number;
  updatedBy: string;
  updateDateTimeServer: Date;
  updateDateTimeBrowser: Date;
  createdBy: string;
  createDateTimeBrowser: Date;
  createDateTimeServer: Date;
}
