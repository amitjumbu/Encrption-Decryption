"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerLocationDDModel = exports.MapForecastCustomerLocationModel = exports.SaveUpdateEquipmentMaterialModel = exports.EquipmentTypeMaterialPropertyDetailModel = exports.CopyMaterialPropertyModel = exports.SaveUpdateModel = exports.MaterialPropertyDetailEditModel = exports.UOMModel = exports.MaterialPropertyDetailModel = exports.MaterialPropertyModel = exports.MaterialHierarchyDetailModel = exports.MaterialHierarchyModel = exports.MaterialGroupDetailModel = exports.MaterialGroupModel = exports.MaterialCommodityMap = void 0;
var Pagination_Model_1 = require("./Pagination.Model");
var MaterialCommodityMap = /** @class */ (function (_super) {
    __extends(MaterialCommodityMap, _super);
    function MaterialCommodityMap() {
        var _this = _super.call(this) || this;
        _this.setupComplete = false;
        _this.isReserve = false;
        _this.isActive = false;
        _this.isDeleted = false;
        return _this;
    }
    return MaterialCommodityMap;
}(Pagination_Model_1.PaginationModel));
exports.MaterialCommodityMap = MaterialCommodityMap;
var MaterialGroupModel = /** @class */ (function () {
    function MaterialGroupModel() {
        this.isDeleted = false;
    }
    return MaterialGroupModel;
}());
exports.MaterialGroupModel = MaterialGroupModel;
var MaterialGroupDetailModel = /** @class */ (function () {
    function MaterialGroupDetailModel() {
        this.isDeleted = false;
    }
    return MaterialGroupDetailModel;
}());
exports.MaterialGroupDetailModel = MaterialGroupDetailModel;
var MaterialHierarchyModel = /** @class */ (function () {
    function MaterialHierarchyModel() {
        this.isDeleted = false;
    }
    return MaterialHierarchyModel;
}());
exports.MaterialHierarchyModel = MaterialHierarchyModel;
var MaterialHierarchyDetailModel = /** @class */ (function () {
    function MaterialHierarchyDetailModel() {
        this.isDeleted = false;
    }
    return MaterialHierarchyDetailModel;
}());
exports.MaterialHierarchyDetailModel = MaterialHierarchyDetailModel;
var MaterialPropertyModel = /** @class */ (function () {
    function MaterialPropertyModel() {
        this.isVisible = false;
        this.isEditable = false;
        this.requiredUom = false;
        this.isDeleted = false;
    }
    return MaterialPropertyModel;
}());
exports.MaterialPropertyModel = MaterialPropertyModel;
var MaterialPropertyDetailModel = /** @class */ (function () {
    function MaterialPropertyDetailModel() {
        this.isVisible = false;
        this.isEditable = false;
        this.requiredUom = false;
        this.isDeleted = false;
    }
    return MaterialPropertyDetailModel;
}());
exports.MaterialPropertyDetailModel = MaterialPropertyDetailModel;
var UOMModel = /** @class */ (function () {
    function UOMModel() {
        this.dataTypeScale = false;
        this.isDeleted = false;
    }
    return UOMModel;
}());
exports.UOMModel = UOMModel;
var MaterialPropertyDetailEditModel = /** @class */ (function () {
    function MaterialPropertyDetailEditModel() {
        this.isVisible = false;
        this.isEditable = false;
        this.requiredUom = false;
        this.isDeleted = false;
    }
    return MaterialPropertyDetailEditModel;
}());
exports.MaterialPropertyDetailEditModel = MaterialPropertyDetailEditModel;
var SaveUpdateModel = /** @class */ (function () {
    function SaveUpdateModel() {
    }
    return SaveUpdateModel;
}());
exports.SaveUpdateModel = SaveUpdateModel;
var CopyMaterialPropertyModel = /** @class */ (function () {
    function CopyMaterialPropertyModel() {
    }
    return CopyMaterialPropertyModel;
}());
exports.CopyMaterialPropertyModel = CopyMaterialPropertyModel;
var EquipmentTypeMaterialPropertyDetailModel = /** @class */ (function () {
    function EquipmentTypeMaterialPropertyDetailModel() {
    }
    return EquipmentTypeMaterialPropertyDetailModel;
}());
exports.EquipmentTypeMaterialPropertyDetailModel = EquipmentTypeMaterialPropertyDetailModel;
var SaveUpdateEquipmentMaterialModel = /** @class */ (function () {
    function SaveUpdateEquipmentMaterialModel() {
    }
    return SaveUpdateEquipmentMaterialModel;
}());
exports.SaveUpdateEquipmentMaterialModel = SaveUpdateEquipmentMaterialModel;
var MapForecastCustomerLocationModel = /** @class */ (function () {
    function MapForecastCustomerLocationModel() {
    }
    return MapForecastCustomerLocationModel;
}());
exports.MapForecastCustomerLocationModel = MapForecastCustomerLocationModel;
var CustomerLocationDDModel = /** @class */ (function () {
    function CustomerLocationDDModel() {
    }
    return CustomerLocationDDModel;
}());
exports.CustomerLocationDDModel = CustomerLocationDDModel;
//# sourceMappingURL=material.model.js.map