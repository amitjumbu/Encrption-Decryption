"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrganizationHierarchy = void 0;
var OrganizationHierarchy = /** @class */ (function () {
    function OrganizationHierarchy() {
        this.PageNo = 1;
        this.PageSize = 100;
    }
    return OrganizationHierarchy;
}());
exports.OrganizationHierarchy = OrganizationHierarchy;
//# sourceMappingURL=organization-hierarchy.model.js.map