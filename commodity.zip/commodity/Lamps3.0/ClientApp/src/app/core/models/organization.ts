export class Organization {
  isSelected: boolean;
  billingName: string;
  code: string;
  createDateTimeBrowser: Date;
  createDateTimeServer: Date;
  createdBy: string;
  description: string;
  enterPriseName: string;
  filterOn: string;
  groupName: string;
  id: number;
  isActive: boolean;
  isDeleted: boolean;
  name: string;
  organizationFunction: string;
  organizationId: number;
  responseMessage: string;
  responseMessageCode: number;
  sortColumn: string;
  sortOrder: string;
  sourceSystemID: number;
  updateDateTimeBrowser: Date;
  updateDateTimeServer: Date;
  updatedBy: string;
  ClientID: number;
  PageNo: number;
  PageSize: number;
  SortOrder: string;
  constructor() {
    this.PageNo = 1;
    this.PageSize = 100;
    this.SortOrder = 'ASC'
  }

}
