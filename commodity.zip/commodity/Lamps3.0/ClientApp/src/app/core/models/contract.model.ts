import { PaginationModel } from "./Pagination.Model";

export class Contract extends PaginationModel {
  ClientId: number;
  LocationTypeId?: number;
  constructor() {
    super();
  }
} 
export class ContractViewModel {
  ID: number;
  Contract_Type: string;
  ContractTypeId: number;
  ClientID: number;
  Contract_No: string;
  Version: string;
  Description: string;
  Billing_Entity: string;
  Customer_Ship_To_Location: string;
  Business_Partner: string;
  Customer_Code: string; 
  Effective_Start: string;
  Effective_End: string;
  EarliestPriceEnd: string;
  Evergreen: string;
  End_Alert_Days: string;
  Status: string;
  ContractApproved: string;
  Approved_Datetime: string;
  IsSelected: boolean = false;
}

export class ContractObjectViewModel {
  Id: number;
  Code: string;
  ContractNumber: string;
  Description: string;
  ParentId: number;
  LocationId: number;
  ContractTypeId: number;
  ContractVersion: number;
  ContractVersionString: string;
  TermStartDate: Date;
  TermEndDate: Date;
  ContractEndAlertDays: number;
  ShippingInstructions: string;
  SetupComplete: boolean;
  SetupCompleteDateTime: Date;
  TransportationComment: string;
  LoadingComment: string;
  RowVersion: number;
  ContractComment: string;
  IsActive: number;
  EarliestPriceEndDate: Date;
  OrderComment: string;
  IsDeleted: boolean;
  ClientId: number;
  SourceSystemId: number;
  CreatedBy: string;
  CreateDateTimeBrowser: Date;
  CreateDateTimeServer: Date;
  UpdatedBy: string;
  UpdateDateTimeBrowser: Date;
  UpdateDateTimeServer: Date;
}

export class LineItem {
  Id: number;
  Material: string;
  Charge: string;
  Rate: string;
  RateType: string;
  UOM: string;
  Quantity_per_UOM: string;
  Commodity: string;
  Sales_Tax_Price: string;
  PriceIncreaseMethod: string;
  ShowOnBOL: string;
  AutoAdded: string;
  AddPallet: string;
  MethodType: string;
  EffectiveStart: string;
  EffectiveEnd: string;
  Add_New: string;
  Delete: string;
  ChargeId: number;
  MaterialId: number;
  ContractTypeId: number;
  ParentId: number;
}

export class ContractDetails {
  ContractTypeId: number;
  Id?: number;
  BusinessPartnerContractId?: number;
  CustomerContractId?: number;
  PriceMethodTypeId?: number;
  MaterialId?: number;
  ChargeId?: number;
  Uomid?: number;
  CommodityId?: number;
  QuantityPerUom?: number;
  DetailDescription: string;
  TermStartDate?: Date;
  TermEndDate?: Date;
  ShippingInstructionsNotRequired?: boolean;
  RateValue: number;
  ChargeComputationMethodId?: number;
  ShowOnBol?: number;
  IsRequired?: number;
  SalesTaxClassId?: number;
  PriceIncreaseMethodTypeId?: number;
  AddPalletBags?: number;
  IsDeleted: boolean;
  ClientId?: number;
  SourceSystemId?: number;
  CreatedBy: string;
  CreateDateTimeBrowser?: Date;
  CreateDateTimeServer: Date;
  UpdatedBy: string;
  UpdateDateTimeBrowser?: Date;
  UpdateDateTimeServer: Date;

}

export class DefineCharacteristics {
  Id?: number;
  ContractTypeId?: number;
  CustomerContractId?: number;
  BusinessPartnerContractId?: number;
  EntityPropertyId: number;
  PropertyValue: string;
  PropertiesUom: string;
  IsDeleted?: boolean;
  ClientId?: number;
  SourceSystemId?: number;
  UpdatedBy: string;
  UpdateDateTimeServer: Date;
  UpdateDateTimeBrowser?: Date;
  CreatedBy: string;
  CreateDateTimeBrowser?: Date;
  CreateDateTimeServer?: Date;
}
