"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LocationUnit = /** @class */ (function () {
    function LocationUnit() {
        this.PageNo = 1;
        this.PageSize = 100;
    }
    return LocationUnit;
}());
exports.LocationUnit = LocationUnit;
//# sourceMappingURL=location-unit.js.map