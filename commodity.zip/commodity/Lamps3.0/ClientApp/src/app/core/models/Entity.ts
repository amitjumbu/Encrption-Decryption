export class EntityclientPropertyControlValueViewModel {
  controlDisplayValue: string;
  controlDatabaseValue: number;
  isDeleted: boolean;
  id: number;
  constructor() {
    this.id = this.controlDatabaseValue;
  }
}
