/*
      Developer Name: Rizwan Khan
      Date: Sep 04, 2020
      TFS ID: 17
      Logic Description: This is used as base class in partograph model
   */
export class GlobalConstants {
  public static FETAL_HEART_RATE: string = "FHR";
  public static BLOOD_PRESSURE: string = "BP";
  public static PULSE: string = "PL";
  public static CONTRACTION_PER_10MINS: string = "CN";
  public static TEMPERATURE: string = "TEMP";
  public static OXYTOCIN: string = "OXY";
  public static DROPS: string = "DROPS";
  public static CERVIX: string = "CERVIX";
  public static DESCENT_OF_HEAD: string = "DESCENT";
  public static VOlUME: string = "VL";
  public static PROTEIN: string = "PT";
  public static ACETON: string = "ACT";
  public static CAPUT: string = "CAPUT";
  public static AMNIOTIC: string = "AMF";
  public static MOULDING: string = "MD";

  // Partograph Monitoring Stage Wise Code for Dynamic Measurement

  public static PARTOGRAPH_MONITORING_STAGE3 = "PMS-3";
  public static PARTOGRAPH_MONITORING_STAGE4 = "PMS-4";

  // Registration Page Code for Dynamic parameter
  public static PATIENT_REGISTRATION_STAGE1 = "PREG-1";

  // PrepartumCare Page Code for Dynamic parameter
  public static PATIENT_PrepartumCare_STAGE1 = "PREC-1";
  public static PATIENT_PrepartumCare_STAGE2 = "PREC-2";
  public static PATIENT_PrepartumCare_STAGE3 = "PREC-3";
  public static PATIENT_PrepartumCare_STAGE4 = "PREC-4";
  public static PATIENT_PrepartumCare_STAGE5 = "PREC-5";

  // PostpartumCare Page Code for Dynamic parameter
  public static PATIENT_PostpartumCare_STAGE1 = "POSTC-1";
  public static PATIENT_PostpartumCare_STAGE2 = "POSTC-2";
  public static PATIENT_PostpartumCare_STAGE3 = "POSTC-3";
  public static PATIENT_PostpartumCare_STAGE4 = "POSTC-4";
  public static PATIENT_PostpartumCare_STAGE5 = "POSTC-5";

  //END

  // 
 // public static PARTOGRAPH_MONITORING_STAGE41 = "PMS-4";

  //public static FAHRENHEIT_FORMULA = 


  // Added By Kapil
  public static Success: string = "Success";
  public static CustomerReturn: string = "CustomerReturn";
  public static PriceMethodCateoryCode: string = "PricingMethod";

  public static SUCCESS_MESSAGE = "Record saved successfully.";
  public static SUCCESS_UPDATE_MESSAGE = "Record update successfully.";
  public static FAILED_MESSAGE = "Record not saved.";
  public static Not_found_MESSAGE = "No record found.";
 
  public static MaxLength_MESSAGE = "max length 500 characters only!";

  public static BLOODPRESSURE_COMPARE_MESSAGE = "Diastolic Pressure(mmHg) can never be higher than Systolic Pressure(mmHg).";

  public static OPERATING_LOCATION_CODE = "OP";

  public static SourceSystemId = 1;

  public static DEFAULT_GEOLOCATION_MODE: string = "COUNTRY";
  public static STATE_GEOLOCATION_MODE: string = "STATE";
  public static CITY_GEOLOCATION_MODE: string = "CITY";
  public static ZIP_GEOLOCATION_MODE: string = "ZIP";
  public static EXISTING_ADDRESS_MODE: string = "EXISTINGADDRESS";

  
  //Add selected code by default
  public static EA: string = "EA";
  public static PLT: string = "PLT";
  public static Customer: string = "Customer";
  public static OpenOrderNeedsToBeCompleted: string = "OpenOrderNeedsToBeCompleted";
  public static SendforShipping: string = "SendforShipping";
  public static StockTransfer: string = "StockTransfer";
  public static Collections: string = "Collections";


  public static Primary_Contact_Information: string = "PC01";
  public static Emergency_Contact_Information: string = "EC01";
  public static Primary_Physician_Information: string = "PPC01";
  public static Secondary_Physician_Information: string = "SPI01";
  public static Referral_Information: string = "RF01";

  // Address Type 
  public static HOME_ADDRESS_TYPE_CODE: string = "HOMEADDRESS";
  public static WORK_ADDRESS_TYPE_CODE: string = "WORKADDRESS";
  public static MAILING_ADDRESS_TYPE_CODE: string = "MAILINGADDRESS";
    
  // Address Type 
  public static PRIMARY_ADDRESS_TYPE_CODE: string = "PrimaryAdd";
  public static EMERGENCY_ADDRESS_TYPE_CODE: string = "EmergencyAdd";

  public static PerEA: string = "PerEA";
  public static PerPallet: string = "PerPallet";
  public static PerBag: string = "PerBag";
  public static PerEAPerMonth: string = "PerEAPerMonth";
  public static PerEAPerWeek: string = "PerEAPerWeek";
  public static PercentageAmount: string = "%Amount";
  public static DOE: string = "DOE";
  public static UnusedPerPallet: string = "UnusedPerPallet";
  public static PerShipment: string = "PerShipment";
  public static ChargeAmount: string = "ChargeAmount";
  public static PerUnit: string = "PerUnit";
  public static PerUnitXPerEA: string = "PerUnitXPerEA";



 
  public static NonBillable: string = "NonBillable";
  public static Billable: string = "Billable";
  public static DefaultMaterialChargeCode: string = "Reusable Plastic Container";
  public static NotRemoved: string = "Selected item can't not be deleted.";
  public static ValidationError: string = "Please provide the valid data.";

  public static PelletCode: string = "PLT";
  public static BagCode: string = "BAG";

  public static PalletChargeDefault: string = "Pallet";
  public static BagChargeDefault: string = "Bag";

  public static MaterialItem: string = "Material";
  public static PackageItem: string = "Package";

  //order success
  public static OrderSuccess: string = "Order saved successfully";

  public static AdjustmentChargesUpdate: string = "Adjustment chagres updated successfully.";
  //Preferred Material
  public static materialId: string = "materialId";
  public static quantity: string = "quantity";
  public static uomId: string = "uomId";


  // Contactfield  
  public static contactTypeId: string = "contactTypeId";
  public static firstName: string = "firstName";
  public static lastName: string = "lastName";
  public static email: string = "email";
  public static workPhone: string = "workPhone";
  public static mobilePhone: string = "mobilePhone";
  public static PleaseselectAddressType: string = "Please select Address Type";

  public static OrderUnsuccess: string = "Order not saved";
  public static AlreadyaddedMaterial: string = "Selected material already into list with same charge.";
  public static AlreadyaddedCharge: string = "Selected charge already into list.";
  public static Alreadyadded: string = "Duplicate data can't be insert.";
  public static delete_message: string = "Successfully deleted!";

  public static OrganizationTypeId: number = 1;

  public static OrganizationTypeCode: string = "OP";

  public static PageActionTypeCustomer: string = "Location";
  public static OrganizationTypeIdCust: number = 6;

  public static OrganizationTypeCodeCust: string = "Customer";

  public static OrderIDPreferredMaterial: number = 0;
  public static SectionIDPreferredMaterial: number = 0;

  public static OrderTypeIDForCustomer: number = 1;
  public static SectionIDDefaultPallet: number = 1;
  public static DecimalPrferenceForMoney: string = "DefaultNoOfDecimalPlacesForMoney";

  public static OperatingLocation_Active = 'Operating location activated successfully.';
  public static OperatingLocation_InActive = 'Operating location inactivate.';
  public static OperatingLocation_SelectActive = 'please select operating location to active.';
  public static OperatingLocation_SelectInActive = 'please select operating location to Inactive.';
  public static decimalCode = 'DefaultNoOfDecimalPlacesForMoney';

  
}

