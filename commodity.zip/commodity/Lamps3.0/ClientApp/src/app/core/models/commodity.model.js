"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommodityCheckModel = exports.CommodityNewModel = exports.CommodityEitModel = exports.Commodity = exports.CommodityPaginatorListViewModel = exports.PeriodicElement = exports.CommodityTypeListViewModel = exports.CommodityCallListViewModel = void 0;
var Pagination_Model_1 = require("./Pagination.Model");
var CommodityCallListViewModel = /** @class */ (function () {
    function CommodityCallListViewModel() {
    }
    return CommodityCallListViewModel;
}());
exports.CommodityCallListViewModel = CommodityCallListViewModel;
var CommodityTypeListViewModel = /** @class */ (function () {
    function CommodityTypeListViewModel() {
    }
    return CommodityTypeListViewModel;
}());
exports.CommodityTypeListViewModel = CommodityTypeListViewModel;
var PeriodicElement = /** @class */ (function () {
    function PeriodicElement() {
        this.IsSeleted = false;
        this.Count = 0;
        this.IsSeleted = false;
        this.Count = 0;
    }
    return PeriodicElement;
}());
exports.PeriodicElement = PeriodicElement;
var CommodityPaginatorListViewModel = /** @class */ (function () {
    function CommodityPaginatorListViewModel() {
    }
    return CommodityPaginatorListViewModel;
}());
exports.CommodityPaginatorListViewModel = CommodityPaginatorListViewModel;
var Commodity = /** @class */ (function () {
    function Commodity() {
    }
    return Commodity;
}());
exports.Commodity = Commodity;
var CommodityEitModel = /** @class */ (function (_super) {
    __extends(CommodityEitModel, _super);
    function CommodityEitModel() {
        var _this = _super.call(this) || this;
        _this.IsSeleted = false;
        _this.Count = 0;
        return _this;
    }
    return CommodityEitModel;
}(Commodity));
exports.CommodityEitModel = CommodityEitModel;
var CommodityNewModel = /** @class */ (function (_super) {
    __extends(CommodityNewModel, _super);
    function CommodityNewModel() {
        return _super.call(this) || this;
    }
    return CommodityNewModel;
}(Pagination_Model_1.PaginationModel));
exports.CommodityNewModel = CommodityNewModel;
var CommodityCheckModel = /** @class */ (function () {
    function CommodityCheckModel() {
    }
    return CommodityCheckModel;
}());
exports.CommodityCheckModel = CommodityCheckModel;
//# sourceMappingURL=commodity.model.js.map