"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SortOrder = exports.PaginationModel = void 0;
var PaginationModel = /** @class */ (function () {
    function PaginationModel() {
        this.pageNo = 1;
        this.pageSize = 10;
        this.pageSizeOptions = [10, 20, 30, 50];
    }
    return PaginationModel;
}());
exports.PaginationModel = PaginationModel;
var SortOrder;
(function (SortOrder) {
    SortOrder[SortOrder["ASC"] = 0] = "ASC";
    SortOrder[SortOrder["DESC"] = 1] = "DESC";
})(SortOrder = exports.SortOrder || (exports.SortOrder = {}));
//# sourceMappingURL=Pagination.Model.js.map