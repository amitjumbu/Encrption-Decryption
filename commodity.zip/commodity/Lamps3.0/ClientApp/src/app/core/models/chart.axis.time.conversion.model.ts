// TFSID 16012 Add Property for cont
export class ChartTimeConversionXAxis{
  xAxisPosition = 0;
  xCervixTime = 0;
  xAxisPulseBp = 60;
  xAxisPositionContraction = 0;
  observationStartTime: any;
  isTimeExceed: number;
  minutes: number;
  hours: number;
  timeNow: any;
  TestingStartdate: any;
  currentDate: Date;
  xAxisInterval_Sys = 0;
  xAxisBPonly = 0;
  halfPlotting = 0;
  timeZone: string;
  DisplayCurrentTime: string;
}
