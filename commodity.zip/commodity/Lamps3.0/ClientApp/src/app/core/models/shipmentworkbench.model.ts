export class ShipmenteditModel {

  
}
 export class CommonListViewModel {

  ClientID: number;
  PageNo: number;
  PageSize: number;
  constructor() {
    this.PageNo = 0;
    this.PageSize = 10;
   
  }


}
export class ShipmentMaterialDeatails {
  ID: number;
  MaterialID: number;
  Quantity: number;
  ShowOnBOL: number;
  PriceMethodType: string;
  CommudityName: string;
  OrderNumber: string;
  MaterialName: string;
  LocationName: string;
  QuantityDiff: number;
  ShippedQuantity: number;
  
  
}
