import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { BPByLocation, BPByCarrier } from '../models/BusinessPartner.model';
import { BaseService } from './base.service';
import { PreferenceTypeService } from './preferencetype.service';

@Injectable({
  providedIn: 'root'
})

export class BusinessPartnerService extends BaseService {
  
  constructor(private http: HttpClient,
    preferenceService: PreferenceTypeService) {
    super(preferenceService);
  }

  getBPByLocation(paginationModel: BPByLocation) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/BusinessPartner/GetByLocation`,
      paginationModel)
      .pipe(map(charge => {
        return charge;
      }));
  }

  getBPByCarrier(paginationModel: BPByCarrier) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/BusinessPartner/GetByCarier`,
      paginationModel)
      .pipe(map(charge => {
        return charge;
      }));
  }

  getLocationFunctionList(requestObj: any) {

    return this.http.post<any>(`${this.MASTER_SERVICE_URL}/LocationFunction/list`,
      requestObj)
      .pipe(map(charge => {
        return charge;
      }));
  }

  updateBPByLocation(saveObj: any) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/BusinessPartner/update/BpByLocation`,
      saveObj)
      .pipe(map(charge => {
        return charge;
      }));
  }

  updateBPByCarrier(saveObj: any) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/BusinessPartner/update/BpByCarrier`,
      saveObj)
      .pipe(map(charge => {
        return charge;
      }));
  }
  mergeCharacteristicsData(updateList: any[]) {

    return this.http.post<any>(`${this.BASE_SERVICE_URL}/BusinessPartnerPropertyDetail/updateAll`, updateList)
      .pipe(map(result => {
        return result;
      }));
  }
  mergeCarrierCharacteristicsData(updateList: any[]) {

    return this.http.post<any>(`${this.BASE_SERVICE_URL}/CarrierPropertyDetail/updateAll`, updateList)
      .pipe(map(result => {
        return result;
      }));
  }
  getExistingCarrierCharacteristics(requestObj: { CarrierId: number; ClientId: number; }) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/CarrierPropertyDetail/GetExistingCharacteristics`, requestObj)
      .pipe(map(response => {
        return response;
      }));
  }

  deleteCarrierCharacteristics(requestObj: any) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/CarrierPropertyDetail/DeleteExistingCharacteristics`, requestObj)
      .pipe(map(response => {
        return response;
      }));
  }


  addCarrier(requestObj: any) {
    return this.http.post<any>(`${this.BASE_SERVICE_URL}/BusinessPartner/add/BpByCarrier`, requestObj)
      .pipe(map(response => {
        return response;
      }));
  }
}
