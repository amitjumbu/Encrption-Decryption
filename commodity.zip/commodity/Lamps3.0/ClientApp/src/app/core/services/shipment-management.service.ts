import { Injectable } from '@angular/core';
import { JsonApiService } from './json-api.service';
import { environment } from '@env/environment';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

import { regularOrderModel, PeriodicElement, CommonOrderModel } from '../../core/models/regularOrder.model';
import { map } from 'rxjs/operators';
import { Observable, BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';
import { GlobalConstants } from '@app/core/models/GlobalConstants ';
import { CommonListViewModel } from '../models/shipmentworkbench.model';
import { OriginOfGoods } from '../models/OriginOfGoods.model';
import { ShipmentNaftaReportData } from '../models/ShipmentNaftaReportData.model';
import { BaseService } from './base.service';
import { PreferenceTypeService } from './preferencetype.service';
@Injectable({
  providedIn: 'root'
})
export class shipmentManagementService extends BaseService {
  private httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  public userAccess: Observable<any>;
  public userAccessSubject: BehaviorSubject<any>;
  public ShipmentsforEdit: any = {};
  public ShipmentforEditOrders: any = {};
  public EditingShipment: any;
  public LocationsData: any = [];

  constructor(private jsonApiService: JsonApiService, private http: HttpClient, private authservices: AuthService, preferenceService: PreferenceTypeService ) {
    super(preferenceService);
    this.userAccessSubject = new BehaviorSubject<Array<PeriodicElement>>([]);
    this.userAccess = this.userAccessSubject.asObservable();

  }

  OrderTypeList() {
   // return this.http.get<any>(`${environment.masterServerUrl}${routesConstrant.OrderType}/${Id}`)
    return this.http.get<any>(`${environment.coreBaseApiUrl}/shipment/GetOrderTypeForShipment`)
      .pipe(map(result => {
        return result;
      }));
  }

  OrderStatusList() {
   // return this.http.get<any>(`${environment.masterServerUrl}/OrderStatus/GetByID?id=` + id)
    return this.http.get<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentStatusForShipment`)
      
      .pipe(map(result => {
        return result;
      }));
  }

  ShipmentConditionList() {
    // return this.http.get<any>(`${environment.masterServerUrl}/OrderStatus/GetByID?id=` + id)
    return this.http.get<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentConditionForShipment`)
      .pipe(map(result => {
        return result;
      }));
  }


  CarrierList(CommonListViewModel: CommonListViewModel) {
    return this.http.post<any>(`${environment.masterServerUrl}/Carrier/List`, {})
      .pipe(map(result => {
       
        return result;
      }));
  }

  EquipmentTypeData(CommonListViewModel: CommonListViewModel) {
    return this.http.post<any>(`${environment.masterServerUrl}/EquipmentType/List`, {})
      .pipe(map(result => {
        return result;
      }));
  }

  GetChargeType() { 
    return this.http.get<any>(`${environment.coreBaseApiUrl}/charge/list`)
      .pipe(map(data => { return data; }));
    }
  
  GetFrieghtMode() {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/FreightMode/list`, {})
      .pipe(map(data => {
        return data;
      }));
  }

  GetShippingOrders(ShipmentID: number) {
    var RequestObject = {
      ShipmentID: ShipmentID
    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentOrders`, RequestObject)
      .pipe(map(data => {
          return data;
        }));
  }

  GetShipmentOrderDetailsforSID(ShipmentID:number) {
    var RequestObject = {
      ShipmentID: ShipmentID
    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentOrdersDetailsForShipmentId`, RequestObject)
      .pipe(map(data => {
        return data;
      }));
  }

  GetApcharges(ShipmentID: number) {
    var RequestObject = {
      ShipmentID: ShipmentID
    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/GetApcharges`, RequestObject)
      .pipe(map(data => {
        
        return data;
      }));
  }

  GetOrderAmountforApcharges(apchargeBusinessPartnerID, apchargeChargeType, shipmentID) {
    var RequestObject = {
      BusinessPartnerID: parseInt(apchargeBusinessPartnerID),
      ChargeType: apchargeChargeType,
      ShipmentID:shipmentID
    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/GetOrderAmountforAPCharges`, RequestObject)
      .pipe(map(data => {
       return data;
      }));
  }

  GetShipmentDetails(ShipmentID: number) {
    var RequestObject = {
      ShipmentID: ShipmentID
    };
     return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentdetails`, RequestObject)
      .pipe(map(data => {
        return data;
      }));
  }

  GetAllShipmentDetails() {
   return this.http.get<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentdetails`)
     .pipe(map(data => {
        return data;
      }));
  }

  GetLocationsforDD() {
    return this.http.get<any>(`${environment.coreBaseApiUrl}/shipment/GetLoctionsForShipment`)
       .pipe(map(data => {
        return data;
      }));
  }

  GetTenderstatusforDD() {
    return this.http.get<any>(`${environment.coreBaseApiUrl}/shipment/GetTenderStatusForShipment`)
      .pipe(map(data => {
        return data;
      }));
  }
  
  SaveNaftaReport(ShipmentNaftaReportData: ShipmentNaftaReportData[]) {
    debugger;
    ShipmentNaftaReportData[0].clientId = this.authservices.currentUserValue.ClientId;
    ShipmentNaftaReportData[0].SourceSystemId = 1;
    var httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData`, ShipmentNaftaReportData[0], httpOptions)
      .pipe(map(response => {
        return response;
      }));
  }
  sendImage(formData) {
    debugger;
    //var httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData/autherizedSignature`, formData)
      .pipe(map(response => {
        return response;
      }));
  }
  SaveOriginOfGoods(OriginOfGoods: OriginOfGoods[]) {
    debugger;
    OriginOfGoods[0].ClientId = this.authservices.currentUserValue.ClientId;
    OriginOfGoods[0].SourceSystemId = 1;
    var httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/CountryOfOriginOfMaterial`, OriginOfGoods[0], httpOptions)
      .pipe(map(response => {
        return response;
      }));
  }
  updateOriginOfGoods(OriginOfGoods: OriginOfGoods[]) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/CountryOfOriginOfMaterial/update`, OriginOfGoods[0])
      .pipe(map(response => {
        return response;
      }));
  }
  updateNaftaReport(ShipmentNaftaReportData: ShipmentNaftaReportData[]) {
    debugger;
    return this.http.post<any>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData/update`, ShipmentNaftaReportData[0])
      .pipe(map(response => {
        return response;
      }));
  }
  getShipmentNaftaReportDataList() {
    return this.http.get<any>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData/list`)
      .pipe(map(response => {
        return response;
      }));
  }
  getOriginOfGoodsList() {
    return this.http.get<any>(`${environment.coreBaseApiUrl}/CountryOfOriginOfMaterial/list`)
      .pipe(map(response => {
        return response;
      }));
  }
  deleteAllOriginOfGoods(ids: string) {
    debugger;
    const body = { IDs: ids }
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<OriginOfGoods>(`${environment.coreBaseApiUrl}/CountryOfOriginOfMaterial/DeleteAll`, body, this.httpOptions);
  }
  deleteAllNaftaReport(ids: string) {
    debugger;
    const body = { IDs: ids }
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<OriginOfGoods>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData/DeleteAll`, body, this.httpOptions);
  }
  getOriginOfGoodsDetailsList(paginationModel: OriginOfGoods) {
   
    var httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/CountryOfOriginOfMaterial/GetOriginOfGoodsDetails`, paginationModel, httpOptions)
      .pipe(map(response => {
       
        return response;
      }));
  }
  getAllShipmentNaftaReportDataList(paginationModel: ShipmentNaftaReportData) {

    var httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData/GetShipmentNaftaReportData`, paginationModel, httpOptions)
      .pipe(map(response => {

        return response;
      }));
  }
  GetNetCost(EntityId: number, EntityPropertyId: number) {
    debugger;
    var AllData = { EntityId: Number(EntityId), EntityPropertyId: Number(EntityPropertyId) };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/ShipmentNaftaReportData/getNetCostData`, AllData)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));
  }

  SaveShipment(ShipmentSaveDetails) {
    var ShipmentDetails1: any = {};

    ShipmentDetails1.id = ShipmentSaveDetails.id;
    ShipmentDetails1.orderTypeID = ShipmentSaveDetails.orderTypeID;
    ShipmentDetails1.statusID =ShipmentSaveDetails.statusID;
    ShipmentDetails1.conditonID = ShipmentSaveDetails.conditonID;
    ShipmentDetails1.shipDate =ShipmentSaveDetails.shipDate;
    ShipmentDetails1.carrierID = ShipmentSaveDetails.carrierID;
    ShipmentDetails1.shipmentTenderStatusID = ShipmentSaveDetails.shipmentTenderStatusID;
    ShipmentDetails1.equipmentID = ShipmentSaveDetails.EquipmentID;
    ShipmentDetails1.modeID = ShipmentSaveDetails.modeID;

    ShipmentDetails1.trailerNumber = ShipmentSaveDetails.trailerNumber;
    ShipmentDetails1.trailerSealNumber = ShipmentSaveDetails.trailerSealNumber;
    ShipmentDetails1.approvedBy = ShipmentSaveDetails.approvedBy;
    ShipmentDetails1.approvedDateTime = ShipmentSaveDetails.approvedDateTime;
    ShipmentDetails1.compliedWithShippingInstructions = ShipmentSaveDetails.compliedWithShippingInstructions;
    ShipmentDetails1.dropTrailer = ShipmentSaveDetails.dropTrailer;
    ShipmentDetails1.trailerCheckInTime = ShipmentSaveDetails.trailerCheckInTime;
    ShipmentDetails1.trailerCheckOutTime = ShipmentSaveDetails.trailerCheckOutTime;
    ShipmentDetails1.sortStartTime = ShipmentSaveDetails.sortStartTime;
    ShipmentDetails1.sortEndTime = ShipmentSaveDetails.sortEndTime;
    ShipmentDetails1.cpdata = ShipmentSaveDetails.CarrierPickupData;
    ShipmentDetails1.csddata = ShipmentSaveDetails.CarrierStopData;
    ShipmentDetails1.orderComments = ShipmentSaveDetails.OrderComments;
    ShipmentDetails1.apcharges = ShipmentSaveDetails.apcharges;
    ShipmentDetails1.salesOrderDetail = ShipmentSaveDetails.salesOrderDetail;
    ShipmentDetails1.deletesalesOrderDetail = ShipmentSaveDetails.deletesalesOrderDetail;
    ShipmentDetails1.Locations = ShipmentSaveDetails.Locations;
    ShipmentDetails1.Appointments = ShipmentSaveDetails.Appointments;
    console.log(JSON.stringify(ShipmentDetails1));
   return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/SaveShipment`, ShipmentDetails1)
       .pipe(map(data => {
        return data;
      }));
  }

  GetShippingOrdersDetails(ShipmentID: number) {
    var RequestObject = {
      ShipmentID: ShipmentID
    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/GetShipmentOrdersDetails`, RequestObject)
      .pipe(map(data => {
        return data;
      }));
  }
  GetAdjustChargesDefault(RequestObject: any) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/OrderCalculation/GetAdjustChargesDefaultData`, RequestObject)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));
  }

  GetMaterialQuantity(data: any[], RequestObject: any) {
    var AllData = { Materials: data, MaterialQuantityRequestModel: RequestObject };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/Material/AllMaterialquantity`, AllData)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));
  }
  SendShipmentTOMAS(shipmentID: number, CarrierInDate: Date, CarrierOutDate: Date, fromlocationid : number) {
    var AllData = { shipmentID: Number(shipmentID), carrierInTime: CarrierInDate.toString(), carrierOutTime: CarrierOutDate.toString(), clientID: this.authservices.currentUserValue.ClientId, FromLocationID: Number(fromlocationid)};
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/SendShipmentToMAS`, AllData)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));
  }

  convertDateTimeToStringDateTime(selectedDate: Date) {
        if (selectedDate == undefined || selectedDate == null)
      selectedDate = new Date();

    var date = selectedDate.getDate();
    var month = selectedDate.getMonth() + 1;
    var year = selectedDate.getFullYear();
    var hours = selectedDate.getHours();
    var minuts = selectedDate.getMinutes();

    return date.toString() + "-" + month.toString() + "-" + year.toString() + "-" + hours.toString() + "-" + minuts.toString();
  }

  GetMaterialCommodity(data: any[], RequestObject: any) {
    var AllData = { Materials: data, MaterialQuantityRequestModel: RequestObject };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/Material/DefaultMaterialCommodity`, AllData)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));
  }

  GetDefaultMaterialProperty(RequestObject: any) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/Material/DefaultMaterialProperty`, RequestObject)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));

  }
  GetOrderMaterialList(sectionID: number) {
    debugger;
    var RequestObject = {
      ClientID: this.authservices.currentUserValue.ClientId,
      SectionID: sectionID
    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/Material/OrderMaterialList`, RequestObject)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));
  }
  GetOrganizationList() {
    debugger;
    var RequestObject = {

      ClientID: this.authservices.currentUserValue.ClientId,
 
    };

    return this.http.post<any>(`${environment.serverUrl}/Organization/organizationList`, RequestObject)
      .pipe(map(orderDetails => {
        return orderDetails;
      }));

  }
  GetCountryList() {
   // var RequestObject = sectionID;
    //{
     // ClientID: this.authservices.currentUserValue.ClientId,
    //  SectionID: sectionID
    //};
    return this.http.get<any>(`${environment.serverUrl}/Country/GetCountryList`)
      .pipe(map(CountryDetails => {
        return CountryDetails;
      }));

  }

  GetManufacturerList(sectionID: number) {
    debugger;
    var RequestObject = {

      ClientID: this.authservices.currentUserValue.ClientId,
      SectionID: sectionID
      
    };

    return this.http.post<any>(`${environment.coreBaseApiUrl}/Location/ManufacturerList`, RequestObject)
      .pipe(map(ManufacturerDetails => {
        return ManufacturerDetails;
      }));

  }

  Tonu(RequestObject: any) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/Tonu`, RequestObject)
      .pipe(map(data => {
        return data;
      }));
  }

  Cancel(RequestObject: any) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/Cancel`, RequestObject)
      .pipe(map(data => {
        return data;
      }));
  }


  SaveShipmentOrders(ShipmentOrders) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/SaveShipmentOrders`, ShipmentOrders)
      .pipe(map(data => {
        return data;
      }));
  }

  ShipSelecteShipment(SelectedShipmentDetails) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/ShipSelectedShipment`, SelectedShipmentDetails)
      .pipe(map(data => {
        return data;
      }));
  }
    
  ReceiveSelectedShipment(SelectedShipmentDetails) {
    return this.http.post<any>(`${environment.coreBaseApiUrl}/shipment/ReceiveSelectedShipment`, SelectedShipmentDetails)
      .pipe(map(data => {
        return data;
      }));
  }

}



export const routesConstrant = {
  
  OrderType: '/OrderType',


}
