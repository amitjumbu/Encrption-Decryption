import { Injectable } from '@angular/core';

import { JsonApiService } from './json-api.service';
import { environment } from '@env/environment';
import { User } from '..';
import { HttpClient } from '@angular/common/http';

const routes = {
    users: '/users'
};

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private jsonApiService: JsonApiService, private http: HttpClient) {}

  getAll() {
    return this.http.get<User[]>(`${environment.serverUrl}/users`);
  }

}
