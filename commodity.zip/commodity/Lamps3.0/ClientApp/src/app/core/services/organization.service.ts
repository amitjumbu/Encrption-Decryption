import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment as env } from '@env/environment';
import { Organization } from '../models/organization';
import { PreferenceTypeService } from './preferencetype.service';
import { BaseService } from './base.service';


const BASE_URL = env.masterServerUrl;
@Injectable({
  providedIn: 'root'
})
export class OrganizationService extends BaseService {
  private httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };

  constructor(private http: HttpClient, public preferenceService: PreferenceTypeService) {
    super(preferenceService);
  }


  // Get Organization List
  getOrganizationList(organization: Organization) {

    return this.http.post<any>(BASE_URL + '/Organization/GetAllRecords', organization)
      .pipe(map(OrganizationList => {
        return OrganizationList;
      }));
  }


  // Get Organization Characteristics List
  getCharacteristicsList(organizationId: number) {
    const reqBody = {
      OrganizationId: organizationId
    }
    return this.http.post<any>(env.coreBaseApiUrl + '/OrganizationPropertyDetail/GetAllRecords', reqBody)
      .pipe(map(CharacteristicsList => {
        return CharacteristicsList;
      }));
  }

  // Delete Organization Characteristics List
  deleteCharacteristics(deleteReqBody) {
    return this.http.post<any>(env.coreBaseApiUrl + '/OrganizationPropertyDetail/DeleteByID', deleteReqBody)
  }


  // Get Organization Characteristics Description List
  getCharacteristicsListDescription(EntityCode: string) {
    const reqBody = {
      EntityCode: EntityCode
    }
    return this.http.post<any>(env.coreBaseApiUrl + '/OrganizationPropertyDetail/GetOrganizationCharacteristics', reqBody)
      .pipe(map(CharacteristicsListDescription => {
        return CharacteristicsListDescription;
      }));
  }

  saveCharacteristics(saveReqBody) {
    return this.http.post<any>(env.coreBaseApiUrl + '/OrganizationPropertyDetail/SaveAll', saveReqBody)
  }
}
