import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//import { PreferenceTypeService } from '.';
import { BaseService } from './base.service';
import { environment } from '../../../environments/environment';
import { PreferenceTypeService, UsersContactViewModel } from '..';
import { map } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { EquipmentViewModel, EquipmentTypeAEModel, EquipmentTypeSaveModel, EquipmentTypeFreightModeMapModel } from '../models/Equipment';
import { FreightMode } from '../../modules/system-settings/modals/freightmode';


const BASE_URL = environment.coreBaseApiUrl;
const MASTER_URL = environment.masterServerUrl;

@Injectable({
  providedIn: 'root'
})
export class EquipmentService extends BaseService{
  private httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private http: HttpClient, private authservices: AuthService,
    preferenceService: PreferenceTypeService) {
    super(preferenceService);
  }

  getEquipmentList(paginationModel: EquipmentViewModel) {
    
    return this.http.post<any>(`${environment.masterServerUrl}/EquipmentType/GetAllRecords`,
      paginationModel)
      .pipe(map(result => {
        return result;
      }));
  }

  getFrieghtModeList() {
    var RequestObject = {
      pageSize: 100,
      pageNo: 1

    };
    return this.http.post<any>(`${environment.coreBaseApiUrl}/FreightMode/List`,
      RequestObject)
      .pipe(map(result => {
        return result;
      }));
  }

  getAll(freightModal: FreightMode) {    
    return this.http.post<any>(`${environment.coreBaseApiUrl}/FreightMode/GetAllRecords`, freightModal)
      .pipe(        
        map(response => { return response }
        ));
  }

  deleteEquipmentById(viewModel: EquipmentViewModel) {
    var RequestObject = {
      iDs: viewModel.selectedIds
    };
    return this.http.post<any>(`${environment.masterServerUrl}/EquipmentType/DeleteAll`, RequestObject)
      .pipe(map(result => {
        return result;
      }));
  }
  
  saveEquipmentType(modal: EquipmentTypeSaveModel[]) {    
    return this.http.post<any>(MASTER_URL + '/EquipmentType/SaveAll', modal, this.httpOptions)
      .pipe(map(saveresponse => {
        return saveresponse;
      }));
  }

  totalCount(modal: EquipmentViewModel) {    
    return this.http.post<any>(MASTER_URL + '/EquipmentType/TotalRecordsCount', modal, this.httpOptions)
      .pipe(map(saveresponse => {
        return saveresponse;
      }));
  }

  getFreightsByEquipmentTypeID(modal: EquipmentTypeFreightModeMapModel) {    
    return this.http.post<any>(MASTER_URL + '/EquipmentType/GetFreightsByEquipmentTypeID', modal, this.httpOptions)
      .pipe(map(saveresponse => {
        return saveresponse;
      }));
  }

  updateEquipmentType(modal: EquipmentViewModel) {
    debugger
    return this.http.post<any>(MASTER_URL + '/EquipmentType/Update', modal, this.httpOptions)
      .pipe(map(saveresponse => {
        return saveresponse;
      }));
  }
}
