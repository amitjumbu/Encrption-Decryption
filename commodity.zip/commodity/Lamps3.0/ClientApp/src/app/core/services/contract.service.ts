import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Injectable, ɵCompiler_compileModuleAndAllComponentsAsync__POST_R3__ } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment as env } from '../../../environments/environment';
import { Contract, ContractObjectViewModel, ContractDetails, ContractViewModel, DefineCharacteristics } from '../models/contract.model';
import { Observable, BehaviorSubject } from 'rxjs';


const BASE_URL = env.coreBaseApiUrl;
const Master_URL = env.masterServerUrl;
@Injectable({
  providedIn: 'root'
})

export class ContractService {
  private httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  
  constructor(private http: HttpClient) {
   
  }
  savedData: any;
  
  getContractTypeList(modal:Contract) {
    return this.http.post<any>(`${Master_URL}/contracttype/list`, modal , this.httpOptions)
      .pipe(map(contractTypeList => {
        return contractTypeList.data.map(r => ({ id: r.id, itemName: r.name }));
      }));
  }

  getCustomerShipLocation(model: Contract) {
    model.pageNo = 0;
    model.pageSize = 0;
    return this.http.post<any>(`${BASE_URL}/Location/list`, model, this.httpOptions)
      .pipe(map(customerShipList => {        
        return customerShipList.data.map(r => ({ id: r.id, itemName: r.id +' - '+r.name }));
      }));
  }


  getContractList(modal: Contract) {
    return this.http.post<any>(`${env.coreBaseApiUrl}/Contract/GetAllContract`, modal,this.httpOptions)
      .pipe(map(contractList => {
        return contractList;
      }));
  }
    
  getContractById(modal: ContractViewModel): Observable<any> {
    return this.http.post<any>(`${env.coreBaseApiUrl}/Contract/GetContractById`, { ClientID: modal.ClientID, ID: modal.ID, ContractTypeId:modal.ContractTypeId}, this.httpOptions)
      .pipe(map(contractList => {
        return contractList;
      }));

  }


  getTotalCount(modal: Contract): Observable<any> {
    modal.pageNo = 0;
    modal.pageSize = 0;
    return this.http.post<any>(`${env.coreBaseApiUrl}/Contract/AllContractCount`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  saveContract(modal: ContractObjectViewModel): Observable<any> {
    return this.http.post<any>(`${env.coreBaseApiUrl}/Contract`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getCommentsLocation(id: number) {
    return this.http.get<any>(`${env.coreBaseApiUrl}/Location/id?id=${id}`)
      .pipe(map(res => {
          return res;
      }));
  }
  getContractTypeId(id: number) {
    return this.http.get<any>(`${env.masterServerUrl}/ContractType/${id}`)
      .pipe(map(res => {
        return res;
      }));
  }
  setContractApprove(modal: ContractViewModel): Observable<any> {
    return this.http.post<any>(`${env.coreBaseApiUrl}/Contract/ContractApprove`, {ID:modal.ID,ContractTypeId:modal.ContractTypeId}, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }

  getMaterialDescription(modal: Contract): Observable<any> {
    modal.pageNo = 1;
    modal.pageSize = 500;
    return this.http.post<any>(`${BASE_URL}/Material/List`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
   
  getChargeDescription(modal: Contract): Observable<any> {
    modal.pageNo = 1;
    modal.pageSize = 500;
    return this.http.post<any>(`${BASE_URL}/Charge/GetAll`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getCommodityList(modal: Contract): Observable<any> {
    modal.pageNo = 1;
    modal.pageSize = 500;
    return this.http.post<any>(`${BASE_URL}/Commodity/GetAllCom`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getChargeComputationMethod(): Observable<any> {
    return this.http.get<any>(`${BASE_URL}/ChargeComputationMethod/List`, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }

  getPriceMethodTypeList(modal: Contract): Observable<any> {
     return this.http.post<any>(`${Master_URL}/PriceMethodType/List`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getPriceIncreaseMethodTypeList(modal: Contract): Observable<any> {
    return this.http.post<any>(`${Master_URL}/PriceIncreaseMethodType/List`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getSalesTaxList(modal: Contract): Observable<any> {   
    return this.http.post<any>(`${Master_URL}/SalesTaxClass/List`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getUomList(modal: Contract): Observable<any> {
    return this.http.post<any>(`${Master_URL}/Uom/List`, modal, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  SaveContractDetails(flagViewModel: ContractDetails[]): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/SaveContractDetails`, flagViewModel, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }

  getContractDetails(ClientId, ContractTypeId, ParentId): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/GetContractDetails`, { ClientId, ContractTypeId, ParentId}, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  getContractDetailsByIds(ClientId, ContractTypeId, ParentId): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/GetContractDetailsByIds`, { ClientId, ContractTypeId, ParentId }, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }

  getCharacteristics(): Observable<any> {
    return this.http.get<any>(`${BASE_URL}/Contract/GetCharacteristic`, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  GetDefineCharacteristics(flagViewModel: ContractViewModel): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/GetCharacteristicById`, flagViewModel, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  SaveDefineCharacteristics(flagViewModel: DefineCharacteristics[]): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/SaveDefiningCharacteristics`, flagViewModel, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  DeleteDefiningCharacteristics(flagViewModel: DefineCharacteristics[]): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/DeleteDefiningCharacteristics`, flagViewModel, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  DeleteContract(model: ContractViewModel[]): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/DeleteContracts`, model, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  ActiveContracts(model: ContractViewModel[]): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/ActiveContracts`, model, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
  InactiveContracts(model: ContractViewModel[]): Observable<any> {
    return this.http.post<any>(`${BASE_URL}/Contract/InactiveContracts`, model, this.httpOptions)
      .pipe(map(res => {
        return res;
      }));
  }
}
