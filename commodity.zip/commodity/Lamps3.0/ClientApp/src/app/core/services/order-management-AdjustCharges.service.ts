import { Injectable } from '@angular/core';
import { AdjustChargesModel, RateTypeWithUOM, CalculationAmountVM } from '../../core/models/regularOrder.model';
import { BehaviorSubject, of, observable } from 'rxjs';
import { GlobalConstants } from '@app/core/models/GlobalConstants ';
import { OrderManagementService } from './order-management.service';
import { ToastrService } from 'ngx-toastr';
import { OrdermanagementCommonOperation } from './order-management-common-operations.service'; //, CalculationRateType

@Injectable({
  providedIn: 'root'
})
export class OrderManagementAdjustChargesService {

  /// Define All Variables
  private _allAdjustChargesData: AdjustChargesModel[] = [];

  private _MaterialDetails: any[];
  private _ShippingMaterialDetails: any[];
  private _defaultContractChargesData: AdjustChargesModel[] = [];
  private _allChargesSelectedContract: AdjustChargesModel[] = [];

  private _rateTypeWithUOM: RateTypeWithUOM[] = [];
  private PriceMethodData: any[] = [];
  private CommodityData: any[] = [];
  private ChargesData: any[] = [];
  private RateTypeData: any[] = [];
  private _defaultCommodityID: number;
  private _defaultChargeIDForMaterial: number;
  private _defaultChargeNameForMaterial: string;
  private defaultCommodityName: string;
  editIndex: number = -1;
  private _totalAmount = 0;
  private _ShippingOrdersDetails: any[];
  private contractAdjustmentCharges: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  private addEditAdjustmentCharges: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);

  defaultUpdate = this.contractAdjustmentCharges.asObservable();
  addEditAdjustmentChargesFlag = this.addEditAdjustmentCharges.asObservable();

  private currentOrderID: number = 0;
  private currentOrderTypeID: number = 0;
  private isLocationChangeByUser: boolean = true;
  private isToContractChangeByUser: boolean = true;

  MaxPalletSize: number = 0;
  /// End Here

  constructor(private orderManagementService: OrderManagementService, private toastrService: ToastrService, private orderCommonService: OrdermanagementCommonOperation) {
    
    this.editIndex = -1;
    this.orderManagementService.GetPriceMethods()
      .subscribe(
        result => {

          if (result.message == GlobalConstants.Success || result.Message == GlobalConstants.Success) {
            this.PriceMethodData = result.data == undefined ? result.Data : result.data;
          }
        }
      );

    this.orderManagementService.GetCommodities()
      .subscribe(
        result => {

          if (result.message == GlobalConstants.Success || result.Message == GlobalConstants.Success) {
            this.CommodityData = result.data == undefined ? result.Data : result.data;
          }
        }
      );

    this.orderManagementService.GetCharges()
      .subscribe(
        result => {

          if (result.message == GlobalConstants.Success || result.Message == GlobalConstants.Success) {
            this.ChargesData = result.data == undefined ? result.Data : result.data;

            if (this.ChargesData != undefined && this.ChargesData != null) {

              this.ChargesData.forEach((value, index) => {

                if (value.code == GlobalConstants.DefaultMaterialChargeCode) {
                  this._defaultChargeIDForMaterial = value.id;
                  this._defaultChargeNameForMaterial = value.code;
                }

              });

            }

          }
        }
      );


    this.orderManagementService.GetRateType()
      .subscribe(
        result => {

          if (result.message == GlobalConstants.Success || result.Message == GlobalConstants.Success) {
            this.RateTypeData = result.data == undefined ? result.Data : result.data;
          }
        }
      );

  }


  /// Define All Properties
  get allAdjustChargesData(): AdjustChargesModel[] {
    return this._allAdjustChargesData;
  }
  set allAdjustChargesData(value: AdjustChargesModel[]) {
    this._allAdjustChargesData = value;
  }
  get MaterialDetails(): any[] {
    return this._MaterialDetails;
  }
  set MaterialDetails(value: any[]) {
    this._MaterialDetails = value;
  }
  get ShippingMaterialDetails(): any[] {
    return this._ShippingMaterialDetails;
  }
  set ShippingMaterialDetails(value: any[]) {
    this._ShippingMaterialDetails = value;
  }
  get defaultContractChargesData(): AdjustChargesModel[] {
    return this._defaultContractChargesData;
  }
  set defaultContractChargesData(value: AdjustChargesModel[]) {
    this._defaultContractChargesData = value;
  }

  get SelectedContractCharges(): AdjustChargesModel[] {
    return this._allChargesSelectedContract;
  }
  set SelectedContractCharges(value: AdjustChargesModel[]) {
    this._allChargesSelectedContract = value;
  }
  get rateTypeWithUOM(): RateTypeWithUOM[] {
    return this._rateTypeWithUOM;
  }
  set rateTypeWithUOM(value: RateTypeWithUOM[]) {
    this._rateTypeWithUOM = value;
  }
  get DefaultCommodityID(): number {
    return this._defaultCommodityID;
  }
  set DefaultCommodityID(value: number) {
    this._defaultCommodityID = value;
  }
  get TotalAmount(): number {
    return this._totalAmount;
  }
  set TotalAmount(value: number) {
    this._totalAmount = value;
  }

  get ShippingOrdersDetails(): any[] {
    return this._ShippingOrdersDetails;
  }
  set ShippingOrdersDetails(value: any[]) {
    this._ShippingOrdersDetails = value;
  }

  get IsLocationChangeByUser(): boolean {
    return this.isLocationChangeByUser;
  }
  set IsLocationChangeByUser(value: boolean) {
    this.isLocationChangeByUser = value;
  }

  get IsToContractChangeByUser(): boolean {
    return this.isToContractChangeByUser;
  }
  set IsToContractChangeByUser(value: boolean) {
    this.isToContractChangeByUser = value;
  }

  //ShippingOrdersDetails

  get OrderID(): number {
    return Number(this.currentOrderID  == undefined ? 0 : this.currentOrderID);
  }

  set OrderID(value: number) {
    this.currentOrderID = Number(value);
  }

  get OrderTypeID(): number {
    return Number(this.currentOrderTypeID == undefined ? 0 : this.currentOrderTypeID);
  }

  set OrderTypeID(value: number) {
    this.currentOrderTypeID = Number(value);
  }


  // End here
  shipToLocationID: number;
  contractID: number;

  updateContractDefault() {

    var isMaterialSelected = false;

    var materials = [];

    this.MaterialDetails.forEach((value, index) => {

      var RateTypeData = this.rateTypeWithUOM.find(x => x.uomid == value.uomid);

      materials.push({
        MaterialID: value.materialID,
        MaterialName: value.name,
        RateType: RateTypeData.rateTypeName,
        RateTypeID: RateTypeData.rateTypeID,
        Quantity: value.quantity,
        Type: GlobalConstants.MaterialItem
      });

      isMaterialSelected = true;
    });

    this.ShippingMaterialDetails.forEach((value, index) => {

      //var RateTypeData = this.rateTypeWithUOM.find(x => x.uomid == value.uomid);
      materials.push({
        MaterialID: value.materialID,
        MaterialName: value.name,
        RateType: '',
        RateTypeID: -1,
        Quantity: value.quantity,
        Type: GlobalConstants.PackageItem
      });

    });


    if (!isMaterialSelected && this.contractID == 0 && this.shipToLocationID == 0) return;

    var RequestObject = {
      ContractID: Number(this.contractID),
      ShipTOLocationID: Number(this.shipToLocationID),
      Materials: materials,
      Code: GlobalConstants.PriceMethodCateoryCode,
      OrderID: null,
      OrderTypeID : null
    };

    // !this.IsToContractChangeByUser && need to apply
    if (this.OrderID > 0 && this.OrderTypeID > 0 &&  !this.IsLocationChangeByUser) {
      RequestObject.OrderTypeID = this.OrderTypeID;
      RequestObject.OrderID = this.OrderID;
    }

    this.orderManagementService.GetAdjustChargesDefault(RequestObject)
      .subscribe(result => {

        this.allAdjustChargesData = [];
        this.defaultContractChargesData = [];
        this.SelectedContractCharges = [];
        if (result.message == GlobalConstants.Success || result.Message == GlobalConstants.Success) {
          this.allAdjustChargesData = <AdjustChargesModel[]>result.data.responseAdjustCharges;
          this.defaultContractChargesData = <AdjustChargesModel[]>result.data.responseContractDefaultRateValue;
          this.SelectedContractCharges = <AdjustChargesModel[]>result.data.allContractDetailValue;

          this.calculatetotalAmount();
          this.contractAdjustmentCharges.next(true);

        }
      });

  }



  //this method use to recalculate all the material charges on basis of Material list and pallet list and existing charges list

  reCalculateAllOrder() {

    this.editIndex = -1;

    this.CommodityData.forEach((value, index) => {
      if (value.id == this.DefaultCommodityID) {
        this.defaultCommodityName = value.name;
      }

    });



    if (this.MaterialDetails.length > 0 && this.ShippingMaterialDetails.length > 0) {
      // this section create material if list don't have any charges.
      if (this.allAdjustChargesData.length == 0 && this.defaultContractChargesData.length == 0) {
        // this.CreateAdjustChargesData();
      }
      else {
        this.AdjustmnetChargesRecalcuation();
      }
     

    }

    this.calculatetotalAmount();
  }

  


  private AdjustmnetChargesRecalcuation() {
    var tempModifiedAdjustCharges: AdjustChargesModel[] = [];
    var materialQuantity = 0;

    // this section check material one by one it is into grid or not
    this.MaterialDetails.forEach((value, index) => {

      materialQuantity = materialQuantity + parseInt(value.quantity);

      //check selected material is autoadded or not.
      var recordIntoDefault = this.defaultContractChargesData.filter(x => x.materialID == value.materialID);

      if (recordIntoDefault != undefined && recordIntoDefault.length > 0) {
        // if the material is auto added then we will seach all chagres auto added or not
        recordIntoDefault.forEach((defaultValue, defaultIndex) => {
          //search material with specific charge is into grid or not
          var recordsintoGrid = this.allAdjustChargesData.find(x => x.materialID == defaultValue.materialID && x.chargeID == defaultValue.chargeID);
          if (recordsintoGrid == undefined) {
            //if the material with specific chagre not into grid then add into grid as well
            var selectedElementNotExistsIntoGrid: AdjustChargesModel = JSON.parse(JSON.stringify(defaultValue));
            //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

            //CalculateData.Quantity = Number(value.quantity);
            //CalculateData.RateTypeName = selectedElementNotExistsIntoGrid.rateTypeName;
            //CalculateData.RateValue = Number(selectedElementNotExistsIntoGrid.overrideRateValue != 0 ? selectedElementNotExistsIntoGrid.overrideRateValue : selectedElementNotExistsIntoGrid.rateValue);
            //CalculateData.ChargeUnit = Number(selectedElementNotExistsIntoGrid.chargeUnit);

            //selectedElementNotExistsIntoGrid.amount = this.orderCommonService.calculateAmount(CalculateData);
            selectedElementNotExistsIntoGrid.amount = this.CalculatePerRowCharges(selectedElementNotExistsIntoGrid, Number(value.quantity))
            selectedElementNotExistsIntoGrid.fullAmount = selectedElementNotExistsIntoGrid.amount + selectedElementNotExistsIntoGrid.overrideAmount;
            selectedElementNotExistsIntoGrid.overrideShowOnBOL = selectedElementNotExistsIntoGrid.showOnBOL;
            tempModifiedAdjustCharges.push(selectedElementNotExistsIntoGrid);
          }
          else {
            // the material with specific chagre already into grid then recalculate the amount again
            var selectedElementExistsIntoGrid: AdjustChargesModel = JSON.parse(JSON.stringify(recordsintoGrid));

            if (!selectedElementExistsIntoGrid.isAutoAddedExclude) {
              //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

              //CalculateData.Quantity = Number(value.quantity);
              //CalculateData.RateTypeName = selectedElementExistsIntoGrid.rateTypeName;
              //CalculateData.RateValue = Number(selectedElementExistsIntoGrid.overrideRateValue != 0 ? selectedElementExistsIntoGrid.overrideRateValue : selectedElementExistsIntoGrid.rateValue);
              //CalculateData.ChargeUnit = Number(selectedElementExistsIntoGrid.chargeUnit);

              //selectedElementExistsIntoGrid.amount = this.orderCommonService.calculateAmount(CalculateData);
              selectedElementExistsIntoGrid.amount = this.CalculatePerRowCharges(selectedElementExistsIntoGrid, Number(value.quantity));
              selectedElementExistsIntoGrid.fullAmount = selectedElementExistsIntoGrid.amount + selectedElementExistsIntoGrid.overrideAmount;
            }
            selectedElementExistsIntoGrid.overrideShowOnBOL = selectedElementExistsIntoGrid.showOnBOL;
            //temprary hold element for refershing the grid
            tempModifiedAdjustCharges.push(selectedElementExistsIntoGrid);

          }
        });

      }
      else
      {
        // this section only modify the dropdown and grid will be updated by user.
      }

    });

    /// material calculation end here


    /// shiping material calculation start here
    this.ShippingMaterialDetails.forEach((value, index) => {

      //materialQuantity = materialQuantity + parseInt(value.quantity);

      //check selected material is autoadded or not.
      var recordIntoDefault = this.defaultContractChargesData.filter(x => x.materialID == value.materialID);

      if (recordIntoDefault != undefined && recordIntoDefault.length > 0) {
        // if the material is auto added then we will seach all chagres auto added or not
        recordIntoDefault.forEach((defaultValue, defaultIndex) => {
          //search material with specific charge is into grid or not
          var recordsintoGrid = this.allAdjustChargesData.find(x => x.materialID == defaultValue.materialID && x.chargeID == defaultValue.chargeID);
          if (recordsintoGrid == undefined) {
            //if the material with specific chagre not into grid then add into grid as well
            var selectedElementNotExistsIntoGrid: AdjustChargesModel = JSON.parse(JSON.stringify(defaultValue));
            //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

            //CalculateData.Quantity = Number(value.quantity);
            //CalculateData.RateTypeName = selectedElementNotExistsIntoGrid.rateTypeName;
            //CalculateData.RateValue = Number(selectedElementNotExistsIntoGrid.overrideRateValue != 0 ? selectedElementNotExistsIntoGrid.overrideRateValue : selectedElementNotExistsIntoGrid.rateValue);
            //CalculateData.ChargeUnit = Number(selectedElementNotExistsIntoGrid.chargeUnit);

            //selectedElementNotExistsIntoGrid.amount = this.orderCommonService.calculateAmount(CalculateData);

            selectedElementNotExistsIntoGrid.amount = this.CalculatePerRowCharges(selectedElementNotExistsIntoGrid, Number(value.quantity));
            selectedElementNotExistsIntoGrid.fullAmount = selectedElementNotExistsIntoGrid.amount + selectedElementNotExistsIntoGrid.overrideAmount;
            selectedElementNotExistsIntoGrid.overrideShowOnBOL = selectedElementNotExistsIntoGrid.showOnBOL;
            tempModifiedAdjustCharges.push(selectedElementNotExistsIntoGrid);
          }
          else {
            // the material with specific chagre already into grid then recalculate the amount again
            var selectedElementNotExistsIntoGrid: AdjustChargesModel = JSON.parse(JSON.stringify(recordsintoGrid));
            if (!selectedElementNotExistsIntoGrid.isAutoAddedExclude) {
              //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

              //CalculateData.Quantity = Number(value.quantity);
              //CalculateData.RateTypeName = selectedElementNotExistsIntoGrid.rateTypeName;
              //CalculateData.RateValue = Number(selectedElementNotExistsIntoGrid.overrideRateValue != 0 ? selectedElementNotExistsIntoGrid.overrideRateValue : selectedElementNotExistsIntoGrid.rateValue);
              //CalculateData.ChargeUnit = Number(selectedElementNotExistsIntoGrid.chargeUnit);

              //selectedElementNotExistsIntoGrid.amount = this.orderCommonService.calculateAmount(CalculateData);
              selectedElementNotExistsIntoGrid.amount = this.CalculatePerRowCharges(selectedElementNotExistsIntoGrid, Number(value.quantity));
              selectedElementNotExistsIntoGrid.fullAmount = selectedElementNotExistsIntoGrid.amount + selectedElementNotExistsIntoGrid.overrideAmount;
              
            }
            selectedElementNotExistsIntoGrid.overrideShowOnBOL = selectedElementNotExistsIntoGrid.showOnBOL;
            //temprary hold element for refershing the grid

            

            tempModifiedAdjustCharges.push(selectedElementNotExistsIntoGrid);


           

          }
        });

      }

    });



    // Auto Added Charges which are not exists into gird add them
    var allAutoAddedCharges = this.defaultContractChargesData.filter(x => x.materialID <= 0 && x.chargeID > 0);

    if (allAutoAddedCharges != null && allAutoAddedCharges.length > 0) {
      //Now Check existing Charge into grid or not
      allAutoAddedCharges.forEach((value, index) => {
        var alreadyApplied = this.allAdjustChargesData.find(x => x.materialID == value.materialID && x.chargeID == value.chargeID);
        if (alreadyApplied != null && alreadyApplied != undefined) {
          //Charges already into grid then recalculate amount 
          var exsitingCharge: AdjustChargesModel = JSON.parse(JSON.stringify(alreadyApplied));
          if (!exsitingCharge.isAutoAddedExclude) {
            //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

            //CalculateData.Quantity = Number(materialQuantity);
            //CalculateData.RateTypeName = exsitingCharge.rateTypeName;
            //CalculateData.RateValue = Number(exsitingCharge.overrideRateValue != 0 ? exsitingCharge.overrideRateValue : exsitingCharge.rateValue);
            //CalculateData.ChargeUnit = Number(exsitingCharge.chargeUnit);

            //exsitingCharge.amount = this.orderCommonService.calculateAmount(CalculateData);

            exsitingCharge.amount = this.CalculatePerRowCharges(exsitingCharge, Number(materialQuantity));

            exsitingCharge.fullAmount = exsitingCharge.amount + exsitingCharge.overrideAmount;
          }
          exsitingCharge.overrideShowOnBOL = exsitingCharge.showOnBOL;
          tempModifiedAdjustCharges.push(exsitingCharge);
        }
        else {

          // this section find chagres not added into grid then add this chagres into grid as well
          var nonExisting: AdjustChargesModel = JSON.parse(JSON.stringify(value));

          //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

          //CalculateData.Quantity = Number(materialQuantity);
          //CalculateData.RateTypeName = nonExisting.rateTypeName;
          //CalculateData.RateValue = Number(nonExisting.overrideRateValue != 0 ? nonExisting.overrideRateValue : nonExisting.rateValue);
          //CalculateData.ChargeUnit = Number(nonExisting.chargeUnit);

          //nonExisting.amount = this.orderCommonService.calculateAmount(CalculateData);

          nonExisting.amount = this.CalculatePerRowCharges(nonExisting, Number(materialQuantity));
          nonExisting.fullAmount = nonExisting.amount + nonExisting.overrideAmount;
          nonExisting.showOnBOL = nonExisting.overrideShowOnBOL;
          tempModifiedAdjustCharges.push(nonExisting);
        }

      });

    }

    // end of chagre calculation

    this.allAdjustChargesData.splice(0, this.allAdjustChargesData.length);

    // Recalculate the Percentage Charges

    tempModifiedAdjustCharges.forEach((value, index) => {
      if (value.rateTypeName == GlobalConstants.PercentageAmount) {
        this.CalculatePerRowCharges(value, 1);
      }

    });

    this.allAdjustChargesData = JSON.parse(JSON.stringify(tempModifiedAdjustCharges));



  }


  removeAdjustChargesValue(element: AdjustChargesModel[], isForciable = false) {
    this.editIndex = -1;
    element.forEach((elementvalue, index) => {
      if (element != undefined) {
        if (isForciable) {
          elementvalue.isManual = true;
        }
        var index = this.allAdjustChargesData.indexOf(elementvalue);
        if (elementvalue.isManual) {
          if (index > -1) {
            this.allAdjustChargesData.splice(index, 1);     
          }
        }
        else {
         
          var isAutoAdded = this.defaultContractChargesData.find(x => x.materialID == elementvalue.materialID && x.chargeID == elementvalue.chargeID);

          if (isAutoAdded != undefined && !isForciable) {

            if (confirm("You can't remove this element, we can only this chagres as blank.")) {
              this.allAdjustChargesData[index].isEdited = true;
              this.allAdjustChargesData[index].isAutoAddedExclude = true;
              this.allAdjustChargesData[index].amount = 0;
              this.allAdjustChargesData[index].overrideAmount = 0;
              this.allAdjustChargesData[index].fullAmount = 0;
            }
          }
          else {
            this.toastrService.warning(GlobalConstants.NotRemoved);
            
          }

        }


        var totalMaterialQuanity: number = 0;

        this.MaterialDetails.forEach((value, index) => {
          totalMaterialQuanity = totalMaterialQuanity + Number(value.quantity);
        });

        this.allAdjustChargesData.forEach((value, index) => {

          if ((value.materialID <= 0 || value.materialID == null) && value.chargeID > 0) {
            //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

            //CalculateData.Quantity = Number(totalMaterialQuanity);
            //CalculateData.RateTypeName = value.rateTypeName;
            //CalculateData.RateValue = Number(value.rateValue);
            //CalculateData.ChargeUnit = Number(value.chargeUnit);

            if (!value.isAutoAddedExclude) {
              //value.amount = this.orderCommonService.calculateAmount(CalculateData);
              value.amount  = this.CalculatePerRowCharges(value, Number(totalMaterialQuanity));
              value.fullAmount = value.amount + value.overrideAmount;
            }
            else {
              value.amount = value.amount;
              value.overrideAmount = value.amount;
              value.fullAmount = value.fullAmount;
            }
          }
        });

      }
    });

    this.calculatetotalAmount();

    //this.reCalculateAllOrder();

  }

  //this method add material manually into grid source.so we don't need to check default values which is set by contract.
  AddEditMaterialInAdjustCharges(materialId: number, materialName: string, quantity: number, ChargeID: number, ChargeName: string,
    RateTypeID: number, RateTypeName: string, RateValue: any, PriceMethodID: number, PriceMethodName: string,
    CommodityID: number, CommodityName: string, ShowOnBOL: boolean, AdjustmentAmount: number, isMaterial: boolean, isChargeOnly: boolean, EquipmentID: number, ChargeUnit: number
  ) {


    var materialList: any = [];

    this.allAdjustChargesData.forEach((value, index) => {


      if (value.type == GlobalConstants.MaterialItem) {
        materialList.push({
          MaterialID: Number(value.materialID),
          Quantity: Number(value.orderQuantity),
          ChargeID: Number(value.chargeID)
        });
      }
    });

    if (materialId > 0 && isMaterial == true) {
      var materialIndex: number = -1;
      materialList.forEach((value, index) => {
        if (value.MaterialID == Number(materialId) && materialIndex == -1) {
          materialIndex = index;
        }
      });


      if (materialIndex > -1) {
        materialList[materialIndex].quantity = Number(quantity);
      }
      else {

        materialList.push({
          MaterialID: Number(materialId),
          Quantity: Number(quantity),
          ChargeID: Number(ChargeID)
        });
      }
    }

   
    this.AddEditMaterialInAdjustChargesUpdater(materialId, materialName, quantity, ChargeID, ChargeName,
      RateTypeID, RateTypeName, RateValue, PriceMethodID, PriceMethodName,
      CommodityID, CommodityName, ShowOnBOL, AdjustmentAmount, isMaterial, isChargeOnly, EquipmentID, ChargeUnit);
    this.calculatetotalAmount();
    
  }


 
  clearPreviousValues() {

    if (this.allAdjustChargesData != undefined && this.allAdjustChargesData.length > 0) { this.allAdjustChargesData.splice(0, this.allAdjustChargesData.length); }
    if (this.defaultContractChargesData != undefined && this.defaultContractChargesData.length > 0) { this.defaultContractChargesData.splice(0, this.defaultContractChargesData.length); }

  }


  private AddEditMaterialInAdjustChargesUpdater(materialId: number, materialName: string, quantity: number, ChargeID: number, ChargeName: string,
    RateTypeID: number, RateTypeName: string, RateValue: any, PriceMethodID: number, PriceMethodName: string,
    CommodityID: number, CommodityName: string, ShowOnBOL: boolean, AdjustmentAmount: number, isMaterial: boolean, isChargeOnly: boolean, EquipmentID: number, ChargeUnit: number
  ) {
    
    quantity = 0;
    if (materialId != undefined && materialId > 0) {
      this.MaterialDetails.forEach((value, index) => {
        if (value.materialID == materialId) {
          quantity = Number(value.quantity);
        }
      });
    }
    else {
      quantity = 0;
      this.MaterialDetails.forEach((value, index) => {
        quantity = quantity + Number(value.quantity);
      });
    }


    var materialExisting = this.editIndex > -1 ? this.allAdjustChargesData[this.editIndex] : this.allAdjustChargesData.find(x => x.materialID == materialId  && x.chargeID == ChargeID);

    if (materialExisting != undefined && materialExisting != null) {
      materialExisting.chargeID = Number(ChargeID);
      materialExisting.chargeName = ChargeName;
      if (Number(materialId) > 0) {
        materialExisting.materialName = materialExisting.materialID != materialId ? materialName : materialExisting.materialName;
      }
      else {
        materialExisting.materialName = "";
      }

      materialExisting.materialID = Number(materialId);
      materialExisting.orderQuantity = Number(quantity);
      materialExisting.overrideRateValue = Number(RateValue);
      materialExisting.overrideShowOnBOL = ShowOnBOL;
      materialExisting.type = isMaterial ? GlobalConstants.MaterialItem : (isChargeOnly ? '' : GlobalConstants.PackageItem);
      materialExisting.chargeUnit = Number(ChargeUnit);

      
      if (Number(materialExisting.commodityID) != Number(CommodityID)) {
        materialExisting.overrideCommodityID = Number(CommodityID);
        materialExisting.overrideCommodityName = CommodityName;

      }

      if (Number(materialExisting.priceMethodID) != Number(PriceMethodID)) {
        materialExisting.overridePriceMethodID = Number(PriceMethodID);
        materialExisting.overridePriceMethodName = PriceMethodName;

      }

      if (materialExisting.rateTypeID != RateTypeID) {
        materialExisting.overrideRateTypeID = Number(RateTypeID);
        materialExisting.overrideRateTypeName = RateTypeName;

      }

      
      ////var CalculateData: CalculationAmountVM = new CalculationAmountVM();

      ////CalculateData.Quantity = Number(materialExisting.orderQuantity);
      ////CalculateData.RateTypeName = materialExisting.overrideRateTypeID > 0 ? materialExisting.overrideRateTypeName : materialExisting.rateTypeName;
      ////CalculateData.RateValue = Number(materialExisting.isEdited ? materialExisting.overrideRateValue : materialExisting.rateValue);
      ////CalculateData.ChargeUnit = Number(materialExisting.chargeUnit);

      ////materialExisting.amount = this.orderCommonService.calculateAmount(CalculateData);

      materialExisting.amount = this.CalculatePerRowCharges(materialExisting, Number(materialExisting.orderQuantity));

      materialExisting.overrideAmount = Number(AdjustmentAmount);

      materialExisting.fullAmount = Number(materialExisting.amount) + Number(materialExisting.overrideAmount);

      materialExisting.isAutoAddedExclude = false;
    }
    else {

      var newChargesAdd = new AdjustChargesModel();
      newChargesAdd.type = isMaterial ? GlobalConstants.MaterialItem : (isChargeOnly ? '' : GlobalConstants.PackageItem);
      newChargesAdd.materialID = Number(materialId);

      if (Number(materialId) > 0) {
        newChargesAdd.materialName = materialName;
      }

      newChargesAdd.chargeID = Number(ChargeID);
      newChargesAdd.chargeName = ChargeName;
      newChargesAdd.isManual = true;
      newChargesAdd.commodityID = Number(CommodityID);
      newChargesAdd.commodityName = CommodityName;
      newChargesAdd.orderQuantity = Number(quantity);
      newChargesAdd.rateTypeID = Number(RateTypeID);
      newChargesAdd.rateTypeName = RateTypeName;
      newChargesAdd.priceMethod = PriceMethodName;
      newChargesAdd.priceMethodID = Number(PriceMethodID);
      newChargesAdd.rateValue = Number(RateValue);
      newChargesAdd.isEdited = true; // for skipping the update value from latest contract.
      newChargesAdd.showOnBOL = ShowOnBOL;
      newChargesAdd.overrideShowOnBOL = ShowOnBOL;
      newChargesAdd.shippedQuantity = 0;
      newChargesAdd.chargeUnit = ChargeUnit;
      if (AdjustmentAmount > 0) {
        newChargesAdd.amount = AdjustmentAmount;
      }
      else {
        //newChargesAdd.amount = RateValue * quantity;

        //var CalculateData: CalculationAmountVM = new CalculationAmountVM();

        //CalculateData.Quantity = newChargesAdd.orderQuantity;
        //CalculateData.RateTypeName = newChargesAdd.rateTypeName;
        //CalculateData.RateValue = newChargesAdd.rateValue;
        //CalculateData.ChargeUnit = ChargeUnit;
        //newChargesAdd.amount = this.orderCommonService.calculateAmount(CalculateData);
        newChargesAdd.amount = this.CalculatePerRowCharges(newChargesAdd, Number(newChargesAdd.orderQuantity));

      }

      newChargesAdd.fullAmount = newChargesAdd.amount + newChargesAdd.overrideAmount;
      newChargesAdd.isAutoAddedExclude = false;
      this.allAdjustChargesData.push(newChargesAdd);
    }

    this.toastrService.success(GlobalConstants.AdjustmentChargesUpdate);
  }

  AddEditMaterialUnSubscribe() {
    this.addEditAdjustmentCharges.unsubscribe();
  }

  public calculatetotalAmount() {

    this.TotalAmount = 0;
    if (this.allAdjustChargesData != undefined && this.allAdjustChargesData != null && this.allAdjustChargesData.length > 0) {
      this.allAdjustChargesData.forEach((value, index) => {

        if (value.type != GlobalConstants.PackageItem && value.priceMethod == GlobalConstants.Billable) {

          this.TotalAmount = this.TotalAmount + Number(value.fullAmount);
        }
      });
    }
  }

  CalculatePerRowCharges(data: AdjustChargesModel,quantity = 0):number {

    var CalculateData: CalculationAmountVM = new CalculationAmountVM();

    CalculateData.Quantity = Number(quantity);
    CalculateData.RateTypeName = data.rateTypeName;
    CalculateData.RateValue = Number(data.overrideRateValue != 0 ? data.overrideRateValue : data.rateValue);
    CalculateData.ChargeUnit = Number(data.chargeUnit);
    var totalPallets = 0;
    var totalQuantity = 0;
    this.MaterialDetails.forEach((value, index) => {
      totalPallets = totalPallets + Number(value.pallets == undefined ? value.Pallets : value.pallets);
      totalQuantity = totalQuantity + Number(value.quantity);
    });
    CalculateData.TotalPallets = totalPallets;
    CalculateData.TotalQuantity = totalQuantity;
    CalculateData.MaxPallets = this.MaxPalletSize;
    CalculateData.TotalAmount = 0;
    this.allAdjustChargesData.forEach((value, index) => {
      if (value.rateTypeName != GlobalConstants.PercentageAmount) {
        CalculateData.TotalAmount = CalculateData.TotalAmount + value.fullAmount;
      }
    });



    return this.orderCommonService.calculateAmount(CalculateData);
  }

}
