import { INavData } from '@coreui/angular';
// TFSID 16469 Dynamic menu set text according to language selection
export const navItemsTosca: INavData[] = [
  // Developer : Rajesh , TFSID 17127 Dynamic menu set text and create a new component according to approval navigation.
  // date 18-8-2020
  {
    key: 'key_managePartograph ',
    name: 'Manage Partograph',
    url: '/pagenotfound',
    icon: '',
    children: [
      {

        key: 'key_workbench',
        name: 'Partograph workbench ',
        url: '/manage-partograph',
        icon: ''
      },
    ]

  },
  {
    key: 'key_datamanagement',
    name: 'Data Management',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_PatientSetup  ',
        name: 'Patient Setup',
        url: '/manage-partograph/patientsetup',
        icon: ''
      },
      {

        key: 'key_HospitalSetup  ',
        name: 'Hospital Setup',
        url: '/manage-partograph/hospitalsetup',
        icon: ''
      },
      {

        key: 'key_StaffSetup  ',
        name: 'Staff Setup',
        url: '/manage-partograph/hospitalstaff',
        icon: ''
      },

      {
        key: 'key_facilityOrganizationSetup',
        name: 'Facility Organization Setup',
        url: '/pagenotfound',
        icon: '',
        children: [
          {
            key: 'key_Organization',
            name: 'Organization',
            url: '/data-management/organization',
            icon: ''
          },

        ]
      },
    ]

  },

  {
    key: 'key_AlertManagement',
    name: 'User Alert Management ',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_AlertHistory',
        name: 'Alert History',
        url: '/alert-management/alert-history',
        icon: ''
      }
    ]
  },

  {
    key: 'key_user_managements',
    name: 'User Management',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_user_setup',
        name: 'User Setup',
        url: '/user-management/user-list',
        icon: ''
      },

    ]
  },


  {
    key: 'key_Subscription_and_Billing_Management ',
    name: 'Subscription and Billing Management ',
    url: '/plan/plan',
    icon: '',
    children: [
      {
        key: 'key_Subscription ',
        name: 'Subscription ',
        url: '/plan/plan',
      },
      {
        key: 'key_BillingPayment ',
        name: 'Billing and Payment',
        url: '/plan/billing-payment',
      }
    ]
  },

  // Developer : Rajesh , TFSID 17127
  // Detail: Create sidebar menu as same toscatransplace.corp.osoftec.com menu
  // date 19-8-2020


  {
    key: 'key_title',
    name: 'Create Toscatransplace menu',
    url: '/dashboard/home',
    icon: '',
  },

  {
    key: 'key_Data_management',
    name: 'Data Management',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_om',
        name: 'Organization Management',
        url: '/pagenotfound',
        icon: '',
        children: [
          //{
          //  key: 'key_OrganizationType',
          //  name: 'Organization Type Group ',
          //  url: '/data-management/organization-type-group',
          //  icon: ''
          //},
          {
            key: 'key_OrganizationLevel',
            name: 'Organization Level',
            url: '/data-management/organization-level',
            icon: ''
          },
          {
            key: 'key_Organization',
            name: 'Organization',
            url: '/data-management/manage-organization',
            icon: ''
          },

        ]
      },


      {
        key: 'key_business_partner',
        name: 'Business Partner By location',
        url: '/data-management/business-partner-by-location',
      },
      {
        key: 'key_customer_partner',
        name: 'Customer By location',
        url: '/data-management/customer-partner-by-location',
      },
      {
        key: 'key_operating_location',
        name: 'Operating Locations',
        url: '/data-management/operating-location',
      },
      {
        key: 'key_contract',
        name: 'Contract',
        url: '/data-management/contract-list',
      },


      {
        key: 'key_material_management',
        name: 'Material Management',
        url: '/data-management/material-management',
        icon: '',
        children: [
          {
            key: 'key_material',
            name: 'Material',
            url: '/data-management/material',
            icon: '',
          },
          {
            key: 'key_materialGroup',
            name: 'Material Group',
            url: '/data-management/material-group',
            icon: '',
          },
          {
            key: 'key_materialHistory',
            name: 'Material Hierarchy',
            url: '/data-management/material-hierarchy',
            icon: '',
          }
        ]
      },


      {
        key: 'key_freight_management',
        name: 'Freight Management',
        url: '/pagenotfound',
        icon: '',
        children: [
          {
            key: 'key_Freight_lanes',
            name: 'Freight Lanes City, State',
            url: '/data-management/freight-lanes',
            icon: '',
          },
          {
            key: 'key_Fuel',
            name: 'Fuel Price',
            url: '/data-management/fuel-price',
            icon: '',
          },
        ]
      },

      {
        key: 'key_Appointment',
        name: 'Appointment',
        url: '/data-management/appointment',
        icon: 'beta',
      },

      {
        key: 'key_TeamCalendar',
        name: 'Team Calendar',
        url: '/data-management/team-calendar',
        icon: 'beta',
      },

      {
        key: 'key_Credit_management',
        name: 'Credit Management',
        url: '/credit-management',
        icon: '',
      },

      {
        key: 'key_Clame',
        name: 'Claim',
        url: '/data-management/claim',
        icon: '',
      },

      {
        key: 'key_Commodity',
        name: 'Commodity',
        url: '/data-management/commodity',
        icon: '',
      },

      //{
      //  key: 'key_Contact',
      //  name: 'Contact',
      //  url: '/pagenotfound',
      //  icon: '',
      //},


      {
        key: 'key_Alert_management',
        name: 'Alert Management',
        url: '/alert-management/alert-list',
        icon: '',
        children: [
          {
            key: 'key_Alert-histpry',
            name: 'Alert History',
            url: '/alert-management/alert-history',
            icon: '',
          },
        ]
      },
      {
        key: 'key_Infrastucture',
        name: 'Infrastructure',
        url: '/data-management/Infrastructure',
        icon: 'beta',
        children: [
          {
            key: 'key_Properties',
            name: 'Properties',
            url: '/data-management/properties',
            icon: 'beta',
          },
          {
            key: 'key_Relation',
            name: 'Relation (s)',
            url: '/data-management/relations',
            icon: 'beta',
          },
          {
            key: 'key_Capabilities',
            name: 'Capabilities',
            url: '/data-management/capabilities',
            icon: 'beta',
          },
          {
            key: 'key_Infraplantflow',
            name: 'Infra Plant Flow',
            url: '/data-management/infra-plant-flow',
            icon: 'beta',
          },
        ]
      },
      {
        key: 'key_billofmaterial',
        name: 'Bill Of Material',
        url: '/data-management/billofmaterial',
        icon:'beta',
      },
      {
        key: 'key_Equipmentmanagement',
        name: 'Equipment Management',
        url: '/data-management/equipment-management',
        icon: 'beta',
        children: [
          {
            key: 'key_Equipmentclass',
            name: 'Equipment Class',
            url: '/data-management/equipment-class',
            icon: 'beta',
          },
          {
            key: 'key_EquipmentType',
            name: 'Equipment Type',
            url: '/system-settings/equipment-type',
            icon: 'beta',
          },
          {
            key: 'key_Equipment',
            name: 'Equipment',
            url: '/data-management/equipment',
            icon: 'beta',
          },
        ]
      },
    ]
  },


  {
    key: 'key_Forecasting',
    name: 'Forecasting',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_sales_forecasting',
        name: 'Create & Compute Sales Forecast',
        url: '/forecasting/forecasting',
        icon: '',
      },
      {
        key: 'key_sales_forecasting',
        name: 'Define Macro indicator',
        url: '/forecasting/macro-indicator',
        icon: 'beta',
      },
      {
        key: 'key_sales_forecasting',
        name: 'Define Micro indicator',
        url: '/forecasting/micro-indicator',
        icon: 'beta',
      },
    ]
  },

  {
    key: 'key_Inventory',
    name: 'Inventory',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_correntOnHandInventory',
        name: 'Current On Hand Inventory',
        url: '/inventory/current-on-hand-inventory',
        icon: 'Beta',
      },
      {
        key: 'key_Inventoryreservation',
        name: 'Inventory Reservation',
        url: '/inventory/inventory-reservation',
        icon: 'beta',
      },
      {
        key: 'key_Bucket',
        name: 'Bucket',
        url: '/inventory/bucket',
        icon: 'beta',
      },
      {
        key: 'key_Inventoryavailabilityforecast',
        name: 'Inventory Availability Forecast',
        url: '/inventory/inventory-availability-forecast',
        icon: 'beta',
      },
    ]
  },
  {
    key: 'key_Inventorytraget',
    name: 'Inventory Target',
    url: '/pagenotfound',
    icon: 'beta',
    children: [
      {
        key: 'key_dcinventorylevels',
        name: 'DCInventoryLevels',
        url: '/inventory-target/dcinventory-levels',
        icon: 'beta',
      },
      {
        key: 'key_plantinventorylevels',
        name: 'Plant Inventory Levels',
        url: '/inventory-target/plant-inventory-levels',
        icon: 'beta',
      },
     
     
    ]
  },

  {
    key: 'key_OrderManagement',
    name: 'Order Management',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_order_workBench',
        name: 'Order Workbench',
        url: '/order-management/order-workbench',
        icon: '',
      },
      {
        key: 'key_order_History',
        name: 'Order Workbench',
        url: '/order-management/order-history',
        icon: '',
      },
      {
        key: 'key_OrderReports',
        name: 'Order Reports',
        url: '/pagenotfound',
        icon: '',
        children: [
          {
            key: 'key_PlannedOrder',
            name: 'Planned Order Report',
            url: '/order-management/planned-report',
            icon: '',
          },
        ]
      },
//satyen singh TFS ID 18330
      {
        key: 'key_Atporderprocessing',
        name: 'ATP Order Processing',
        url: '/pagenotfound',
        icon: '',
        children: [
          {
            key: 'key_Ordersummary',
            name: 'Order Summary',
            url: '/order-management/order-summary',
            icon: '',
          },
          {
            key: 'key_Atpprocessing',
            name: 'ATP Processing',
            url: '/order-management/atpprocessing',
            icon: '',
          },
          {
            key: 'key_Materialdailyview',
            name: 'Material Daily View',
            url: '/order-management/material-daily-view',
            icon: '',
          },
          {
            key: 'key_Shipfromrouting',
            name: 'Ship From Routing',
            url: '/order-management/ship-from-routing',
            icon: '',
          },
        ]
      },
      {
        key: 'key_Atpreport',
        name: 'ATP Reports',
        url: '/pagenotfound',
        icon: '',
        children: [
          {
            key: 'key_Reservationactivity',
            name: 'Reservation Activity Report',
            url: '/order-management/reservation-activity-report',
            icon: '',
          },
        ]
      },
  //end here
    ]
  },


  {
    key: 'key_ShipmentManagement',
    name: 'Shipment Management',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_ShipmentWorkbench',
        name: 'Shipment Workbench',
        url: '/shipment-management/shipment-workbench',
        icon: '',
      },
      {
        key: 'key_CustomerReport',
        name: 'Customs Report Data',
        url: '/pagenotfound',
        icon: '',
        children: [
          {
            key: 'key_originOfGoods',
            name: 'Origin Of Goods',
            url: '/shipment-management/origin-of-goods',
            icon: '',
          },
          {
            key: 'key_NAFTA',
            name: 'NAFTA Report Setting',
            url: '/shipment-management/shipment-nafta-report',
            icon: '',
          },
        ]
      },
      {
        key: 'key_ShipmentHistory',
        name: 'Shipment History',
        url: '/shipment-management/shipment-history',
        icon: '',
      },

    ]
  },

  
  {
    key: 'key_FPSManagement',
    name: 'FPS Management',
    url: '/fps-management/fps-summary',
    icon: 'beta',
    children: [
      {
        key: 'key_fpsSummary',
        name: 'FPS Summary',
        url: '/fps-management/fps-summary',
        icon: 'beta',
      },
      {
        key: 'key_production_tracking',
        name: 'Production Tracking',
        url: '/fps-management/production-tracking',
        icon: 'beta',
      },
      {
        key: 'key_fpsInitialWorkbench',
        name: 'fps workbench initial',
        url: '/fps-management/fps-workbench-initial',
        icon: 'beta',
      },
      {
        key: 'key_schedule_timeline',
        name: 'Schedule Timeline',
        url: '/fps-management/schedule-timeline',
        icon: 'beta',
      },
    ]
  },

  {
    key: 'key_Reports',
    name: 'Reports',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_chargesDetails',
        name: 'Charges Detail',
        url: '/pagenotfound',
        icon: '',
      },
      {
        key: 'key_forcastCom',
        name: 'Forecast Compare',
        url: '/reports/forecast-compare',
        icon: '',
      },
      {
        key: 'key_forcastrevie',
        name: 'Forecast Review',
        url: '/reports/forecast-review',
        icon: '',
      },
      {
        key: 'key_Freight',
        name: 'Freight Cost',
        url: '/pagenotfound',
        icon: '',
      },
      {
        key: 'key_OrderPlan',
        name: 'Order Plan',
        url: '/pagenotfound',
        icon: '',
      },
      {
        key: 'key_DownloadReports',
        name: 'Download Reports',
        url: '/reports/download-reports',
        icon: '',
      },
    ]
  },

  {
    key: 'key_SystemSettings',
    name: 'System Settings',
    url: '/pagenotfound',
    icon: '',
    children: [
      {
        key: 'key_Application',
        name: 'Application Settings',
        url: '/system-settings/application-settings',
        icon: '',
      },
      {
        key: 'key_manageUser',
        name: 'Manage User Alert',
        url: '/alert-management/alert-list',
        icon: '',
      },
      {
        key: 'key_Charge',
        name: 'Charge',
        url: '/system-settings/charge',
        icon: '',
      },
      {
        key: 'key_AppCharge',
        name: 'Application Charges',
        url: '/system-settings/application-chagers',
        icon: '',
      },
      {
        key: 'key_FuelCharge',
        name: 'Fuel Surcharge Index',
        url: '/system-settings/fuel-surcharge',
        icon: '',
      },
      {
        key: 'key_FreightMode',
        name: 'Freight Mode',
        url: '/system-settings/freight-mode',
        icon: '',
      },
      {
        key: 'key_EquipmentType',
        name: 'Equipment Type',
        url: '/system-settings/equipment-type',
        icon: '',
      },
      {
        key: 'key_ModelRollPermission',
        name: 'Module Role Permission',
        url: '/manage-partograph/modulerolepermissions',
        icon: '',
      },
      {
        key: 'key_preferance',
        name: 'Special Preference',
        url: '/system-settings/special-preference',
        icon: '',
      },
      {
        key: 'key_UserM',
        name: 'User Management',
        url: '/user-management/user-list',
        icon: '',
      },
      {
        key: 'key_geolocation',
        name: 'Geo Location Management',
        url: '/system-settings/geo-location',
        icon: '',
      },
    ]
  },

  {
    key: 'key_mps',
    name: 'MPS',
    url: '/pagenotfound',
    icon: 'beta',
    children: [
      {
        key: 'key_mpsSummaryWorkbench',
        name: 'MPS Summary Workbench',
        url: '/mps/mps-summary-workbench',
        icon: 'beta',
      },
      {
        key: 'key_RowMaterialDemand',
        name: 'Raw Material Demand',
        url: '/mps/raw-material-demand',
        icon: 'beta',
      }
    ]
  },

  {
    key: 'key_WarehouseManagement',
    name: 'Warehouse Management',
    url: '/pagenotfound',
    icon: 'beta',
    children: [
      {
        key: 'key_ReceiptOrder',
        name: 'Receipt Order',
        url: '/warehouse-management/receipt-order',
        icon: 'beta',
      },
      {
        key: 'key_IssueOrder',
        name: 'Issue Order',
        url: '/warehouse-management/issue-order',
        icon: 'beta',
      },
      {
        key: 'key_InventoryDailyView',
        name: 'Inventory Daily View',
        url: '/warehouse-management/inventory-daily-view',
        icon: 'beta',
      },
      {
        key: 'key_MaterialInBox',
        name: 'Material In Box',
        url: '/warehouse-management/material-in-box',
        icon: 'beta',
      },
      {
        key: 'key_PackagingMaterial',
        name: 'Packaging Material',
        url: '/warehouse-management/packaging-material',
        icon: 'beta',
      },
      {
        key: 'key_GenerateTags',
        name: 'Generate Tags',
        url: '/warehouse-management/generate-tags',
        icon: 'beta',
      },
      {
        key: 'key_AssociateRFID',
        name: 'Associate RFID',
        url: '/warehouse-management/associate-rfid',
        icon: 'beta',
      },
      {
        key: 'key_AssetInOut',
        name: 'Asset In / Out',
        url: '/warehouse-management/asset-in-out',
        icon: 'beta',
      },
      {
        key: 'key_MaterialChainOfCustody',
        name: 'Material Chain of Custody',
        url: '/warehouse-management/material-chain-of-custody',
        icon: 'beta',
      } 
      
    ]
  },
  {
    key: 'key_PurchaseOrder',
    name: 'Purchase Order',
    url: '/pagenotfound',
    icon: 'beta',
    children: [
      {
        key: 'key_PurchaseOrderWorkbench',
        name: 'Purchase Order Workbench',
        url: '/purchase-order/purchase-order-workbench',
        icon: 'beta',
      }
    ]
  },

];
