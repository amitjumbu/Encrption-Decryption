import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  // {
  //   path: '',
  //   component: ContactComponent
  // }
];

export const BillingManagementRoutes = RouterModule.forChild(routes);
