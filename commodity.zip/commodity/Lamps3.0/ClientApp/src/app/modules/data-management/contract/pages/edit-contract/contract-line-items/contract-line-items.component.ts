import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ViewItemComponent } from './view-item/view-item.component';
import { Contract } from '../../../../../../core/models/contract.model';
import { ContractService } from '../../../../../../core/services/contract.service';
import { AuthService } from '../../../../../../core/services';

@Component({
  selector: 'app-contract-line-items',
  templateUrl: './contract-line-items.component.html',
  styleUrls: ['./contract-line-items.component.css']
})
export class ContractLineItemsComponent implements OnInit {
 

  itemListA = [];

  settingsA = {};

  selectedItemsA = [];
  savedData2: any;
  count = 3;
  object: Contract = new Contract();
  ChargeDescription = [];
  settingsCharge = {};
  selectedCharge = [];
  constructor(private authService: AuthService, private contractService: ContractService) { }


  @Input() savedData: any;

  @ViewChild('ViewItem') ViewItem: ViewItemComponent;
  ngOnInit(): void {
      // for searchable dropdown
   
   
    setTimeout(() => {
      this.object.ClientId = this.authService.currentUserValue.ClientId;
      this.savedData2 = this.savedData;
      if (this.savedData != null) {
        this.ViewItem.FillData();
      }
    }, 5000);
    this.getChargeDescription();
      // searchable dropdown end
    }//init() end
    onAddItemA(data: string) {
      this.count++;
      this.itemListA.push({ "id": this.count, "itemName": data });
      this.selectedItemsA.push({ "id": this.count, "itemName": data });
    }
    onItemSelect(item: any) {}
  OnItemDeSelect(item: any) {}
    onSelectAll(items: any) {}
  onDeSelectAll(items: any) { }


  getChargeDescription() {
    debugger;
    this.object.ClientId = this.authService.currentUserValue.ClientId;
    this.contractService.getChargeDescription(this.object)
      .subscribe(res => {
        debugger;
        if (res.message == "Success") {
          var data = res.data;
          this.ChargeDescription = data.map(r => ({ id: r.id, itemName: r.description }));
          this.settingsCharge = {
            singleSelection: false,
            text: "Select",
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            addNewItemOnFilter: true,
            badgeShowLimit: 1
          };
        }
      });
  }
}
