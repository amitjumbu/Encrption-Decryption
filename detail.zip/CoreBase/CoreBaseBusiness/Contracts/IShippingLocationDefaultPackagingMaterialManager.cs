﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IShippingLocationDefaultPackagingMaterialManager : IBaseManager<ShippingLocationDefaultPackagingMaterial, ShippingLocationDefaultPackagingMaterialViewModel>
    {


        Task<bool> AddAsync(ShippingLocationDefaultPackagingMaterialViewModel viewModel);

        Task<IEnumerable<ShippingLocationDefaultPackagingMaterialViewModel>> RangeAsync(int recordCount, ShippingLocationDefaultPackagingMaterialViewModel viewModel);
        Task<int> CountAsync(ShippingLocationDefaultPackagingMaterialViewModel viewModel);

        Task<IEnumerable<ShippingLocationDefaultPackagingMaterialViewModel>> GetList(int id);


        //Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

        Task<bool> DeleteAllAsync(ShippingLocationDefaultPackagingMaterialViewModel viewModel);
    }
} 

