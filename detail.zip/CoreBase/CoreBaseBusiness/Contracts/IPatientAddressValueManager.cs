﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IPatientAddressValueManager : IBaseManager<PatientAddress, PatientAddressValueViewModel>
    {

        Task<bool> AddAsync(PatientAddressValueViewModel viewModel);

        Task<bool> UpdateAsync(PatientAddressValueViewModel viewModel); 

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<IEnumerable<PatientAddressValueViewModel>> RangeAsync(int recordCount, PatientAddressValueViewModel viewModel);

    }
}
