﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IFuelSurchargeIndexManager : IBaseManager<FuelChargeIndex, FuelSurchargeIndexViewModel>
    {

        Task<IEnumerable<FuelPriceTypeViewModel>> GetFuelPriceTypes(FuelPriceTypeViewModel fuelpricetypeViewModel);
        Task<int> CountAsync(FuelSurchargeIndexViewModel viewModel);
        public List<FuelPriceTypeViewModel> GetFuelPriceType(long ClientId);

        public List<UOMViewModel> GetChargeRateUOM(long ClientId);
        //Task<bool> AddAsync(List<FuelSurchargeIndexViewModel> viewModel);
        Task<bool> AddAsync(FuelSurchargeIndexViewModel viewModel);
        //Task<bool> SaveAll(IEnumerable<FuelSurchargeIndexViewModel> viewModel);
        Task<IEnumerable<FuelSurchargeIndexViewModel>> SaveAll(List<FuelSurchargeIndexViewModel> viewModel);
        Task<bool> UpdateAsync(FuelSurchargeIndexViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);
        Task<IEnumerable<FuelSurchargeIndexViewModel>> GetFuelSurChargeindexList(FuelSurchargeIndexViewModel fuelSurchargeIndexViewModel);
        Task<IEnumerable<FuelSurchargeIndexViewModel>> GetFuelSurchargeIndexListByIDs(CollectFuelchargeIndexIDs collectFuelchargeIndexIDs);
        Task<bool> DeleteAllAsync(List<string> ids);
        Task<IEnumerable<FuelSurchargeIndexViewModel>> GetFuelSurchargeListByIDs(CollectFuelchargeIndexIDs collectHospialIDs);
    }
} 

