﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IMaterialGroupManager : IBaseManager<MaterialGroup, MaterialGroupViewModel>
    {
        Task<IEnumerable<MaterialGroupViewModel>> GetAllMaterialGroupData(MaterialGroupViewModel requestCommonViewModel);
    }
}