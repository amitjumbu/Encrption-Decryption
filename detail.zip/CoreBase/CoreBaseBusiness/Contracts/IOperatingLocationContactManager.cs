﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace CoreBaseBusiness.Contracts
{
   public interface IOperatingLocationContactManager : IBaseManager<OperatingLocationContact, OperatingLocationContactViewModel>
    {
        Task<bool> AddAsync(OperatingLocationContactViewModel viewModel);

        Task<bool> UpdateAsync(OperatingLocationContactViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);
    }
}
