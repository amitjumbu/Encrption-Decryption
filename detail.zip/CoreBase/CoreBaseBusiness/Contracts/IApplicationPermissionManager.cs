﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;

namespace CoreBaseBusiness.Contracts
{
    public interface IApplicationPermissionManager : IBaseManager<ApplicationPermission, ApplicationPermissionViewModel>
    {
        Task<ApplicationPermissionViewModel> GetElementPermission(ApplicationPermissionViewModel viewModel);

        Task<bool> Delete(EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket);

    }
}