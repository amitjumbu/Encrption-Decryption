﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    public interface ICarrierPropertyDetailManager :
        IBaseManager<CarrierPropertyDetail, CarrierPropertyDetailViewModel>
    {

        Task<bool> MergeCarrierPropertyDetails(List<CarrierPropertyDetailViewModel> mergeModels);
        Task<bool> DeleteExistingCharacteristics(LocationPropertyDeleteModel locationDeleteModel);
        Task<IEnumerable<CarrierPropertyDetailViewModel>> GetExistingCarrierCharacteristics(CarrierPropertyDetailViewModel carrierPropertyDetailViewModel);
    }
}