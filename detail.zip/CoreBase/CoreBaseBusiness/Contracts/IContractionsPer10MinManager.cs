﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{
    public interface IContractionsPer10MinManager : IBaseManager<Measurement_ContractionsMeasurementValue, ContractionsPer10MinViewModel>
    {

        Task<bool> AddAsync(ContractionsPer10MinViewModel viewModel);

        Task<bool> UpdateAsync(ContractionsPer10MinViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy); 

        
    }
} 

