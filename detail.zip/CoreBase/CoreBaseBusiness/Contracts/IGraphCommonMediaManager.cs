﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IGraphCommonMediaManager
    {
        Task<IEnumerable<GraphCommonMediaViewModel>> GetAllAsync(int recordCount, GraphCommonMediaViewModel viewModel);

        Task<bool> AddAsync(GraphCommonMediaViewModel viewModel);
         
        Task<bool> UpdateAsync(GraphCommonMediaViewModel viewModel);

        Task<GraphCommonMediaViewModel> GetByIDAsync(GraphCommonMediaViewModel viewModel);

        Task<bool> DeleteAsync(GraphCommonMediaViewModel viewModel, string DeletedBy);

       
    }
} 

