﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;

namespace CoreBaseBusiness.Contracts
{
    public interface IOperatingLocationManager : IBaseManager<OperatingLocation, OperatingLocationViewModel>
    {
        Task<bool> Delete(EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket);
        Task<OperatingLocationViewModel> GetAsync(long id);

        Task<IEnumerable<OperatingLocation>> RangeAsync(int recordCount, OperatingLocation viewModel);

        IEnumerable<object> GetOrganizationHierarchyGroupAsync(int recordCount, OperatingLocationViewModel viewModel);
        IEnumerable<object> GetOrganizationHierarchyEnterprisesAsync(int recordCount, OperatingLocationViewModel viewModel);
        Task<IEnumerable<OperatingLocationListViewModel>> GetLocationsListByIDs(CollectHospialIDs collectHospialIDs);
    }
}