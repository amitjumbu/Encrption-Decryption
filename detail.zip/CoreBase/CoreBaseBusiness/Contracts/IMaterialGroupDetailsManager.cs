﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using CoreBaseData.Repository.Implementation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IMaterialGroupDetailsManager : IBaseManager<MaterialGroupDetail, MaterialGroupDetailsViewModel>
    {
        Task<IEnumerable<MaterialGroupDetailsViewModel>> GetMaterialGroupDetailById(MaterialGroupDetailsViewModel viewModel);

        Task<int> CountMGDAsync(MaterialGroupDetailsViewModel viewModel);
    }
}
