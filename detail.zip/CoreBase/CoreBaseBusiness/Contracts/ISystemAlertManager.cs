﻿namespace CoreBaseBusiness.Contracts
{
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ISystemAlertManager : IBaseManager<SystemAlert, SystemAlertViewModel>
    {
        new Task<bool> AddAsync(SystemAlertViewModel viewModel);

        new Task<bool> UpdateAsync(SystemAlertViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);
    }
}