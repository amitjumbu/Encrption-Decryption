﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ICustomerContractDetailManager : IBaseManager<CustomerContractDetail, CustomerContractDetailViewModel>
    {
        new Task<bool> AddAsync(CustomerContractDetailViewModel viewModel);

        new Task<bool> UpdateAsync(CustomerContractDetailViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);
    }
}