﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IPatientResourceListManager : IBaseManager<PatientResourceList, PatientResourceListViewModel>
    {
        Task<bool> CheckPhysicianMappedWithPatient(PatientResourceMapppingViewModel pData);
        Task<PatientResourceListViewModel> GetAsync(int id);
        Task<int> CountAsync(PatientResourceListViewModel viewModel);
        Task<bool> AddAsync(PatientResourceListViewModel viewModel);
        Task<IEnumerable<PatientResourceListViewModel>> GetPhysiciansByPatientId(PatientResourceListViewModel ViewModel);
        Task<bool> DeleteAllAsync(string ids, string deletedBy);
    }
} 

