﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IVolumeManager : IBaseManager<Measurement_UrineVolumeMeasurementValue, VolumeViewModel>
    {

        Task<bool> AddAsync(VolumeViewModel viewModel);

        Task<bool> UpdateAsync(VolumeViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

      
    }
} 

 