﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ICommodityTypeManager : IBaseManager<CommodityType, CommodityTypeViewModel>
    {

        Task<IEnumerable<CommodityTypeViewModel>> ListAsync(CommodityTypeViewModel viewModel);

        Task<bool> UpdateAll(IEnumerable<CommodityTypeViewModel> viewModel);

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<object> getComTypExist(string ComtypCode);

        //Task<bool> UpdateAsync(CommodityTypeViewModel viewModel);
    }
}