﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IUserAlertManager : IBaseManager<UserAlert, UserAlertViewModel>
    {
        new Task<bool> AddAsync(UserAlertViewModel viewModel);

        new Task<bool> UpdateAsync(UserAlertViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<IEnumerable<UserAlertSPViewModel>> GetAllAlerts(UserAlertViewModel viewModel);


        Task<bool> ActivateUserAlert(List<string> ids, bool isActive);

        Task<bool> DeleteAllAsync(List<string> ids);
    }
}