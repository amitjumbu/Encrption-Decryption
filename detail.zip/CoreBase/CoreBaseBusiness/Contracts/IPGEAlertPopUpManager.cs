﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IPGEAlertPopUpManager : IBaseManager<PGEAlertPopUp, PGEAlertPopUpViewModel>
    {

        Task<bool> AddAsync(PGEAlertPopUpViewModel viewModel);

        Task<bool> UpdateAsync(PGEAlertPopUpViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
}  

