﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IDropsMinManager : IBaseManager<Measurement_DropsMinMeasurementValue, DropsMinViewModel>
    {

        Task<bool> AddAsync(DropsMinViewModel viewModel);

        Task<bool> UpdateAsync(DropsMinViewModel viewModel);
         
        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

