﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
   public interface IHospitalSetupManager : IBaseManager<Location, LocationViewModel>
    {
        Task<bool> AddAsync(LocationViewModel viewModel);

        Task<bool> UpdateAsync(LocationViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);
        Task<IEnumerable<Location>> RangeAsync(int recordCount, Location viewModel);
    }
}
