﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IProteinManager : IBaseManager<Measurement_UrineProtienMeasurementValue, ProteinViewModel>
    {

        Task<bool> AddAsync(ProteinViewModel viewModel); 

        Task<bool> UpdateAsync(ProteinViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

        
    }
} 

 