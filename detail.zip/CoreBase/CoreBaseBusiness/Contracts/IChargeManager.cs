﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IChargeManager : IBaseManager<Charge, ChargeViewModel>
    {

        Task<IEnumerable<ChargeViewModel>> GetChageListForAdjustChageSection(ChargeViewModel chargeViewModel);

        Task<IEnumerable<ChargeViewModel>> UpdateModelsAsync(List<ChargeViewModel> chargeViewModels);

        Task<IEnumerable<ChargeViewModel>> GetAllChargeDetails(ChargeViewModel chargeViewModel);
        Task<object> GetCharge(ParameterModel parameterModel);
    }
}