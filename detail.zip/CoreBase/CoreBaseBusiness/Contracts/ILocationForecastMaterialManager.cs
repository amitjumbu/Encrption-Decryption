﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    public interface ILocationForecastMaterialManager : IBaseManager<LocationForecastMaterial, LocationForecastMaterialViewModel>
    {

        Task<IEnumerable<LocationForecastMaterialViewModel>> GetListByLocationId(long id);

        Task<bool> AddAsync(LocationForecastMaterialViewModel viewModel);

        Task<IEnumerable<LocationForecastMaterialViewModel>> GetList();

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<bool> DeleteByIdsAsync(int[] ids, string deletedBy);

        Task<IEnumerable<ForecastCustomerLocationViewModel>> SaveAll(List<ForecastCustomerLocationViewModel> viewModels);

        Task<IEnumerable<ForecastCustomerLocationViewModel>> DeleteAllAsync(List<ForecastCustomerLocationViewModel> viewModels);
    }
}