﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IPatientObstetricFormulaManager : IBaseManager<PatientObstetricFormula, PatientObstetricFormulaViewModel>
    {
        Task<PatientObstetricFormulaViewModel> GetAsync(int id);
        Task<int> CountAsync(PatientObstetricFormulaViewModel viewModel);
        Task<bool> AddAsync(PatientObstetricFormulaViewModel viewModel);
        public List<ChoiceOfBirthingPartnerViewModel> GetChoiceofBirthingPartner();
    }
} 

