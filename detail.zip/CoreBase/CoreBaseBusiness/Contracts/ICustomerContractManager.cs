﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ICustomerContractManager : IBaseManager<CustomerContract, CustomerContractViewModel>
    {
        new Task<bool> AddAsync(CustomerContractViewModel viewModel);

        new Task<bool> UpdateAsync(CustomerContractViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);
    }
}