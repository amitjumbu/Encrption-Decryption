﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
   public interface IPatientContactValueManager : IBaseManager<PatientContact, PatientContactValueViewModel>
    {

        Task<bool> AddAsync(PatientContactValueViewModel viewModel);

        Task<bool> UpdateAsync(PatientContactValueViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);  

        Task<IEnumerable<PatientContactValueViewModel>> RangeAsync(int recordCount, PatientContactValueViewModel viewModel);
    }
}
