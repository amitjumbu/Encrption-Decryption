﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using CoreBaseData.Repository.Implementation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IMaterialHierarchyDetailManager : IBaseManager<MaterialHierarchyDetail, MaterialHierarchyDetailViewModel>
    {
        Task<IEnumerable<MaterialHierarchyDetailViewModel>> GetMaterialHierarchyDetailById(MaterialHierarchyDetailViewModel viewModel);

        Task<int> GetMHDCount(MaterialHierarchyDetailViewModel viewModel);
    }
}
