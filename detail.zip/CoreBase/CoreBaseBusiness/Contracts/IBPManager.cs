﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IBPManager : IBaseManager<Measurement_BPMeasurementValue, BPViewModel>
    {

        Task<bool> AddAsync(BPViewModel viewModel);
         
        Task<bool> UpdateAsync(BPViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

