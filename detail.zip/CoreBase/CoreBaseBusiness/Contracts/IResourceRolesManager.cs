﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IResourceRolesManager : IBaseManager<ResourceRoles, ResourceRolesViewModel>
    {
        Task<IEnumerable<ResourceRolesViewModel>> ListAsync(ResourceRolesViewModel viewModel);
        Task<ResourceRolesViewModel> GetAsync(int id);
        public List<ResourceRolesViewModel> GetResourceRole(long ClientId);
        public List<ResourceOnResourceRoleViewModel> GetResourceNameOnResourceRole(ResourceOnResourceRoleViewModel resourceOnResourceRoleViewModel);
    }
}