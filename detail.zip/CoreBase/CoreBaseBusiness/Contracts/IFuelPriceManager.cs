﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IFuelPriceManager : IBaseManager<FuelPrice, FuelPriceViewModel>
    {

        Task<FuelPriceViewModel> GetAsync(int id);


        Task<IEnumerable<FuelPriceViewModel>> RangeAsync(int recordCount, FuelPriceViewModel viewModel);
        Task<int> CountAsync(FuelPriceViewModel viewModel);

        //Task<IEnumerable<LocationViewModel>> GetList(int id);

        Task<bool> AddAsync(FuelPriceViewModel viewModel);

        Task<IEnumerable<FuelPriceViewModel>> GetFuelPriceList(FuelPriceViewModel viewModel);

        Task<IEnumerable<FuelPriceViewModel>> GetFuelPriceListById(FuelPriceViewModel viewModel);

        Task<bool> DeleteAllAsync(FuelPriceViewModel viewModel);

        Task<IEnumerable<FuelPriceViewModel>> GetFuelPriceListByDateAndRate(FuelPriceViewModel viewModel);
        //Task<IEnumerable<FuelPriceViewModel>> SaveAll(List<FuelPriceViewModel> viewModel);

        //Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel);

        //Task<IEnumerable<LocationViewModel>> GetToFromLocation(LocationViewModel viewModel);

        //Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel[] viewModel);
        //Task<IEnumerable<LocationViewModel>> ManufacturerList(LocationViewModel viewModel);
        //Task<IEnumerable<LocationViewModel>> GetHospitalList(LocationViewModel locationViewModel);
        //Task<IEnumerable<OperatingLocationListViewModel>> GetOperatingLocationList(OperatingLocationListViewModel operatingLocationListViewModel);
        //Task<bool> ActivateHospitalStatus(List<string> ids, bool isActive);
        //Task<string> DeleteAllAsync(List<string> ids);

        //Task<bool> UpdateLocationStatus(List<LocationViewModel> viewModels);

        //Task<IEnumerable<LocationViewModel>> GetSalesBroker(LocationViewModel viewModel);

    }
} 

