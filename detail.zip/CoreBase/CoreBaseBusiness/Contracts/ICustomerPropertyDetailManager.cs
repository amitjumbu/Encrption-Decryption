﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface ICustomerPropertyDetailManager : IBaseManager<CustomerPropertyDetail, CustomerPropertyDetailViewModel>
    {

        Task<CustomerPropertyDetailViewModel> GetAsync(int id);

        Task<bool> AddAsync(CustomerPropertyDetailViewModel viewModel);

        Task<IEnumerable<CustomerPropertyDetailViewModel>> RangeAsync(int recordCount, CustomerPropertyDetailViewModel viewModel);

        Task<int> CountAsync(CustomerPropertyDetailViewModel viewModel);

        Task<IEnumerable<CustomerPropertyDetailViewModel>> GetList(int id);

        //Task<IEnumerable<CustomerPropertyDetailViewModel>> GetPreferredMaterialbyId(CustomerPropertyDetailViewModel viewModel);

        //Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

        Task<bool> InsertCustomerPropertyDetails(CustomerPropertyDetailViewModel viewModel);

        Task<bool> DeleteAllAsync(CustomerPropertyDetailViewModel viewModel);

        Task<IEnumerable<CustomerPropertyDetailViewModel>> RangeAsyncList(CustomerPropertyDetailViewModel viewModel);

        Task<IEnumerable<ForecastCustomerLocationViewModel>> GetMapForecastCustomerLocation(ForecastCustomerLocationViewModel viewModel);

        Task<IEnumerable<CustomerLocationDropdownViewModel>> GetCustomerLocationDropDownList(CustomerLocationDropdownViewModel viewModel);

        Task<bool> MergeCustomerPropertyDetails(List<CustomerPropertyDetailViewModel> mergeModels);

        Task<int> GetTotalCount(ForecastCustomerLocationViewModel viewModel);
    }
}