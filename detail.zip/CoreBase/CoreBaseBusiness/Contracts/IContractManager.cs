﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IContractManager : IBaseManager<CustomerContract, CustomerContractViewModel>
    {
        Task<bool> AddAsync(CustomerContractViewModel viewModel);
        Task<object> AddAsyncData(CustomerContractViewModel viewModel);
        Task<object> UpdateContractAsync(CustomerContractViewModel viewModel);
        Task<IEnumerable<CustomerContractViewModel>> RangeAsync(int recordCount, CustomerContractViewModel viewModel);

        Task<IEnumerable<CustomerContractViewModel>> ListAsync(CustomerContractViewModel viewModel);

        Task<IEnumerable<ContractViewModel>> GetAllContract(ContractViewModel requestCommonViewModel);

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<IEnumerable<object>> AddContractAsync(List<ContractDetailViewModel> requestViewModel);

        Task<object> GetContractDetails(CustomerContractViewModel viewModel);
        Task<IEnumerable<ContractDetailViewModel>> GetContractDetailsByIds(CustomerContractViewModel viewModel);

        Task<IEnumerable<object>> GetCharacteristic();

        Task<IEnumerable<object>> AddCharacteristicsAsyncData(List<DefiningCharacteristicsViewModel> ViewModels);

        Task<bool> DeleteDefiningCharacteristics(List<DefiningCharacteristicsViewModel> ViewModels);
        Task<object> GetByIdContract(ContractViewModel requestCommonViewModel);

        Task<IEnumerable<DefiningCharacteristicsViewModel>> GetCharacteristicsData(ContractViewModel viewModel);

        Task<bool> ContractApprove(ContractViewModel viewModel);

        Task<bool> DeleteContracts(List<ContractViewModel> viewModel);

        Task<bool> ActivateContracts(List<ContractViewModel> viewModel);

        Task<bool> InactiveContracts(List<ContractViewModel> viewModel);

        Task<bool> CheckExist(CustomerContractViewModel viewModel);

        Task<bool> DeleteContractDetails(ContractDetailViewModel viewModel);

        Task<bool> SendApprovalNotification(CustomerContractViewModel viewModel);

        Task<IEnumerable<object>> GetLocationsIds(CustomerContractViewModel viewModel);

        Task<object> GetCustomerByContactType(CustomerContractViewModel viewModel);
        Task<object> GetBusinessPartnerOnContactType(BusinessPartnerContractViewModel viewModel);
        Task<IEnumerable<object>> GetChargesAndCharacteristicsFrom(CustomerContractViewModel viewModel);


        Task<object>  SaveAndUpdateContract(CustomerContractViewModel initialCustomerContractViewModel, CustomerContractViewModel finalCustomerContractViewModel);
    }
}