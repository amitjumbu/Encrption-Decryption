﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IBusinessPartnerPropertyDetailManager : 
        IBaseManager<BusinessPartnerPropertyDetail, BusinessPartnerPropertyDetailViewModel>
    {

        Task<bool> MergeBusinessPartnerPropertyDetails(List<BusinessPartnerPropertyDetailViewModel> mergeModels);
    }
}