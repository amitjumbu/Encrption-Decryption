﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IMaterialManager : IBaseManager<Material, MaterialViewModel>
    {

        Task<MaterialViewModel> GetAsync(int id);


        Task<IEnumerable<MaterialViewModel>> RangeAsync(int recordCount, MaterialViewModel viewModel);
        Task<int> CountAsync(MaterialViewModel viewModel);

        Task<bool> AddAsync(MaterialViewModel viewModel);

        Task<bool> UpdateAsync(MaterialViewModel viewModel);

        Task<IEnumerable<MaterialViewModel>> GetOrderMaterial(OrderRequestedMaterialsViewModel orderRequestedMaterialsViewModel);

        Task<LocationMaterialModel> Materialquantity(MaterialQuantityRequestModel flagViewModel);
        Task<IEnumerable<LocationMaterialModel>> LocationMaterial(MaterialCommonModel orderRequestedMaterialsViewModel);
        Task<IEnumerable<LocationMaterialModel>> LocationShippingMaterial(MaterialCommonModel orderRequestedMaterialsViewModel);
        Task<IEnumerable<LocationMaterialModel>> DefaultPallet(MaterialCommonModel orderRequestedMaterialsViewModel);
        Task<IEnumerable<ShippmentMaterialModel>> AllMaterialquantity(AllMaterialQuantityRequestModel flagViewModel);
        Task<int> ListmaterialAsync(MaterialCommodityMapViewModel commonViewModel);
        Task<IEnumerable<MaterialCommodityMapViewModel>> GetAllMaterialCommodityMapData(MaterialCommodityMapViewModel commonViewModel);
        Task<IEnumerable<MaterialViewModel>> GetDefaultMaterialCommodity(MaterialCommodityRequestModel flagViewModel);
        Task<DefaultMaterialProperty> DefaultMaterialProperty(MaterialQuantityRequestModel flagViewModel);

        Task<object> getMaterial(string code);

        Task<IEnumerable<MaterialCommodityMapViewModel>> UpdateMaterialCommodityAsync(List<MaterialCommodityMapViewModel> viewModel);

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<IEnumerable<MaterialPalletsCalculation>> GetMaterialPalletsCalculation(MaterialPalletsCalculation viewModel);
        Task<IEnumerable<MaterialCommodityMapViewModel>> GetAllMaterialWithHMaterialHierarchy(MaterialCommodityDeleteModel commonViewModel);
        Task<object> ContractMaterial(ContractMaterialModel ViewModel);
    }
}