﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{
    public interface IPartographHistoryManager
    {

        Task<List<ChartHistoryViewModel>> GetPartographHistory(ChartHistoryViewModel viewModel);


    }
} 

