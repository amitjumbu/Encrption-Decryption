﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
   public interface IPatientValueManager : IBaseManager<Patient, PatientValueViewModel>
    {
        Task<bool> AddAsync(PatientValueViewModel viewModel);

        Task<bool> UpdateAsync(PatientValueViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy); 

        Task<IEnumerable<PatientValueViewModel>> RangeAsync(int recordCount, PatientValueViewModel viewModel);
        Task<IEnumerable<object>> SearchPatient(PatientViewModel viewModel);
        Task<IEnumerable<object>> RangeAsync1(int recordCount, PatientValueViewModel viewModel);
        public List<PatientHeaderViewModel> GetPatientInfoByID(long PatientId);
        Task<bool> UpdatePatientStatus(PatientTransactionViewModel pData);
        //public List<PatientSetupListViewModel> GetPatientSetupList();
        Task<IEnumerable<PatientSetupListViewModel>> GetPatientSetupList(PatientSetupListViewModel patientSetupList);
        Task<bool> ActivatePatientStatus(List<string> ids, bool isActive);
        Task<IEnumerable<object>> GetPatientList(PatientViewModel viewModel);
        Task<string> DeleteAllAsync(List<string> ids);
        Task<IEnumerable<object>> GetContactAddressPhysicianInfo(PatientViewModel viewModel);


    }
}
