﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IDecentofHeadManager : IBaseManager<Measurement_HeadDescentMeasurementValue, DecentofHeadViewModel>
    {

        Task<bool> AddAsync(DecentofHeadViewModel viewModel);

        Task<bool> UpdateAsync(DecentofHeadViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

        
    }
}  

