﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface ILocationPreferredMaterialManager : IBaseManager<LocationPreferredMaterial, LocationPreferredMaterialViewModel>
    {

        Task<LocationPreferredMaterialViewModel> GetAsync(int id);

        Task<bool> AddAsync(LocationPreferredMaterialViewModel viewModel);

        Task<IEnumerable<LocationPreferredMaterialViewModel>> RangeAsync(int recordCount, LocationContactViewModel viewModel);
        Task<int> CountAsync(LocationPreferredMaterialViewModel viewModel);

        Task<IEnumerable<LocationPreferredMaterialViewModel>> GetList(int id);

        Task<IEnumerable<LocationPreferredMaterialViewModel>> GetPreferredMaterialbyId(LocationPreferredMaterialViewModel viewModel);

        //Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);
        Task<bool> DeleteAllAsync(LocationPreferredMaterialViewModel viewModel);
    }
} 

