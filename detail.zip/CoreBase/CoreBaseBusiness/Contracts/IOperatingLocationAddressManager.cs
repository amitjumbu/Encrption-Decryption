﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace CoreBaseBusiness.Contracts
{
  public  interface IOperatingLocationAddressManager : IBaseManager<OperatingLocationAddress, OperatingLocationAddressViewModel>
    {
        Task<bool> AddAsync(OperatingLocationAddressViewModel viewModel);

        Task<bool> UpdateAsync(OperatingLocationAddressViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);



    }
}
