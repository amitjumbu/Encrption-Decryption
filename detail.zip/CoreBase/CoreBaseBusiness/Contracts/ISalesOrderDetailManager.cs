﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface ISalesOrderDetailManager : IBaseManager<SalesOrderDetail, SalesOrderDetailViewModel>
    {

        Task<SalesOrderDetailViewModel> GetAsync(int id);


        Task<IEnumerable<SalesOrderDetailViewModel>> RangeAsync(int recordCount, SalesOrderDetailViewModel viewModel);
        Task<int> CountAsync(SalesOrderDetailViewModel viewModel);

        Task<bool> AddAsync(SalesOrderDetailViewModel viewModel);

        Task<bool> UpdateAsync(SalesOrderDetailViewModel viewModel);

       
    }
} 

