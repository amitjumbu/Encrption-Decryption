﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IPGEManager : IBaseManager<PGE, PGEViewModel>
    {

        Task<bool> AddAsync(PGEViewModel viewModel);

        Task<bool> UpdateAsync(PGEViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

 