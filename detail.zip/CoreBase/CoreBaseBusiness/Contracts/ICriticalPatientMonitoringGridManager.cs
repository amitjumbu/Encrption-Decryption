﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface ICriticalPatientMonitoringGridManager : IBaseManager<CriticalPatientMonitoringGrid, CriticalPatientMonitoringGridViewModel>
    {

        
        Task<bool> AddAsync(CriticalPatientMonitoringGridViewModel viewModel);
        Task<bool> SaveAll(IEnumerable<CriticalPatientMonitoringGridViewModel> viewModel);
        Task<bool> UpdateAsync(CriticalPatientMonitoringGridViewModel viewModel);
        Task<IEnumerable<CriticalPatientMonitoringGridViewModel>> ListAsync(CriticalPatientMonitoringGridViewModel viewModel);
        //Task<bool> DeleteAsync(long id, string deletedBy);
        Task<IEnumerable<CriticalPatientMonitoringGridViewModel>> GetCriticalPatientMonitoringGridList(CriticalPatientMonitoringGridViewModel criticalPatientMonitoring);
    }
} 

