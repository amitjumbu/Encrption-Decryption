﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{
    public interface ICommentManager : IBaseManager<Comment, CommentViewModel>
    {

        Task<bool> AddAsync(CommentViewModel viewModel);

        Task<bool> UpdateAsync(CommentViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<IEnumerable<CommentViewModel>> RangeAsync(int recordCount, CommentViewModel viewModel);

    }
} 

