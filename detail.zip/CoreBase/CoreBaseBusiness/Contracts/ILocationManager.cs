﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface ILocationManager : IBaseManager<Location, LocationViewModel>
    {

        Task<LocationViewModel> GetAsync(int id);

        Task<IEnumerable<LocationViewModel>> RangeAsync(int recordCount, LocationViewModel viewModel);
        Task<int> CountAsync(LocationViewModel viewModel);

        Task<IEnumerable<LocationViewModel>> GetList(int id);

        Task<bool> AddAsync(LocationViewModel viewModel);
        Task<IEnumerable<LocationViewModel>> SaveAll(List<LocationViewModel> viewModel);

        Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel);

        Task<IEnumerable<LocationViewModel>> GetLocationByLocationFunctionID(LocationViewModel viewModel);

        Task<IEnumerable<LocationViewModel>> GetToFromLocation(LocationViewModel viewModel);

        Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel[] viewModel);
        Task<IEnumerable<LocationViewModel>> ManufacturerList(LocationViewModel viewModel);
        Task<IEnumerable<LocationViewModel>> GetHospitalList(LocationViewModel locationViewModel);
        Task<IEnumerable<LocationViewModel>> GetHospitalListByIDs(CollectHospialIDs collectHospialIDs);
        
        Task<IEnumerable<OperatingLocationListViewModel>> GetOperatingLocationList(OperatingLocationListViewModel operatingLocationListViewModel);
        Task<bool> ActivateHospitalStatus(List<string> ids, bool isActive);
        Task<string> DeleteAllAsync(List<string> ids);

        Task<bool> UpdateLocationStatus(List<LocationViewModel> viewModels);
        Task<bool> UpdateLocationWithoutSetupCompleteAsync(LocationViewModel viewModel);
        Task<IEnumerable<LocationViewModel>> GetSalesBroker(LocationViewModel viewModel);
        Task<bool> DeleteByIdsAsync(int[] ids, string deletedBy);
        Task<IEnumerable<EntityPropertyViewModel>> GetLocationCharacteristics(EntityPropertyViewModel entityPropertyViewModel);
        Task<IEnumerable<OperatingLocationPropertyDetailViewModel>> GetExistingLocationCharacteristics(OperatingLocationPropertyDetailViewModel operatingLocationPropertyDetailView);

        Task<bool> DeleteExistingCharacteristics(LocationPropertyDeleteModel deleteModel);

        Task<VerifyOrderLocationViewModel> VerifyOrderLocationStatus(VerifyOrderLocationViewModel verifyOrderLocationViewModel);

        Task<IEnumerable<LocationForClaim>> BillingEntityForBPlist(LocationViewModel viewModel);
        Task<IEnumerable<LocationForClaim>> BillingEntityForCustomerlist(LocationViewModel viewModel);

    }
} 

