﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using Microsoft.AspNetCore.Http;

    public interface IForecastManager : IBaseManager<Forecast, ForecastViewModel>
    {

        Task<IEnumerable<ForecastViewModel>> GetListById(long id);
        Task<bool> AddForecast(ForecastViewModel viewModel);
        Task<bool> DuplicateExists(ForecastViewModel viewModel);
        Task<List<string>> GetDynamicColumnById(long forecastId);
        Task<IEnumerable<object>> GetForecastDetailById(ForecastViewModel forecastId);
        Task<IEnumerable<ForecastChildViewModel>> GetChildForecastDetailById(ForecastViewModel forecastId);
        Task<IEnumerable<object>> GetForecastTemplateById(ForecastViewModel forecastId);
        Task<IEnumerable<object>> GetStatusAggregateForecastDetailById(ForecastViewModel forecastId);
        Task<ForecastViewModel> GetLastUpdatedForecast();
        Task<ForecastRelationViewModel> UploadForecast(IFormFile file, ForecastUploadViewModel forecastUploadViewModel);

    }
}