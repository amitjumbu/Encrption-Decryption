﻿namespace CoreBaseBusiness.Contracts
{

    using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;


    public interface ICountryOfOriginOfMaterialManager : IBaseManager<CountryOfOriginOfMaterial, CountryOfOriginOfMaterialViewModel>
    {

        Task<bool> AddAsync(CountryOfOriginOfMaterialViewModel viewModel);

        Task<bool> UpdateAsync(CountryOfOriginOfMaterialViewModel viewModel);
        Task<bool> DeleteAllAsync(List<string> ids);
        Task<bool> DeleteAsync(int id, string deletedBy);
        Task<IEnumerable<CountryOfOriginOfMaterialViewModel>> GetAllOriginOfGoodsDetails(CountryOfOriginOfMaterialViewModel ViewModel);
        Task<IEnumerable<CountryOfOriginOfMaterialViewModel>> RangeAsync(int recordCount, CountryOfOriginOfMaterialViewModel viewModel);

    }
}

