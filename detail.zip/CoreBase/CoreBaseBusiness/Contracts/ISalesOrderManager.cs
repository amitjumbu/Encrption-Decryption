﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface ISalesOrderManager : IBaseManager<SalesOrder, SalesOrderViewModel>
    {

        Task<SalesOrderViewModel> GetAsync(long id);


        Task<IEnumerable<SalesOrderViewModel>> RangeAsync(int recordCount, SalesOrderViewModel viewModel);

        Task<int> CountAsync(SalesOrderViewModel viewModel);

        Task<bool> AddAsync(SalesOrderViewModel viewModel);

        Task<bool> UpdateAsync(SalesOrderViewModel viewModel);

        Task<bool> SetOverRideCreditLimit(SalesOrderViewModel viewModel);
        Task<bool> SaveCMComment(SalesOrderViewModel viewModel);

        Task<object> SaveRegularOrder(AllSalesOrderViewModel viewModel);


        Task<object> SaveAll(AllSalesOrderViewModel viewModel);

        Task<object> SaveAllStockTransfer(AllSalesOrderViewModel viewModel);

        Task<CommentModel> GetComment(MaterialCommonModel ViewModel);

        public Task<IEnumerable<CommonOrder>> OrderList(CommonOrder flagViewModel);
        Task<IEnumerable<SalesOrderViewModel>> OrderListCount(CommonOrder flagViewModel);


        Task<List<BulkOrderViewModel>> SaveBulkOrder(BulkOrderViewModel[] ViewModel);

        Task<bool> SendARChargesTOMASAsync(SalesOrderViewModel salesOrderViewModel);
        // Task<SalesOrder> GetAllShipToData(SalesOrderViewModel ViewModel);

        Task<IEnumerable<SalesOrderViewModel>> GetAllShipToData(int id, int clientId, string SelectedTab);

        //Task<IEnumerable<SalesOrderViewModel>> GetAllSalesOrderList(SalesOrderViewModel chargeViewModel);
        Task<int> GetAllSalesOrderListDataCount(SalesOrderListViewModel chargeViewModel);

        Task<IEnumerable<SalesOrderListViewModel>> GetAllSalesOrderList(SalesOrderListViewModel salesOrderListViewModel);

        Task<IEnumerable<SalesOrderListViewModel>> GetAllSalesOrderList(SalesOrderListViewModel salesOrderListViewModel,ref int TotalCount);


        //Task<List<EditVerifyEquipmentMaterialProperty>> GetVerifyEquipmentMaterialPropertyOrder(EditVerifyEquipmentMaterialProperty ViewModel);
        Task<IEnumerable<EditVerifyEquipmentMaterialProperty>> GetVerifyEquipmentMaterialPropertyOrder(EditVerifyEquipmentMaterialProperty viewModel);

        Task<bool> CancelSelectedOrdersAsync(long ClientId, string OrderIdList, string SelectedTab);

        Task<bool> DeleteSelectedOrdersAsync(long ClientId, string OrderIdList, string SelectedTab);


        // Task<IEnumerable<EditVerifyEquipmentMaterialProperty>> GetVerifyEquipmentForMultipleMaterialPropertyOrder(RequestObjectMaterialProperties viewModel);
        Task<IEnumerable<SaveVerifyEquipmentMaterialProperty>> SaveUpdateVerifyEquipmentMaterial(SaveVerifyEquipmentMaterialProperty viewModel);
        Task<object> GetInvoice(InviceParameterModel flagViewModel);

        Task<List<MaterialPropertiesGrid>> GetVerifyEquipmentForMultipleMaterialPropertyOrder(RequestObjectMaterialProperties viewModel);

        Task<List<MaterialPropertiesGrid>> FindMissingMateriaOrder(RequestObjectMaterialProperties viewModel);

        Task<bool> SaveSalesLinkOrder(long ClientId, string OrderIdList, string UserName, int ParentOrderId, string SelectedTab);

        Task<bool> MoveUpDownLinkOrder(long ClientId, int OrderId, int SwapWithOrderId, int RouteSequence, int SwapWithRouteSequence, string UserName, long ShipWithOrderID, long SwapWithShipWithOrderID);
        Task<bool> RemoveSelectedLinkOrderRecord(long ClientId, int OrderId, long ShipWithOrderID, string SelectedTab);


        Task<ValidationResponse> RecalculateExistingOrders(long orderId, int orderTypeId);

        Task<object> GetOrderDetailById(long OrderId, int ClientId, string OrderType);

        Task<IEnumerable<SalesOrderViewModel>> GetOrderDataByOrderIdForShipWith(int ClientId, int OrderId, string InboundOutbound);
        Task<int> CopyOrdersAsync(long ClientId, string OrderIdList, string SelectedTab);
        Task<object> GetInvoiceNumberList(int ClientId);
        Task<object> GetAllSource(int ClientId);
        Task<int> GetCheckStatusForSendtoMass(long ClientId, string OrderIdList, string SelectedTab);

        Task<int> GetCheckStatusReSendtoMass(long ClientId, string OrderIdList, string SelectedTab);

        Task<bool> SendARChargesTOMAS(long ClientId, string OrderIdList, string SelectedTab);
        Task<bool> ReSendARChargesTOMAS(long ClientId, string OrderIdList, string SelectedTab);
        Task<bool> SaveCreateManageFilter(CreateFilter createFilter);
        Task<IEnumerable<CreateFilter>> GetAllCustomManageFiltersData(int clientId, int userId, string selectedTab);
        Task<bool> UpdateManageFilters(CreateFilter createFilter);
        Task<bool> DeleteManageFilters(CreateFilter createFilter);

        Task<string> ConvertTextEnglishToSpanish(string commentstring);


        Task<IEnumerable<object>> GetShipmentNumberDetails(int ClientId, string shipdatefrom, string shipdateto);
        Task<IEnumerable<object>> GetOrderNumberDetails(int ClientId, string shipdatefrom, string shipdateto);

        Task<IEnumerable<object>> GetShipmentNumberWithShippmentID(int ClientId, string shipdatefrom, string shipdateto, long ShipmentID);
        Task<IEnumerable<object>> GetOrderNumberWithShippmentID(int ClientId, string shipdatefrom, string shipdateto,long ShipmentID);

    }
}

