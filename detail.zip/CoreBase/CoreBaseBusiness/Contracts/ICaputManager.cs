﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface ICaputManager : IBaseManager<Measurement_CaputMeasurementValue, CaputViewModel>
    {

        Task<bool> AddAsync(CaputViewModel viewModel);

        Task<bool> UpdateAsync(CaputViewModel viewModel);
         
        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

