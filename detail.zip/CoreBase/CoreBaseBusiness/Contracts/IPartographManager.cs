﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;

namespace CoreBaseBusiness.Contracts
{
    public interface IPartographManager : IBaseManager<Partograph, PartographViewModel>
    {
        Task<bool> Delete(EntityRecordRemoveRequestPacketForSmallID entityRecordRemoveRequestPacket);
        Task<PartographViewModel> GetAsync(long id);

        Task<IEnumerable<PartographViewModel>> RangeAsync(int recordCount, PartographViewModel viewModel);
        Task<IEnumerable<object>> GetAllPatientList(int recordCount, PartographViewModel viewModel);

    }
}