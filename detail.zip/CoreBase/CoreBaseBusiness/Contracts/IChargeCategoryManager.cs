﻿namespace CoreBaseBusiness.Contracts
{
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IChargeCategoryManager : IBaseManager<ChargeCategory, ChargeCategoryViewModel>
    {
    }
}