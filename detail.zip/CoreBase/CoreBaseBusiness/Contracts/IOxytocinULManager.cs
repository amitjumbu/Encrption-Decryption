﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IOxytocinULManager : IBaseManager<Measurement_OxytocinMeasurementValue, OxytocinULViewModel>
    {

        Task<bool> AddAsync(OxytocinULViewModel viewModel);

        Task<bool> UpdateAsync(OxytocinULViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);
         
        
    }
} 

