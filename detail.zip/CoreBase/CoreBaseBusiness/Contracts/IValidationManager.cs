﻿namespace CoreBaseBusiness.Contracts
{ 
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IValidationManager : IBaseManager<Validation, ValidationViewModel>
    {

        Task<bool> AddAsync(ValidationViewModel viewModel);

        Task<bool> UpdateAsync(ValidationViewModel viewModel);
         
        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

