﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;

    public interface ICustomerByLocationManager
    {

        Task<IEnumerable<CustomerByLocationViewModel>>
                GetCustomerByLocation(CustomerByLocationViewModel customerByLocationViewModel);

        Task<bool>
               UpdateCustomerByLocation(CustomerByLocationEditModel customerByLocationEditModel);

        Task<bool> ActivateCustomerByLocation(List<string> ids, bool isActive);

    }
}
