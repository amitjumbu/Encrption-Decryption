﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IGraphCommonCommentManager
    {
        Task<IEnumerable<GraphCommonCommentViewModel>> GetAllAsync(int recordCount, GraphCommonCommentViewModel viewModel);

        Task<bool> AddAsync(GraphCommonCommentViewModel viewModel);
         
        Task<bool> UpdateAsync(GraphCommonCommentViewModel viewModel);

        Task<GraphCommonCommentViewModel> GetByIDAsync(GraphCommonCommentViewModel viewModel);

        Task<bool> DeleteAsync(GraphCommonCommentViewModel viewModel, string DeletedBy);

       
    }
} 

