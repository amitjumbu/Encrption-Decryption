﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ICommodityManager : IBaseManager<Commodity, CommodityViewModel>
    {
        Task<bool> AddAsync(CommodityViewModel viewModel);

        Task<IEnumerable<CommodityViewModel>> RangeAsync(int recordCount, CommodityViewModel viewModel);

        Task<IEnumerable<CommodityTypeViewModel>> ListAsync(CommodityTypeViewModel viewModel);

        //Task<IEnumerable<CommodityViewModel>> ListAsync(CommodityViewModel viewModel);

        Task<IEnumerable<DepartmentViewModel>> ListSegmentAsync(DepartmentViewModel viewModel);

        Task<IEnumerable<CommodityViewModel>> ListCommodityAsync(CommodityViewModel viewModel);

        Task<IEnumerable<CommodityViewModel>> GetDefaultCommodity(RequestCommonViewModel requestCommonViewModel);

        Task<IEnumerable<CommodityViewModel>> GetAllCommodity(CommodityViewModel requestCommonViewModel);

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<object> getCommodity(string code);
    }
}