﻿namespace CoreBaseBusiness.Contracts
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;

    public interface IOrderCalculationManager
    {
        public List<RoleUsersViewModel> GetUsersList(long locationID, string roleName, string userLocationType);

        public OrderDetailViewModel GetOrderDetails(long orderID, long orderTypeID);

        List<ComputationMethodViewModel> GetComputationMethodDataOnElementAndChargeID(RequestDataPriceMethodAndComputationMethod requestDataPriceMethodAndComputationMethod);

        List<PriceMethodViewModel> GetPriceMethodDataOnElementAndChargeID(RequestDataPriceMethodAndComputationMethod requestDataPriceMethodAndComputationMethod);

        List<PriceMethodViewModel> GetPriceMethodList(RequestCommonViewModel requestCommonViewModel);

        ResponseAdjustChargesWithDefaultData GetDefaultAjustCharges(RequestCommonViewModel requestCommonViewModel);

        decimal GetAvailableCredit(AvailableCreaditViewModel requestCommonViewModel);

        FuelChargesViewModel GetFuelCharges(AvailableCreaditViewModel requestCommonViewModel);

        ValidationResponse ValidateMaterialWithEquipment(MaterialEquipmentValidation materialEquipmentValidation);

        ValidationResponse ValidateOrderCoreInputs(AllSalesOrderViewModel salesOrderViewModel);

        Task<CalculateOrderCharges> CalculateOrderChargesOnLatestContractAsync(CalculateOrderCharges calculateOrderCharges);

        decimal CalculateCoreCharges(long quantity, string ratetypecode, decimal ratevalue);

        Task<bool> ModifyEquipmentMaterialPropertyDetails(List<MaterialPropertiesGrid> materialPropertiesGrid, int ClientID, string CreatedBy);

        double CalculateChargesForRegularScreen(RequestObjectChargeFormulaeCalculation viewModel);

        Task<List<MaterialPropertiesGrid>> GetVerifyEquipmentForMultipleMaterialPropertyOrder(RequestObjectMaterialProperties viewModel);
    }
}
