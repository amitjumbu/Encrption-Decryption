﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{
    public interface IAmnioticFluidManager : IBaseManager<Measurement_AmnioticFluidMeasurementValue, AmnioticFluidViewModel>
    {

        Task<bool> AddAsync(AmnioticFluidViewModel viewModel); 

        Task<bool> UpdateAsync(AmnioticFluidViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

