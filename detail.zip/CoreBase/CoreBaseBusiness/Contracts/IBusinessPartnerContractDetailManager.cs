﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IBusinessPartnerContractDetailManager : IBaseManager<BusinessPartnerContractDetail, BusinessPartnerContractDetailViewModel>
    {
        new Task<bool> AddAsync(BusinessPartnerContractDetailViewModel viewModel);

        new Task<bool> UpdateAsync(BusinessPartnerContractDetailViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);
    }
}