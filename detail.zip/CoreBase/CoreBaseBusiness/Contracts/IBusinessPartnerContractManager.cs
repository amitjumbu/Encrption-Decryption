﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IBusinessPartnerContractManager : IBaseManager<BusinessPartnerContract, BusinessPartnerContractViewModel>
    {
        new Task<bool> AddAsync(BusinessPartnerContractViewModel viewModel);

        new Task<bool> UpdateAsync(BusinessPartnerContractViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);
    }
}