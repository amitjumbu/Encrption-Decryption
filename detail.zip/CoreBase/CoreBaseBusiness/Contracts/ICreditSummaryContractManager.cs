﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface ICreditSummaryContractManager : IBaseManager<ArinvoiceAgeDetail, CreditSummaryViewModel>
    {
        Task<IEnumerable<CreditSummaryViewModel>> GetCreditSummaryList(CreditSummaryViewModel creditSummaryViewModel);
        Task<IEnumerable<CreditSummaryViewModel>> GetCreditSummaryListCount(CreditSummaryViewModel creditSummaryViewModel);

    }

}
