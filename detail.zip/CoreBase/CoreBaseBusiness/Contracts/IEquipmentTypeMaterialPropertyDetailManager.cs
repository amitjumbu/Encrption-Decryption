﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using CoreBaseData.Repository.Implementation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IEquipmentTypeMaterialPropertyDetailManager : IBaseManager<EquipmentTypeMaterialPropertyDetail, EquipmentTypeMaterialPropertyDetailViewModel>
    {
        Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetEquipmentTypeMaterialPropertyDetailByCode(EquipmentTypeMaterialPropertyDetailViewModel viewModel);

        Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> SaveAll(List<EquipmentTypeMaterialPropertyDetailViewModel> viewModels);

        Task<IEnumerable<EquipmentMatPropDetailFromSelectedMatModel>> GetEquipmentMatPropDetailFromSelectedMaterial(EquipmentMatPropDetailFromSelectedMatModel viewModel);

        Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetEquipmentTypeMaterialPropertyForPopUp(EquipmentTypeMaterialPropertyDetailViewModel viewModel);

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetMaterialPropertyByEquipmentTypeCode(EquipmentTypeMaterialPropertyDetailViewModel viewModel);

        Task<int> GetCount(EquipmentTypeMaterialPropertyDetailViewModel viewModel);

        Task<int> GetmatTotalCountCount(EquipmentTypeMaterialPropertyDetailViewModel viewModel);

        Task<IEnumerable<EquipmentPropDetailFromSelectedEquipmentModel>> GetCopiedPropFromSelectedEquipment(EquipmentPropDetailFromSelectedEquipmentModel viewModel);

        Task<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>> GetMaterialPropertyByEquipmentForPopUp(MaterialPropertyDetailByEquipmentViewModel viewModel);

        Task<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>> GetTotalCountMaterialPropertyByEquipmentForPopUp(MaterialPropertyDetailByEquipmentViewModel viewModel);

        Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetTotalCountEquipmentTypeMaterialPropertyForPopUp(EquipmentTypeMaterialPropertyDetailViewModel viewModel);
    }
}
