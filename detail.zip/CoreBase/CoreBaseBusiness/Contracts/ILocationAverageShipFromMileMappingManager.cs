﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface ILocationAverageShipFromMileMappingManager : IBaseManager<LocationPreferredMaterial, LocationAverageShipFromMileMappingViewModel>
    {

        Task<LocationAverageShipFromMileMappingViewModel> GetAsync(int id);

        Task<bool> AddAsync(LocationAverageShipFromMileMappingViewModel viewModel);

        Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> RangeAsync(int recordCount, LocationAverageShipFromMileMappingViewModel viewModel);
        Task<int> CountAsync(LocationAverageShipFromMileMappingViewModel viewModel);

        Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> RangeAsyncMilesList(LocationAverageShipFromMileMappingViewModel viewModel);
        Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> GetList(int id);

        //Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> GetPreferredMaterialbyId(LocationAverageShipFromMileMappingViewModel viewModel);

        //Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel);

        //Task<bool> DeleteAsync(long id, string deletedBy);
        Task<bool> DeleteAllAsync(LocationAverageShipFromMileMappingViewModel viewModel);
        Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> GetDistanceAsync(LocationAverageShipFromMileMappingViewModel viewModel);
    }
} 

