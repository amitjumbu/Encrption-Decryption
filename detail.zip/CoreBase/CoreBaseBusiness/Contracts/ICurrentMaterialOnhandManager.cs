﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ICurrentMaterialOnhandManager : IBaseManager<CurrentMaterialOnhand, CurrentMaterialOnhandViewModel>
    {
        Task<IEnumerable<CurrentMaterialOnhandViewModel>> GetAllCurrentMaterialOnhand(CurrentMaterialOnhandViewModel inventoryViewModel);

        Task<int> RcordCountAsync(CurrentMaterialOnhandViewModel viewModel);

        Task<string> GetSumQuantity(CurrentMaterialOnhandViewModel viewModel);

        Task<bool> UpdateCommentAsync(CurrentMaterialOnhandViewModel viewModel);

        Task<bool> DeleteAllAsync(List<string> ids);
    }
}