﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ISystemTypeManager : IBaseManager<SystemType, SystemTypeViewModel>
    {
        new Task<bool> AddAsync(SystemTypeViewModel viewModel);

        new Task<bool> UpdateAsync(SystemTypeViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<IEnumerable<SystemTypeViewModel>> GetSystemTypeByCategoryCode(RequestedSystemCategoryViewModel viewModel);
    }
}