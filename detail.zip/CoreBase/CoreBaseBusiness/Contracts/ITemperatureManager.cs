﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface ITemperatureManager : IBaseManager<Measurement_TemperatureMeasurementValue, TemperatureViewModel>
    {

        Task<bool> AddAsync(TemperatureViewModel viewModel);

        Task<bool> UpdateAsync(TemperatureViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<IEnumerable<TemperatureViewModel>> RangeAsync(int recordCount, TemperatureViewModel viewModel);

    }
} 

