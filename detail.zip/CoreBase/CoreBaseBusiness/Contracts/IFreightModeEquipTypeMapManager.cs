﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IFreightModeEquipTypeMapManager : IBaseManager<FreightModeEquipmentTypeMapping, FreightModeEquipMapViewModel>
    {
        //Task<bool> AddAsync(FreightModeEquipMapViewModel viewModel);

        //Task<FreightModeViewModel> GetAsync(long id);

        //Task<bool> UpdateAsync(FreightModeViewModel viewModel);

        //Task<bool> DeleteAsync(int id, string deletedBy); 

        //Task<IEnumerable<FreightModeEquipMapViewModel>> RangeAsync(int recordCount, FreightModeEquipMapViewModel viewModel);

        //Task<bool> SaveAll(IEnumerable<FreightModeEquipMapViewModel> viewModel);
        Task<IEnumerable<FreightModeEquipMapViewModel>> SaveAll(List<FreightModeEquipMapViewModel> viewModel);
        //Task<bool> UpdateAll(IEnumerable<FreightModeEquipMapViewModel> viewModel);

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<int> CountAsync(FreightModeEquipMapViewModel viewModel);
        //Task<IEnumerable<FreightModeViewModel>> GetEditfmsAsync(string ids);
        public List<FreightModeEquipMapViewModel> GetFreightModeEquipMapList(long FreightModeID);
        Task<IEnumerable<FreightModeEquipmentMapViewModel>> GetFreightModeEquipmentMapingList(FreightModeEquipmentMapViewModel viewModel);
        Task<int> GetCount(FreightModeEquipMapViewModel viewModel);
    }
}
