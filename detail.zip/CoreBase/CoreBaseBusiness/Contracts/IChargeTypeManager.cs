﻿namespace CoreBaseBusiness.Contracts
{
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IChargeTypeManager : IBaseManager<ChargeType, ChargeTypeViewModel>
    {
    }
}