﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{
    public interface ICervixManager : IBaseManager<Measurement_CervixMeasurementValue, CervixViewModel>
    {

        Task<bool> AddAsync(CervixViewModel viewModel);

        Task<bool> UpdateAsync(CervixViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

       
    } 
} 

