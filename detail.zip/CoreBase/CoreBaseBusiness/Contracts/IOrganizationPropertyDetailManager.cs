﻿namespace CoreBaseBusiness.Contracts
{
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IOrganizationPropertyDetailManager : IBaseManager<OrganizationPropertyDetail, OrganizationPropertyDetailViewModel>
    {
        Task<bool> AddAsync(OrganizationPropertyDetailViewModel viewModel);

        //Task<FreightModeViewModel> GetAsync(long id);

        Task<bool> UpdateAsync(OrganizationPropertyDetailViewModel viewModel);
        Task<IEnumerable<OrganizationPropertyDetailViewModel>> SaveAll(List<OrganizationPropertyDetailViewModel> viewModel);
        Task<bool> DeleteAsync(int id, string deletedBy);
        //DeleteByIdsAsync
        Task<bool> DeleteByIdsAsync(OrganizationPropertyDetailViewModel organizationPropertyDetailViewModel);
        Task<IEnumerable<OrganizationPropertyDetailViewModel>> RangeAsync(int recordCount, OrganizationPropertyDetailViewModel viewModel);
        Task<IEnumerable<OrganizationPropertyDetailViewModel>> GetOrganizationPropertyDetailsList(OrganizationPropertyDetailViewModel organizationPropertyDetailViewModel);

        Task<IEnumerable<EntityPropertyViewModel>> GetOrganizationCharacteristics(EntityPropertyViewModel entityPropertyViewModel);
    }
}