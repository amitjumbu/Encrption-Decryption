﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IFreightLaneManager : IBaseManager<FreightLane, FreightLaneViewModel>
    {
        Task<bool> AddAsync(FreightLaneViewModel viewModel);

        //Task<FreightModeViewModel> GetAsync(long id);

        Task<bool> UpdateAsync(FreightLaneViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy); 

        Task<IEnumerable<FreightLaneViewModel>> RangeAsync(int recordCount, FreightLaneViewModel viewModel);

        //Task<bool> SaveAll(IEnumerable<FreightModeViewModel> viewModel);
        Task<IEnumerable<FreightLaneViewModel>> SaveAll(List<FreightLaneViewModel> viewModel);
        Task<IEnumerable<FreightLaneViewModel>> UpdateAll(List<FreightLaneViewModel> viewModel);
        

        Task<bool> DeleteAllAsync(List<string> ids);

        Task<IEnumerable<FreightLaneViewModel>> GetEditfmsAsync(string ids);

        //Task<IEnumerable<FreightModeViewModel>> GetFreightMode(MaterialCommonModel ViewModel);

        Task<IEnumerable<FreightLaneViewModel>> GetFreightLaneList(FreightLaneViewModel freightLaneViewModel);
        Task<IEnumerable<FreightLaneViewModel>> GetFreightLaneExcelErrorList(FreightLaneViewModel freightLaneViewModel);
        
        Task<IEnumerable<FreightLaneViewModel>> GetFreightLaneFilterData(FreightLaneViewModel freightLaneViewModel);

        Task<IEnumerable<FreightLaneViewModel>> InsertFreightLaneExcelData(List<FreightLaneViewModel> freightLaneViewModel);
    }
}
