﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;

    public interface IBusinessPartnerManager
    {

        Task<IEnumerable<BusinessPartnerByLocationViewModel>>
                GetBusinessPartnerByLocation(BusinessPartnerByLocationViewModel businessPartnerByLocationViewModel);

        Task<IEnumerable<BusinessPartnerByCarrierViewModel>>
            GetBusinessPartnerByCarrier(BusinessPartnerByCarrierViewModel businessPartnerByLocationViewModel);
        Task<bool> UpdateBusinessPartnerByLocation(BusinessPartnerByLocationViewModel editModel);
        Task<bool> UpdateBusinessPartnerByCarrier(BusinessPartnerByCarrierViewModel editModel);
        Task<bool> AddCarrier(BusinessPartnerByCarrierViewModel addModel);
        Task<bool> ActivateLocationBusinessPartner(List<string> ids, bool isActive);
        Task<bool> ActivateCarrier(List<string> ids, bool isActive);
        Task<IEnumerable<BusinessPartnerBilingEntityViewModel>>
            GetAllBillingEntity(BusinessPartnerBilingEntityViewModel businessPartnerBilingEntityViewModel);
        Task<IEnumerable<BusinessPartnerBilingEntityViewModel>>
            GetAllBillingEntityforCarrier(BusinessPartnerBilingEntityViewModel businessPartnerBilingEntityViewModel);

        Task<IEnumerable<BusinessPartnerBilingEntityViewModel>>
            GetAllCustomBillingEntity(BusinessPartnerBilingEntityViewModel businessPartnerBilingEntityViewModel);
    }
}
