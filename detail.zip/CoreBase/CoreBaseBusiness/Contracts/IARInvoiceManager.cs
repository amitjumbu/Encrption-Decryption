﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IARInvoiceManager : IBaseManager<ArinvoiceAgeDetail, ARInvoiceAgeDetailViewModel>
    {
        Task<IEnumerable<ARInvoiceAgeDetailViewModel>> GetInvoiceList(ARInvoiceAgeDetailViewModel invoiceViewModel);
        Task<IEnumerable<ARInvoiceAgeDetailViewModel>> GetInvoiceCount(ARInvoiceAgeDetailViewModel invoiceViewModel);

    }
}
