﻿namespace CoreBaseBusiness.Contracts
{
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IShipmentManager : IBaseManager<Shipment, ShipmentViewModel>
    {
        new Task<bool> AddAsync(ShipmentViewModel viewModel);

        new Task<bool> UpdateAsync(ShipmentViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<Object> GetShipmentOrders(ShipmentCommonModel flagViewModel);
        Task<Object> GetLoctionsForShipment(LocationForshipmentParameter viewmodel);


        Task<Object> GetShipmentDetails(ShipmentCommonModel flagViewModel);

        Task<Object> GetShipmentDetails();

        Task<Object> GetTenderStatusForShipment();

        Task<Object> SaveShipmentDetails(ShipmentSaveData  shipmentdetails);

        Task AddAsync(Shipment shipment);

        Task<Object> GetShipmentOrdersDetails(ShipmentCommonModel flagViewModel);
        Task<Object>  GetApcharges(ShipmentCommonModel flagViewModel);
        Task<Object> GetShipmentOrdersDetailsForShipmentId(ShipmentCommonModel flagViewModel);


        Task<bool> ApproveSendShipmentToMAS(ShipmentCommonModel flagViewModel);

        Task<Object> GetOrderAmountforAPCharges(apchargesInputModel apchargesInput);

        Task<Object> GetShipmentStatusForShipment();
        Task<Object> GetShipmentConditionForShipment();
        Task<Object> GetModeForShipment();
        Task<Object> GetOrderTypeForShipment();

        Task<Object> Tonu(ShipmentUpdateModel flagViewModel);
        Task<Object> Cancel(ShipmentUpdateModel flagViewModel);
        Task<Object> SaveShipmentOrders(ShipmentOrdersSaveModel shipmentOrdersdetails);
        Task<Object> ShipSelectedShipment(ShipmentSaveData shipmentdetails);
        Task<Object>  ReceiveSelectedShipment(ShipmentSaveData shipmentdetails);

        Task<IEnumerable<ShipmentDetailsViewModel>> GetShipmentAllDetails(ShipmentOrderDetailViewModel shipmentSaveDataViewModal);
        Task<IEnumerable<ShipmentOrderDetailViewModel>> GetShipmentAllDetailsCount(ShipmentOrderDetailViewModel shipmentSaveDataViewModal);

        Task<object> GetshipFromtypeAll(ShipmentSaveData shipmentdetails);
        Task<object> GetshiptotypeAll(ShipmentSaveData shipmentdetails);
        Task<object> GetshipFromAllData(ShipmentSaveData shipmentdetails);
        Task<object> GetshipToAllData(ShipmentSaveData shipmentdetails);

        Task<Object> ReSendSelectedShipmentToMAS(ShipmentCommonModel flagViewModel);

        Task<Object> GetChargetypeforApcharges(apchargesInputModel apchargesInput);

        Task<List<ShippmentCciViewModel>> GetCciReportById(long shipmentId);

        Task<Object> TPQFailSendShipmentToMAS(ShipmentCommonModel flagViewModel);
        Task<bool> SaveCreateManageFilter(CreateFilter createFilter);
        Task<IEnumerable<CreateFilter>> GetAllCustomManageFiltersData(int clientId, int userId, string selectedTab);
        Task<bool> UpdateManageFilters(CreateFilter createFilter);
        Task<bool> DeleteManageFilters(CreateFilter createFilter);

        Task<Object> GetUOMforApcharespopup();
        Task<ValidationResponse> RecalculateShipment(ShipmentViewModel shipmentViewModel);

        Task<Object> GetProformaInvoiceData(ShipmentCommonModel flagViewModel);
        Task<Object> GetProformaInvoiceOrganizationAddress();
        Task<Object> GetApchargesDuetoLocChange(ApchargeLocChangeModel apchargeLocChangeModel);
        
    }
}