﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IPatientHistoryofPresentIllnessManager : IBaseManager<PatientHistoryofPresentIllness, PatientHistoryofPresentIllnessViewModel>
    {

        Task<int> CountAsync(PatientHistoryofPresentIllnessViewModel viewModel);
        Task<bool> AddAsync(PatientHistoryofPresentIllnessViewModel viewModel);
        public List<PatientCovidStatusViewModel> GetCovidStatus();
        Task<PatientHistoryofPresentIllnessViewModel> GetAsync(int id);
    }
} 

