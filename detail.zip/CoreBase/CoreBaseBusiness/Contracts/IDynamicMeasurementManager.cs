﻿namespace CoreBaseBusiness.Contracts
{ 
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IDynamicMeasurementManager : IBaseManager<DynamicMeasurement, DynamicMeasurementViewModel>
    {

        Task<bool> AddAsync(DynamicMeasurementViewModel viewModel);

        Task<bool> UpdateAsync(DynamicMeasurementViewModel viewModel);
         
        Task<bool> DeleteAsync(long id, string deletedBy);

       
    }
} 

