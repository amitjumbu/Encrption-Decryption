﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IPatientPersonalHistoryManager : IBaseManager<PatientPersonalHistory, PatientPersonalHistoryViewModel>
    {

        Task<int> CountAsync(PatientPersonalHistoryViewModel viewModel);
        Task<bool> AddAsync(PatientPersonalHistoryViewModel viewModel);
    }
} 

