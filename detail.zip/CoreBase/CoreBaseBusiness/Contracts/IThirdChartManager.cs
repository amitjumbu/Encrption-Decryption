﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IThirdChartManager : IBaseManager<Measurement_ComplicationsMeasurementValue, ThirdChartViewModel>
    {

        Task<bool> AddAsync(ThirdChartViewModel viewModel);

        Task<bool> UpdateAsync(ThirdChartViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);

        
    }
} 
 
