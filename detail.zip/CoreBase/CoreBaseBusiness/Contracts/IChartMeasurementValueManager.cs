﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;

namespace CoreBaseBusiness.Contracts
{
    public interface IChartMeasurementValueManager : IBaseManager<ChartMeasurementValue, ChartMeasurementValueViewModel>
    {
        Task<bool> AddAsync(ChartMeasurementValueViewModel viewModel);

        Task<bool> AddAllAsync(List<ChartMeasurementValueViewModel> viewModel);
        Task<IEnumerable<ChartMeasurementValueViewModel>> GetAllAsync(int recordCount, ChartMeasurementValueViewModel viewModel);

        Task<bool> Delete(EntityRecordRemoveRequestPacket chartMeasurementRequestPacket);

        Task<bool> UpdateAllAsync(List<ChartMeasurementValueViewModel> viewModel);

    }
}