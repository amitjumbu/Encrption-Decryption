﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Contracts
{
    public interface IMedicationChartGridManager : IBaseManager<MedicationChartGrid, MedicationChartGridViewModel>
    {

        
        Task<bool> AddAsync(MedicationChartGridViewModel viewModel);
        Task<bool> SaveAll(IEnumerable<MedicationChartGridViewModel> viewModel);
        Task<bool> UpdateAsync(MedicationChartGridViewModel viewModel);

        //Task<bool> DeleteAsync(long id, string deletedBy);
    }
} 

