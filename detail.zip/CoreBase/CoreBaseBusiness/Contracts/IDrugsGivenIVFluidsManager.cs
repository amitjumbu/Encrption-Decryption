﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
  
namespace CoreBaseBusiness.Contracts
{ 
    public interface IDrugsGivenIVFluidsManager : IBaseManager<Measurement_DrugsIVMeasurementValue, DrugsGivenIVFluidsViewModel>
    {

        Task<bool> AddAsync(DrugsGivenIVFluidsViewModel viewModel);

        Task<bool> UpdateAsync(DrugsGivenIVFluidsViewModel viewModel);

        Task<bool> DeleteAsync(long id, string deletedBy);
        Task<int> DrugsGivenFluidsInsertUpdate(List<DrugsGivenIVFluidsViewModel> listData);


    }
} 

