﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IFreightModeManager : IBaseManager<FreightMode, FreightModeViewModel>
    {
        Task<bool> AddAsync(FreightModeViewModel viewModel);

        //Task<FreightModeViewModel> GetAsync(long id);

        Task<bool> UpdateAsync(FreightModeViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy); 

        Task<IEnumerable<FreightModeViewModel>> RangeAsync(int recordCount, FreightModeViewModel viewModel);

        //Task<bool> SaveAll(IEnumerable<FreightModeViewModel> viewModel);
        Task<IEnumerable<FreightModeViewModel>> SaveAll(List<FreightModeViewModel> viewModel);

        Task<bool> UpdateAll(IEnumerable<FreightModeViewModel> viewModel);

        Task<string> DeleteAllAsync(string IDs, string deleteby);

        Task<IEnumerable<FreightModeViewModel>> GetEditfmsAsync(string ids);

        Task<IEnumerable<FreightModeViewModel>> GetFreightMode(MaterialCommonModel ViewModel);

        Task<IEnumerable<FreightModeViewModel>> GetFreightModeList(FreightModeViewModel freightModeViewModel);

    }
}
