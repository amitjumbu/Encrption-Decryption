﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IChargeComputationMethodMappingManager : IBaseManager<ChargeComputationMethodMapping, ChargeComputationMethodMappingViewModel>
    {
        Task<IEnumerable<ChargeComputationMethodMappingViewModel>> GetChargeCompuationMethodMappingDetails(ChargeComputationMethodMappingViewModel chargeViewModel);
        Task<IEnumerable<ChargeComputationMethodMappingForOrderViewModel>> GetChargeComputationMethodsForPerticularCharge(ChargeComputationMethodMappingViewModel viewModel);
    }
}