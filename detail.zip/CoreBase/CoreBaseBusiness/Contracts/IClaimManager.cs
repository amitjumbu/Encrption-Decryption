﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IClaimManager : IBaseManager<Claim, ClaimViewModel>
    {

        Task<IEnumerable<ChargeViewModel>> GetChageListForAdjustChageSection(ChargeViewModel chargeViewModel);

        Task<IEnumerable<ChargeViewModel>> UpdateModelsAsync(List<ChargeViewModel> chargeViewModels);

        Task<IEnumerable<ChargeViewModel>> GetAllChargeDetails(ChargeViewModel chargeViewModel);

        Task<IEnumerable<ClaimViewModel>> GetAllClaimData(ClaimViewModel claimViewModel, ref int TotalCount);

        Task<object> GetFilterClaimData(ClaimFilterParameter ViewModel);
        Task<int> GetAllClaimDataCount(ClaimViewModel claimViewModel);

        Task<object> GetClaimDetailsByClaimId(int ClaimId, int ClientId);

        Task<object> CompleteSetupAndNotify(int clientId, int claimId, bool isCompleteSetupAndNotify, int claimStatusId, int userId);
        Task<object> SetClaimApproved(int clientId, int claimId, bool isApproved, int claimStatusId, int userId);
        Task<object> SaveClaimDetail(ClaimDetailModel ViewModel);
        Task<object> SaveClaim(ClaimModel ViewModel);
        Task<object> CompleteSetupAndNotifyAlert(int clientId, int claimId, bool isCompleteSetupAndNotify);
        Task<object> SetClaimApprovedAlert(int clientId, int claimId, bool isApproved);

        Task<object> UpdateClaim(ClaimModel ViewModel);
        Task<object> SaveMultiClaimDetail(MultiClaimModel multiClaimModel);
        Task<object> DeleteClaimDetail(MultiClaimModel multiClaimModel);
        Task<bool> ClaimSelectedRecordsDelete(int userId, int clientID, string selectedRecords);




    }
}