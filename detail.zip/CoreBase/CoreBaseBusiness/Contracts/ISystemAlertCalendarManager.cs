﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface ISystemAlertCalendarManager : IBaseManager<SystemAlertCalendar, SystemAlertCalendarViewModel>
    {

        Task<bool> AddAsync(SystemAlertCalendarViewModel viewModel);

        Task<bool> UpdateAsync(SystemAlertCalendarViewModel viewModel);

        Task<bool> DeleteAsync(int id, string deletedBy);

        Task<IEnumerable<SystemAlertCalendarViewModel>> RangeAsync(int recordCount, SystemAlertCalendarViewModel viewModel);

    }
}