﻿namespace CoreBaseBusiness.Contracts
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    public interface ICalendarTypeManager : IBaseManager<CalendarType, CalendarTypeViewModel>
    {

        Task<IEnumerable<CalendarTypeViewModel>> GetList();

    }
}