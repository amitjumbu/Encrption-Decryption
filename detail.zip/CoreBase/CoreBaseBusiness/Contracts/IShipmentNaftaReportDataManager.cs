﻿namespace CoreBaseBusiness.Contracts
{

    using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;


    public interface IShipmentNaftaReportDataManager : IBaseManager<ShipmentNaftaReportData, ShipmentNaftaReportDataViewModel>
    {

        Task<bool> AddAsync(ShipmentNaftaReportDataViewModel viewModel);

        Task<bool> UpdateAsync(ShipmentNaftaReportDataViewModel viewModel);
        Task<bool> DeleteAllAsync(List<string> ids);
        Task<bool> DeleteAsync(int id, string deletedBy);
        Task<IEnumerable<NetCostViewModel>> GeAllNetCostData(NetCostViewModel ViewModel);
        //Task<bool> UploadFilesAsync(ShipmentNaftaReportDataViewModel ViewModel);
        Task<IEnumerable<ShipmentNaftaReportDataViewModel>> GetAllShipmentNaftaReportData(ShipmentNaftaReportDataViewModel ViewModel);
        Task<IEnumerable<ShipmentNaftaReportDataViewModel>> RangeAsync(int recordCount, ShipmentNaftaReportDataViewModel viewModel);
        Task<IEnumerable<ShipmentNaftaReportList>> GetNaftaReportById(long shipmentId);
    }
}

