﻿namespace CoreBaseBusiness.Contracts
{ 
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;

    public interface IWebControlTypePossibleValueManager : IBaseManager<WebControlTypePossibleValue, WebControlTypePossibleValueViewModel>
    {

        Task<bool> AddAsync(WebControlTypePossibleValueViewModel viewModel);

        Task<bool> UpdateAsync(WebControlTypePossibleValueViewModel viewModel);
         
        Task<bool> DeleteAsync(long id, string deletedBy);
        Task<List<DynamicWebcontrolParameterViewModel>> GetDynamicWebcontrolParameterTable(DynamicWebcontrolParameterViewModel viewModel);


        Task<List<DynamicWebcontrolParameterViewModel>> SaveDynamicParameter(AddDynamicMeasurementParameterViewModel viewModel);
        Task<int> FinalSaveDynamicParameter(List<DynamicMeasurementParameterValueViewModel> viewModel);
        
    }
} 

