﻿using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using CoreBaseData.Repository.Implementation;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Contracts
{
    public interface IMaterialPropertyDetailManager : IBaseManager<MaterialPropertyDetail, MaterialPropertyDetailViewModel>
    {
        Task<IEnumerable<MaterialPropertyDetailViewModel>> GetMaterialPropertyDetailByCode(MaterialPropertyDetailViewModel viewModel);

        Task<IEnumerable<MaterialPropertyDetailViewModel>> SaveAll(List<MaterialPropertyDetailViewModel> viewModels);

        Task<IEnumerable<MatPropDetailFromSelectedMatViewModel>> GetMaterialPropertyDetailFromSelectedMaterial(MatPropDetailFromSelectedMatViewModel viewModel);

        Task<bool> DeleteAllAsync(List<string> ids);
    }
}
