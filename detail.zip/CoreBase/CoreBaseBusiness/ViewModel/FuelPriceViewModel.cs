﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.ViewModel
{
    public partial class FuelPriceViewModel : BaseViewModel
    {
        public string SelectedIds { get; set; }
        public int CountryId { get; set; }
        public string CountryCode { get; set; }
        public int FuelPriceTypeId { get; set; }
        public string PriceType { get; set; }
        public DateTime FuelPriceDateTime { get; set; }
        public string FuelPriceDateTimePicker { get; set; }
        public decimal Rate { get; set; }
        public decimal ChargeRatePerMile { get; set; }
        
        public int Uomid { get; set; }
        public string UOM { get; set; }






        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
    }
    
}
