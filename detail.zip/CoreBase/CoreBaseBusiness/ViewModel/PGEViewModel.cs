﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class PGEViewModel:BaseGraphViewModel
    {
        public ICollection<PGECommentViewModel> Comments { get; set; }

        public ICollection<PGEMediaViewModel> Medias { get; set; }
    }
} 