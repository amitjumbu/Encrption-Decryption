﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
    
    public class AmnioticFluidMediaViewModel : BaseGraphMediaViewModel
    {
        
        public long AmnioticFluidID { get; set; }

        public AmnioticFluidViewModel AmnioticFluid { get; set; }
    }
}