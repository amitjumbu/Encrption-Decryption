﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class PatientHeaderViewModel
    {
        public long PatientId { get; set; }
        public string PatientName { get; set; }
        public long CRNo { get; set; }
        public long MRDNo { get; set; }
        public long UnitNo { get; set; }
        public DateTime AdmissionDate { get; set; }
    }
} 