﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class BulkOrderViewModel
    {
        public string RequestedDeliveryDate { get; set; }
        public string ScheduledShipDate { get; set; }
        public string MustArriveByDate { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public string TrailerNumber { get; set; }
        public long MaterialID { get; set; }
        public long CarrierId { get; set; }
        public long ToLocationId { get; set; }
        public long ShipToTypeId { get; set; }
        public long ToContractId { get; set; }
        public string TransplaceOrderComment { get; set; }
        public string TransplaceDeliveryComment { get; set; }
        public string CreatedBy { get; set; }
        public string OrderNumber { get; set; }
        public int OrderStatusId { get; set; }
        public int OrderTypeId { get; set; }
        public long EquipmentTypeId { get; set; }
        public int ClientId { get; set; }
        public long ShipFromTypeId { get; set; }
        public long FromCustomerContractId { get; set; }
        public long FromLocationId { get; set; }
        public string SupressEmailConfirmation { get; set; }
        public string Code { get; set; }
        public decimal OrderQuantity { get; set; }
        public string MaterialName { get; set; }
        public string Carrier { get; set; }
        public string ToLocationName { get; set; }
        public string ShipToTypeName { get; set; }
        public string ToContractName { get; set; }
        public string ShipFromTypeName { get; set; }
        public string FromContractName { get; set; }
        public string FromLocationName { get; set; }
        public string EquipmentTypeName { get; set; }
        public int EquivalentPallets { get; set; }
        public int PropertyValue { get; set; }
        public int ExternalReferenceNumber { get; set; }
        public string OrderSourceSystem { get; set; }

    }


    public partial class EditVerifyEquipmentMaterialProperty
    {
        public long materialID { get; set; }
        public long equipmentTypeID { get; set; }
        public int id { get; set; }
        public string code { get; set; }
        public long propertyValue { get; set; }
        public string propertiesUOM { get; set; }
        public int sno { get; set; }
        public long materialWeight { get; set; }
        public string materialName { get; set; }
    }

    public partial class SaveVerifyEquipmentMaterialProperty
    {
        public long materialID { get; set; }
        public long equipmentTypeID { get; set; }
        public long propertyValueUP { get; set; }
        public long propertyValuePE { get; set; }
        public long propertyValueUE { get; set; }
        public long materialWeight { get; set; }
        public long idUP { get; set; }
        public long idPE { get; set; }
        public long idUE { get; set; }
        public string codeUP { get; set; }

        public string codePE { get; set; }
        public string codeUE { get; set; }
        public string propertiesUOMUP { get; set; }
        public string propertiesUOMPE { get; set; }

        public string propertiesUOMUE { get; set; }
        public long clientID { get; set; }
        public string createdBy { get; set; }
    }

    public partial class RequestObjectMaterialProperties
    {
        public string materialID { get; set; }
        public long equipmentTypeID { get; set; }
    }

    public partial class MaterialPropertiesGrid
    {
        public long MaterialID { get; set; }
        public long EquipmentID { get; set; }

        public long ID { get; set; }

        public double MaterialWeight { get; set; }

        public long UnitInPallet { get; set; }

        public long PalletInEquipement { get; set; }

        public long UnitInEquipement { get; set; }

        public string MaterialName { get; set; }
    }

    public partial class RequestObjectMaterialPropertiesGrid
    {
        public int ClientID { get; set; }

        public string UserName { get; set; }

        public List<MaterialPropertiesGrid> materialPropertiesGrids { get; set; }

    }


    public class RequestObjectChargeFormulaeCalculation
    {
        public int? Quantity { get; set; }
        public int RateTypeID { get; set; }
        public double RateValue { get; set; }
        public double ChargeUnit { get; set; }
        public int PricemethodID { get; set; }
        public int? TotalPallets { get; set; }
        public int? EquipmentTypeID { get; set; }
        public long? LocationID { get; set; }
        public long? OrderID { get; set; }
        public double TotalAmount { get; set; }
        public double Percentage { get; set; }
        public int? TotalQuantity { get; set; }
    }
}
