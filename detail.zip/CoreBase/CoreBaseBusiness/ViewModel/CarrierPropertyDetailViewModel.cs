﻿namespace CoreBaseBusiness.ViewModel
{
    public partial class CarrierPropertyDetailViewModel : BaseViewModel
    {
        public string Ids { get; set; }

        public long CarrierId { get; set; }

        public int? EntityPropertyId { get; set; }

        public string EntityPropertyCode { get; set; }

        public string PropertyValue { get; set; }

        public string PropertiesUom { get; set; }

        public string PageAction { get; set; }

        public string DisplayName { get; set; }
    }

}
