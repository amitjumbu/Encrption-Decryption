﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage;
using NPOI.Util;

namespace CoreBaseBusiness.ViewModel
{
    public partial class MaterialViewModel : BaseViewModel
    {
        public string Code { get; set; }

        public string HierarchyCode { get; set; }
        public string Sku { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long MaterialHierarchyId { get; set; }
        public DateTime? EffectiveStartDate { get; set; }
        public DateTime? EffectiveEndDate { get; set; }
        public bool? SetupComplete { get; set; }
        public DateTime? SetupCompleteDateTime { get; set; }
        public bool? IsReserve { get; set; }
        public long? DefaultCommodityId { get; set; }
        public string ExternalSourceMaterialKey { get; set; }
        public int? DefaultUOMID { get; set; }
        public string CommodityName { get; set; }
        public string UOMCode { get; set; }
        public int BoldFlag { get; set; }

        public virtual MaterialHierarchy MaterialHierarchy { get; set; }
        public virtual ICollection<MaterialPropertyDetail> MaterialPropertyDetail { get; set; }



    }

    public class MaterialQuantityRequestModel
    {
        public long EquipmentTypeID { get; set; }
        public long MaterialId { get; set; }
        public string EntityPropertyCode { get; set; }
        public int ClientID { get; set; }

        public long ID { get; set; }

        public string PropertyValue { get; set; }
        public string PropertiesUOM { get; set; }
        public long LocationID { get; set; }


    }

    public class LocationMaterialModel
    {
        public LocationMaterialModel()
        {
           // this.MaterialProperties = new List<MaterialEquipmentMappingPropertyDefaultValues>();
        }
        public long MaterialID { get; set; }
        public long Quantity { get; set; }
        public string Name { get; set; }
        public long ShippedQuantity { get; set; }
        public int? UOMID { get; set; }
        public string PropertyValue { get; set; }
        public string Code { get; set; }
        public long Pallets { get; set; }
        public int Flag { get; set; }
        public int BagFlag { get; set; }
        public string UOMCODE { get; set; }


    }

    public class MaterialCommonModel
    {
        public long LocationID { get; set; }
        public string EntityPropertyCode { get; set; }
        public int ClientID { get; set; }

        public long EquipmentTypeID { get; set; }

        public long ContractID { get; set; }

        public long UserID { get; set; }

        public long? OrderID { get; set; }
        public int? OrderTypeID { get; set; }

    }

    public class ShippmentMaterialModel
    {
        public long MaterialID { get; set; }
        public long Quantity { get; set; }
        public string Name { get; set; }
        public int EntityPropertyId { get; set; }
        public long ShippedQuantity { get; set; }
        public int? UOMID { get; set; }
        public string PropertyValue { get; set; }
        public string Code { get; set; }
        public long Pallets { get; set; }
        public int Flag { get; set; }
        public int BagFlag { get; set; }
        public string UOMCODE { get; set; }

    }


    public class AllMaterialQuantityRequestModel
    {
        public MaterialQuantityRequestModel MaterialQuantityRequestModel { get; set; }
        public List<MeterialDetailViewModel> Materials { get; set; }
    }

    public class MaterialCommodityMapViewModel : BaseViewModel
    {
        public string Code { get; set; }
        public string SKU { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public long MaterialHierarchyID { get; set; }
        public DateTime? EffectiveStartDate { get; set; }
        public DateTime? EffectiveEndDate { get; set; }
        public string SetupDone { get; set; }
        public bool? SetupComplete { get; set; }
        public DateTime? SetupCompleteDateTime { get; set; }
        public string Status { get; set; }
        public string IsReserveStr { get; set; }
        public bool? IsReserve { get; set; }
        public long? DefaultCommodityID { get; set; }
        public string ExternalSourceMaterialKey { get; set; }
        public string DefaultCommodity { get; set; }
        public string MaterialHierarchyName { get; set; }
    }
    public class CommonOrder : BaseViewModel
    {
        public decimal SalesOrderHeaderID { get; set; }
        public DateTime? OrderDate { get; set; }
        public string OrderNumber { get; set; }
        public string ShipToAddress { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public decimal OrderStatusCode { get; set; }
        public string OrderStatus { get; set; }
        public decimal? AvailableCreditFromMAS { get; set; }
        public decimal? OrderAmount { get; set; }
        public decimal? RemainingCredit { get; set; }
        public bool? OverrideCreditHold { get; set; }
        public decimal? RuningTotal { get; set; }
        public string Comment { get; set; }
        public int? IsMass { get; set; }
        public int? OrganizationID { get; set; }
    }

    public class MaterialCommodityRequestModel
    {
        public MaterialQuantityRequestModel MaterialQuantityRequestModel { get; set; }
        public List<MaterialViewModel> Materials { get; set; }
    }




   public class  DefaultMaterialProperty
    {
        public int MaterialPriceMethodID { get; set; }
        public string MaterialPriceMethod { get; set; }
        public int PalletPriceMethodID { get; set; }
        public string PalletPriceMethod { get; set; }
        
        public bool ShowOnBOL { get; set; }
    }

    public class MaterialCommodityDeleteModel    {
        public string IDs { get; set; }
    }

    public class MaterialPalletsCalculation
    {
        public int SalesOrderID { get; set; }
        public int ClientID { get; set; }
        public int Bags { get; set; }
        public string Name { get; set; }
        public long EquipmentTypeId { get; set; }
        public long MaterialID { get; set; }
        public int PropertyValue { get; set; }
        public long Quantity { get; set; }
        public int Pallets { get; set; }
    }

    public class ContractMaterialModel
    {
        public int ClientID { get; set; }
        public long ContractID { get; set; }
        public long LocationID { get; set; }


    }
}
