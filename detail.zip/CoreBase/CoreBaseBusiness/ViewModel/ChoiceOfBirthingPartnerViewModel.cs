﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.ViewModel
{
    public partial class ChoiceOfBirthingPartnerViewModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        //public string Description { get; set; }
        //public bool IsDeleted { get; set; }
        //public int? ClientId { get; set; }
        //public int? SourceSystemId { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }
        //public ResponseMessages ResponseMessageCode { get; set; }
        //public string ResponseMessage
        //{
        //    get
        //    {
        //        if (ResponseMessageCode == ResponseMessages.None)
        //            return ResponseMessages.Success.ToString();
        //        return this.ResponseMessageCode.ToString();
        //    }
        //}
        //public int PageNo { get; set; }
        //public int PageSize { get; set; }


    }
}
