﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CoreBaseBusiness.ViewModel
{
    public partial class MaterialPropertyDetailViewModel
    {
        public long ID { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public int MaterialPropertyID { get; set; }
        public string ControlDisplayValue { get; set; }
        public string MaterialPropertyValue { get; set; }
        public string MaterialPropertyValueUOM { get; set; }
        public long MatpDID { get; set; }
        public long MaterialID { get; set; }
        public string MatCode { get; set; }
        public string MatName { get; set; }
        public int? ValidationId { get; set; }
        public bool? IsVisible { get; set; }
        public bool? IsEditable { get; set; }
        public bool? RequiredUom { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
    }

    public partial class MatPropDetailFromSelectedMatViewModel
    {
        public long First { get; set; }

        public long Second { get; set; }
    }

    public class MaterialPropertyDetailDeleteModel
    {
        public string IDs { get; set; }
    }
}
