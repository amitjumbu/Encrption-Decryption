﻿using CoreBaseBusiness.ViewModel;
using System;
using System.Collections.Generic;
using System.Text; 

namespace CoreBaseBusiness.ViewModel
{
    public class AuditTrailViewModel : BaseViewModel
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public string ColumnValue { get; set; }
        public string AuditData { get; set; }
        public string AuditBy { get; set; }
        public string AuditOn { get; set; }
    }
}
