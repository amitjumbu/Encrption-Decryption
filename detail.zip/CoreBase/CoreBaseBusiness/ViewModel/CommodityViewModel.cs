﻿namespace CoreBaseBusiness.ViewModel
{
    using CoreBaseBusiness.Helpers.Enums;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public partial class CommodityViewModel : BaseViewModel
    {
        public CommodityViewModel()
        {

        }

        //public long ID { get; set; }
        public long CommodityTypeID { get; set; }
        public long? DepartmentID { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        //public bool IsDeleted { get; set; }
        //public int? ClientID { get; set; }
        //public int? SourceSystemID { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }

        public string CommodityTypeName { get; set; }

        public string SegmentDescription { get; set; }

        //public ResponseMessages ResponseMessageCode { get; set; }

        //public string ResponseMessage
        //{
        //    get
        //    {
        //        if (this.ResponseMessageCode == ResponseMessages.None)
        //        {
        //            return ResponseMessages.Success.ToString();
        //        }

        //        return this.ResponseMessageCode.ToString();
        //    }
        //}

        //public int PageNo { get; set; }

        //public int PageSize { get; set; }
    }

    public class CommodityDelete
    {
        public string IDs { get; set; }

    }
}
