﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class FreightLaneViewModel : BaseViewModel
    {
        // public long Id { get; set; }
        public long? FreightLaneDetId { get; set; }
        public string FromCountry { get; set; }
        public string FromState { get; set; }
        public string FromCity { get; set; }
        public string FromZipcode { get; set; }
        public string ToCountry { get; set; }
        public string ToState { get; set; }
        public string ToCity { get; set; }
        public string ToZipcode { get; set; }
        public string Carrier { get; set; }
        public decimal? RatePerLoad { get; set; }
        public string RatePerUom { get; set; }
        public string EquipmentType { get; set; }
        public string FreightMode { get; set; }
        public int? FreightLaneTypeId { get; set; }
        public int? FreightModeId { get; set; }
        public int FromGeoLocationId { get; set; }
        public int ToGeoLocationId { get; set; }
        //public bool? IsActive { get; set; }
        public decimal? Distance { get; set; }
        public int? DistanceUomid { get; set; }
        public decimal? TravelTime { get; set; }
        public int? TravelTimeUomid { get; set; }
        public decimal? TravelTimeInDays { get; set; }

        public long FreightLaneId { get; set; }
        public long CarrierID { get; set; }
        public long? EquipmentTypeID { get; set; }
        public long? MaterialId { get; set; }
        public decimal? Quantity { get; set; }
        public int? QuantityUomid { get; set; }
        public decimal? CostPerUnit { get; set; }
        public int? CostUOMID { get; set; }
        //excel Import
        public string RateType { get; set; }
        public string CarrierSCAC { get; set; }
        public string OriginCountry { get; set; }
        public string OriginCity { get; set; }
        public string OriginState { get; set; }
        public string DestinationCountry { get; set; }
        public string DestinationCity { get; set; }
        public string DestinationState { get; set; }
        public string TransitDays { get; set; }
        public string RateUOM { get; set; }
        public string Rate { get; set; }
        public string MinCharge { get; set; }
        public string MaxCharge { get; set; }
      //  public string EquipmentType { get; set; }
        public string RateEffBeginDate { get; set; }
        public string RateEffEndDate { get; set; }
        public string Funds { get; set; }
        public string ModeType { get; set; }
        public string DistanceUOM { get; set; }
        public string Distances { get; set; }
    }
    public class FreightLaneDelete
    {
        public string IDs { get; set; }

    }
    //public class FreightLaneExcelExport
    //{


    //}
}
