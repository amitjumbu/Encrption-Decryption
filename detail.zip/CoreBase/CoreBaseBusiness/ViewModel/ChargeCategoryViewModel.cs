﻿namespace CoreBaseBusiness.ViewModel
{
    using System;

    public class ChargeCategoryViewModel : BaseViewModel
    {
        public ChargeCategoryViewModel() {}
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

    }
}
