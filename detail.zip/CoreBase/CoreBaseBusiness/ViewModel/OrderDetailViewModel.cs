﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class OrderDetailViewModel
    {
        public long Id { get; set; }
        public int? OrderTypeId { get; set; }
        public long? FromLocationId { get; set; }
        public long? ToLocationId { get; set; }
        public long? EquipmentTypeId { get; set; }
        public long? FromAddressId { get; set; }
        public long? ParentSalesOrderId { get; set; }
        public string OrderNumber { get; set; }
        public int? OrderVersionNumber { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public long? FromCustomerContractId { get; set; }
        public long? ToCustomerContractId { get; set; }
        public long? FromBusinessPartnerContractId { get; set; }
        public long? ToBusinessPartnerContractId { get; set; }
        public int? ShipmentFlowId { get; set; }
        public long? ShipToCustomerId { get; set; }
        public long? BillToCustomerId { get; set; }
        public long? BillToOrgAddressId { get; set; }
        public long? ShipFromLocationContactId { get; set; }
        public long? ShipToLocationContactId { get; set; }
        public long? ShipToCustomerContactAddressId { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime OrderEntryDate { get; set; }
        public int? CreditHoldFlag { get; set; }
        public int? HeaderHoldFlag { get; set; }
        public string SupressEmailConfirmation { get; set; }
        public DateTime? RequestedDeliveryDate { get; set; }
        public DateTime? MustDeliverByDate { get; set; }
        public int? Cpufreight { get; set; }
        public int? StatusCode { get; set; }
        public DateTime? StatusDateTime { get; set; }
        public string Comments { get; set; }
        public DateTime? ScheduledShipDate { get; set; }
        public int? ArchargesSentToAccounting { get; set; }
        public bool? OverrideCreditHold { get; set; }
        public bool? NeedToSendNotification { get; set; }
        public bool HasClaim { get; set; }
        public string TransportationComment { get; set; }
        public string LoadingComment { get; set; }
        public decimal? ShipmentId { get; set; }
        public int? ShipmentConditionId { get; set; }
        public byte[] RowVersion { get; set; }
        public bool? DropTrailer { get; set; }
        public long? CarrierId { get; set; }
        public string SpanishTransportationComment { get; set; }
        public string SpanishLoadingComment { get; set; }
        public string SpanishShipmentComment { get; set; }
        public string TransplaceOrderComment { get; set; }
        public string TransplaceDeliveryComment { get; set; }
        public string TrailerNumber { get; set; }
        public string TrailerSealNumber { get; set; }
        public string TransplaceOrderCommentSpanish { get; set; }
        public string TransplaceDeliveryCommentSpanish { get; set; }
        public bool? IsDiverted { get; set; }
        public decimal? ChargeRatePerMile { get; set; }
        public decimal? CustomerMiles { get; set; }
        public decimal? CustomerPercent { get; set; }
        public decimal? AllocatedFreightCharge { get; set; }
        public DateTime? EstimatedDeliveryDate { get; set; }
        public string InvoiceNo { get; set; }
        public string AdditionalInstructionComment { get; set; }


    }

    public class OrderRequestedMaterialsViewModel
    {
        public long OrderID { get; set; }

        public long MaterialGroupID { get; set; }

        public int ClientID { get; set; }

        /// <summary>
        /// 0 For Add/Edit Material.
        /// 1 For Adjust Material Section.
        /// 3 For Adjust Chagre Section.
        /// </summary>
        public int SectionID { get; set; }

        public int? OrderTypeID { get; set; }
    }

    public class RequestDataPriceMethodAndComputationMethod
    {
        public long MaterialID { get; set; }

        public long ChargeID { get; set; }

        public long ShipTOLocationID { get; set; }

        public long ContractID { get; set; }

        public int? ClientID { get; set; }

        /// <summary>
        /// O : for computation method.
        /// 1 : for Price method.
        /// </summary>
        public int Type { get; set; }
    }

    public class PriceMethodViewModel
    {
        public int STATUS { get; set; }

        public int PriceMethodTypeID { get; set; }
    }

    public class ComputationMethodViewModel
    {
        public long ID { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public string ChargeComputationMethodComments { get; set; }
    }

    public class RequestCommonViewModel
    {
        public long ContractID { get; set; }

        public long MaterialID { get; set; }

        public long ShipToLocationID { get; set; }

        public long ShipFromLocationID { get; set; }

        public int ContractType { get; set; }

        public string ContactTypeCode { get; set; }

        public int? ClientID { get; set; }

        public long ChargeID { get; set; }

        public List<MeterialDetailViewModel> Materials { get; set; }


        public long? OrderID { get; set; }

        public int? OrderTypeID { get; set; }

        public string ValidDate { get; set; }
    }

    public class MeterialDetailViewModel
    {
        public long MaterialID { get; set; }

        public string MaterialName { get; set; }

        public string RateType { get; set; }

        public long RateTypeID { get; set; }

        public long Quantity { get; set; }

        public string Type { get; set; }

        public string MaterialHiraryCode { get; set; }

        public long ChargeID { get; set; }
    }

    public class ResponseAdjustChargesWithDefaultData
    {
        public List<ResponseAdjustCharges> ResponseAdjustCharges { get; set; }

        public List<ResponseAdjustCharges> ResponseContractDefaultRateValue { get; set; }


        public List<ResponseAdjustCharges> allContractDetailValue { get; set; }
    }


    public class ResponseAdjustCharges
    {
        public ResponseAdjustCharges()
        {
            this.overrideCommodityID = 0;
            this.overrideCommodityName = "";
            this.overridePriceMethodID = 0;
            this.overridePriceMethodName = "";
            this.overrideRateTypeID = 0;
            this.overrideRateTypeName = "";
            this.overrideRateValue = 0;
            this.overrideAmount = 0;
        }
        public long? MaterialID { get; set; }

        public string MaterialName { get; set; }

        public long ChargeID { get; set; }

        public string ChargeName { get; set; }

        public decimal RateValue { get; set; }

        public bool ShowOnBOL { get; set; }

        public string PriceMethod { get; set; }

        public int PriceMethodID { get; set; }

        public string RateTypeName { get; set; }

        public long RateTypeID { get; set; }

        public string CommodityName { get; set; }

        public long CommodityID { get; set; }

        public string RateType { get; set; }

        public long OrderQuantity { get; set; }

        public long ShippedQuantity { get; set; }

        public decimal Amount { get; set; }

        public bool IsManual { get; set; }

        public string type { get; set; }

        public decimal overrideRateValue { get; set; }

        public long overrideCommodityID { get; set; }

        public string overrideCommodityName { get; set; }

        public long overrideRateTypeID { get; set; }

        public string overrideRateTypeName { get; set; }

        public long overridePriceMethodID { get; set; }

        public string overridePriceMethodName { get; set; }

        public decimal overrideAmount { get; set; }

        public bool overrideShowOnBOL { get; set; }

        public bool isEdited { get; set; }

        public decimal QuantityPerUOM { get; set; }

        public decimal ToatalPalletBag { get; set; }

        public decimal ChargeUnit { get; set; }

        public int IsRequired { get; set; }

        public decimal FullAmount { get; set; }

        public bool IsAutoAdded { get; set; }
        public bool IsDefault { get; set; }
        public bool IsModified { get; set; }
    }

    public class OrderRequestViewModel
    {
        public long OrderID { get; set; }

        public long OrderTypeID { get; set; }

        public int? ClientID { get; set; }
    }

    public class AvailableCreaditViewModel
    {
        [Required]
        public DateTime RequestedOrderDate { get; set; }

        [Required]
        public long LocationID { get; set; }

        public int? ClientID { get; set; }
    }

    public class FuelChargesViewModel
    {
        public string ChargeRatePerMile { get; set; }

        public string CustomerMiles { get; set; }

        public string CustomerPercent { get; set; }
    }

    public class MaterialEquipmentValidation
    {
        public long EquipmentID { get; set; }

        public int ClientID { get; set; }

        public List<OrderMaterials> MaterialList { get; set; }
    }

    public class ValidationResponse
    {
        public bool IsValid { get; set; }

        public string Message { get; set; }

        public bool IsConfirmation { get; set; }
    }

    public class RegularOrderValidationResponse
    {
        public ValidationResponse validationResponse { get; set; }

        public List<MaterialPropertiesGrid> editVerifyEquipmentMaterialProperties { get; set; }
    }

    public class CalculateOrderCharges
    {

        public int? MaterialID { get; set; }

        public int ChargeID { get; set; }

        public int RateTypeID { get; set; }

        public string RateTypeName { get; set; }

        public decimal RateValue { get; set; }

        public decimal Amount { get; set; }

        public long Qunatity { get; set; }

        [Required]
        public long ContractID { get; set; }

        public string ContractCode { get; set; }

        [Required]
        public long LocationID { get; set; }

        [Required]
        public DateTime RequestedDelieveryDate { get; set; }
    }

    public class ContractDropdownViewModel
    {
        public long Id { get; set; }
        public string ContractNumber { get; set; }

        public string Code { get; set; }

        public string ContractType { get; set; }
    }

    public class RateValueCalculator
    {
        [Required]
        public long Quantity { get; set; }

        [Required]
        public decimal RateValue { get; set; }

        [Required]
        public string RateType { get; set; }

        public decimal Amount { get; set; }

    }


    public class ARChargesListAutoAddedList
    {
        public long MaterialID { get; set; }
        public long ChargeID { get; set; }
        public int Quantity { get; set; }
        public int EquivalentPallet { get; set; }
        public int ChargeComputationMethodID { get; set; }
        public int CommodityID { get; set; }
        public int PriceMethodTypeID { get; set; }
        public decimal RateValue { get; set; }
        public decimal InvoiceAmount { get; set; }
        public int SeqNO { get; set; }
        public bool ShowOnBOL { get; set; }


    }


}
