﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.ViewModel
{
    public partial class LocationViewModel : BaseViewModel
    {
        public int LocationTypeId { get; set; }
        public int LocationId { get; set; }
        public int LocationFunctionId { get; set; }
        public string LocationFunctionName { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsPrimary { get; set; }
        public long? DefaultCommodityID { get; set; }
        public int? TimeZoneId { get; set; }
        public string CovidAccepting { get; set; }
        public long? OrganizationId { get; set; }
        public string OrganisationName { get; set; }
        public string OrganisationDescription { get; set; }
        public string CountryCode { get; set; }

        public string StateCode { get; set; }

        public string CityCode { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public string CountryName { get; set; }

        public string ZipCode { get; set; }
        public string OrderComment { get; set; }
        public string TransportationComment { get; set; }
        public string LoadingComment { get; set; }
        public string ShippingInstructionsDescription { get; set; }
        public bool? SetupComplete { get; set; }
        public DateTime? SetupCompleteDateTime { get; set; }
        public string SetupCompleteBy { get; set; }
        public string ExternalSourceLocationKey { get; set; }
        public string LocationTypeCode { get; set; }
        public string LocationTypeName { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
    }
    public class CollectHospialIDs
    {
        public string IDs { get; set; }
        public bool isActive { get; set; }

    }

    public class LocationDeleteModel
    {
        public int[] ids { get; set; }

        public string deletedBy { get; set; }

    }

    public class LocationPropertyDeleteModel
    {
        public int LocationId { get; set; }

        public string LocationTypeCode { get; set; }

        public int[] Ids { get; set; }

        public string DeletedBy { get; set; }

    }

    public class VerifyOrderLocationViewModel
    {
        public long? TolocationID { get; set; }
        public bool IsValidToLocation { get; set; }
        public long? FromlocationID { get; set; }
        public bool IsValidFromLocation { get; set; }
    }

    public class LocationForClaim
    {
        public long ID { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public long EntityId { get; set; }
       


    }
}
