﻿using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class MouldingViewModel
    {
        public bool IsChartHistory { get; set; }

        public long Id { get; set; }
        public string ReferenceNo { get; set; }
        public long? PatientId { get; set; }
        public long? PartographId { get; set; }
        public int? StagesId { get; set; }
        public string ChartValue { get; set; }
        public int? Uomid { get; set; }
        public decimal? XAxisPosition { get; set; }
        public decimal? YAxisPosition { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public Boolean IsAll { get; set; }
        public bool? IsVisible { get; set; }

        public virtual Partograph Partograph { get; set; }
        public virtual Patient Patient { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }

        public ICollection<MouldingCommentViewModel> Comments { get; set; }

        public ICollection<MouldingMediaViewModel> Medias { get; set; }
    }
} 