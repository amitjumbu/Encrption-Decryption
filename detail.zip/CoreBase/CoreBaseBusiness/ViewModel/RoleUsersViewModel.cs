﻿namespace CoreBaseBusiness.ViewModel
{
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    public class RoleUsersViewModel
    {
        public long ID { get; set; }

        public string Name { get; set; }
    }

    public class LocationwiseUsersViewModel
    {
        public long LocationID { get; set; }

        public int? ClientID { get; set; }
    }

}
