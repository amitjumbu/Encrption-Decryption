﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class BusinessPartnerContractViewModel
    {
       

        public long Id { get; set; }
        public string Code { get; set; }
        public string ContractNumber { get; set; }
        public string Description { get; set; }
        public long? ParentId { get; set; }
        public long? LocationId { get; set; }
        public int? ContractTypeId { get; set; }
        public int ContractVersion { get; set; }
        public string ContractVersionString { get; set; }
        public DateTime? TermStartDate { get; set; }
        public DateTime? TermEndDate { get; set; }
        public int? ContractEndAlertDays { get; set; }
        public string ShippingInstructions { get; set; }
        public bool? SetupComplete { get; set; }
        public DateTime? SetupCompleteDateTime { get; set; }
        public string TransportationComment { get; set; }
        public string LoadingComment { get; set; }
        public byte[] RowVersion { get; set; }
        public string ContractComment { get; set; }
        public int? IsActive { get; set; }
        public DateTime? EarliestPriceEndDate { get; set; }
        public string OrderComment { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }



    }
}
