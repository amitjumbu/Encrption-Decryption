﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class ResourceOnResourceRoleViewModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string PhysicianName { get; set; }
        public bool IsDeleted { get; set; }
        public long ClientId { get; set; }
        public bool IsActive { get; set; }
        public long LocationID { get; set; }
        public long ResourceTypeID { get; set; }
        public long ResourceRoleID { get; set; }
        public string ResourceRoleCode { get; set; }
        public string ResourceRoleName { get; set; }
    }
}