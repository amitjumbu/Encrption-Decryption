﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public class ForecastViewModel : BaseViewModel
    {
        public ForecastViewModel()
        {
            ForecastDetailViewModel = new HashSet<ForecastDetailViewModel>();
        }

        public int? ForecastTypeId { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsActive { get; set; }

        public long? HistoricalForecastId { get; set; }

        public int? CalendarTypeId { get; set; }

        public int? NoOfDaysInAperiod { get; set; }

        public List<int> SalesManagerIds { get; set; }

        public virtual ForecastTypeViewModel ForecastType { get; set; }
        public virtual ICollection<ForecastDetailViewModel> ForecastDetailViewModel { get; set; }

    }

}
