﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class DynamicWebcontrolParameterViewModel
    {

        public string StageCode { get; set; }
        public string webControlType { get; set; }
        public string Code { get; set; }
        public string ControlName { get; set; }
        public string HeadName { get; set; }
        public int WebControlTypeID { get; set; }
        public string ParameterValue { get; set; }

        public int DynamicMeasurementParameterID { get; set; }

        public string ParameterValueComment { get; set; }
        public int? ClientId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public string Mode { get; set; }

        public string UOM { get; set; }

        public int PatientID { get; set; }
        public int PartographID { get; set; }
        public List<CoreBaseData.Models.Entity2.WebControlTypePossibleValue> webcontorlTypePossibleValues { get; set; }
        public object validations { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }


    }
}
