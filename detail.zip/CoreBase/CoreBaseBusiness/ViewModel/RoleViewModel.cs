using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public class RoleViewModel : BaseViewModel
    {
        public RoleViewModel()
        {

        }
        public string RoleName { get; set; }
        public string Description { get; set; }
        public bool IsSystem { get; set; }
        
    }
}