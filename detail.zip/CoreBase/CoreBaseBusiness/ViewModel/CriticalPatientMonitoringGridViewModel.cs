﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class CriticalPatientMonitoringGridViewModel
    {
        public long Id { get; set; }
        public string Code { get; set; }
        public int PartogrpahId { get; set; }
        public DateTime Date1 { get; set; }
        public string Time1 { get; set; }
        public decimal Temp { get; set; }
        public decimal PulseRate { get; set; }
        public string BloodPressure { get; set; }
        public decimal RespiratoryRate { get; set; }
        public decimal Spo2 { get; set; }
        public decimal AbdominalGirth { get; set; }
        public string PerAbdominalExam { get; set; }
        public string LocalExamination { get; set; }
        public string UrinaryOutput { get; set; }
        public string Drain { get; set; }
        public string KneeReflex { get; set; }
        public string RyleTube { get; set; }
        public string Comments { get; set; }
        public bool IsDeleted { get; set; }
        public int ClientId { get; set; }
        public int SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
} 