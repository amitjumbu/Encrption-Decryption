﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class ContractionsPer10MinViewModel
    {
        public long Id { get; set; }
        public string ReferenceNo { get; set; }
        public long? PatientId { get; set; }
        public long? PartographId { get; set; }
        public int? StagesId { get; set; }
        public string ChartValue { get; set; }
        public int? Uomid { get; set; }
        public decimal? XAxisPosition { get; set; }
        public decimal? YAxisPosition { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public Boolean IsVisible { get; set; }

        public Boolean IsAll { get; set; }
        public decimal? IntialPosition { get; set; }

        public decimal? PreviousPosition { get; set; }

        public string PatternValue { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }

        //public int InitialPos { get; set; }
        //public int PatternValue { get; set; }
        //public string PreviousPoint { get; set; }

        //public bool IsAll { get; set; }
        public ICollection<ContractionsPer10MinCommentViewModel> Comments { get; set; }

        public ICollection<ContractionsPer10MinMediaViewModel> Medias { get; set; }
    }
} 