﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class ClaimViewModel : BaseViewModel
    {
        public ClaimViewModel()
        {

        }
        public string FilterOn { get; set; }
        public Int64 ClaimId { get; set; }
        public string ClaimStatus { get; set; }
        // public int ClaimStatusId { get; set; }
        public string ClaimFor { get; set; }
        //  public int ClaimForId { get; set; }
        public string BillingEntity { get; set; }
        public string Customer { get; set; }
        public string BusinessPartner { get; set; }
        public decimal InvoicedAmount { get; set; }
        public decimal ClaimAmount { get; set; }
        public decimal ApprovedAmount { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? CreateDateTimeServer { get; set; }
        public string ApprovedBy { get; set; }
        public string SortColumn { get; set; }
        public string SortOrder { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public string Title { get; set; }

    }

    public class ClaimFilterParameter
    {
        public long ShipmentID { get; set; }
        public int ClientID { get; set; }
        public long OrderID { get; set; }
        public long ClaimID { get; set; }
        public int ClaimFor { get; set; }



    }

    public class ClaimDetailModel
    {
        public long ID { get; set; }
        public long ClaimID { get; set; }
        public int ClientID { get; set; }
        public long BusinessLocationID { get; set; }
        public long CustomerLocationID { get; set; }
        public long FromLocationID { get; set; }
        public long ToLocationID { get; set; }
        public long MaterialID { get; set; }
        public long ChargeID { get; set; }
        public long ShippedQuantity { get; set; }
        public decimal InvoicedAmount { get; set; }
        public decimal ClaimedQuantity { get; set; }
        public decimal ClaimAmount { get; set; }
        public decimal RecommendedAmount { get; set; }
        public decimal ApprovedAmount { get; set; }
        public string InvoiceNumber { get; set; }
        public long StatusID { get; set; }
        public string ApproverComment { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreateDateTimeBrowser { get; set; }
    }
    public class ResponseModel
    {
        public string Status { get; set; }
        public string Message { get; set; }

    }
    public class ClaimModel
    {
        public string ClaimComments { get; set; }
        public long ClaimForID { get; set; }
        public long ClaimID { get; set; }
        public long ClaimStatusID { get; set; }
        public long ClientID { get; set; }
        public string CreateDateTimeBrowser { get; set; }
        public string CreateDateTimeServer { get; set; }
        public string CreatedBy { get; set; }
        public string DateSubmitted { get; set; }
        public long? EntityId { get; set; }
        public long? EntityKeyId { get; set; }
        public string FromshipdatecalendarDate { get; set; }
        public Boolean IsDeleted { get; set; }
        public long? LocationId { get; set; }
        public string ToshipdatecalendarDate { get; set; }
        public string UpdateDateTimeServer { get; set; }

        public string InvoiceNumber { get; set; }
        public string Claimamount { get; set; }
        public string Approvedamount { get; set; }
        public Boolean IsSetupAndNotify { get; set; }
        public Boolean IsApproved { get; set; }
    }

    public class ClaimDetailModelUP
    {
        public long ID { get; set; }
        public long ClaimID { get; set; }
        public long? MaterialID { get; set; }
        public long? ChargeID { get; set; }
        public decimal? InvoicedQuantity { get; set; }
        public decimal? InvoicedAmount { get; set; }
        public int? InvoicedAmountUOMID { get; set; }
        public decimal? ApprovedAmount { get; set; }
        public decimal? ClaimAmount { get; set; }
        public decimal? ClaimedQuantity { get; set; }
        public decimal? ApprovedQuantity { get; set; }
        public long? LocationID { get; set; }
        public string Comments { get; set; }
        public int ClaimStatusID { get; set; }
        public string InvoiceNumber { get; set; }
        public decimal? RecommendedAmount { get; set; }
        public int? ClientID { get; set; }
        public string CreatedBy { get; set; }
        public int IsDeleted { get; set; }


    }

    public class MultiClaimModel
    {

        public string CreateDateTimeBrowser { get; set; }
        public ClaimDetailModelUP[] claimDetailModelUP { get; set; }
    }
}
