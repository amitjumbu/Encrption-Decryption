﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public class ForecastChildViewModel : BaseViewModel
    {
        public ForecastChildViewModel()
        {

        }
        public long ID { get; set; }
        public long ParentForecastID { get; set; }
        public string ParentForecastName { get; set; }
        public string ParentForecastDescription { get; set; }
        public string ParentForecastCode { get; set; }
        public string ChildForecastName { get; set; }
        public string ChildForecastDescription { get; set; }
        public string ChildForecastCode { get; set; }
        public long ForecastImportActionTypeID { get; set; }
        public string ForecastImportActionTypeName { get; set; }
        public string ForecastImportActionTypeCode { get; set; }
        public DateTime ImportedDateTime { get; set; }
        public string ImportedBy { get; set; }

    }

}
