﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    public class OperatingLocationListViewModel : BaseViewModel
    {
        //public int ID { get; set; }
        public string LocationFunction { get; set; }
        public long LocationId { get; set; }
        public int LocationFunctionID { get; set; }
        public string LocationDescription { get; set; }
        public string EnterPriseName { get; set; }
        public string GroupName { get; set; }
        public string BillingName { get; set; }
        public string CityName { get; set; }
        public string StateName { get; set; }
        public string PropertyValue { get; set; }
        public bool SetupComplete { get; set; }
        public string SetupCompleteBy { get; set; }
        public string SetupCompleteDateTime { get; set; }
        public DateTime SetupCompletedDateTime { get; set; }
        public string MasInventoryWarehouse { get; set; }
        public long OrganizationID { get; set; }
        public string OrganizationName { get; set; }
        public int isShippingAdress { get; set; }

        public string LocationFunctionType { get; set; }
    }
   
}
