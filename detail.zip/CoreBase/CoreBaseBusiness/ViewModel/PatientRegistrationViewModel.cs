﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class PatientRegistrationViewModel
    {

        public PatientRegistrationViewModel()
        {

        }

        public long Id { get; set; }
        public string ReferenceNo { get; set; }
        public int PatientID { get; set; }
        public long? PartographID { get; set; }
        public DateTime DOB { get; set; }
        public int Age { get; set; }
        public string Sex { get; set; }
        public string DateTimeOfAdmission { get; set; }
        public string CR_OutdoorNo { get; set; }
        public string Booked_RegStered_Emergency { get; set; }
        public string UnitNo { get; set; }
        public string MRD_IndoorNo { get; set; }
        public int? VisitNo { get; set; }
        public string UnitHead { get; set; }
        public int? LiteracyID_Wife { get; set; }
        public int? LiteracyID_Husband { get; set; }
        public string Socio_economicStatus { get; set; }
        public Boolean SelfVisit { get; set; }
        public Boolean? Referred { get; set; }
        public int? ReferredFromResourceContactID { get; set; }
        public string ReasonForReferral { get; set; }
        public DateTime? DateTimeForReferral { get; set; }
        public Boolean? PriorInformation { get; set; }
        public string Comments { get; set; }
        public bool? IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public string AdmittedBy { get; set; }
    }


   
}
