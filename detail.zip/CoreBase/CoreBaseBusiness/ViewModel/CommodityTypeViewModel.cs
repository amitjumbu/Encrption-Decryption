﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class CommodityTypeViewModel : BaseViewModel
    {
        public string Code { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }
    }

    public class CommodityTypeDelete
    {
        public string IDs { get; set; }
    }

    //public class DataReturn
    //{
    //    public object data { get; set; }

    //    public object IsDeleted { get; set; }
    //}
}