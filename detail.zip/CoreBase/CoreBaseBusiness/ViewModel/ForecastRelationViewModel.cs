﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public class ForecastRelationViewModel : BaseViewModel
    {
        public ForecastRelationViewModel()
        {

        }

        public long ParentForecastId { get; set; }

        public string ParentForecastName { get; set; }

        public long ChildForecastId { get; set; }

        public string ChildForecastName { get; set; }

        public int ForecastImportActionTypeId { get; set; }

        public string  ForecastImportActionTypeName { get; set; }


    }


    public class ForecastUploadViewModel
    {
        public ForecastUploadViewModel()
        {
        }

        public string ForecastName { get; set; }
        public string ForecastDesc { get; set; }
        public bool IsOverride { get; set; }
        public long ParentForecastId { get; set; }
        public string CreatedBy { get; set; }

    }

}
