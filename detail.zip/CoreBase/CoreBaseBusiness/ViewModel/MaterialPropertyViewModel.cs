﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CoreBaseBusiness.ViewModel
{
    public partial class MaterialPropertyViewModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string ControlTypeName { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public string MaterialPropertyValueUom { get; set; }
        public int? ValidationId { get; set; }
        public bool? IsVisible { get; set; }
        public bool? IsEditable { get; set; }
        public bool? RequiredUom { get; set; }
    }
    public class MaterialPropertyControlValueViewModel
    {
        public long ID { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string ControlTypeName { get; set; }
        public int MaterialPropertyID { get; set; }
        public string ControlDisplayValue { get; set; }
        public string ControlDatabaseValue { get; set; }
        public string MaterialPropertyValueUOM { get; set; }
        public int ValidationID { get; set; }
        public bool IsVisible { get; set; }
        public bool IsEditable { get; set; }
        public bool RequiredUom { get; set; }
    }

}
