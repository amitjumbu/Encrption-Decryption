﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class MedicationChartGridViewModel
    {
        public long Id { get; set; }
        public long PartographId { get; set; }
        public string NameOfDrugMedicineInjection { get; set; }
        public string Dose { get; set; }
        public string Route { get; set; }
        public DateTime? DateTime1 { get; set; }
        public DateTime? DateTime2 { get; set; }
        public DateTime? DateTime3 { get; set; }
        public DateTime? DateTime4 { get; set; }
        public DateTime? DateTime5 { get; set; }
        public string Comments { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        
    }
} 