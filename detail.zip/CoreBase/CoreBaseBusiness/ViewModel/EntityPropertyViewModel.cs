﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CoreBaseBusiness.ViewModel
{
    public partial class EntityPropertyViewModel
    {
        public EntityPropertyViewModel()
        {
            entityclientPropertyControlValueViewModel = new List<EntityClientPropertyControlValueViewModel>();
        }
        public int Id { get; set; }
        public string ReferenceNo { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public bool IsDeleted { get; set; }
        public long OrganizationID { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public long EntityPropertyID { get; set; }
        public long EntityClientPropertyId { get; set; }
        public string EntityPropertyCode { get; set; }
        public long EntityID { get; set; }
        public string EntityCode { get; set; }
        public string WebControlCode { get; set; }
        public string WebControlName { get; set; }
        public string WebControlDescription { get; set; }
        public bool RequiredUom { get; set; }
        public bool IsEditable { get; set; }
        public List<EntityClientPropertyControlValueViewModel> entityclientPropertyControlValueViewModel { get; set; }
    }
}
