﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class PatientContactValueViewModel : BaseViewModel
    {
        public long ID { get; set; }
        public long PatientID { get; set; }
        public string ReferenceNo { get; set; }
        public int ContactTypeID { get; set; }
        public string Code { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string NickName { get; set; } 
        public string Description { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string WorkPhone { get; set; }
        public string WorkPhoneSalt { get; set; }
        public string WorkPhoneCountryCodeId { get; set; }
        public string MobilePhoneCountryCodeId { get; set; }
        public string MobilePhone { get; set; }
        public string MobilePhoneSalt { get; set; }
        public string Email { get; set; }
        public string EmailSalt { get; set; }
        public string PrimaryEmail { get; set; }
        public bool IsDeleted { get; set; }
        public Nullable<int> ClientID { get; set; }
        public Nullable<int> SourceSystemID { get; set; }
        public string UpdatedBy { get; set; }
        public System.DateTime UpdateDateTimeServer { get; set; }
        public System.DateTime UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreateDateTimeBrowser { get; set; }
        public System.DateTime CreateDateTimeServer { get; set; }

    }
}
