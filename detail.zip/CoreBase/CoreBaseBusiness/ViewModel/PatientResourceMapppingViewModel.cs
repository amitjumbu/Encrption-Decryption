﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
   
    public class PatientResourceMapppingViewModel
    {
        
        public long PatientId { get; set; }

        public long ResourceId { get; set; }

        public int ResourceRoleId { get; set; }

    }
}