﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
  public class AddressDetailsViewModel
    {
        public long ID { get; set; }
        public string AddressFor { get; set; }
        public string ReferenceNo { get; set; }
        public int AddressTypeID { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public long PatientID { get; set; }
        public long OperatingLocationID { get; set; }
        public int GeoLocationID { get; set; }
        public string StreetName1 { get; set; }
        public string StreetName2 { get; set; }
        public string StreetName3 { get; set; }
        public string GeoCode { get; set; }
        public bool IsActive { get; set; }
        
        public bool IsDeleted { get; set; }
        public int ClientID { get; set; }
        public int SourceSystemID { get; set; }
        public string UpdatedBy { get; set; }
        public System.DateTime UpdateDateTimeServer { get; set; }
        public System.DateTime UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreateDateTimeBrowser { get; set; }
        public System.DateTime CreateDateTimeServer { get; set; }

        public ICollection<AddressDetailsViewModel> AddressDetailsModelList;
    }
}
