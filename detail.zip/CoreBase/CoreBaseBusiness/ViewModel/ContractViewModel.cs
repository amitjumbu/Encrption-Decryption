﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class ContractViewModel : BaseViewModel
    {        

        public string Contract_Type { get; set; }
        public int ContractTypeId { get; set; }
        public long LocationID { get; set; }
        public string Contract_No { get; set; }
        public int Version { get; set; }
        public string Customer_Code { get; set; }
        public string Description { get; set; }        
        public string Billing_Entity { get; set; }
        public string Customer_Ship_To_Location { get; set; }
        public string Business_Partner { get; set; }
        
        public DateTime? Effective_Start { get; set; }
        public DateTime? Effective_End { get; set; }
        public DateTime? EarliestPriceEnd { get; set; }
        public string Evergreen { get; set; }
        public int End_Alert_Days { get; set; }
        public string Status { get; set; }
        public string ContractApproved { get; set; }
        public Boolean LocationStatus { get; set; }
        public Boolean LocationSetupComplete { get; set; }
        public DateTime? Approved_Datetime { get; set; }        

    }

    public partial class ContractDetailViewModel
    {
        public int ContractTypeId { get; set; }
        public long Id { get; set; }
        public long BusinessPartnerContractId { get; set; }
        public long CustomerContractId { get; set; }
        public int? PriceMethodTypeId { get; set; }
        public long? MaterialId { get; set; }
        public long? ChargeId { get; set; }
        public int? Uomid { get; set; }
        public long? CommodityId { get; set; }
        public decimal? QuantityPerUom { get; set; }
        public string DetailDescription { get; set; }
        public DateTime? TermStartDate { get; set; }
        public DateTime? TermEndDate { get; set; }
        public bool? ShippingInstructionsNotRequired { get; set; }
        public decimal RateValue { get; set; }
        public int? ChargeComputationMethodId { get; set; }
        public int? ShowOnBol { get; set; }
        public int? IsRequired { get; set; }
        public int? SalesTaxClassId { get; set; }
        public int? PriceIncreaseMethodTypeId { get; set; }
        public int? AddPalletBags { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }
    }
    public partial class ContractShowDetail
    {
        public long ID { get; set; }
        public string MethodType { get; set; }
        public string Material { get; set; }
        public string Charge { get; set; }
        public string UOM { get; set; }
        public string Commodity { get; set; }
        public decimal Quantity_per_UOM { get; set; }
        public DateTime EffectiveStart { get; set; }
        public DateTime EffectiveEnd { get; set; }
        public decimal Rate { get; set; }
        public string RateType { get; set; }
        public int ShowOnBOL { get; set; }
        public int? IsRequired { get; set; }
        public string Sales_Tax_Price { get; set; }
        public string PriceIncreaseMethod { get; set; }
        public int AddPallet { get; set; }
        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }
    }
    public partial class DefiningCharacteristicsViewModel
    {
        public long Id { get; set; }
        public int ContractTypeId { get; set; }
        public long CustomerContractId { get; set; }
        public long BusinessPartnerContractId { get; set; }
        public int EntityPropertyId { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUom { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }
    }
}
