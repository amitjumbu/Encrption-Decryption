﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class LocationForecastMaterialViewModel : BaseViewModel
    {
        public long LocationId { get; set; }

        public long MaterialId { get; set; }

        public string MaterialName { get; set; }

        public string MaterialCode { get; set; }

        public string SelectedMaterialIds { get; set; }
    }

   
}
