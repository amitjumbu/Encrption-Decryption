﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class PGEAlertPopUpViewModel:BaseGraphViewModel
    {
        public ICollection<PGEAlertPopUpCommentViewModel> Comments { get; set; }
        public ICollection<PGEAlertPopUpMediaViewModel> Medias { get; set; }
    }
} 