﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.ViewModel
{
    public partial class LocationContactViewModel
    {  
        public long Id { get; set; }
        public long LocationId { get; set; }
        public string ReferenceNo { get; set; }
        public int ContactTypeId { get; set; }
        public string Code { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string NickName { get; set; }
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        public string WorkPhone { get; set; }
        public string WorkPhoneSalt { get; set; }
        public string WorkPhoneCountryCode { get; set; }
        public string MobilePhoneCountryCode { get; set; }
        public string MobilePhone { get; set; }
        public string MobilePhoneSalt { get; set; }
        public string Email { get; set; }
        public string EmailSalt { get; set; }
        public string PrimaryEmail { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public virtual Location Location { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
}
