﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
   
    public class ContractionsPer10MinCommentViewModel : BaseGraphCommentViewModel
    {
      
        public long ContractionsPer10MinID { get; set; }

        public ContractionsPer10MinViewModel ContractionsPer10Min { get; set; }
    }
}