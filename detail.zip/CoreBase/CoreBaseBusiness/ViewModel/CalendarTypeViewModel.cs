﻿using System;

namespace CoreBaseBusiness.ViewModel
{
    public class CalendarTypeViewModel : BaseViewModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime? CalenderStartDate { get; set; }
        public int? CalenderIntervaldays { get; set; }

    }

}
