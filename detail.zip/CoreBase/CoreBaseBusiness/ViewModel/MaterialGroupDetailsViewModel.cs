﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CoreBaseBusiness.ViewModel
{
    public partial class MaterialGroupDetailsViewModel : BaseViewModel
    {
        public long MaterialGroupID { get; set; }

        public string MaterialGroupValue { get; set; }

        public string MaterialGroupValueDesc { get; set; }
    }
}
