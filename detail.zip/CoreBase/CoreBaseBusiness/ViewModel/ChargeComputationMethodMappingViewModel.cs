﻿namespace CoreBaseBusiness.ViewModel
{
    using System.Collections.Generic;
    public class ChargeComputationMethodMappingViewModel : BaseViewModel
    {

        public ChargeComputationMethodMappingViewModel()
        {
            this.ComputationMappings = new List<ChargeComputationMethodViewModel>();
        }
        public long ChargeId { get; set; }
        public string ChargeDescription { get; set; }
        public string ChargeTypeDescription { get; set; }
        public string ChargeCategoryDescription { get; set; }
        public string ComputationMapping { get; set; }
        public string ComputationMappingDescription { get; set; }
        public List<ChargeComputationMethodViewModel> ComputationMappings { get; set; }

    }

    public class ChargeComputationMethodMappingForOrderViewModel : BaseViewModel
    {

        public ChargeComputationMethodMappingForOrderViewModel()
        {
        }
        public long ChargeId { get; set; }
        
        public int ChargeComputationMethodID { get; set; }
    }
}
