﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class ApplicationPermissionViewModel : BaseViewModel
    {

        public ApplicationPermissionViewModel()
        {
           
        }

        public new int ID { get; set; }

       // [Required]
        public string Code { get; set; }

       
        public string Name { get; set; }
        public string Description { get; set; }

        [Required]
        public long ApplicationElementDetailID { get; set; }
        
        [Required]
        public int RoleID { get; set; }
        // public int PermissionID { get; set; }
        //public bool IsPermitted { get; set; }

        public string ReferenceNo { get; set; }


        public bool AllowView { get; set; }
        public bool AllowUpdate { get; set; }
        public bool AllowApprove { get; set; }

    }



}
