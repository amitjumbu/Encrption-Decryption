﻿using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class AddDynamicMeasurementParameterViewModel
    {

        public int DynamicMesurementId { get; set; }

        public int WebControlTypeID { get; set; }

        public string Name { get; set; }

        public int? ClientId { get; set; }

        public int? SourceSystemId { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? UpdateDateTimeBrowser { get; set; }

        public string StageCode { get; set; }
        public string UOM { get; set; }

        public int? PatientID { get; set; }
        public int? PartographID { get; set; }
    }
}
