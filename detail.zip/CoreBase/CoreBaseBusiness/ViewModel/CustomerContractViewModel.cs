﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class CustomerContractViewModel
    {


        public long Id { get; set; }
        public string Code { get; set; }
        public string ContractNumber { get; set; }
        public string Description { get; set; }
        public long? ParentId { get; set; }
        public long? LocationId { get; set; }
        public int? ContractTypeId { get; set; }
        public int ContractVersion { get; set; }
        public string ContractVersionString { get; set; }
        public DateTime? TermStartDate { get; set; }
        public string TermStartDateStr { get; set; }
        public DateTime? TermEndDate { get; set; }
        public string TermEndDateStr { get; set; }
        public int? ContractEndAlertDays { get; set; }
        public string ShippingInstructions { get; set; }
        public bool? SetupComplete { get; set; }
        public DateTime? SetupCompleteDateTime { get; set; }
        public string TransportationComment { get; set; }
        public string LoadingComment { get; set; }
        public byte[] RowVersion { get; set; }
        public string ContractComment { get; set; }
        public int? IsActive { get; set; }
        public DateTime? EarliestPriceEndDate { get; set; }
        public string OrderComment { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public string UpdatedBy { get; set; }

        public string ScreenAction { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }

        public List<ContractDetailsListItemViewModel> lineItems { get; set; }

        public List<ContractDataCharacteriStics> contractCharacterstics { get; set; }
    }


    public class ContractDetailsListItemViewModel
    {
        public long ID { get; set; }
        public string Material { get; set; }
        public string Charge { get; set; }
        public string Commodity { get; set; }
        public string RateType { get; set; }
        public decimal Rate { get; set; }
        public string UOM { get; set; }
        public decimal Quantity_per_UOM { get; set; }
        public string Sales_Tax_Price { get; set; }
        public string MethodType { get; set; }

       
        public int ShowOnBOL { get; set; }
        public int AutoAdded { get; set; }
        public int AddPallet { get; set; }
        public string PriceIncreaseMethod { get; set; }
        public DateTime EffectiveStart { get; set; }
        public string EffectiveStartStr { get; set; }

        public DateTime EffectiveEnd { get; set; }
        public string EffectiveEndStr { get; set; }
        //public long Add_New { get; set; }
        //public bool Delete { get; set; }
        //public bool IsDeleted { get; set; }
        //public bool IsDisabledAddPallet { get; set; }

        public long PriceMethodTypeID { get; set; }
        public long MaterialID { get; set; }
        public long ChargeID { get; set; }

        public long UOMID { get; set; }

        public long CommodityID { get; set; }

        public long SalesTaxClassID { get; set; }

        public long RateTypeID { get; set; }

        public long PriceIncreaseMethodTypeID { get; set; }
    }


    public class ContractDataCharacteriStics
    {

        public string selectRow { get; set; }
        public long Id { get; set; }
        public long EntityId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string Value { get; set; }
        public string UOM { get; set; }
    }

    public class ContractRequestObject
    { 
        public CustomerContractViewModel InitialContract { get; set; }
        public CustomerContractViewModel UpdatedContract { get; set; }
    }


}
