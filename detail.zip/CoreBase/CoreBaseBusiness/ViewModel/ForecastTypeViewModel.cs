﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class ForecastTypeViewModel
    {
        public ForecastTypeViewModel()
        {
            Forecast = new HashSet<ForecastViewModel>();
        }

        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public virtual ICollection<ForecastViewModel> Forecast { get; set; }
    }

}
