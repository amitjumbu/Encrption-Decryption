﻿using CoreBaseBusiness.Helpers.Enums;
using System;

namespace CoreBaseBusiness.ViewModel
{

    public class PatientHistoryofPresentIllnessViewModel
    {

        public long Id { get; set; }
        public string ReferenceNo { get; set; }
        public long? PatientId { get; set; }
        public long? PartographId { get; set; }
        public int? AmenorrhoeaSince { get; set; }
        public string AmenorrhoeaDropBox { get; set; }
        public int? CovidStatusId { get; set; }
        public string DiagnosisDate { get; set; }
        public string LabourPains { get; set; }
        public string LabourPainsDropBox { get; set; }
        public string BleedingPv { get; set; }
        public string BleedingPvdropBox { get; set; }
        public string Headache { get; set; }
        public string HeadacheDropBox { get; set; }
        public string ReducedabsentFetalMovements { get; set; }
        public string ReducedabsentFetalMovementsDropBox { get; set; }
        public string LeakingPv { get; set; }
        public string LeakingPvdropBox { get; set; }
        public string Convulsions { get; set; }
        public string ConvulsionsDropBox { get; set; }
        public string Vomiting { get; set; }
        public string VomitingDropBox { get; set; }
        public string Urinary { get; set; }
        public string UrinaryDropBox { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }

    }


}