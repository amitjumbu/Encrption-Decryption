﻿using System;

namespace CoreBaseBusiness.ViewModel
{
    public class CustomerByLocationViewModel : BaseViewModel
    {

        public CustomerByLocationViewModel()
        {
        }

        public long CustomerId { get; set; }

        public string CustomerCode { get; set; }

        public string CustomerDescription { get; set; }

        public string CustomerName { get; set; }


        public long OrganizationID { get; set; }

        public string OrganizationName { get; set; }

        public bool SetupDone { get; set; }

        public DateTime? SetupDoneDateTime { get; set; }

        public string CustomerTypeName { get; set; }

        public long BillingEntityId { get; set; }

        public string BillingEntityName { get; set; }

        public long GroupNameId { get; set; }

        public string GroupName { get; set; }

        public long EnterpriseId { get; set; }

        public string EnterpriseName { get; set; }

        public string CityState { get; set; }

        public string MasInventoryWarehouse { get; set; }

        public bool OrganizationIsActive { get; set; }

        public long SalesManagerId { get; set; }


        public long SalesBrokerId { get; set; }


        public long DefaultCommodityID { get; set; }

        public string LoadingComment { get; set; }

        public string TransportationComment { get; set; }

    }

    public class CustomerByLocationEditModel : BaseViewModel
    {
        public CustomerByLocationEditModel()
        {
        }

        public int CustomerId { get; set; }

        public int DefaultCommodityID { get; set; }

        public int SalesBrokerId { get; set; }

        public int SalesManagerId { get; set; }

        public bool SetupDone { get; set; }

        public DateTime? SetupDoneDateTime { get; set; }

        public string LoadingComment { get; set; }

        public string TransportationComment { get; set; }
    }
}
