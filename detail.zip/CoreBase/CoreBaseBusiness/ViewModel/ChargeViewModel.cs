﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    public class ChargeViewModel : BaseViewModel
    {
        public ChargeViewModel()
        {
        }

        public int? ChargeTypeId { get; set; }
        public string ChargeTypeDescription { get; set; }
        public int? ChargeCategoryId { get; set; }
        public string ChargeCategoryDescription { get; set; }
        public int? ChargeComputationMethodId { get; set; }
        public string ChargeComputationMethodDescription { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public bool? DomesticOnly { get; set; }
        public bool? ExportOnly { get; set; }
        public bool? DomesticExportBoth { get; set; }
        public string ApplyContractFor { get; set; }
        public string ExternalSourceChargeKey { get; set; }
        public ChargeCategoryViewModel ChargeCategory { get; set; }
        public ChargeComputationMethodViewModel ChargeComputationMethod { get; set; }
        public ChargeTypeViewModel ChargeType { get; set; }
        public ClientViewModel Client { get; set; }
    }

    public class ParameterModel
    {
        public int ClientID { get; set; }
        public int Category { get; set; }
    }

    public class ChargeModel
    {
        public long ID { get; set; }
        public string ItemName { get; set; }
    }
}
