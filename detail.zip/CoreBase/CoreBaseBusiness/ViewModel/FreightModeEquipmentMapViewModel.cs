﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{

    public class FreightModeEquipmentMapViewModel : BaseViewModel
    {

        //public int ID { get; set; }
        public int FreightModeID { get; set; }
        public long EquipmentTypeID { get; set; }
        public string EquipmentTypeName { get; set; }
        //public bool IsDeleted { get; set; }
        //public int? ClientId { get; set; }
        //public int? SourceSystemId { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public ResponseMessages ResponseMessageCode { get; set; }
        //public string ResponseMessage
        //{
        //    get
        //    {
        //        if (ResponseMessageCode == ResponseMessages.None)
        //            return ResponseMessages.Success.ToString();
        //        return this.ResponseMessageCode.ToString();
        //    }
        //}
        //public int PageNo { get; set; }
        //public int PageSize { get; set; }

    }
}

