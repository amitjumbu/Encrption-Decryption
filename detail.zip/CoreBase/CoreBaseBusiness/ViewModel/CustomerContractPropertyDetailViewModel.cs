﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public partial class CustomerContractPropertyDetailViewModel
    {
        public long Id { get; set; }
        public long CustomerContractId { get; set; }
        public int EntityPropertyId { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUom { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }

    }
}
