using CoreBaseBusiness.Helpers.Enums;
//using CoreBaseData.Helpers.Enums;
using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public class BaseGraphViewModel
    {
        public long Id { get; set; }

        public int ClientId { get; set; }


        public int PaientId { get; set; }
         

        public int PartographId { get; set; }

        public int? StagesId { get; set; }

        public Nullable<int> CommentId { get; set; }

        public Nullable<int> DocumentId { get; set; }

        public string ChartValue { get; set; }

        public string XAxisPosition { get; set; }

        public string YAxisPosition { get; set; }

        public Nullable<int> SourceSystemID { get; set; }

        public Nullable<System.DateTime> UpdateDateTimeServer { get; set; }

        public Nullable<System.DateTime> UpdateDateTimeBrowser { get; set; }

        public System.DateTime CreateDateTimeBrowser { get; set; }

        public System.DateTime CreateDateTimeServer { get; set; }

        public string UpdatedBy { get; set; }

        public string CreatedBy { get; set; }

        public bool IsDeleted { get; set; }


        public bool IsActive { get; set; }


        //  public int Id { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }


      
    }


    
}