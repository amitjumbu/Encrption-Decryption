﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{

    public class FreightModeViewModel :BaseViewModel
    {

        //public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal? FuelSurFreightModePercentageRate { get; set; }
        public decimal? MilesPerGallon { get; set; }
        public decimal? MilesPerHour { get; set; }
        public decimal? DriverHoursPerDay { get; set; }
        public bool IsDeleted { get; set; }
        //public int? ClientId { get; set; }
        public int? SourceSystemID { get; set; }
        public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }
        public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        public string ExternalSourceFreightModeKey { get; set; }
        public bool SetupComplete { get; set; }
        public Nullable<System.DateTime> SetupCompleteDateTime { get; set; }
        public string SetupCompleteBy { get; set; }
        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        //public int PageNo { get; set; }
        //public int PageSize { get; set; }
    }

    public class FreightModeDelete
    {
        public string IDs { get; set; }
        public string DeletedBy { get; set; }

    }
}
