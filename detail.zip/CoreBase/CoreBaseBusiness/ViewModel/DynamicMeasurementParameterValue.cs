using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;
//using CoreBaseData.Helpers.Enums;
using System;
using System.Collections.Generic;

namespace CoreBaseBusiness.ViewModel
{
    public class DynamicMeasurementParameterValueViewModel
    {

        public int DynamicMeasurementParameterID { get; set; }
        public string ParameterValue { get; set; }
        public string ParameterValueComment { get; set; }
        public int PatientID { get; set; }
        public int PartographID { get; set; }
        public int ClientID { get; set; }
        public int SourceSystemID { get; set; }
        public string createdBy { get; set; }
        public string StageCode { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
       // public List<DynamicMeasurementParameterValue> DynamicViewList { get; set; }
    }
}