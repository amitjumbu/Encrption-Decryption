﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    class Apcharges
    {
        public long ShipmentID { get; set; }
        public long? BusinessPartnerID { get; set; }
        public int? BusinessEntityID { get; set; }
        public long? ChargeID { get; set; }
        public int?  ChargeUOMID { get; set; }
        public int? ChargeSequence { get; set; }
        public decimal? ChargeValue { get; set; }
        public decimal? ChargeModifiedValue { get; set; }
        public int? SalesTaxClassID { get; set; }
        public int? ClientID { get; set; }
        public string? BPType { get; set; }
        public string? BusinessPartnerName { get; set; }
        public string? ChargeTypeName { get; set; }
        public string? ChargeUOMName { get; set; }
        public string? SalesTaxClassName { get; set; }
        public string? ModifiedBy { get; set; }
        public Boolean? AutoAdded { get; set; }

    }
}
