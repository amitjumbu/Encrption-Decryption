﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using CoreBaseBusiness.Helpers.Enums;

    public partial class CurrentMaterialOnhandViewModel : BaseViewModel
    {
        public CurrentMaterialOnhandViewModel()
        {
        }

        public long LocationID { get; set; }

        public long MaterialID { get; set; }

        public int? InventoryTypeID { get; set; }

        public decimal? Amount { get; set; }

        public int? AmountUOMID { get; set; }

        public decimal Quantity { get; set; }

        public int? QuantityUOMID { get; set; }

        public string Status { get; set; }

        public string LocationType { get; set; }

        public string Location { get; set; }

        public string MaterialCode { get; set; }

        public string MaterialName { get; set; }

        public string UOM { get; set; }

        public string Comment { get; set; }
    }

    public class InventoryCommentViewModel
    {
        public string Comment { get; set; }
    }

    public class InventoryDeleteModel
    {
        public string IDs { get; set; }
    }
}
