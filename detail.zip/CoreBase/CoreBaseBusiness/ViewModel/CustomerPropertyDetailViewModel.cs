﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.ViewModel
{
    public partial class CustomerPropertyDetailViewModel : BaseViewModel
    {
        public string Ids { get; set; }
        public long LocationId { get; set; }
        public int? EntityPropertyId { get; set; }
        public string EntityPropertyCode { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUom { get; set; }
        public string PageAction { get; set; }
    }

    public class ForecastCustomerLocationViewModel : BaseViewModel
    {
        public long MaterialID { get; set; }
        public long LocationID { get; set; }
        public string LocationCode { get; set; }
        public string LocationName { get; set; }
        public int? EntityPropertyID { get; set; }
        public string Code { get; set; }
        public string DisplayName { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUOM { get; set; }
    }

    public class CustomerLocationDropdownViewModel
    {
        public long ID { get; set; }
        public long LocationID { get; set; }
        public string LocationCode { get; set; }
        public string LocationName { get; set; }
        public int? EntityPropertyID { get; set; }
        public string DropDownValue { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUOM { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientID { get; set; }
        public int? SourceSystemID { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime? CreateDateTimeServer { get; set; }
    }

    public class LocationToMaterialDeleteModel
    {
        public string IDs { get; set; }
    }
}
