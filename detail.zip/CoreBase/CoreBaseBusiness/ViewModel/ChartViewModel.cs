﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class ChartViewModel
    {
    }

    public class ClientViewModel
    { 
    }

    public class MeasurementParameterViewModel
    { 
    
    }

    public class PatientViewModel
    { 
      public string SearchMode { get; set; }
      public string SearchKey { get; set; }
      
      public long? PatientId { get; set; }

    }

    public class ChartMeasurementCommentViewModel
    { }

    public class ChartMeasurementMediaViewModel
    { }

    public class ChartAlertRulesByValueDetailViewModel { }

    public class ChartValidationRuleDetailViewModel { }
}
