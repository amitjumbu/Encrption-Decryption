﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CoreBaseBusiness.ViewModel
{
    public partial class EquipmentTypeMaterialPropertyDetailViewModel : BaseViewModel
    {
        public long EquipmentTypeID { get; set; }
        public long MaterialID { get; set; }
        public int EntityPropertyID { get; set; }
        public string EquipmentTypeIDs { get; set; }
        public string PropertyValue { get; set; }
        public string EquipmentTypeCode { get; set; }
        public string EquipmentTypeDescription { get; set; }
        public string EntityPropertyCode { get; set; }
        public string EntityPropertyDescription { get; set; }
        public string MaterialCode { get; set; }
        public string MaterialDescription { get; set; }
        public string PropertiesUOM { get; set; }
    }

    public class EquipmentTypeMaterialPropertyDetailDeleteModel
    {
        public string IDs { get; set; }
    }

    public partial class EquipmentMatPropDetailFromSelectedMatModel
    {
        public string MaterialCodeGlobal { get; set; }

        public string MaterialCodeDropDown { get; set; }

        public int ClientID { get; set; }
    }

    public partial class EquipmentPropDetailFromSelectedEquipmentModel
    {
        public string EquipmentCodeGlobal { get; set; }

        public string EquipmentCodeDropDown { get; set; }

        public int ClientID { get; set; }
    }

    public partial class MaterialPropertyDetailByEquipmentViewModel : BaseViewModel
    {
        public long EquipmentTypeID { get; set; }
        public long MaterialID { get; set; }
        public int EntityPropertyID { get; set; }
        public string MaterialIDs { get; set; }
        public string PropertyValue { get; set; }
        public string EquipmentTypeCode { get; set; }
        public string EquipmentTypeDescription { get; set; }
        public string EntityPropertyCode { get; set; }
        public string EntityPropertyDescription { get; set; }
        public string MaterialCode { get; set; }
        public string MaterialDescription { get; set; }
        public string PropertiesUOM { get; set; }
    }
}
