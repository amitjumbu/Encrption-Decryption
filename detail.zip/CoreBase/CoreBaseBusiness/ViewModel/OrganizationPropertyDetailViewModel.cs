﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
  
    public class OrganizationPropertyDetailViewModel:BaseViewModel
    {
        //public long Id { get; set; }
        public long OrganizationId { get; set; }
        public int EntityPropertyId { get; set; }
        public string EntityPropertyName { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUom { get; set; }
        public bool IsEditable { get; set; }
        //public bool IsDeleted { get; set; }
        //public int? ClientId { get; set; }
        //public int? SourceSystemId { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }
    }
}