﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class OperatingLocationViewModel : BaseViewModel
    {

        public OperatingLocationViewModel()
        {

        }


        public string ReferenceNo { get; set; }
        public int OperatingLocationTypeID { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsPrimary { get; set; }
        public int? TimeZoneID { get; set; }
        public long? OrganizationID { get; set; }
        public bool IsActive { get; set; }
        public bool? SetupComplete { get; set; }
        public DateTime? SetupCompleteDateTime { get; set; }
        public string ExternalSourceLocationKey { get; set; }

        public bool IsDeleted { get; set; }
        public Nullable<int> ClientID { get; set; }
        public Nullable<int> SourceSystemID { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> UpdateDateTimeServer { get; set; }
        public Nullable<System.DateTime> UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreateDateTimeBrowser { get; set; }
        ////public System.DateTime CreateDateTimeServer { get; set; }

      //  public OperatingLocationTypeViewModel OperatingLocationType { get; set; }

        public ICollection<OperatingLocationAddressViewModel> OperatingLocationAddresses { get; set; }

        public ICollection<OperatingLocationContactViewModel> OperatingLocationContacts { get; set; }



    }



}
