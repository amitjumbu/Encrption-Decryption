﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.ViewModel
{
    public partial class LocationPreferredMaterialViewModel
    {
        public long Id { get; set; }
        public long LocationId { get; set; }
        public string PageAction { get; set; }
        public long MaterialId { get; set; }
        public string MaterialName { get; set; }
        public decimal? Quantity { get; set; }
        public int? UomId { get; set; }
        public string UomName { get; set; }
        public bool IsDeleted { get; set; } 
        public string MaterialIds { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public string DeletedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        //public virtual Client Client { get; set; }
        //public virtual Location Location { get; set; }
        //public virtual Material Material { get; set; }
        //public virtual SourceSystem SourceSystem { get; set; }
        //public virtual Uom Uom { get; set; }        

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
}
