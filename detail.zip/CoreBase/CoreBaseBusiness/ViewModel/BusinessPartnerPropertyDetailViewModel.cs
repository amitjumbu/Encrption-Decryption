﻿namespace CoreBaseBusiness.ViewModel
{
    public partial class BusinessPartnerPropertyDetailViewModel : BaseViewModel
    {
        public string Ids { get; set; }
        public long LocationId { get; set; }
        public int? EntityPropertyId { get; set; }
        public string EntityPropertyCode { get; set; }
        public string PropertyValue { get; set; }
        public string PropertiesUom { get; set; }
        public string PageAction { get; set; }
    }

}
