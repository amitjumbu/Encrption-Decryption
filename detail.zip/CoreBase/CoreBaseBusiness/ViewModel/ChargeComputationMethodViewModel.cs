﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    public class ChargeComputationMethodViewModel : BaseViewModel
    {
        public ChargeComputationMethodViewModel()
        {
        }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ChargeComputationMethodComments { get; set; }
        public DateTime? ComputationEffectiveDate { get; set; }
        public DateTime? ComputationExpirationDate { get; set; }

    }
}
