﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
  
    public class PGEAlertPopUpCommentViewModel : BaseGraphCommentViewModel
    {
        
        public long PGEAlertPopUpID { get; set; }

        public PGEAlertPopUpViewModel PGEAlertPopUp { get; set; }
    }
}