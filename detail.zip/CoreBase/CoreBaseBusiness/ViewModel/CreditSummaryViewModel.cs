﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class CreditSummaryViewModel : BaseViewModel
    {
        
        
        public string BillingEntity { get; set; }
        public string CreditlimitFromMAS { get; set; }
        public string AvailableCreditFromMAS { get; set; }
        public string ValueOfUnshippedPlannedOrdersInLamps { get; set; }
        public string RemainingCredit { get; set; }
        public int? OrganizationID { get; set; }
        //public string? SystemTypeCode { get; set; }
        //public bool IsDeleted { get; set; }
        //public int? ClientId { get; set; }
        //public int? SourceSystemId { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }

    }
    
}
