﻿using System;

namespace CoreBaseBusiness.ViewModel
{
    public class BusinessPartnerByCarrierViewModel : BaseViewModel
    {

        public BusinessPartnerByCarrierViewModel()
        {
        }

        public long BusinessPartnerId { get; set; }

        public string BusinessPartnerCode { get; set; }

        public string BusinessPartnerDescription { get; set; }

        public string BusinessPartnerName { get; set; }


        public long OrganizationID { get; set; }

        public string OrgName { get; set; }

        public bool SetupDone { get; set; }

        public DateTime? SetupDoneDateTime { get; set; }

        public string SetupDoneBy { get; set; }

        public string BusinessPartnerTypeName { get; set; }

        public long BillingEntityId { get; set; }

        public string BillingEntityName { get; set; }

        public long GroupNameId { get; set; }

        public string GroupName { get; set; }

        public long EnterpriseId { get; set; }

        public string EnterpriseName { get; set; }

        public string CityState { get; set; }

        public string ScacValue { get; set; }
        public string TransportationComment { get; set; }
        public string LoadingComment { get; set; }


    }
    public class CollectionCarrierID
    {
        public string IDs { get; set; }
        public bool isActive { get; set; }
    }
}
