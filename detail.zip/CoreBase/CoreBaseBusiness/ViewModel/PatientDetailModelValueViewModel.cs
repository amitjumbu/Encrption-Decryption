﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
   public class PatientDetailModelValueViewModel
    {

        public PatientValueViewModel PatientsDM;
        public ICollection<PatientAddressValueViewModel> PatientsAddressDM;
        public ICollection<PatientContactValueViewModel> PatientsContactDM;

        public ICollection<OperatingLocationAddressViewModel> LocationAddressDM;
        public ICollection<OperatingLocationContactViewModel> LocationContactDM;
    }
}
