﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class ChartMeasurementValueViewModel : BaseViewModel
    {

        public ChartMeasurementValueViewModel()
        {

        }




        public long? PatientID { get; set; }
        public long ChartID { get; set; }

        public string ChartName { get; set; }

        public int MeasurementParameterID { get; set; }

        public string MeasurementParameterName { get; set; }

        public long? PartographID { get; set; }
        public string Value { get; set; }

        public int? UOMID { get; set; }
        public decimal X_axis_Position { get; set; }
        public decimal Y_axis_Position { get; set; }


        public string Comment { get; set; }




    }


   
}
