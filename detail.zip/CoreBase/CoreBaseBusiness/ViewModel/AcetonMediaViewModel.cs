﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
  
    public class AcetonMediaViewModel : BaseGraphMediaViewModel
    {
       
        public long AcetonID { get; set; }

        public AcetonViewModel Aceton { get; set; }
    }
}