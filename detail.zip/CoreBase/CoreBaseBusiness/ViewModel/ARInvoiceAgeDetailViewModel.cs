﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    using CoreBaseBusiness.Helpers.Enums;

    public class ARInvoiceAgeDetailViewModel : BaseViewModel
    {
      //  public long Id { get; set; }
        public long ArinvoiceAgeId { get; set; }
        public string PurchaseOrderNumber { get; set; }
        public string PONo { get; set; }
        public string BillOfLading { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime? DueDate { get; set; }
        public decimal? InvoiceBalance { get; set; }
        public decimal? InvoiceAmount { get; set; }

        public string OrderNo { get; set; }


        public decimal? OpenAmount { get; set; }
        public decimal? CurrentAmount { get; set; }
        public decimal? PastDueAmount { get; set; }


        public int? OrganizationID { get; set; }
        public string? SystemTypeCode { get; set; }
        //public bool IsDeleted { get; set; }
        //public int? ClientId { get; set; }
        //public int? SourceSystemId { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }

    }

    public class InviceParameterModel
    {
        public long ShipmentID { get; set; }
        public int ClientID { get; set; }
    }

    
}
