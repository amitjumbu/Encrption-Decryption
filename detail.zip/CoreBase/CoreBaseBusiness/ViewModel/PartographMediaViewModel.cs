﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class PartographMediaViewModel : BaseViewModel
    {

        public PartographMediaViewModel()
        {

        }



        public long PartographID { get; set; }

        public long? DocumentID { get; set; }
       
        public bool IsUrgent { get; set; }
        public PartographViewModel Partograph { get; set; }
    }


   
}
