using CoreBaseBusiness.Helpers.Enums;
//using CoreBaseData.Helpers.Enums;
using System;

namespace CoreBaseBusiness.ViewModel
{
    public class BaseViewModel : PaginationViewModel
    {
        public long ID { get; set; }
        public string ReferenceNo { get; set; }

      //  public int ClientId { get; set; }
        public int UserId { get; set; }
        
        public string UpdatedBy { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsActive { get; set; }

       
        public Nullable<int> ClientID { get; set; }
        public Nullable<int> SourceSystemID { get; set; }
       
        public Nullable<System.DateTime> UpdateDateTimeServer { get; set; }
        public Nullable<System.DateTime> UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreateDateTimeBrowser { get; set; }
        public System.DateTime? CreateDateTimeServer { get; set; }


      //  public int Id { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; } 
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }

    }

    public class EntityRecordRemoveRequestPacket
    {
        public long ID { get; set; }

        public string UserName { get; set; }


    }

    public class EntityRecordRemoveRequestPacketForSmallID
    {
        public int ID { get; set; }

        public string UserName { get; set; }


    }
}