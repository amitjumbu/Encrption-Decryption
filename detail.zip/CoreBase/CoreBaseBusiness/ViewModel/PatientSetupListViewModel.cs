﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseData.Models.Entity2;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace CoreBaseBusiness.ViewModel
{
    public partial class PatientSetupListViewModel : BaseViewModel
    {
        public long PatientId { get; set; }
        public string PatientName { get; set; }
        public string RegistrationNo { get; set; }
        public string PhysicianName { get; set; }
        public string HospitalName { get; set; }
        //public DateTime AdmissionDate { get; set; }
        public int PatientConditionID { get; set; }
        public string PatientConditionName { get; set; }
        public int PatientStatusID { get; set; }
        public string PatientStatusName { get; set; }
        public string Active { get; set; }
        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }

    }
}
