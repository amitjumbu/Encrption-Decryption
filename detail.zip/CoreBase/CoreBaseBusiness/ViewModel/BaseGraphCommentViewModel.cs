﻿namespace CoreBaseBusiness.ViewModel
{
    using System;
    using System.ComponentModel;
    using CoreBaseBusiness.Helpers.Enums;

    public class BaseGraphCommentViewModel
    {
        public string Description { get; set; }

        public bool? IsUrgent { get; set; }

        public long Id { get; set; }

        public int ClientId { get; set; }

        public int? SourceSystemID { get; set; }

        public DateTime? UpdateDateTimeServer { get; set; }

        public DateTime? UpdateDateTimeBrowser { get; set; }

        public System.DateTime CreateDateTimeBrowser { get; set; }

        public System.DateTime CreateDateTimeServer { get; set; }

        public string UpdatedBy { get; set; }

        public string CreatedBy { get; set; }

        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        [DefaultValue(true)]
        public bool IsActive { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }

        public string ResponseMessage
        {
            get
            {
                if (this.ResponseMessageCode == ResponseMessages.None)
                {
                    return ResponseMessages.Success.ToString();
                }

                return this.ResponseMessageCode.ToString();
            }
        }

        public int PageNo { get; set; }

        public int PageSize { get; set; }
    }
}