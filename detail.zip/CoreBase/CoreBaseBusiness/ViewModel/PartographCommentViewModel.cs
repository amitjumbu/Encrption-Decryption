﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class PartographCommentViewModel : BaseViewModel
    {

        public PartographCommentViewModel()
        {

        }



        public long PartographID { get; set; }

        public string Description { get; set; }

       
        public bool IsUrgent { get; set; }
        public PartographViewModel Partograph { get; set; }
    }


   
}
