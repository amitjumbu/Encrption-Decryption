﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class ForecastDetailViewModel
    {
        public long Id { get; set; }
        public long ForecastId { get; set; }
        public long LocationId { get; set; }
        public long? MaterialId { get; set; }
        public DateTime PeriodStartDate { get; set; }
        public decimal? Quantity { get; set; }
        public int? QuantityUomid { get; set; }
        public bool Ignore { get; set; }
        public string LocationStatus { get; set; }
        public long? CommodityId { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }

        public virtual ForecastViewModel ForecastViewModel { get; set; }
    }

}
