﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{

    //public class PatientViewModel{
    
    //    public PatientValueViewModel PVM { get; set; }
    //    public ICollection <PatientAddressValueViewModel>  PVMAddress{ get; set; }
    //    public ICollection<PatientContactValueViewModel> PVMContect { get; set; }
        
    //}


    public class PatientValueViewModel 
    {

        public long ID { get; set; }
        public string ReferenceNo { get; set; }

        public int? PatientTypeID { get; set; }

        public string Code { get; set; }

        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Prefix { get; set; }

        public string Suffix { get; set; }
        public string Description { get; set; }

        public long? LocationId { get; set; }
        public long? OperatingLocationID { get; set; }
        public string RegistrationNo { get; set; }
        public bool IsReferred { get; set; }
        public bool? IsActive { get; set; }
        public System.DateTime AdmissionDate { get; set; }
        public string AdmittedBy { get; set; }
        public int? PatientStatusID { get; set; }
        public int? PatientCovidStatusID { get; set; }

        public DateTime? CovidDiagnosisDate { get; set; }
        public bool IsDeleted { get; set; }

        public int? ClientID { get; set; }

        public int? SourceSystemID { get; set; }

        public string UpdatedBy { get; set; }
        public DateTime? UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreateDateTimeBrowser { get; set; }
        public System.DateTime CreateDateTimeServer { get; set; }
        public bool? SetupCompleted { get; set; }
        public DateTime? SetupCompletedDateTime { get; set; }
        public string SetupCompletedBy { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        //public bool IsActive { get; set; }

    }
    public class CollectPatientIDs
    {
        public string IDs { get; set; }
        public bool isActive { get; set; }

    }
}
