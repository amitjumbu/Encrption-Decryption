﻿using CoreBaseBusiness.Helpers.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{

    public class PatientTransactionViewModel 
    {

        public string PatientId { get; set; }
        
        public bool IsDeleted { get; set; }
    
        public string Mode { get; set; }

        public int? ClientID { get; set; }

        public string UpdatedBy { get; set; }
      
        public DateTime? UpdateDateTimeBrowser { get; set; }
        
        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }

    }
}
