﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.ViewModel
{
    public class PartographViewModel : BaseViewModel
    {

        public PartographViewModel()
        {

        }




        public long PatientID { get; set; }
        public long? TeamID { get; set; }
        public  bool IsActive { get; set; }

       
        public string Code { get; set; }

        
        public string Name { get; set; }
        public string Description { get; set; }

        public string ReferenceNo { get; set; }

        public PatientViewModel Patient { get; set; }

        public PatientRegistrationViewModel PatientRegistration { get; set; }
        public ICollection<PartographCommentViewModel> PartographComments { get; set; }

        public ICollection<PartographMediaViewModel> PartographMedia { get; set; }
    }


   
}
