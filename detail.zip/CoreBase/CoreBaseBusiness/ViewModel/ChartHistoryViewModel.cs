﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseData.Models.Entity;

namespace CoreBaseBusiness.ViewModel
{
  
    public class ChartHistoryViewModel
    {
       
        public string chartValue { get; set; }
        public decimal? xAxisPosition { get; set; }
        public decimal? yAxisPosition { get; set; }

        public string mode { get; set; }
        public int ClientId { get; set; }
        public int PartographId { get; set; }
        public int StagesId { get; set; }
        public DateTime? CreateDateTimeServer { get; set; }

        public string CreatedBy { get; set; }

        public bool? IsUrgent { get; set; }
        public string Description { get; set; }

        public int PageSize { get; set; }

        public int PageNo { get; set; }

    }
}