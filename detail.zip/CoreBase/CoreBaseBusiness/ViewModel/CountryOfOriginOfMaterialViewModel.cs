﻿using System;
using System.Collections.Generic;


namespace CoreBaseBusiness.ViewModel
{
    public partial class CountryOfOriginOfMaterialViewModel : BaseViewModel
    {
        //public int Id { get; set; }
        public long MaterialId { get; set; }
        public int CountryId { get; set; }
        public decimal MaterialPercentage { get; set; }
        public long? LocationID { get; set; }
        public string Comment { get; set; }
        public bool IsDeleted { get; set; }
        public string Material { get; set; }
        public string Country { get; set; }
        public string Manufacturer { get; set; }
       

        // public int? ClientId { get; set; }
        //public int? SourceSystemId { get; set; }
        //public string UpdatedBy { get; set; }
        //public DateTime UpdateDateTimeServer { get; set; }
        //public DateTime? UpdateDateTimeBrowser { get; set; }
        //public string CreatedBy { get; set; }
        //public DateTime? CreateDateTimeBrowser { get; set; }
        //public DateTime CreateDateTimeServer { get; set; }
        public int PageNo { get; set; }

        public int PageSize { get; set; }

    }
    public class OriginOfGoodsDelete
    {
        public string IDs { get; set; }

    }
}
