﻿using System;
using System.Collections.Generic;
using System.Text;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreBaseBusiness.Helpers.Enums;

namespace CoreBaseBusiness.ViewModel
{
    public class BaseGraphMediaViewModel
    {

        public long? DocumentID { get; set; }
        public bool? IsUrgent { get; set; }

        
        public long ID { get; set; }

        
        public int ClientID { get; set; }

        public Nullable<int> SourceSystemID { get; set; }

        public Nullable<System.DateTime> UpdateDateTimeServer { get; set; }

        public Nullable<System.DateTime> UpdateDateTimeBrowser { get; set; }

        public System.DateTime CreateDateTimeBrowser { get; set; }

        public System.DateTime CreateDateTimeServer { get; set; }

        public string UpdatedBy { get; set; }

        public string CreatedBy { get; set; }

        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        public ResponseMessages ResponseMessageCode { get; set; }
        public string ResponseMessage
        {
            get
            {
                if (ResponseMessageCode == ResponseMessages.None)
                    return ResponseMessages.Success.ToString();
                return this.ResponseMessageCode.ToString();
            }
        }
        public int PageNo { get; set; }
        public int PageSize { get; set; }

    }
}