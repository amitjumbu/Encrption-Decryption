using System;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Services;
using CoreBaseData;
using CoreBaseData.Helpers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NLog;
using NLog.Fluent;

namespace CoreBaseBusiness.Filters
{
    public class ExceptionFilter : IExceptionFilter
    {
        private string FileName { get; set; }

        private string ControllerName { get; set; }

        private int LineNumber { get; set; }

        private string InstanseDetails { get; set; }

        private readonly IHangfireOperation hangfireOperation;
        private IInstanseLogger instanseLogger;
        private IWebHostEnvironment webHostEnvironment;
        private readonly IConfiguration configuration;

        public ExceptionFilter(IHangfireOperation hangfireOperation, IOptions<ConfigurationKeys> configurationKeys, IInstanseLogger instanseLogger, IWebHostEnvironment webHostEnvironment, IConfiguration configuration)
        {
            this.hangfireOperation = hangfireOperation;
            this.instanseLogger = instanseLogger;
            this.webHostEnvironment = webHostEnvironment;
            this.configuration = configuration;
        }

        public void OnException(ExceptionContext context)
        {

            this.ExceptionTracer(context);
            var errorCode = "Oops. Something went wrong... Unable to fulfill the request.";
            var statusCode = HttpStatusCode.BadRequest;
            var exceptionType = context.Exception.GetType();
            switch (context.Exception)
            {
                case Exception e when exceptionType == typeof(UnauthorizedAccessException):
                    statusCode = HttpStatusCode.Unauthorized;
                    errorCode = "Unauthorized Access";
                    break;
                case CustomException e when exceptionType == typeof(CustomException):
                    statusCode = HttpStatusCode.BadRequest;
                    errorCode = e.Message.ToString();
                    break;
                case CustomException e when exceptionType == typeof(Exception):
                    statusCode = HttpStatusCode.BadRequest;
                    errorCode = e.Message.ToString();
                    break;
                default:
                    statusCode = HttpStatusCode.InternalServerError;
                    errorCode = context.Exception.Message.ToString();
                    if (errorCode == string.Empty || errorCode == null)
                    {
                        errorCode = "Oops. Something went wrong... Unable to fulfill the request.";
                    }

                    break;
            }

            context.ExceptionHandled = true;

            HttpResponse response = context.HttpContext.Response;
            response.StatusCode = (int)statusCode;
            response.ContentType = "application/json";
            var errorObject = new { Message = errorCode, StackTrace = context.Exception.StackTrace.ToString() };

            this.InstanseDetails = this.instanseLogger.InstanseLoggerString();

            var emailBody = this.CreateEmailBody(context, statusCode);
            var emailSubject = "Lamps : Error:" + context.Exception.Message;

            var recieverEmail = this.configuration["ExceptionEmailReciever"].ToString();

            if (!this.webHostEnvironment.IsDevelopment())
            {
                this.hangfireOperation.SendEmailAsyn(emailBody, emailSubject, recieverEmail, string.Empty, string.Empty, null);
            }

            if (this.webHostEnvironment.IsDevelopment())
            {
                response.WriteAsync(new ErrorDetails()
                {
                    StatusCode = (int)statusCode,
                    Message = emailBody,
                }.ToString());
            }
            else
            {
                response.WriteAsync(new ErrorDetails()
                {
                    StatusCode = (int)statusCode,
                    Message = errorCode,
                }.ToString());
            }
        }

        private string GetUserName()
        {
            var dataInstanse = this.InstanseDetails;
            if (!string.IsNullOrEmpty(dataInstanse))
            {
                int createdByIndex = dataInstanse.ToLower().IndexOf("createdby");
                int createdByDate = dataInstanse.ToLower().IndexOf("createdatetimebrowser");

                if (createdByDate > 0 && createdByDate > createdByIndex && createdByIndex > 0)
                {
                    var userName = dataInstanse.Substring(createdByIndex, createdByDate - createdByIndex);

                    if (string.IsNullOrEmpty(userName))
                    {
                        var userNameFilter = userName.Replace("CreatedBy", string.Empty).Replace("CreateDateTimeBrowser", string.Empty);
                        return userNameFilter;
                    }
                }
            }

            return string.Empty;
        }

        private void ExceptionTracer(ExceptionContext context)
        {
            var st = new StackTrace(context.Exception, true);

            var frame = st.GetFrame(0);

            this.LineNumber = frame.GetFileLineNumber();
            this.FileName = frame.GetFileName();

            var controllerFrame = st.GetFrames().FirstOrDefault(x => !string.IsNullOrEmpty(x.GetFileName()) && x.GetFileName().Contains("Controller"));

            if (controllerFrame != null)
            {
                this.ControllerName = controllerFrame.GetFileName();
            }
        }

        private string CreateEmailBody(ExceptionContext context, HttpStatusCode httpStatusCode)
        {
            StringBuilder errorMsg = new StringBuilder();
            errorMsg.Append(context.Exception.Message);
            errorMsg.Append("<p>");
            errorMsg.Append("Location Code : 'Core Base'");
            errorMsg.Append("<br/>Error Code  :	" + context.Exception.Message.ToString());
            errorMsg.Append("<br/>Status Code  :" + httpStatusCode.ToString());
            errorMsg.Append("<br/>User Name   :" + this.GetUserName());
            errorMsg.Append("<br/>Controller Name:" + this.ControllerName);
            errorMsg.Append("<br/>Stack Trace   :	" + this.FileName + " and Line number : " + this.LineNumber);
            errorMsg.Append("<br/>Current Data   :" + this.InstanseDetails);
            errorMsg.Append("</p>");
            return errorMsg.ToString();
        }
    }
}