using AutoMapper;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;

using System.Collections.Generic;
using System.Linq;

namespace CoreBaseBusiness.Configuretion
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            this.CreateMap<CoreBaseData.Models.Entity2.UserAlertHistory, UserAlertHistoryViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ShipmentNaftaReportData, ShipmentNaftaReportDataViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CountryOfOriginOfMaterial, CountryOfOriginOfMaterialViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.FreightModeEquipmentTypeMapping, FreightModeEquipMapViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.FreightLaneExcelUpload, FreightLaneViewModel>().ReverseMap();
            this.CreateMap<FreightMode, FreightModeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.FreightLane, FreightLaneViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.FreightLaneDetail, FreightLaneViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.Department, DepartmentViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CommodityType, CommodityTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.Material, MaterialCommodityMapViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MaterialGroup, MaterialGroupViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MaterialGroupDetail, MaterialGroupDetailsViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MaterialHierarchy, MaterialHierarchyViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MaterialHierarchyDetail, MaterialHierarchyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MaterialProperty, MaterialPropertyViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MaterialPropertyDetail, MaterialPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.EquipmentTypeMaterialPropertyDetail, EquipmentTypeMaterialPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.LocationForecastMaterial, ForecastCustomerLocationViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CustomerPropertyDetail, ForecastCustomerLocationViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CurrentMaterialOnhand, CurrentMaterialOnhandViewModel>().ReverseMap();
            this.CreateMap<ChartMeasurementValueViewModel, ChartMeasurementValue>().ReverseMap();
            this.CreateMap<IEnumerable<ChartMeasurementValueViewModel>, IEnumerable<ChartMeasurementValue>>().ReverseMap();

            this.CreateMap<ChartMeasurementCommentViewModel, ChartMeasurementComment>().ReverseMap();
            this.CreateMap<IEnumerable<ChartMeasurementCommentViewModel>, IEnumerable<ChartMeasurementComment>>().ReverseMap();

            this.CreateMap<PatientValueViewModel, CoreBaseData.Models.Entity2.Patient>().ReverseMap();
            this.CreateMap<PatientAddressValueViewModel, PatientAddress>().ReverseMap();
            this.CreateMap<PatientContactValueViewModel, PatientContact>().ReverseMap();

            this.CreateMap<ApplicationPermissionViewModel, ApplicationPermission>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.Partograph, PartographViewModel>().ReverseMap();
            this.CreateMap<PartographComment, PartographCommentViewModel>().ReverseMap();
            this.CreateMap<PartographMedia, PartographMediaViewModel>().ReverseMap();
            this.CreateMap<IEnumerable<Partograph>, IEnumerable<PartographViewModel>>();
            this.CreateMap<IEnumerable<PartographComment>, IEnumerable<PartographCommentViewModel>>().ReverseMap();
            this.CreateMap<IEnumerable<PartographMedia>, IEnumerable<PartographMediaViewModel>>().ReverseMap();

            this.CreateMap<OperatingLocation, OperatingLocationViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.FuelPrice, FuelPriceViewModel>().ReverseMap();
            this.CreateMap<OperatingLocationType, OperatingLocationTypeViewModel>().ReverseMap();
            this.CreateMap<OperatingLocationAddress, OperatingLocationAddressViewModel>().ReverseMap();
            this.CreateMap<OperatingLocationContact, OperatingLocationContactViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementBpmeasurementValue, BPViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementUrineAcetoneMeasurementValue, AcetonViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.FuelPriceType, FuelPriceTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementAmnioticFluidMeasurementValue, AmnioticFluidViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementCervixMeasurementValue, CervixViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementContractionsMeasurementValue, ContractionsPer10MinViewModel>().ReverseMap();
            this.CreateMap<Comment, CommentViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementHeadDescentMeasurementValue, DecentofHeadViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementDropsMinMeasurementValue, DropsMinViewModel>().ReverseMap();
            this.CreateMap<Measurement_DrugsIVMeasurementValue, DrugsGivenIVFluidsViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementValue, FetalHeartRateViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementMouldingMeasurementValue, MouldingViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementOxytocinMeasurementValue, OxytocinULViewModel>().ReverseMap();
            this.CreateMap<PGEAlertPopUp, PGEAlertPopUpViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementUrineProtienMeasurementValue, ProteinViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementPulseMeasurementValue, PulseViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementTemperatureMeasurementValue, TemperatureViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementUrineVolumeMeasurementValue, VolumeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MeasurementCaputMeasurementValue, CaputViewModel>().ReverseMap();
            this.CreateMap<PGE, PGEViewModel>().ReverseMap();
            this.CreateMap<Measurement_ComplicationsMeasurementValue, ThirdChartViewModel>().ReverseMap();
            this.CreateMap<Measurement_UrineVolumeMeasurementComment, VolumeCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_UrineProtienMeasurementComment, ProteinCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_BPMeasurementComment, BPCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_UrineAcetoneMeasurementComment, AcetonCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_FetalHeartrateMeasurementComment, FetalHeartRateCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_AmnioticFluidMeasurementComment, AmnioticFluidCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_CervixMeasurementComment, CervixCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_ContractionsMeasurementComment, ContractionsPer10MinCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_HeadDescentMeasurementComment, DecentofHeadCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_DropsMinMeasurementComment, DropsMinCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_DrugsIVMeasurementComment, DrugsGivenIVFluidsCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_MouldingMeasurementComment, MouldingCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_OxytocinMeasurementComment, OxytocinULCommentViewModel>().ReverseMap();
            this.CreateMap<PGEAlertPopUpComment, PGEAlertPopUpCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_PulseMeasurementComment, PulseCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_CaputMeasurementComment, CaputCommentViewModel>().ReverseMap();
            this.CreateMap<PGEComment, PGECommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_ComplicationsMeasurementComment, ThirdChartCommentViewModel>().ReverseMap();
            this.CreateMap<Measurement_UrineVolumeMeasurementMedia, VolumeMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_UrineProtienMeasurementMedia, ProteinMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_BPMeasurementMedia, BPMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_UrineAcetoneMeasurementMedia, AcetonMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_FetalHeartrateMeasurementMedia, FetalHeartRateMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_AmnioticFluidMeasurementMedia, AmnioticFluidMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_CervixMeasurementMedia, CervixMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_ContractionsMeasurementMedia, ContractionsPer10MinMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_HeadDescentMeasurementMedia, DecentofHeadMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_DropsMinMeasurementMedia, DropsMinMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_DrugsIVMeasurementMedia, DrugsGivenIVFluidsMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_MouldingMeasurementMedia, MouldingMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_OxytocinMeasurementMedia, OxytocinULMediaViewModel>().ReverseMap();
            this.CreateMap<PGEAlertPopUpMedia, PGEAlertPopUpMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_PulseMeasurementMedia, PulseMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_CaputMeasurementMedia, CaputMediaViewModel>().ReverseMap();
            this.CreateMap<PGEMedia, PGEMediaViewModel>().ReverseMap();
            this.CreateMap<Measurement_ComplicationsMeasurementMedia, ThirdChartMediaViewModel>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementBPMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementUrineAcetoneMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementAmnioticFluidMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, Measurement_CaputMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementCervixMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementContractionsMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementHeadDescentMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementDropsMinMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementDrugsIVMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementMouldingMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementOxytocinMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementUrineProtienMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementPulseMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementPulseMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementTemperatureMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, Measurement_ComplicationsMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonCommentViewModel, CoreBaseData.Models.Entity2.MeasurementUrineVolumeMeasurementComment>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_BPMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_UrineAcetoneMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_AmnioticFluidMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_CaputMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_CervixMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_ContractionsMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_HeadDescentMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_DropsMinMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_DrugsIVMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_MouldingMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_OxytocinMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_UrineProtienMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_PulseMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_UrineProtienMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_ComplicationsMeasurementMedia>().ReverseMap();
            this.CreateMap<GraphCommonMediaViewModel, Measurement_UrineVolumeMeasurementMedia>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.SystemAlert, SystemAlertViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.UserAlert, UserAlertViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.SystemAlertCalendar, SystemAlertCalendarViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.Location, LocationViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.LocationType, LocationTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CustomerPropertyDetail, CustomerPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.LocationAverageShipFromMileMapping, LocationAverageShipFromMileMappingViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.LocationPreferredMaterial, LocationPreferredMaterialViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.LocationPreferredMaterial, LocationPreferredMaterialViewModel>()
               .ForMember(w => w.MaterialName, opt => opt.MapFrom(src1 => src1.Material.Name))
                .ForMember(w => w.UomName, opt => opt.MapFrom(src1 => src1.Uom.Code))
                .ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.ShippingLocationDefaultPackagingMaterial, ShippingLocationDefaultPackagingMaterialViewModel>()
               .ForMember(w => w.MaterialName, opt => opt.MapFrom(src1 => src1.Material.Name))                
                .ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.OperatingLocationPropertyDetail, OperatingLocationPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.Material, MaterialViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.WebControlType, WebControlTypeViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.WebControlTypePossibleValue, WebControlTypePossibleValueViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.DynamicMeasurement, DynamicMeasurementViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.Validation, ValidationViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.Commodity, CommodityViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.SystemType, SystemTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.FuelChargeIndex, FuelSurchargeIndexViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.MedicationChartGrid, MedicationChartGridViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CriticalPatientMonitoringGrid, CriticalPatientMonitoringGridViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientObstetricFormula, PatientObstetricFormulaViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.SalesOrder, SalesOrderViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.StockTransferOrder, SalesOrderViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.SalesOrderDetail, SalesOrderDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.StockTransferOrderDetail, SalesOrderDetailViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.PatientRegistration, PatientRegistrationViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.CustomerContract, CustomerContractViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CustomerContractDetail, CustomerContractDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CustomerContractPropertyDetail, CustomerContractPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerContract, BusinessPartnerContractViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerContract, CustomerContractViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerContractDetail, BusinessPartnerContractDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerContractPropertyDetail, BusinessPartnerContractPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientHistoryofPresentIllness, PatientHistoryofPresentIllnessViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.Charge, ChargeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ChargeCategory, ChargeCategoryViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ChargeType, ChargeTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ChargeComputationMethod, ChargeComputationMethodViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ChargeComputationMethodMapping, ChargeComputationMethodMappingViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientMensturalHistory, PatientMensturalHistoryViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientContraceptionHistory, PatientContraceptionHistoryViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientContracpetionHisotryMethod, PatientContracpetionHisotryMethodViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientPersonalHistory, PatientPersonalHistoryViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.PatientResourceList, PatientResourceListViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ResourceRoleList, ResourceRoleListViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ChargeComputationMethodMapping, ChargeComputationMethodMappingForOrderViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ArinvoiceAgeDetail, ARInvoiceAgeDetailViewModel>().ReverseMap();

            this.CreateMap<CoreBaseData.Models.Entity2.OrganizationPropertyDetail, OrganizationPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.LocationForecastMaterial, LocationForecastMaterialViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.Forecast, ForecastViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ForecastRelation, ForecastRelationViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ForecastDetail, ForecastDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.ForecastType, ForecastTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CalendarType, CalendarTypeViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CustomerContractDetail, ContractDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerContractDetail, ContractDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CustomerContractPropertyDetail, DefiningCharacteristicsViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerContractPropertyDetail, DefiningCharacteristicsViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.BusinessPartnerPropertyDetail, BusinessPartnerPropertyDetailViewModel>().ReverseMap();
            this.CreateMap<CoreBaseData.Models.Entity2.CarrierPropertyDetail, CarrierPropertyDetailViewModel>().ReverseMap();
        }
    }
}