using CoreBaseBusiness.ViewModel;
using Dapper;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Helpers
{
    public interface IConvertEnglishToSpanish
    {
        Task<string> ConvertTextEnglishToSpanish(string text);
    }

    public class ConvertEnglishToSpanish: IConvertEnglishToSpanish
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public string BaseConnectionString
        {
            get
            {
                var configurationBuild = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
                return configurationBuild["ConnectionString:CoreBaseDB"];

            }
        }
        private string ConnectionString { get { return this.BaseConnectionString; } }
        public async Task<string> ConvertTextEnglishToSpanish(string text)
        {
            try
            {
                if (text == "" || text == null)
                    return "";

                string OutPutString = string.Empty;

                ////code to translate into spanish from Microsoft translation API key
                //GetMicrosoftTranslatorAPIKey();

                string host = "https://api.cognitive.microsofttranslator.com";
                string route = "/translate?api-version=3.0&to=en&to=es";
                string subscriptionKey = GetMicrosoftTranslatorAPIKey();
                //string subscriptionKey = "82c7a9748a1f4d36a6ad92390e4c9dfb"; //59fc901903e74cdb9ed5bd8b45dd1383 old

                System.Object[] body = new System.Object[] { new { Text = text } };
                var requestBody = JsonConvert.SerializeObject(body);
                using (var client = new HttpClient())
                using (var request = new HttpRequestMessage())
                {
                    // In the next few sections you'll add code to construct the request.
                    // Set the method to POST
                    request.Method = HttpMethod.Post;

                    // Construct the full URI
                    request.RequestUri = new Uri(host + route);

                    // Add the serialized JSON object to your request
                    request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");

                    // Add the authorization header
                    request.Headers.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

                    //// Send request, get response
                    var response = client.SendAsync(request).Result;
                    if (Convert.ToString(response.StatusCode) == "OK")
                    {
                        var jsonResponse = response.Content.ReadAsStringAsync().Result;
                        var data = JsonConvert.DeserializeObject<List<RootObject>>(jsonResponse);
                        if (data[0] != null)
                        {
                            if (data[0].translations != null)
                            {
                                OutPutString = data[0].translations[1].text;
                            }
                        }
                    }



                }
                return OutPutString;

            }
            catch (Exception ex)
            {
                return "";
            }
        }

        public string GetMicrosoftTranslatorAPIKey()
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@Key", "MICROSOFT_TRANSLATOR_API_KEY");
                var createFilterViewModels = con.Query<string>("SPO_GetSystemSettingKeyValueDetail", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return createFilterViewModels.FirstOrDefault();
            }
        }

       
    }
    
    public class DetectedLanguage
    {
        public string language { get; set; }
        public double score { get; set; }
    }

    public class Translation
    {
        public string text { get; set; }
        public string to { get; set; }
    }

    public class RootObject
    {
        public DetectedLanguage detectedLanguage { get; set; }
        public List<Translation> translations { get; set; }
    }
} 