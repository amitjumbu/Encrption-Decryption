using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using CoreBaseData.Helpers;
using Newtonsoft.Json; 

namespace CoreBaseBusiness.Helpers.En_De
{
    public static class AesEncryptDecryptService
    {
        private readonly static byte[] _key = Encoding.UTF8.GetBytes("7061737323313233");
        private readonly static byte[] _iv = Encoding.UTF8.GetBytes("7061737323313233");
        public static string Encrypt<T>(this T input)
        {
            string serializedString = null;
            if (typeof(T) == typeof(string))
                serializedString = input.ToString();
            else
                serializedString = input.Serialize();
            var encryptedBytes = EncryptStringToBytes(serializedString);
            return Convert.ToBase64String(encryptedBytes);
        }

        public static TReturn Decrypt<TReturn>(this string input)
        {
            var encryptedBytes = Convert.FromBase64String(input);
            var decryptedString = DecryptStringFromBytes(encryptedBytes);
            return decryptedString.Deserialize<TReturn>();
        }

        private static byte[] EncryptStringToBytes(string plainText)
        {
            // Check arguments.  
            if (plainText == null || plainText.Length <= 0)
            {
                plainText = string.Empty;
                //throw new ArgumentNullException("plainText");
            }
            if (_key == null || _key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            if (_iv == null || _iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            byte[] encrypted;
            
            // Create a RijndaelManaged object  
            // with the specified key and IV.  
            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = _key;
                rijAlg.IV = _iv;

                // Create a decrytor to perform the stream transform.  
                var encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.  
                using (var msEncrypt = new MemoryStream())
                {
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.  
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            // Return the encrypted bytes from the memory stream.  
            return encrypted;
        }

        private static string DecryptStringFromBytes(byte[] cipherText)
        {
            // Check arguments.  
            if (cipherText == null || cipherText.Length <= 0)
            {
                throw new ArgumentNullException("cipherText");
            }
            if (_key == null || _key.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }
            if (_iv == null || _iv.Length <= 0)
            {
                throw new ArgumentNullException("key");
            }

            // Declare the string used to hold  
            // the decrypted text.  
            string plaintext = null;

            // Create an RijndaelManaged object  
            // with the specified key and IV.  
            using (var rijAlg = new RijndaelManaged())
            {
                //Settings  
                rijAlg.Mode = CipherMode.CBC;
                rijAlg.Padding = PaddingMode.PKCS7;
                rijAlg.FeedbackSize = 128;

                rijAlg.Key = _key;
                rijAlg.IV = _iv;

                // Create a decrytor to perform the stream transform.  
                var decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                try
                {
                    // Create the streams used for decryption.  
                    using (var msDecrypt = new MemoryStream(cipherText))
                    {
                        using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {

                            using (var srDecrypt = new StreamReader(csDecrypt))
                            {
                                // Read the decrypted bytes from the decrypting stream  
                                // and place them in a string.  
                                plaintext = srDecrypt.ReadToEnd();

                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return plaintext;
        }
    }
}