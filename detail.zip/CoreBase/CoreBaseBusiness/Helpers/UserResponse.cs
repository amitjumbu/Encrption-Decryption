using System;
using System.Net;
using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using System.Collections.Generic;
//using CoreBaseData.Helpers.Enums;
using CoreBaseBusiness.Helpers.Enums;

namespace CoreBaseBusiness.Helpers
{
    public class UserResponse<T> where T : class
    {
        public int StatusCode { get; set; }
        public int RecordCount { get; set; }
        public string Message { get; set; }
        public dynamic Data { get; set; }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }

        public static UserResponse<T> SendResponse(int recordCount, IEnumerable<T> viewModel)
        { 
            UserResponse<T> response = new UserResponse<T>();
            response.StatusCode = (int)HttpStatusCode.OK;
            response.RecordCount = recordCount;
            response.Message = ResponseMessages.Success.ToString();
            response.Data = viewModel;
            return response;
        }
        public static UserResponse<T> SendResponse(T viewModel)
        {
            UserResponse<T> response = new UserResponse<T>();
            response.StatusCode = (int)HttpStatusCode.OK;
            response.RecordCount = 0;
            response.Message = ResponseMessages.Success.ToString();
            response.Data = viewModel;
            return response;
        }
        public static UserResponse<T> SendResponse(string message, HttpStatusCode statusCode, T viewModel = null)
        {
            UserResponse<T> response = new UserResponse<T>();
            response.StatusCode = (int)statusCode;
            response.RecordCount = 0;
            response.Message = message;
            response.Data = viewModel;
            return response;
        }
        // public static UserResponse<T> SendResponse(string viewModel)
        // {
        //     UserResponse<T> response = new UserResponse<T>();
        //     response.StatusCode = (int)HttpStatusCode.OK;
        //     response.RecordCount = 0;
        //     response.Message = ResponseMessages.Success.ToString();
        //     response.Data = viewModel;
        //     return response;
        // }
    }
}
