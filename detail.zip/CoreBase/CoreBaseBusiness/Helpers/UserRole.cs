using CoreBaseData.Helpers;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace CoreBaseBusiness.Helpers
{
    public class UserRole
    {
        public static string roles(string currentUserRoles, string currentUserEmail, int currentUserId, int tenantId)
        {
            string retValue = "";
            try
            {
                var roles = JsonConvert.DeserializeObject<IEnumerable<dynamic>>(currentUserRoles);
                foreach (var item in roles)
                {
                    if (item.RoleName == "Super Admin" || item.RoleName == "EY Admin")
                    {
                        retValue = "Admin";
                    }
                    else
                    {
                        if (retValue == "")
                            retValue = "Other";
                    } 
                }
            }
            catch { retValue = "Other"; }

            retValue = retValue == "Admin" ? "" : retValue;
            Sessions.CurrentUserRole = retValue;
            Sessions.CurrentUserId = currentUserId;
            Sessions.CurrentUserEmail = currentUserEmail;
            Sessions.TenantId = tenantId;
            return retValue;

            //     Super_Admin= "Super Admin",
            //     EY_Admin="EY Admin",
            //     Tenant_Admin="Tenant Admin",
            //     Owner="Owner",
            //     Approver="Approver",
            //     Reviewer="Reviewer",
            //     Auditor="Auditor"
        }
    }
}