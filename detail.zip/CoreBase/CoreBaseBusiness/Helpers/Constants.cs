namespace CoreBaseBusiness.Helpers
{
    public static class Constants
    {
        public static class Identifire
        {
            public const string Post = "post";
            public const string Add = "add";
            public const string Update = "update";
            public const string Delete = "delete";
            public const string GetAll = "getAll";
            public const string Id = "Id";
            public const string List = "list";
            public const string GetByID = "getbyid";
            public const string DeleteByID = "deletebyIds";
            public const string GetDetail = "getdetail";
            public const string ActiveAll = "activeall";
            public const string DeleteAll = "deleteall";
            public const string UpdateAll = "updateall";
            public const string SaveAll = "SaveAll";
            public const string GetSalesManager = "getsalesmanager";
            public const string OrderMaterialList = "ordermateriallist";
            public const string PalletList = "palletlist";
            public const string Materialquantity = "materialquantity";
            public const string LocationMaterial = "LocationMaterial";
            public const string EditFreigtmodes = "{ids}";
            public const string GetAllCom = "getallcom";
            public const string GetAllCommodityType = "getallcommodityType";
            public const string GetAllByCategoryCode = "getallbycategorycode";
            public const string GetPriceMethodByMaterialAndCharge = "getpricemethodbymaterialandcharge";
            public const string GetComputationMehtodByMaterialAndCharge = "GetComputationMehtodByMaterialAndCharge";
            public const string GetDefaultCommodity = "GetDefaultCommodity";
            public const string GetFuelPriceType = "GetFuelPriceType";
            public const string ChargeRateUOM = "ChargerateUOM";
            public const string GetAdjustChargesDefaultData = "GetAdjustChargesDefaultData";
            public const string GetPriceMethodResult = "GetPriceMethodResult";
            public const string LocationShippingMaterial = "LocationShippingMaterial";
            public const string GetAvailableCredit = "GetAvailableCredit";
            public const string GetFuelCharges = "GetFuelCharges";
            public const string ValidateMaterialInOrder = "ValidateMaterialInOrder";
            
            public const string CalculateCharges = "CalculateCharges";

            public const string AmountCalculator = "AmountCalculator";

            public const string GetComment = "GetComment";

            public const string ValidateOrderCoreInputs = "ValidateOrderCoreInputs";
            public const string GetAllCriticalpatientmonitoringList = "GetAllCriticalpatientmonitoringList";
            public const string GetPatientInfoByID = "GetPatientInfoByID";
            public const string GetChargeDetails = "GetChargeDetails";
            public const string GetCovidStatus = "GetCovidStatus";
            public const string GetShipmentOrdersDetails = "GetShipmentOrdersDetails";
            public const string GetFreightModeEquipMapList = "GetFreightModeEquipMapList";
            public const string GetChoiceofBirthingPartner = "GetChoiceofBirthingPartner";
            public const string GetPatientList = "GetPatientList";
            public const string ManufacturerList = "ManufacturerList";
            public const string GetOriginOfGoodsDetails = "GetOriginOfGoodsDetails";
            public const string AllMaterialquantity = "allmaterialquantity";
            public const string GetAddedPatientList = "GetAddedPatientList";
            public const string DeleteMessageAll = "Some Records can't be Deleted Due to Record exist in Partograph!";
            public const string DeleteMessageSingle = "Record Deleted Successfully!";
            public const string GetAllHospital = "GetAllHospital";
            public const string OrderList = "OrderList";
            public const string GetAllPhysiciansByPatientId = "GetAllPhysiciansByPatientId";
            public const string DefaultMaterialCommodity = "DefaultMaterialCommodity";
            public const string DefaultMaterialProperty = "DefaultMaterialProperty";

            public const string SaveBulkOrder = "SaveBulkOrder";
            public const string GetResourceRole = "GetResourceRole";
            public const string ApproveSendShipmentToMAS = "ApproveSendShipmentToMAS";
            public const string SendARChargesToMAS = "SendARChargesToMAS"; 
            public const string GetResourceNameOnResourceRole = "GetResourceNameOnResourceRole";

            public const string GetByLocation = "GetByLocation";
            public const string GetByCarrier = "GetByCarier";
            public const string BpByLocation = "BpByLocation";
            public const string BpByCarrier = "BpByCarrier";

            public const string BusinessPartner = "BP";
            public const string CustomerPartner = "Customer";

            public const string GetFuelList = "GetFuelList";

            public const string SaveShipment = "SaveShipment";
            public const string GetApcharges = "GetApcharges";
            public const string GetShipmentDetails = "GetShipmentDetails"; 
            public const string GetTenderStatusForShipment = "GetTenderStatusForShipment";
            public const string GetLoctionsForShipment = "GetLoctionsForShipment";
            public const string GetShipmentOrders = "GetShipmentOrders";
            public const string GetShipmentOrdersDetailsForShipmentId = "GetShipmentOrdersDetailsForShipmentId";
            public const string GetShipmentOrdersDetailsForShipmentId1 = "GetShipmentOrdersDetailsForShipmentId1";
            public const string CheckPhysicianMappedWithPatient = "CheckPhysicianMappedWithPatient";
            public const string GetAllShipToDataList = "GetAllShipToDataList";
            public const string GetSalesOrderList = "GetSalesOrderList"; 
            public const string GetSalesOrderDataCount = "GetSalesOrderDataCount";
            public const string GetSalesOrderListDataCount = "GetSalesOrderListDataCount"; 
            public const string PostResourceRoles = "PostResourceRoles";
            public const string ListForDD = "ListForDD";
            public const string GetOrderAmountforAPCharges = "GetOrderAmountforAPCharges";
            public const string GetShipmentStatusForShipment = "GetShipmentStatusForShipment";
            public const string GetShipmentConditionForShipment= "GetShipmentConditionForShipment";
            public const string GetModeForShipment ="GetModeForShipment";
            public const string GetOrderTypeForShipment = "GetOrderTypeForShipment";
            public const string Tonu = "Tonu";
            public const string Cancel = "Cancel";
            public const string SaveSalesOrderLinkData = "SaveSalesOrderLinkData"; 
            public const string ChangeOrderLocation = "ChangeOrderLocation";
            public const string SaveShipmentOrders = "SaveShipmentOrders";
            public const string ShipSelectedShipment = "ShipSelectedShipment";
            public const string ReceiveSelectedShipment= "ReceiveSelectedShipment";
            public const string ReSendShipmentToMAS = "ReSendShipmentToMAS";
            public const string TPQFailSendShipmentToMAS = "TPQFailSendShipmentToMAS";
            public const string GetRateTypeOfChargeID = "GetRateTypeOfChargeID";
            public const string GetVerifyEquipmentMaterialPropertyOrder = "GetVerifyEquipmentMaterialPropertyOrder";
            public const string Status = "status";
            public const string CancelSelectedOrders = "CancelSelectedOrders"; 
            public const string DeleteSelectedOrders = "DeleteSelectedOrders"; 

            public const string GetVerifyEquipmentMultipleMaterialPropertyOrder = "GetVerifyEquipmentMultipleMaterialPropertyOrder";

            public const string SaveUpdateVerifyEquipmentMaterial = "SaveUpdateVerifyEquipmentMaterial";
            public const string SaveBulkMaterialProperties = "SaveBulkMaterialProperties";

            public const string CalculateChargesForAdjustmnetGrid = "CalculateChargesForAdjustmnetGrid";

            public const string GetInvoice = "GetInvoice";

            public const string FindMissingMaterialPropertyOrder = "FindMissingMaterialPropertyOrder";
            public const string GetShipmentNaftaReportData = "GetShipmentNaftaReportData";
            
            public const string GetAllOperatingLocationList = "GetAllOperatingLocationList";
            public const string MoveUpDownOrderRouteSequence = "MoveUpDownOrderRouteSequence";
            public const string RemoveSelectedLinkOrder = "RemoveSelectedLinkOrder";
            public const string UpdateHospital = "UpdateHospital";
            public const string OP= "OP";
            public const string GetOrderDataByOrderIdForShipWithPopup = "GetOrderDataByOrderIdForShipWithPopup"; 
            public const string GetNetCostData = "getNetCostData";
            public const string AutherizedSignature = "autherizedSignature";
            public const string UpdateFuelIndex = "UpdateFuelIndex";
            public const string GetShipmentDetailsAll = "GetShipmentDetailsAll";
            public const string GetShipmentDetailsAllCount = "GetShipmentDetailsAllCount";

            public const string GetAllUserAlertHistory = "GetAllUserAlertHistory";
            public const string GetSearchResult = "GetSearchResult";
            
            public const string ActiveCarrier = "ActiveCarrier";

            public const string GetshipFromtypeAll = "GetshipFromtypeAll";
            public const string GetshiptotypeAll = "GetshiptotypeAll";
            public const string GetshipFromAllData = "GetshipFromAllData";
            public const string GetshipToAllData = "GetshipToAllData";
            public const string CopyOrders = "CopyOrders";
            public const string GetAllInvoiceNo = "GetAllInvoiceNo"; 
            public const string GetAllSourceList = "GetAllSourceList";

            public const string GetCheckStatusForSendtoMass= "GetCheckStatusForSendtoMass";
            public const string GetCheckStatusReSendtoMass = "GetCheckStatusReSendtoMass";
            public const string SendARChargesToMASS = "SendARChargesToMASS";
            public const string ReSendARChargesToMASS = "ReSendARChargesToMASS";
            public const string GetChargetypeforApcharges = "GetChargetypeforApcharges";
            public const string ValidateMaterialsInputs = "ValidateMaterialsInputs";

            public const string GetHierarchyByMaterialID = "GetHierarchyByMaterialID";
            public const string GetBillingEntity = "GetBillingEntity";
            public const string GetBillingEntityCarrier = "GetBillingEntityCarrier";
            public const string CreateManageFilter = "CreateManageFilter";
            public const string GetAllCustomManageFilters = "GetAllCustomManageFilters";
            public const string UpdateManageFilter = "UpdateManageFilter";
            public const string DeleteManageFilter = "DeleteManageFilter";

            public const string GetCustomBillingEntity = "GetCustomBillingEntity";
            public const string GetUOMforApcharespopup= "GetUOMforApcharespopup";
            public const string GetFreightModeEquipmentMapingList = "GetFreightModeEquipmentMapingList";
            public const string ConvertCulture = "ConvertCulture";
            public const string ContractMaterial = "ContractMaterial";

            public const string RecalculateOrder = "RecalculateOrder";

            public const string GetClaimList = "GetClaimList";
            public const string GetFilterClaimData = "GetFilterClaimData";
            public const string GetClaimListCount = "GetClaimListCount";
            public const string GetClaimByClaimId = "GetClaimByClaimId";

            public const string GetProformaInvoiceData= "GetProformaInvoiceData";

            public const string ShipmentReCalculate = "ShipmentReCalculate";
            public const string SetCompleteSetupAndNotify = "SetCompleteSetupAndNotify";
            public const string ClaimApproved = "ClaimApproved";

            public const string GetCharge = "GetCharge";
            public const string SaveClaimDetail = "SaveClaimDetail";
            public const string GetProformaInvoiceOrganizationAddress = "GetProformaInvoiceOrganizationAddress";
            public const string SaveMultiClaimDetail = "SaveMultiClaimDetail";
            public const string DeleteClaimDetail = "DeleteClaimDetail";
            public const string DeleteClaimSelectedRecords = "DeleteClaimSelectedRecords";

            public const string GetApchargesDuetoLocChange= "GetApchargesDuetoLocChange";
        }

        public static class ModelEntityCodeValue
        {
            /// <summary>
            /// EntityName : LocationType.
            /// </summary>
            public static class LocationType
            {
                /// <summary>
                /// Get Customer Details.
                /// </summary>
                public const string Customer = "Customer";
                public const string Location = "Location";
                public const string BusinessPartner = "BP";
            }

            /// <summary>
            /// EntityName : Roles.
            /// </summary>
            public static class Roles
            {
                /// <summary>
                /// Get Customer Details.
                /// </summary>
                public const string SalesManager = "SalesManager";
            }

            public static class OrderType
            {
                public const string CPUOrder = "CPUOrder";
                public const string Customer = "Customer";
                public const string CustomerReturn = "CustomerReturn";
                public const string CustomerToCustomer = "CustomerToCustomer";
                public const string StockTransfer = "StockTransfer";
                public const string Collections = "Collections";
                public const string ChargeOrder = "ChargeOrder";
            }

            public static class OrderStatus
            {
                public const string SendforShipping = "SendforShipping";
                public const string ShippedInventoryAndARChargesSentToMAS = "ShippedInventoryAndARChargesSentToMAS";
                public const string AssignedToShipment = "AssignedToShipment";
            }

        }

        public static class Authentication
        {
            public const string Token = "Token";
            public const string EncryptedKey = "eyEic@dm!n$1234asr";
            public const string RandomKey = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ!#$%&*@";
            public const string ConnectionString = "server=10.1.10.16;database=ADecTecDBDEV;User ID=lamps;password=atlanta@2013;";
        }

        public static class stringcons
        {
            public const string India_Standard_Time = "India Standard Time";

        }


        public static class PageActionType
        {
            public const string User = "User";
            public const string Patient = "Patient";
            public const string Carrier = "Carrier";
            public const string Location = "Location";
            public const string Organization = "Organization";
            public const string Resource = "Resource";
        }
        public static class JwtClaimIdentifiers
        {
            public const string Id = "id";
            public const string Email = "email";
            public const string TenantId = "tenantid";
            public const string Name = "name";
        }

        public static class ConfiguredDBs
        {
            public const string PostgreSQL = "POSTGRESQL";
            public const string SQLServer = "SQLSERVER";
        }
        public static class Errors
        {
            public const string Err500 = "Oops.Something went wrong... Unable to fulfill the request.";
            public const string Err501 = "Oops.Something went wrong... Unable to fulfill the request.";
            public const string CandidateError101 = "Candidate Alreday Delete";
            public const string InvalidMDY = "Invalid(MM/DD/YYYY)";
            public const string GraterDate = "Should be greater than or equal to today's date";
            public const string ErrorExceptionFilter = "Error in ExceptionFilter";
            public const string Success = "success";
            public const string Formnotsubmit = "Form not submitted";

            public const string InvalidClient = "Invalid client";
            public const string InvalidRequest = "Invalid request";
            public const string InvalidID = "Invalid ID";
            public const string InvalidCreatedDate = "Invalid created date";
            public const string InvalidAlertID = "Invalid Alert ID";
            public const string InvalidEntityID = "Invalid Entity ID";
            public const string InvalidName = "Invalid Name";
            public const string InvalidCode = "Invalid Code";
            public const string InvalidMaterial = "Invalid Material";
            public const string InvalidCharge = "Invalid Charge";
            public const string InvalidContract = "Invalid Contract";
            public const string InvalidShippingTo = "Invalid Shipping to location";
            public const string InvalidUpdatedBy = "Invalid updated by";


        }

        public static class OrderManagement
        {
            public static int ResuableContainerID = 3;
            public static string MaterialItem = "Material";
            public static string PackageItem = "Package";
        }

        public static class OrderManagementValidationMessage
        {
            public const string InvalidPO = "PurchaseOrderNumberMissing";
            public const string InvalidDate = "RequestedDelieveryDateMissing";
            public const string ValidDate = "Request delievery date should be greater thand today date.";
            public const string ValidShipToLocation = "InvalidLocation"; 
            public const string InvalidOrderType = "Please selecte valid order type.";
            public const string InvalidMaterials = "there is no any material and charges in order";
            public const string InvalidAdjustmentCharges = "there some invalid data into adjustment charges grid.";
            public const string MissingRPC = "Order must have at least one Resuable Container";
            public const string TruckOverloaded = "TruckOverloaded";
            public const string Material = "Material ";
            public const string CantMoreThan = "  can't more than ";
            public const string DuplicateMaterial = "Duplicate materials are in adjustment charegs.";
            public const string OneMaterialNeed = "OneMaterialNeeded";
            public const string MaterialAmountZero = "Material amount and ratevalue must be something.";
            public const string EquipmentMaterialEmpty = "EquipementTypeMissing";
            public const string FromLocationMissing = "FromLocationMissing";
            public const string BusinessPartnerMustBeMASWearHOuse = "MASInventoryWareHouseMissing";
            public const string ChargeShouldbeNonNegative = "InvalidARCharges";
            public const string InvalidScheduleDate = "ScheduleShipDateMissing";
            public const string MaterialQuantityPositive = "InvalidMaterialQuantity";
            public const string ValidShipToType = "InvalidShipToType";
            public const string MaterialSizeOver = "MaterialSizeOver";
            public const string mustarrivegraterthanScheduleshipdate = "mustarrivegraterthanscheduleshipdate";
            public const string linkedOrderTruckOverload = "linkedOrderTruckOverload";

            public const string InvalidCarrier = "CarrierMissing";

            // do not change this string value, with the help of this message we open material proeprty popup into UI.
            public const string Materialpropertymissing = "materialpropertymissing";
        }

        public static class AppConstants
        {
            public const string FilePath = "FilePath";
            public const string CandidateXL = "CandidateXL";
            public const string UploadPath = "UploadPath";
            public const string UploadPathWithSlash = "UploadPathWithSlash";
            public const string ResourcePath = "EY.EIC.Base.Api.Helpers.Resources.EICResources";
            public const string ApplicationJson = "application/json";
            public const string Authorization = "Authorization";
            public const string Bearer = "Bearer";
            public const string Package = "Package";

            public const string AccountName = "eicstorageaccount";
            public const string AccountKey = "VcXqHuxbV7EhHejbMftbVKDpRf5LMw8HztCFwuP68bcci87+u/QRT7kb8O69DuRoAabtDihOadu5xfsXT7K0NQ==";
        }

        // public static class JwtClaims
        // {
        //     public const string ApiAccess = "api_access";
        // }

        public static class SpecificCode
        {
            /// <summary>
            /// Get Customer Details.
            /// </summary>
            public const string OrderCode = "Tosca";
            public const string OrderNo = "1001";

        }

    }
}