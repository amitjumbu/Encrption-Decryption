using Microsoft.AspNetCore.Http;

namespace CoreBaseBusiness.Helpers
{
    public class Sessions
    {
        public static string CurrentUserRole = "";
        public static int CurrentUserId = 0;
        public static int TenantId = 0;
        public static string CurrentUserEmail = "";

    }
} 