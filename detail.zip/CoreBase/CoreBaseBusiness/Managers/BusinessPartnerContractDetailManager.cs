﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using NPOI.OpenXmlFormats.Dml;

    public class BusinessPartnerContractDetailManager : BaseManager<BusinessPartnerContractDetail, BusinessPartnerContractDetailViewModel>, IBusinessPartnerContractDetailManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;
        private readonly IConfiguration configuration;

        public BusinessPartnerContractDetailManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext, IConfiguration configuration)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        /// <summary>
        /// this method sends the BusinessPartnerContractDetail on ID Basis.
        /// </summary>
        /// <param name="id">Id of BusinessPartnerContractDetail</param>
        /// <returns>BusinessPartnerContractDetail Entity View Model.</returns>
        public async override Task<BusinessPartnerContractDetailViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWork.BusinessPartnerContractDetailRepository.GetAsync(id);
            var viewModel = this.mapper.Map<BusinessPartnerContractDetailViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<BusinessPartnerContractDetailViewModel>> ListAsync(BusinessPartnerContractDetailViewModel viewModel)
        {
            Expression<Func<BusinessPartnerContractDetail, bool>> condition = c => !c.IsDeleted && (c.BusinessPartnerContractId == viewModel.BusinessPartnerContractId || viewModel.BusinessPartnerContractId == 0 || viewModel.BusinessPartnerContractId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0 || viewModel.ClientId == null) && (c.ChargeId == viewModel.ChargeId || viewModel.ChargeId == 0 || viewModel.ChargeId == null);
            var module = await this.unitOfWork.BusinessPartnerContractDetailRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<BusinessPartnerContractDetailViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async override Task<bool> AddAsync(BusinessPartnerContractDetailViewModel viewModel)
        {
            var module = this.mapper.Map<BusinessPartnerContractDetail>(viewModel);
            var result = await this.unitOfWork.BusinessPartnerContractDetailRepository.AddAsync(module);
            return await Task.FromResult<bool>(result);
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(BusinessPartnerContractDetailViewModel viewModel)
        {
            var module = this.mapper.Map<BusinessPartnerContractDetail>(viewModel);
            var result = await this.unitOfWork.BusinessPartnerContractDetailRepository.UpdateAsync(module);
            return await Task.FromResult<bool>(result);
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(BusinessPartnerContractDetailViewModel viewModel)
        {
            Expression<Func<BusinessPartnerContractDetail, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.BusinessPartnerContractDetailRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        public async override Task<IEnumerable<BusinessPartnerContractDetailViewModel>> RangeAsync(int recordCount, BusinessPartnerContractDetailViewModel viewModel)
        {
            Expression<Func<BusinessPartnerContractDetail, bool>> condition = c => !c.IsDeleted && (c.BusinessPartnerContractId == viewModel.BusinessPartnerContractId || viewModel.BusinessPartnerContractId == 0 || viewModel.BusinessPartnerContractId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0 || viewModel.ClientId == null) && (c.ChargeId == viewModel.ChargeId || viewModel.ChargeId == 0 || viewModel.ChargeId == null);
            var module = await this.unitOfWork.BusinessPartnerContractDetailRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            if (module.Any())
            {
                var BusinessPartnerContractDetailModel = this.mapper.Map<IEnumerable<BusinessPartnerContractDetailViewModel>>(module);
                return BusinessPartnerContractDetailModel;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.BusinessPartnerContractDetailRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

     
    }
}