﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class SalesOrderDetailManager : BaseManager<SalesOrderDetail, SalesOrderDetailViewModel>, ISalesOrderDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public SalesOrderDetailManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        /// <summary>
        ///User can get Retrieves data from SalesOrderDetail by id.
        /// </summary>
        public override async Task<SalesOrderDetailViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.SalesOrderDetailRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<SalesOrderDetailViewModel>((SalesOrderDetail)module);
        }

        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async override Task<IEnumerable<SalesOrderDetailViewModel>> ListAsync(SalesOrderDetailViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<SalesOrderDetail, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.SalesOrderDetailRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<SalesOrderDetailViewModel>>(module);
        }

        /// <summary>
        /// SalesOrderDetail Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(SalesOrderDetailViewModel viewModel)
        {
            var module = this._mapper.Map<SalesOrderDetail>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
          
            var data = this._unitOfWork.SalesOrderDetailRepository.AddAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for SalesOrderDetail Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(SalesOrderDetailViewModel viewModel)
        {
            var module = this._mapper.Map<SalesOrderDetail>(viewModel);
            var data = this._unitOfWork.SalesOrderDetailRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from SalesOrderDetail.
        /// </summary>
        public async override Task<int> CountAsync(SalesOrderDetailViewModel viewModel)
        {
            Expression<Func<SalesOrderDetail, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.SalesOrderDetailRepository.CountAsync(condition);
        }

        /// <summary>
        ///Get All List for SalesOrderDetail Data List
        /// </summary>
        public async override Task<IEnumerable<SalesOrderDetailViewModel>> RangeAsync(int recordCount, SalesOrderDetailViewModel viewModel)
        {
            Expression<Func<SalesOrderDetail, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.SalesOrderDetailRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<SalesOrderDetailViewModel>>(module);
            return mappedData;
        }
        /// <summary>
        ///  Deletes record from location id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.SalesOrderDetailRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
    }
}