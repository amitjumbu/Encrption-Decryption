﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class FreightModeEquipTypeMapManager : BaseManager<FreightModeEquipmentTypeMapping, FreightModeEquipMapViewModel>, IFreightModeEquipTypeMapManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;


        public FreightModeEquipTypeMapManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }


        //public async Task<bool> SaveAll(IEnumerable<FreightModeEquipMapViewModel> viewModels)
        //{
        //    if (viewModels.Any())
        //    {
        //        foreach (FreightModeEquipMapViewModel ViewModel in viewModels)
        //        {

        //            var result = await this.unitOfWork.FreightModeEquipmentTypeMapRepository.AddAsync(this._mapper.Map<FreightModeEquipmentTypeMapping>(ViewModel)).ConfigureAwait(false);
        //        }

        //        var finalResult = this.unitOfWork.Save();

        //        return await Task.FromResult<bool>(finalResult).ConfigureAwait(false);

        //    }
        //    else
        //    {
        //        return await Task.FromResult<bool>(false).ConfigureAwait(false);
        //    }
        //}
        public async Task<IEnumerable<FreightModeEquipMapViewModel>> SaveAll(List<FreightModeEquipMapViewModel> ViewModels)
        {
            var freightalls = new List<FreightModeEquipMapViewModel>();

            foreach (FreightModeEquipMapViewModel ViewModel in ViewModels)
            {
                var module = this._mapper.Map<FreightModeEquipmentTypeMapping>(ViewModel);
                var result = await this.unitOfWork.FreightModeEquipmentTypeMapRepository.AddAsync(module).ConfigureAwait(false);
                //var result = await this._unitOfWork.freightmodeRepository.AddAsync(this._mapper.Map<FreightMode>(ViewModel)).ConfigureAwait(false);
                if (result)
                {
                    this.unitOfWork.Save();
                    ViewModel.ID = module.ID;
                    freightalls.Add(ViewModel);
                }
            }
            return freightalls;
        }


        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<int> ID = ids.ConvertAll(int.Parse);

                List<FreightModeEquipmentTypeMapping> freightmodeequiptypemap = this.unitOfWork.FreightModeEquipmentTypeMapRepository.ListAsync(p => ID.Contains(p.ID)).Result.ToList();
                
                foreach (FreightModeEquipmentTypeMapping freightmap in freightmodeequiptypemap)
                {
                    //freightmap.IsDeleted = false;                   
                    unitOfWork.FreightModeEquipmentTypeMapRepository.DeleteAsync(freightmap.ID);
                    var result = this.unitOfWork.Save();

                    
                }

                return await Task.FromResult<bool>(true);
            }

            return await Task.FromResult<bool>(false);
        }

        public override Task<bool> AddAsync(FreightModeEquipMapViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(FreightModeEquipMapViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<FreightModeEquipMapViewModel>> ListAsync(FreightModeEquipMapViewModel viewModel)
        {
            throw new NotImplementedException();
        }
        public async override Task<int> CountAsync(FreightModeEquipMapViewModel viewModel)
        {
            Expression<Func<FreightModeEquipmentTypeMapping, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.FreightModeID > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted && c.FreightModeID == viewModel.FreightModeID);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this.unitOfWork.FreightModeEquipmentTypeMapRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<FreightModeEquipMapViewModel>> RangeAsync(int recordCount, FreightModeEquipMapViewModel viewModel)
        {
            Expression<Func<FreightModeEquipmentTypeMapping, bool>> condition = (c => c.IsDeleted == false && c.FreightModeID == viewModel.FreightModeID);
            var module = await this.unitOfWork.FreightModeEquipmentTypeMapRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<FreightModeEquipMapViewModel>>(module);
            return mappedData;
        }
        
        public List<FreightModeEquipMapViewModel> GetFreightModeEquipMapList(long FreightModeID)
        {
            List<FreightModeEquipMapViewModel> usersList = new List<FreightModeEquipMapViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("FreightModeID", FreightModeID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetFreightModeEquipMapList", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new FreightModeEquipMapViewModel()
                    {
                        ID = Convert.ToInt32(dr["ID"]),
                        FreightModeID = Convert.ToInt32(dr["FreightModeID"]),
                        EquipmentTypeID = Convert.ToInt32(dr["EquipmentTypeID"]),
                        EquipmentTypeName = dr["EquipmentTypeName"].ToString()
                    });
                }
            }

            return usersList;
        }

        public async Task<IEnumerable<FreightModeEquipmentMapViewModel>> GetFreightModeEquipmentMapingList(FreightModeEquipmentMapViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {

                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }
            parameters.Add("ClientID", viewModel.ClientID);
            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }
            parameters.Add("FreightModeID", viewModel.FreightModeID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetFreightModeEquipmentMapList", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                
                var finalResult = ConvertDataTabe.CreateListFromTable<FreightModeEquipmentMapViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<FreightModeEquipmentMapViewModel>>(FilterResult<FreightModeEquipmentMapViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }
            return null;
        }
        public async Task<int> GetCount(FreightModeEquipMapViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientId);
                parameters.Add("FreightModeID", viewModel.FreightModeID);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_CountFreightModeEquipmentMaps", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FreightModeEquipMapViewModel>(ds.Tables[0]);
                int number = Convert.ToInt32(ds.Tables[0].Rows[0].Field<int>("RecordCount"));
                return await Task.FromResult<int>(number);
            }

            return 0;
        }
    }
}
