﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ChargeCategoryManager : BaseManager<ChargeCategory, ChargeCategoryViewModel>, IChargeCategoryManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public ChargeCategoryManager(IMapper mapper,  ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  To be implemeneted.
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> AddAsync(ChargeCategoryViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  List all the Charge Category.
        /// </summary>
        /// <param name="viewModel">ChargeCategoryViewModel to be used if we want to toggle between isdeleted flag</param>
        /// <returns>List of ChargeCategoryViewModel </returns>
        public async override Task<IEnumerable<ChargeCategoryViewModel>> ListAsync(ChargeCategoryViewModel viewModel)
        {
            var module = await this.unitOfWork.ChargeCategoryRepository.ListAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ChargeCategoryViewModel>>(module);
        }

        /// <summary>
        ///   To be implemeneted.
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> UpdateAsync(ChargeCategoryViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}