﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class CommodityManager : BaseManager<Commodity, CommodityViewModel>, ICommodityManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public CommodityManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

       

        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async Task<IEnumerable<CommodityTypeViewModel>> ListAsync(CommodityTypeViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Commodity, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientID || viewModel.ClientID == null || viewModel.ClientID == 0);

            var module = await this.unitOfWork.CommodityRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CommodityTypeViewModel>>(module);
        }

        ///// <summary>
        /////  Retrieves  All data from location.
        ///// </summary>
        //public async Task<IEnumerable<CommodityViewModel>> ListAsync(CommodityViewModel viewModel)
        //{
        //    // TODO: This can be used for contains 
        //    Expression<Func<Commodity, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientID || viewModel.ClientID == null || viewModel.ClientID == 0);

        //    var module = await this.unitOfWork.CommodityRepository.ListAsync(condition).ConfigureAwait(false);
        //    return this._mapper.Map<IEnumerable<CommodityViewModel>>(module);
        //}



        public async Task<IEnumerable<DepartmentViewModel>> ListSegmentAsync(DepartmentViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Department, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientId || viewModel.ClientId == null || viewModel.ClientId == 0);

            var module = await this.unitOfWork.CommodityRepository.ListSegmentAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<DepartmentViewModel>>(module);
        }

        public async Task<IEnumerable<CommodityViewModel>> ListCommodityAsync(CommodityViewModel viewModel = null)
        {
            var module = await this.unitOfWork.CommodityRepository.ListCommodityAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CommodityViewModel>>(module);
        }

        public async override Task<IEnumerable<CommodityViewModel>> ListAsync(CommodityViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Commodity, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientID || viewModel.ClientID == null || viewModel.ClientID == 0);

            var module = await this.unitOfWork.CommodityRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CommodityViewModel>>(module);
        }

        /// <summary>
        /// Commodity Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(CommodityViewModel viewModel)
        {
            var module = this._mapper.Map<Commodity>(viewModel);
            var data = this.unitOfWork.CommodityRepository.AddAsync(module);

            var finalResult = this.unitOfWork.Save();

            viewModel.ID = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Commodity Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(CommodityViewModel viewModel)
        {
            var module = this._mapper.Map<Commodity>(viewModel);
            var data = this.unitOfWork.CommodityRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Commodity.
        /// </summary>
        public async override Task<int> CountAsync(CommodityViewModel viewModel)
        {
            Expression<Func<Commodity, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.ID > 0)
            {
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            }
            else
            {
                condition = condition.And(c => c.IsDeleted == false);
            }

            return await this.unitOfWork.CommodityRepository.CountAsync(condition);
        }

        /// <summary>
        ///Get All List for Commodity Data List
        /// </summary>
        public async override Task<IEnumerable<CommodityViewModel>> RangeAsync(int recordCount, CommodityViewModel viewModel)
        {
            Expression<Func<Commodity, bool>> condition = (c => c.IsDeleted == false);
            var module = await this.unitOfWork.CommodityRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<CommodityViewModel>>(module);
            return mappedData;
        }
        /// <summary>
        ///  Deletes record from location id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.CommodityRepository.DeleteAsync(id, deletedBy);
            this.unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<IEnumerable<CommodityViewModel>> GetDefaultCommodity(RequestCommonViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ContractID", requestCommonViewModel.ContractID);
            parameters.Add("ContractType", requestCommonViewModel.ContractType);
            parameters.Add("MaterialID", requestCommonViewModel.MaterialID);
            parameters.Add("LocationID", requestCommonViewModel.ShipToLocationID);
            parameters.Add("ChargeID", requestCommonViewModel.ChargeID);
            parameters.Add("ClientID", requestCommonViewModel.ClientID);

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetDefaultCommodity", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                List<CommodityViewModel> orders = ConvertDataTabe.CreateListFromTable<CommodityViewModel>(ds.Tables[0]);

                if (orders.Count > 0)
                {
                    return await Task.FromResult<IEnumerable<CommodityViewModel>>(orders.AsEnumerable());
                }
                else
                {
                    return null;
                }
            }

            return null;
        }

        public async Task<IEnumerable<CommodityViewModel>> GetAllCommodity(CommodityViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (requestCommonViewModel != null && string.IsNullOrWhiteSpace(requestCommonViewModel.FilterOn))
            {
                parameters.Add("ClientID", requestCommonViewModel.ClientID);
                parameters.Add("PageNumber", requestCommonViewModel.PageNo);
                parameters.Add("PageSize", requestCommonViewModel.PageSize);
            }
            else
            {
                parameters.Add("ClientID", requestCommonViewModel.ClientID);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetAllCommodity", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CommodityViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CommodityViewModel>>(FilterResult<CommodityViewModel>.GetFilteredResult(finalResult, requestCommonViewModel.FilterOn, requestCommonViewModel.PageSize));
            }

            return null;
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> ID = ids.ConvertAll(long.Parse);

                List<Commodity> commodities = this.unitOfWork.CommodityRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();

                foreach (Commodity commodity in commodities)
                {
                    commodity.IsDeleted = true;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }

        public async Task<object> getCommodity(string code)
        {
            var comdata = await this.unitOfWork.CommodityRepository.GetByCode(code);    
            //var mappedData = this._mapper.Map<CommodityViewModel>(code);
            if (comdata != null)
            {
                return await Task.FromResult<object>(comdata);
            }
            else
            {
                return await Task.FromResult<object>(null);
            }
        }
    }
}