﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class BPManager : BaseManager<MeasurementBpmeasurementValue, BPViewModel>, IBPManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public BPManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<BPViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.BPRepository.GetAsync(id);

           
            var viewModel = this._mapper.Map<BPViewModel>(module);

            
            return viewModel; 
        }

        /// <summary>
        ///  Retrieves  All data from BP Details.
        /// </summary>
        public async override Task<IEnumerable<BPViewModel>> ListAsync(BPViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementBpmeasurementValue, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.BPRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<BPViewModel>>(module);
        }

        /// <summary>
        /// Add New BP Data into System
        /// </summary>
        public async override Task<bool> AddAsync(BPViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementBpmeasurementValue>(viewModel);
            var data = this._unitOfWork.BPRepository.AddAsync(module);

            

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for BP Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(BPViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementBpmeasurementValue>(viewModel);
            var data = this._unitOfWork.BPRepository.UpdateAsync(module);

            

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from BP Details.
        /// </summary>
        public async override Task<int> CountAsync(BPViewModel viewModel)
        {
            Expression<Func<MeasurementBpmeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.BPRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  BP details of Patient 
        /// </summary>
        public async override Task<IEnumerable<BPViewModel>> RangeAsync(int recordCount, BPViewModel viewModel)
        {
            // Expression<Func<MeasurementBpmeasurementValue, bool>> condition = (c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));

            Expression<Func<MeasurementBpmeasurementValue, bool>> condition = (c => c.IsDeleted == false);

          
            if (viewModel.IsAll)
            {
                condition = (c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId && c.StagesId == viewModel.StagesId);
            }
            else
            {
                condition = (c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId && c.StagesId == viewModel.StagesId && Convert.ToDecimal(c.UpperBPValue) < 420 && c.YAxisPosition <420);
            }
            var module = await this._unitOfWork.BPRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var BpModel = this._mapper.Map<IEnumerable<BPViewModel>>(module);
           

            return BpModel;
        }


        /// <summary>
        ///  Deletes record BP from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = await this._unitOfWork.BPRepository.DeleteAsync(id, deletedBy).ConfigureAwait(true);

            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


