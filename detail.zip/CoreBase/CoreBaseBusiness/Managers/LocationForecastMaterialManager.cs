﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;

    public class LocationForecastMaterialManager 
        : BaseManager<LocationForecastMaterial, LocationForecastMaterialViewModel>,
        ILocationForecastMaterialManager
    {
        private readonly IMapper mapper;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;


        public LocationForecastMaterialManager(
            IMapper mapper,
            ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  Retrieves  All data from LocationForecastMaterial for the view model location id .
        /// </summary>
        /// <returns>List of LocationForecastMaterial.</returns>
        public async override Task<IEnumerable<LocationForecastMaterialViewModel>> ListAsync(LocationForecastMaterialViewModel viewModel)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if(viewModel.LocationId > 0 )
            {
                chargeParameter.Add("LocationId", viewModel.LocationId);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetLocationForecastMaterial", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationForecastMaterialViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationForecastMaterialViewModel>>(finalResult.AsEnumerable());
            }

            return null;
        }

        /// <summary>
        /// LocationContact Add Data.
        /// </summary>
        /// <returns>boolean of success or failure .</returns>
        public async override Task<bool> AddAsync(LocationForecastMaterialViewModel viewModel)
        {
            string[] materialIdsList = viewModel.SelectedMaterialIds.Split(",");
            foreach (var item in materialIdsList)
            {
                if (item != "")
                {
                    viewModel.MaterialId = Convert.ToInt32(item);
                    var module = this.mapper.Map<LocationForecastMaterial>(viewModel);
                    module.IsDeleted = false;
                    module.UpdateDateTimeServer = DateTime.Now;
                    module.CreateDateTimeServer = DateTime.Now;
                    var setupAdd = await this.unitOfWork.LocationForecastMaterialRepository.AddAsync(module);
                    if (!setupAdd)
                    {
                        // if fails during any items delete , then return failure
                        return false;
                    }
                }
                
            }

            var data = this.unitOfWork.Save();
            return await Task.FromResult<bool>(data);
        }

        /// <summary>
        ///  Updates existing record for LocationContact Details.
        /// </summary>
        /// <returns>boolean of success or failure .</returns>
        public async override Task<bool> UpdateAsync(LocationForecastMaterialViewModel viewModel)
        {
            var module = this.mapper.Map<LocationForecastMaterial>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            var data = this.unitOfWork.LocationForecastMaterialRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }


        /// <summary>
        /// Get list of all non deleted LocationForecastMaterial.
        /// </summary>
        /// <returns>returns list of non Deleted LocationForecastMaterial.</returns>
        public async Task<IEnumerable<LocationForecastMaterialViewModel>> GetList()
        {
            Expression<Func<LocationForecastMaterial, bool>> condition = c => c.IsDeleted == false;
            var module = await this.unitOfWork.LocationForecastMaterialRepository.GetList(condition);
            var mappedData = this.mapper.Map<IEnumerable<LocationForecastMaterialViewModel>>(module);
            return mappedData;
        }

        /// <summary>
        /// Get list of all non deleted LocationForecastMaterial for a location Id .
        /// </summary>
        /// <returns>returns list of non Deleted LocationForecastMaterial for a location Id .</returns>
        public async Task<IEnumerable<LocationForecastMaterialViewModel>> GetListByLocationId(long locationId)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (locationId > 0)
            {
                chargeParameter.Add("LocationId", locationId);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetLocationForecastMaterial", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationForecastMaterialViewModel>(ds.Tables[0]);
                return await Task.FromResult(finalResult.AsEnumerable());
            }

            return null;
        }


        /// <summary>
        ///  Deletes record from LocationForecastMaterial by id.
        /// </summary>
        /// <returns>returns success or failure boolean.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.LocationForecastMaterialRepository.DeleteAsync(id, deletedBy);
            this.unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<bool> DeleteByIdsAsync(int[] ids, string deletedBy)
        {
            foreach (int id in ids)
            {
               var setupDelete = await this.unitOfWork.LocationForecastMaterialRepository.DeleteAsync(id, deletedBy);
                if (!setupDelete)
                {
                    // if fails during any items delete , then return failure
                    return false;
                }
            }

            var saveResponse = this.unitOfWork.Save();

            return await Task.FromResult<bool>(saveResponse);
        }

        public async Task<IEnumerable<ForecastCustomerLocationViewModel>> SaveAll(List<ForecastCustomerLocationViewModel> viewModels)
        {
            var materialLocationall = new List<ForecastCustomerLocationViewModel>();

            foreach (ForecastCustomerLocationViewModel viewModel in viewModels)
            {
                var model = this.mapper.Map<LocationForecastMaterial>(viewModel);
                var result = await this.unitOfWork.LocationForecastMaterialRepository.SaveLocationToMaterialAsync(model).ConfigureAwait(false);
                if (result)
                {
                    this.unitOfWork.Save();
                    materialLocationall.Add(viewModel);
                }
            }

            return materialLocationall;
        }

        public async Task<IEnumerable<ForecastCustomerLocationViewModel>> DeleteAllAsync(List<ForecastCustomerLocationViewModel> viewModels)
        {
            var materialLocationall = new List<ForecastCustomerLocationViewModel>();

            foreach (ForecastCustomerLocationViewModel viewModel in viewModels)
            {
                var model = this.mapper.Map<LocationForecastMaterial>(viewModel);
                var result = await this.unitOfWork.LocationForecastMaterialRepository.DeleteLocationToMaterialAsync(model).ConfigureAwait(false);
                if (result)
                {
                    this.unitOfWork.Save();
                    materialLocationall.Add(viewModel);
                }
            }

            return materialLocationall;
            ////if (ids.Any())
            ////{
            //    List<long> iD = ids.ConvertAll(long.Parse);

            //    List<LocationForecastMaterial> locationstoMaterials = this.unitOfWork.LocationForecastMaterialRepository.ListAsync(p => iD.Contains(p.Id)).Result.ToList();

            //    foreach (LocationForecastMaterial locationstoMaterial in locationstoMaterials)
            //    {
            //        await this.unitOfWork.LocationForecastMaterialRepository.DeleteLocationToMaterialAsync(locationstoMaterial.Id);
            //        var result = this.unitOfWork.Save();
            //    }

            //    return await Task.FromResult<bool>(true);
            ////}

            //return await Task.FromResult<bool>(false);
        }
    }
}