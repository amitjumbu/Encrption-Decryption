﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class ForecastManager : BaseManager<Forecast, ForecastViewModel>, IForecastManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;


        public ForecastManager(
            IMapper mapper,
            ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.unitOfWork.ConnectionString = this.BaseConnectionString;
        }

        Task<IEnumerable<ForecastViewModel>> IForecastManager.GetListById(long id)
        {
            throw new System.NotImplementedException();
        }

        public override Task<bool> AddAsync(ForecastViewModel viewModel)
        {
            throw new System.NotImplementedException();
        }

        public override Task<bool> UpdateAsync(ForecastViewModel viewModel)
        {
            throw new System.NotImplementedException();
        }

        public async override Task<IEnumerable<ForecastViewModel>> ListAsync(ForecastViewModel viewModel)
        {

            var module = await this.unitOfWork.ForecastRepository
                                    .ListAsync(c => viewModel != null ? c.IsDeleted == viewModel.IsDeleted : !c.IsDeleted)
                                    .ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ForecastViewModel>>(module);
        }

        public async Task<bool> AddForecast(ForecastViewModel viewModel)
        {
            if (viewModel != null)
            {
                var forecastToAdd = this.mapper.Map<Forecast>(viewModel);
                if (string.IsNullOrEmpty(forecastToAdd.Code))
                {
                    forecastToAdd.Code = forecastToAdd.Name.Replace(" ", string.Empty);
                }

                // default the forecast Tpe
                forecastToAdd.ForecastTypeId = this.GetDefaultForeCastTypeId();

                var added = await this.unitOfWork.ForecastRepository.AddAsync(forecastToAdd);
                if (added)
                {
                    this.unitOfWork.Save();
                }
                else
                {
                    return false;
                }

                if (viewModel.SalesManagerIds != null && viewModel.SalesManagerIds.Count > 0)
                {
                    // create forecast details
                    Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
                    chargeParameter.Add("ForecastName", viewModel.Name);
                    chargeParameter.Add("SalesManagerId", string.Join(",", viewModel.SalesManagerIds.ToArray()));
                    DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_AddForecastDetail", chargeParameter);

                    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            var isSuccess = Convert.ToInt32(dr["Success"]);
                            if (isSuccess == 1)
                            {
                                return true;
                            }
                            else
                            {
                                // rollback the forecast which was created.
                                var deleted = await this.unitOfWork.ForecastRepository.TruncatebyNameAsync(viewModel.Name);
                                if (deleted)
                                {
                                    this.unitOfWork.Save();
                                }

                                return false;
                            }
                        }
                    }
                }

            }

            return false;
        }

        private int GetDefaultForeCastTypeId()
        {
            Dictionary<string, object> forecastTypeParameter = new Dictionary<string, object>();
            forecastTypeParameter.Add("Code", "PrefForecastType");
            DataSet forecastTypeDs = this.unitOfWork.ExecuteProcedure("Sp_GetPreferenceTypeByCode", forecastTypeParameter);

            if (forecastTypeDs != null && forecastTypeDs.Tables != null && forecastTypeDs.Tables.Count > 0)
            {
                foreach (DataRow dr in forecastTypeDs.Tables[0].Rows)
                {
                    try
                    {
                        var modifiedValue = Convert.ToInt32(dr["ModifiedValue"]);
                        if (modifiedValue > 0)
                        {
                            return modifiedValue;
                        }
                    }
                    catch (Exception ex)
                    {
                        // not performing any action
                    }
                }
            }
            return 0;
        }

        public async Task<bool> DuplicateExists(ForecastViewModel viewModel)
        {
            if (viewModel != null)
            {
                var existingModel = await this.unitOfWork.ForecastRepository.GetByNameAsync(viewModel.Name);
                return existingModel != null;
            }
            return false;
        }

        public async Task<List<string>> GetDynamicColumnById(long forecastId)
        {

            // create forecast details
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            chargeParameter.Add("ForecastId", forecastId);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetForecastDynamicColumns", chargeParameter);
            List<string> columns = new List<string>();
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    columns.Add(dr["ColumnName"].ToString());

                }


            }

            return columns;
        }

        public async Task<IEnumerable<object>> GetForecastDetailById(ForecastViewModel forecast)
        {
            // get forecast details
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            chargeParameter.Add("ForecastId", forecast.ID);
            chargeParameter.Add("SortColumn", forecast.SortColumn);
            chargeParameter.Add("SortOrder", forecast.SortOrder);
            chargeParameter.Add("PageNumber", forecast.PageNo);
            chargeParameter.Add("PageSize", forecast.PageSize);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetForecastDetailById", chargeParameter);
            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> row;
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var dataTable = ds.Tables[0];
                var columns = dataTable.Columns;
                foreach (DataRow dr in dataTable.Rows)
                {
                    row = new Dictionary<string, string>();
                    var filterstring = string.Empty;
                    foreach (DataColumn col in dataTable.Columns)
                    {
                        var columnValue = dr[col] != null
                                            ? dr[col].ToString()
                                            : string.Empty;
                        filterstring += columnValue;
                        row.Add(col.ColumnName, columnValue);
                    }

                    // add filtering logic
                    if (string.IsNullOrEmpty(forecast.FilterOn)
                                                || forecast.FilterOn.Split(' ')
                                                    .ToList()
                                                    .Any(s => filterstring
                                                              .Contains(s, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        rows.Add(row);
                    }
                }
            }
            return await Task.FromResult<IEnumerable<object>>(rows);
        }  
        
        public async Task<IEnumerable<ForecastChildViewModel>> GetChildForecastDetailById(ForecastViewModel forecast)
        {
            // get forecast details
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            chargeParameter.Add("ForecastId", forecast.ID);
            chargeParameter.Add("SortColumn", forecast.SortColumn);
            chargeParameter.Add("SortOrder", forecast.SortOrder);
            chargeParameter.Add("PageNumber", forecast.PageNo);
            chargeParameter.Add("PageSize", forecast.PageSize);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetChildForecastDetailById", chargeParameter);
            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> row;

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {

                var finalResult = ConvertDataTabe.CreateListFromTable<ForecastChildViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<ForecastChildViewModel>>(finalResult);
            }
            return null;
        }

        public async Task<IEnumerable<object>> GetForecastTemplateById(ForecastViewModel forecast)
        {
            List<string> templateColumn = await GetColumnsForForecastTemplate(forecast.ID);
            // get forecast details
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            chargeParameter.Add("ForecastId", forecast.ID);
            chargeParameter.Add("SortColumn", forecast.SortColumn);
            chargeParameter.Add("SortOrder", forecast.SortOrder);
            chargeParameter.Add("PageNumber", forecast.PageNo);
            chargeParameter.Add("PageSize", forecast.PageSize);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetForecastDetailById", chargeParameter);
            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> row;
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var dataTable = ds.Tables[0];
                var columns = dataTable.Columns;
                foreach (DataRow dr in dataTable.Rows)
                {
                    row = new Dictionary<string, string>();
                    var filterstring = string.Empty;
                    foreach (var col in templateColumn)
                    {
                        var columnValue = dr[col] != null
                                            ? dr[col].ToString()
                                            : string.Empty;
                        filterstring += columnValue;
                        foreach (var column in dataTable.Columns)
                        {
                            if (column.ToString().Contains(col))
                            {
                                row.Add(column.ToString(), columnValue);
                            }

                        }
                    }

                    rows.Add(row);
                }
            }
            return await Task.FromResult<IEnumerable<object>>(rows);
        }

        private async Task<List<string>> GetColumnsForForecastTemplate(long forecastId)
        {
            string[] defaultColumns = { "Status", "SalesManagername", "GroupName",
                "MasCustomerCode", "BillingEntityName", "MasLocationAddressCode",
                "ShipToLocation", "MaterialDescription", "CommodityName", "DataSegment", "Total"};
            List<string> templateColumn = new List<string>(defaultColumns);
            var dynamicColumn = await this.GetDynamicColumnById(forecastId);
            templateColumn.AddRange(dynamicColumn);
            return templateColumn;
        }

        public async Task<IEnumerable<object>> GetStatusAggregateForecastDetailById(ForecastViewModel forecast)
        {
            // get forecast details
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            chargeParameter.Add("ForecastId", forecast.ID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetStatusAggregateForecastDetailById", chargeParameter);
            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();
            Dictionary<string, string> row;
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var dataTable = ds.Tables[0];
                var columns = dataTable.Columns;
                foreach (DataRow dr in dataTable.Rows)
                {
                    row = new Dictionary<string, string>();
                    var filterstring = string.Empty;
                    foreach (DataColumn col in dataTable.Columns)
                    {
                        var columnValue = dr[col] != null
                                            ? dr[col].ToString()
                                            : string.Empty;
                        filterstring += columnValue;
                        row.Add(col.ColumnName, columnValue);
                    }

                    rows.Add(row);
                }
            }
            return await Task.FromResult<IEnumerable<object>>(rows);
        }
        
        public async Task<ForecastViewModel> GetLastUpdatedForecast()
        {
            // get last updated forecast details
            var lastUpdatedForecastDetail = await this.unitOfWork.ForecastDetailRepository.GetLastUpdatedForecastDetail();
            if (lastUpdatedForecastDetail != null)
            {
                // get forecast info based on forecast detail 
                var forcastDetail = await this.unitOfWork.ForecastRepository
                                .GetById(lastUpdatedForecastDetail.ForecastId);
                return await Task.FromResult<ForecastViewModel>(this.mapper.Map<ForecastViewModel>(forcastDetail));
            }
            return null;
        }
        public async Task<ForecastRelationViewModel> UploadForecast(IFormFile file, ForecastUploadViewModel forecastUploadViewModel)
        {
            // template column for forecastId
            List<string> templateColumn = await GetColumnsForForecastTemplate(forecastUploadViewModel.ParentForecastId);
            // create forecast 
            var parentForecast = await this.unitOfWork.ForecastRepository.GetById(forecastUploadViewModel.ParentForecastId);
            if (parentForecast == null)
                throw new Exception("No parent forecast found");


            // create new Forecast 
            var forecastToAdd = new Forecast();
            forecastToAdd.Name = forecastUploadViewModel.ForecastName;
            forecastToAdd.Description = forecastUploadViewModel.ForecastDesc;
            forecastToAdd.Code = forecastToAdd.Name.Replace(" ", string.Empty);
            forecastToAdd.ForecastTypeId = parentForecast.ForecastTypeId;
            forecastToAdd.StartDate = parentForecast.StartDate;
            forecastToAdd.EndDate = parentForecast.EndDate;
            forecastToAdd.CalendarTypeId = parentForecast.CalendarTypeId;
            forecastToAdd.ClientId = parentForecast.ClientId;
            forecastToAdd.SourceSystemId = parentForecast.SourceSystemId;
            forecastToAdd.CreateDateTimeBrowser = DateTime.UtcNow;
            forecastToAdd.CreateDateTimeServer = DateTime.UtcNow;
            forecastToAdd.UpdateDateTimeBrowser = DateTime.UtcNow;
            forecastToAdd.UpdateDateTimeServer = DateTime.UtcNow;
            forecastToAdd.UpdatedBy = forecastUploadViewModel.CreatedBy;
            forecastToAdd.CreatedBy = forecastUploadViewModel.CreatedBy;

            var addForecast = await this.unitOfWork.ForecastRepository.AddAsync(forecastToAdd);
            if (addForecast)
            {
                this.unitOfWork.Save();
            }
            var newForecast = await this.unitOfWork.ForecastRepository.GetByNameAsync(forecastUploadViewModel.ForecastName);
            if (newForecast == null)
                throw new Exception("Child forecast was not created successfully.");

            // read file
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = new MemoryStream())
            {
                file.CopyTo(stream);
                stream.Position = 0;
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var dynamicColumn = await this.GetDynamicColumnById(parentForecast.Id);
                    var conf = new ExcelDataSetConfiguration
                    {
                        ConfigureDataTable = _ => new ExcelDataTableConfiguration
                        {
                            UseHeaderRow = true
                        }
                    };

                    var dataSet = reader.AsDataSet(conf);

                    // Now you can get data from each sheet by its index or its "name"
                    var dataTable = dataSet.Tables[0];

                    for (var i = 0; i < dataTable.Rows.Count; i++)
                    {
                        foreach (var periodStartCode in dynamicColumn)
                        {
                            ForecastDetail forecastDetail = new ForecastDetail();
                            forecastDetail.ForecastId = newForecast.Id;
                            forecastDetail.PeriodStartCode = periodStartCode;

                            // get Location 
                            var externalSourceLocationKey = dataTable.Rows[i]["MasLocationAddressCode"];
                            Expression<Func<Location, bool>> condition =
                                    c => c.IsDeleted == false
                                            && c.ExternalSourceLocationKey == externalSourceLocationKey && c.IsActive == true;
                            var locationList = await this.unitOfWork.LocationRepository.GetLocationByCondition(condition);
                            if (locationList != null)
                            {
                                forecastDetail.LocationId = locationList.Id;
                            }
                            else
                            {
                                break;
                            }

                            // get material
                            var materialCode = dataTable.Rows[i]["MaterialDescription"];
                            var material = await this.unitOfWork.MaterialRepository.GetByCode(materialCode.ToString());
                            if (locationList != null)
                            {
                                forecastDetail.MaterialId = material.Id;
                            }
                            else
                            {
                                break;
                            }

                            var status = dataTable.Rows[i]["Status"];
                            Expression<Func<ForecastDetail, bool>> forecastCondition =
                                    c => c.IsDeleted == false
                                            && c.LocationId == forecastDetail.LocationId
                                            && (status == null || c.LocationStatus == status.ToString())
                                            && c.MaterialId == forecastDetail.MaterialId
                                            && c.PeriodStartCode == periodStartCode
                                            && c.IsDeleted == false;
                            var existingForecastDetail = await
                                this.unitOfWork.ForecastDetailRepository.GetForecastDetailAsync(forecastCondition);
                            if (existingForecastDetail != null)
                            {
                                forecastDetail = existingForecastDetail;

                            }
                            else
                            {
                                // period start date
                                forecastDetail.PeriodStartDate = parentForecast.StartDate;
                                forecastDetail.CreateDateTimeBrowser = DateTime.UtcNow;
                                forecastDetail.CreateDateTimeServer = DateTime.UtcNow;
                                forecastDetail.CreatedBy = newForecast.CreatedBy;
                            }

                            forecastDetail.UpdateDateTimeBrowser = DateTime.UtcNow;
                            forecastDetail.UpdateDateTimeServer = DateTime.UtcNow;
                            forecastDetail.UpdatedBy = newForecast.UpdatedBy;
                            var periodStartValue = !string.IsNullOrEmpty(dataTable.Rows[i][periodStartCode].ToString())
                                                    ? Convert.ToDecimal(dataTable.Rows[i][periodStartCode])
                                                    : 0;

                            if (forecastUploadViewModel.IsOverride)
                            {
                                forecastDetail.Quantity = periodStartValue;
                            }
                            else
                            {
                                forecastDetail.Quantity = forecastDetail.Quantity + periodStartValue;
                            }
                            if (existingForecastDetail != null)
                            {
                                var updateForecastDetail = await this.unitOfWork.ForecastDetailRepository.UpdateAsync(forecastDetail);
                                if (updateForecastDetail)
                                {
                                    this.unitOfWork.Save();
                                }
                            }
                            else
                            {
                                var addForecastDetail = await this.unitOfWork.ForecastDetailRepository.AddAsync(forecastDetail);
                                if (addForecastDetail)
                                {
                                    this.unitOfWork.Save();
                                }
                            }
                               
                        }
                    }
                }
            }

            // add relation 
            ForecastRelation forecastRelation = new ForecastRelation();
            forecastRelation.ChildForecastId = newForecast.Id;
            forecastRelation.ParentForecastId = parentForecast.Id;
            Expression<Func<ForecastImportActionType, bool>> forecastImportCondition =
                                  c => c.IsDeleted == false 
                                  && c.Code == (forecastUploadViewModel.IsOverride ? "OverwriteAmount" : "AddAmount");
            var forecastImportTypes = await this.unitOfWork.ForecastImportActionTypeRepository.ListAsync(forecastImportCondition);
            if (forecastImportTypes != null && forecastImportTypes.Count() == 1)
            {
                forecastRelation.ForecastImportActionTypeId = forecastImportTypes.First().Id;
            }
            else
            {
                throw new Exception("Invalid forecast import type Id");
            }

            forecastRelation.ClientId = newForecast.ClientId;
            forecastRelation.SourceSystemId = newForecast.SourceSystemId;
            forecastRelation.CreateDateTimeServer = DateTime.UtcNow;
            forecastRelation.CreateDateTimeBrowser = DateTime.UtcNow;
            forecastRelation.CreatedBy = newForecast.CreatedBy;
            forecastRelation.UpdateDateTimeBrowser = DateTime.UtcNow;
            forecastRelation.UpdateDateTimeServer = DateTime.UtcNow;
            forecastRelation.UpdatedBy = newForecast.UpdatedBy;

            var relationadded = await this.unitOfWork.ForecastRelationRepository.AddAsync(forecastRelation);
            if (relationadded)
            {
                this.unitOfWork.Save();
                var modelToreturn = this.mapper.Map<ForecastRelationViewModel>(forecastRelation);
                modelToreturn.ParentForecastName = parentForecast.Name;
                modelToreturn.ChildForecastName = newForecast.Name;
                modelToreturn.ForecastImportActionTypeName = forecastImportTypes.First().Name;
                return modelToreturn;
            }

            return null;
        }
    }
}
