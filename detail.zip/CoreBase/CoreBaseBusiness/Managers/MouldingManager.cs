﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class MouldingManager : BaseManager<MeasurementMouldingMeasurementValue, MouldingViewModel>, IMouldingManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public MouldingManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<MouldingViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.MouldingRepository.GetAsync(id);

            
            var viewModel = this._mapper.Map<MouldingViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_MouldingMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<MouldingViewModel>> ListAsync(MouldingViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementMouldingMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }

            var module = await this._unitOfWork.MouldingRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<MouldingViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_MouldingMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(MouldingViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementMouldingMeasurementValue>(viewModel);
            var data = this._unitOfWork.MouldingRepository.AddAsync(module);

            
            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult); 
        }

        /// <summary>
        ///  Updates existing record for Measurement_MouldingMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(MouldingViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementMouldingMeasurementValue>(viewModel);
            var data = this._unitOfWork.MouldingRepository.UpdateAsync(module);

           

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_MouldingMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(MouldingViewModel viewModel)
        {
            Expression<Func<MeasurementMouldingMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c. == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.MouldingRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_MouldingMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<MouldingViewModel>> RangeAsync(int recordCount, MouldingViewModel viewModel)
        {
            Expression<Func<MeasurementMouldingMeasurementValue, bool>> condition = (c => c.IsDeleted == false);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            var module = await this._unitOfWork.MouldingRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var MouldingModel = this._mapper.Map<IEnumerable<MouldingViewModel>>(module);
            

            return MouldingModel;
        }


        /// <summary>
        ///  Deletes record Measurement_MouldingMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.MouldingRepository.DeleteAsync(id, deletedBy);

            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


