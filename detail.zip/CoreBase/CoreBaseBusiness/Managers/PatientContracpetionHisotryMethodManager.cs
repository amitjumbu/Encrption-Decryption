﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientContracpetionHisotryMethodManager : BaseManager<PatientContracpetionHisotryMethod, PatientContracpetionHisotryMethodViewModel>, IPatientContracpetionHisotryMethodManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientContracpetionHisotryMethodManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        

        public async override Task<int> CountAsync(PatientContracpetionHisotryMethodViewModel viewModel)
        {
            Expression<Func<PatientContracpetionHisotryMethod, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientContracpetionHisotryMethodRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientContracpetionHisotryMethodViewModel>> RangeAsync(int recordCount, PatientContracpetionHisotryMethodViewModel viewModel)
        {
            Expression<Func<PatientContracpetionHisotryMethod, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientContracpetionHisotryMethodRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientContracpetionHisotryMethodViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientContracpetionHisotryMethodViewModel>> ListAsync(PatientContracpetionHisotryMethodViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientContracpetionHisotryMethod, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientContracpetionHisotryMethodRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientContracpetionHisotryMethodViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientContracpetionHisotryMethodViewModel viewModel)
        {
            var module = this._mapper.Map<PatientContracpetionHisotryMethod>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientContracpetionHisotryMethodRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientContracpetionHisotryMethodViewModel viewModel)
        {
            var module = this._mapper.Map<PatientContracpetionHisotryMethod>(viewModel);
            var data = this._unitOfWork.PatientContracpetionHisotryMethodRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
    }
}