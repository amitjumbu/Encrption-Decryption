﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class MaterialGroupDetailsManager : BaseManager<MaterialGroupDetail, MaterialGroupDetailsViewModel>, IMaterialGroupDetailsManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public MaterialGroupDetailsManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }



        //public async Task<MaterialGroupDetailsViewModel> GetMaterialGroupDetailById(int mTGDId)
        //{
        //    var comtypedata = await unitOfWork.MaterialGroupDetailsRepository.GetMaterialGroupDetailById(mTGDId);

        //    var mappedData = this._mapper.Map<MaterialGroupDetailsViewModel>(comtypedata);
        //    if (mappedData != null)
        //    {
        //        return mappedData;
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}

        public override Task<bool> AddAsync(MaterialGroupDetailsViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<MaterialGroupDetailsViewModel>> ListAsync(MaterialGroupDetailsViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(MaterialGroupDetailsViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MaterialGroupDetailsViewModel>> GetMaterialGroupDetailById(MaterialGroupDetailsViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialGroupID", viewModel.MaterialGroupID);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetMaterialGroupDetailById", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialGroupDetailsViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialGroupDetailsViewModel>>(FilterResult<MaterialGroupDetailsViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        public async Task<int> CountMGDAsync(MaterialGroupDetailsViewModel viewModel)
        {
            Expression<Func<MaterialGroupDetail, bool>> condition = c => !c.IsDeleted && (c.MaterialGroupId == viewModel.MaterialGroupID);

            var module = await this.unitOfWork.MaterialGroupDetailsRepository.GetMaterialGroupDetailCountById(condition).ConfigureAwait(false);
            return module;
        }
    }
}