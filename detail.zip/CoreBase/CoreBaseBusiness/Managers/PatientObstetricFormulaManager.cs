﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientObstetricFormulaManager : BaseManager<PatientObstetricFormula, PatientObstetricFormulaViewModel>, IPatientObstetricFormulaManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientObstetricFormulaManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        public override async Task<PatientObstetricFormulaViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.PatientObstetricFormulaRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<PatientObstetricFormulaViewModel>((PatientObstetricFormula)module);
        }

        public async override Task<int> CountAsync(PatientObstetricFormulaViewModel viewModel)
        {
            Expression<Func<PatientObstetricFormula, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientObstetricFormulaRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientObstetricFormulaViewModel>> RangeAsync(int recordCount, PatientObstetricFormulaViewModel viewModel)
        {
            Expression<Func<PatientObstetricFormula, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientObstetricFormulaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientObstetricFormulaViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientObstetricFormulaViewModel>> ListAsync(PatientObstetricFormulaViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientObstetricFormula, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientObstetricFormulaRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientObstetricFormulaViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientObstetricFormulaViewModel viewModel)
        {
            var module = this._mapper.Map<PatientObstetricFormula>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientObstetricFormulaRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientObstetricFormulaViewModel viewModel)
        {
            var module = this._mapper.Map<PatientObstetricFormula>(viewModel);
            var data = this._unitOfWork.PatientObstetricFormulaRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
        public List<ChoiceOfBirthingPartnerViewModel> GetChoiceofBirthingPartner()
        {
            List<ChoiceOfBirthingPartnerViewModel> usersList = new List<ChoiceOfBirthingPartnerViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            //parameters.Add("ClientID", ClientId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetChoiceofBirthingPartner");

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new ChoiceOfBirthingPartnerViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        Name = dr["Name"].ToString()
                    });
                }
            }

            return usersList;
        }
    }
}