﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class LocationPreferredMaterialManager : BaseManager<LocationPreferredMaterial, LocationPreferredMaterialViewModel>, ILocationPreferredMaterialManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public LocationPreferredMaterialManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///User can get Retrieves data from LocationContact by id.
        /// </summary>
        //public override async Task<LocationPreferredMaterialViewModel> GetAsync(int id)
        //{
        //    var module = await _unitOfWork.LocationPreferredMaterialRepository.GetById(id).ConfigureAwait(false);
        //    return this._mapper.Map<LocationPreferredMaterialViewModel>((LocationPreferredMaterial)module);
        //}


        ///// <summary>
        ///// Commodity Add Data.
        ///// </summary>
        //public async override Task<bool> AddAsync(LocationContactViewModel viewModel)
        //{
        //    var module = this._mapper.Map<LocationContact>(viewModel);
        //    var data = this._unitOfWork.LocationContactRepository.AddAsync(module);

        //    var finalResult = this._unitOfWork.Save();

        //    viewModel.Id = finalResult ? module.Id : 0;

        //    return await Task.FromResult<bool>(finalResult);
        //}


        /// <summary>
        ///  Retrieves  All data from LocationContact.
        /// </summary>
        public async override Task<IEnumerable<LocationPreferredMaterialViewModel>> ListAsync(LocationPreferredMaterialViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<LocationPreferredMaterial, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.LocationPreferredMaterialRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<LocationPreferredMaterialViewModel>>(module);
        }

        /// <summary>
        /// LocationContact Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(LocationPreferredMaterialViewModel viewModel)
        {
            var module = this._mapper.Map<LocationPreferredMaterial>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.Material = null;
            module.Uom = null;
            var data = this._unitOfWork.LocationPreferredMaterialRepository.AddAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for LocationContact Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(LocationPreferredMaterialViewModel viewModel)
        {
            if (viewModel.PageAction == Constants.PageActionType.Location)
            {
                var module = this._mapper.Map<LocationPreferredMaterial>(viewModel);
                module.IsDeleted = false;
                module.UpdateDateTimeServer = DateTime.Now;
                module.CreateDateTimeServer = DateTime.Now;
                module.Material = null;
                module.Uom = null;
                var data = this._unitOfWork.LocationPreferredMaterialRepository.UpdateAsync(module);
                this._unitOfWork.Save();
                return await Task.FromResult<bool>(data.Result);
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        ///  Retrieves Count Of All data from LocationContact.
        /// </summary>
        public async override Task<int> CountAsync(LocationPreferredMaterialViewModel viewModel)
        {
            Expression<Func<LocationPreferredMaterial, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.LocationPreferredMaterialRepository.CountAsync(condition);
        }

        /// <summary>
        /// Get All List for LocationContact Data List
        /// </summary>
        public async override Task<IEnumerable<LocationPreferredMaterialViewModel>> RangeAsync(int recordCount, LocationPreferredMaterialViewModel viewModel)
        {
            Expression<Func<LocationPreferredMaterial, bool>> condition = c => c.IsDeleted == false && c.LocationId == viewModel.LocationId;
            var module = await this._unitOfWork.LocationPreferredMaterialRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationPreferredMaterialViewModel>>(module);
            return mappedData;
        }


        /// <summary>
        /// User can get list by locatinId.
        /// </summary>
        public async Task<IEnumerable<LocationPreferredMaterialViewModel>> GetList(int id)
        {
            Expression<Func<LocationPreferredMaterial, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.LocationPreferredMaterialRepository.GetList(condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationPreferredMaterialViewModel>>(module);
            return mappedData;
        }

        public async Task<IEnumerable<LocationPreferredMaterialViewModel>> GetPreferredMaterialbyId(LocationPreferredMaterialViewModel viewModel)
        {
            if(viewModel.PageAction == Constants.PageActionType.Location)
            {
                Expression<Func<LocationPreferredMaterial, bool>> condition = (c => c.IsDeleted == false);
                var module = await this._unitOfWork.LocationPreferredMaterialRepository.GetById(viewModel.MaterialIds);
                //module.Material = null;
                //module.Uom = null;
                var mappedData = this._mapper.Map<IEnumerable<LocationPreferredMaterialViewModel>>(module);
                return mappedData;
            }
            else
            {
                return null;
            }
        }

        public async Task<long> GetLocationTypedId(string code)
        {
            Expression<Func<LocationType, bool>> condition = c => c.IsDeleted == false && c.Code == code;
            var module = await this._unitOfWork.LocationTypeRepository.GetLocationTypeId(condition);
            return module.ID;
        }

        /// <summary>
        ///  Deletes record from LocationContact id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.LocationPreferredMaterialRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        //public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel)
        //{
        //    long locationTypeId = await this.GetLocationTypedId(viewModel.LocationTypeCode);

        //    Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationTypeId == locationTypeId && c.ClientId == viewModel.ClientId && c.IsActive == true;
        //    var module = await this._unitOfWork.LocationRepository.GetList(condition);
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        //    return mappedData;

        //}

        /// <summary>
        ///  Deletes record Caput from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {

            var data = this._unitOfWork.LocationPreferredMaterialRepository.DeleteAsync(id, deletedBy);            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }


        /// <summary>
        /// Softly remove UserAddress from the system.
        /// </summary>
        /// <param name="id">Existing UserAddress ID</param>
        /// <param name="deletedBy">Name of user who wants to remove UserAddress from the system.</param>
        /// <returns>on sucees return true and return false on fail</returns>
        public async Task<bool> DeleteAllAsync(LocationPreferredMaterialViewModel viewModel)
        {
            int flag = 1;
            if (viewModel.MaterialIds.Length > 0)
            {
                if (viewModel.PageAction == Constants.PageActionType.Location)
                {
                    //var values = await this._unitOfWork.LocationAddressRepository.GetByIds(ids).ConfigureAwait(false);
                    var values = await this._unitOfWork.LocationPreferredMaterialRepository.GetById(viewModel.MaterialIds);
                    foreach (var item in values)
                    {
                        //item.UpdatedBy = viewModel.DeletedBy;
                        //item.IsDeleted = true;
                        //item.IsActive = false;
                        var data = this._unitOfWork.LocationPreferredMaterialRepository.DeleteAsync(item.Id, viewModel.DeletedBy);
                        flag++;
                    }
                }
                var finalResult = this._unitOfWork.Save();
                return await Task.FromResult(finalResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(false).ConfigureAwait(false);
            }
        }

        public Task<IEnumerable<LocationPreferredMaterialViewModel>> RangeAsync(int recordCount, LocationContactViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}


