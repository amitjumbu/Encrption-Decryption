﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{

    public class AmnioticFluidManager : BaseManager<MeasurementAmnioticFluidMeasurementValue, AmnioticFluidViewModel>, IAmnioticFluidManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public AmnioticFluidManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<AmnioticFluidViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.AmnioticFluidRepository.GetAsync(id);

            
            var viewModel = this._mapper.Map<AmnioticFluidViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_AmnioticFluidMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<AmnioticFluidViewModel>> ListAsync(AmnioticFluidViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementAmnioticFluidMeasurementValue, bool>> condition = (c => !c.IsDeleted);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            var module = await this._unitOfWork.AmnioticFluidRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<AmnioticFluidViewModel>>(module);
        }
         
        /// <summary>
        /// Add New Measurement_AmnioticFluidMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(AmnioticFluidViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementAmnioticFluidMeasurementValue>(viewModel);
            var data = this._unitOfWork.AmnioticFluidRepository.AddAsync(module);

           
            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;
            
            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_AmnioticFluidMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(AmnioticFluidViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementAmnioticFluidMeasurementValue>(viewModel);
            var data = this._unitOfWork.AmnioticFluidRepository.UpdateAsync(module);

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_AmnioticFluidMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(AmnioticFluidViewModel viewModel)
        {
            Expression<Func<MeasurementAmnioticFluidMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.AmnioticFluidRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_AmnioticFluidMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<AmnioticFluidViewModel>> RangeAsync(int recordCount, AmnioticFluidViewModel viewModel)
        {
            Expression<Func<MeasurementAmnioticFluidMeasurementValue, bool>> condition = (c => c.IsDeleted == false); 
            
            // && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
                                                                                                                      //condition = viewModel.IsAll
                                                                                                                      //    ? condition.And(right: c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId)
                                                                                                                      //    : condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);

            if (viewModel.IsAll)
            {
                condition = (c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId && c.StagesId == viewModel.StagesId);
            }
            else
            {
                condition = (c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId && c.StagesId == viewModel.StagesId);
            }

            var module = await this._unitOfWork.AmnioticFluidRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var AmnioticFluidModel = this._mapper.Map<IEnumerable<AmnioticFluidViewModel>>(module);
            

            return AmnioticFluidModel;
        }


        /// <summary>
        ///  Deletes record Measurement_AmnioticFluidMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.AmnioticFluidRepository.DeleteAsync(id, deletedBy);

            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


