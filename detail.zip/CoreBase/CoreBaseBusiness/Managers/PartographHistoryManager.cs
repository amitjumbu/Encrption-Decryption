﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    // using CoreBaseData.Helpers.PredicateExtension;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;

    public class PartographHistoryManager : IPartographHistoryManager
    {
       

        public PartographHistoryManager()

        {

        }

        public async Task<List<ChartHistoryViewModel>> GetPartographHistory(ChartHistoryViewModel chartData)
        {

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_partographHistory", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@clientId", chartData.ClientId);
                    cmd.Parameters.AddWithValue("@stageId", chartData.StagesId);
                    cmd.Parameters.AddWithValue("@partographId", chartData.PartographId);
                    cmd.Parameters.AddWithValue("@mode", chartData.mode);
                    con.Open();
                    sqla = new SqlDataAdapter(cmd);
                    sqla.Fill(ds);
                }
            }

            List<ChartHistoryViewModel> chartHistoryViewModel = new List<ChartHistoryViewModel>();
            chartHistoryViewModel = (from DataRow dr in ds.Tables[0].Rows
                                     select new ChartHistoryViewModel()
                               {
                                         ClientId = Convert.ToInt32(dr["ClientID"]),
                                         CreatedBy = dr["CreatedBy"].ToString(),
                                         chartValue = dr["chartValue"].ToString(),
                                         xAxisPosition = Convert.ToDecimal(dr["xAxisPosition"]),
                                         yAxisPosition = Convert.ToDecimal(dr["yAxisPosition"]),
                                         CreateDateTimeServer = Convert.ToDateTime(dr["CreateDateTimeServer"]),
                                         mode = dr["mode"].ToString(),
                                         Description = dr["Description"].ToString(),
                                         IsUrgent = (bool)dr["IsUrgent"],
                                         PartographId = Convert.ToInt32(dr["PartographId"]),
                                         StagesId = Convert.ToInt32(dr["StagesId"]),
                                     }).ToList();





            return chartHistoryViewModel;
        }
    }
}


