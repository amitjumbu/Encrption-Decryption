﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class UserAlertManager : BaseManager<UserAlert, UserAlertViewModel>, IUserAlertManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;
        private readonly IConfiguration configuration;

        public UserAlertManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext, IConfiguration configuration)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        /// <summary>
        /// this method sends the UserAlert on ID Basis.
        /// </summary>
        /// <param name="id">Id of UserAlert</param>
        /// <returns>UserAlert Entity View Model.</returns>
        public async override Task<UserAlertViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWork.UserAlertRepository.GetAsync(id);
            var viewModel = this.mapper.Map<UserAlertViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<UserAlertViewModel>> ListAsync(UserAlertViewModel viewModel)
        {
            Expression<Func<UserAlert, bool>> condition = c => !c.IsDeleted && (c.AlertActivationTypeId == viewModel.AlertActivationTypeId || viewModel.AlertActivationTypeId == 0 || viewModel.AlertActivationTypeId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0 || viewModel.ClientId == null) && (c.SystemEventsId == viewModel.SystemEventsId || viewModel.SystemEventsId == 0 || viewModel.SystemAlertId == null) && (c.SystemAlertId == viewModel.SystemAlertId || viewModel.SystemAlertId == 0 || viewModel.SystemAlertId == null);
            var module = await this.unitOfWork.UserAlertRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<UserAlertViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async override Task<bool> AddAsync(UserAlertViewModel viewModel)
        {
            var module = this.mapper.Map<UserAlert>(viewModel);

            var systemAlerts = this.unitOfWork.SystemAlertRepository.ListAsync(p => p.ClientId == viewModel.ClientId && p.SystemEventsId == viewModel.SystemEventsId).Result.FirstOrDefault();

            if (systemAlerts != null)
            {
                module.SystemAlertId = systemAlerts.Id;
                module.AlertActivationTypeId = systemAlerts.AlertActivationTypeID;
                module.Code = "USERALERT";

                module.MessageBody = module.MessageBody.Replace("&lt;#=", "<#=").Replace("#&gt;", "#>");
                var data = this.unitOfWork.UserAlertRepository.AddAsync(module);

                if (data.Result)
                {
                    var finalResult = this.unitOfWork.Save();

                    module.Code = module.Code + module.Id.ToString();

                    this.unitOfWork.UserAlertRepository.UpdateAsync(module);
                    this.unitOfWork.Save();

                    viewModel.Id = finalResult ? module.Id : 0;
                    return await Task.FromResult<bool>(finalResult);
                }
                else
                {
                    return await Task.FromResult<bool>(data.Result);
                }
            }
            else
            {
                return await Task.FromResult<bool>(false);
            }
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(UserAlertViewModel viewModel)
        {
            var module = this.mapper.Map<UserAlert>(viewModel);
            module.MessageBody = module.MessageBody.Replace("&lt;#=", "<#=").Replace("#&gt;", "#>");
            var data = this.unitOfWork.UserAlertRepository.UpdateAsync(module);
            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(UserAlertViewModel viewModel)
        {
            Expression<Func<UserAlert, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.UserAlertRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        public async override Task<IEnumerable<UserAlertViewModel>> RangeAsync(int recordCount, UserAlertViewModel viewModel)
        {
            Expression<Func<UserAlert, bool>> condition = c => c.IsDeleted == false && (c.AlertActivationTypeId == viewModel.AlertActivationTypeId || viewModel.AlertActivationTypeId == 0 || viewModel.AlertActivationTypeId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.SystemEventsId == viewModel.SystemEventsId || viewModel.SystemEventsId == 0 || viewModel.SystemAlertId == null) && (c.SystemAlertId == viewModel.SystemAlertId || viewModel.SystemAlertId == 0 || viewModel.SystemAlertId == null);
            var module = await this.unitOfWork.UserAlertRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            if (module.Any())
            {
                var UserAlertModel = this.mapper.Map<IEnumerable<UserAlertViewModel>>(module);
                return UserAlertModel;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.UserAlertRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// this method get the Data From Procedure.
        /// </summary>
        /// <param name="viewModel">View model have filter like client and others.</param>
        /// <returns>return list of user alerts</returns>
        public async Task<IEnumerable<UserAlertSPViewModel>> GetAllAlerts(UserAlertViewModel viewModel)
        {
            string connectionstring = this.configuration["ConnectionString:CoreBaseDB"];

            List<UserAlertSPViewModel> allUserAlertData = new List<UserAlertSPViewModel>();

            DataTable dt = new DataTable();
            SqlDataReader sdr;
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                using (SqlCommand sqlCommand = new SqlCommand("SP_GetAllUserAlert", con))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    /*sqlCommand.Parameters.AddWithValue("@MasterDBName", "ADecTecCoreMasterDB");
                    sqlCommand.Parameters.AddWithValue("@CoreDBName", "ADecTecCoreBaseDB");
                    sqlCommand.Parameters.AddWithValue("@SecurityDBName", "ADecTecCoreSecurityDB");
                    sqlCommand.Parameters.AddWithValue("@PageIndex", 1);
                    sqlCommand.Parameters.AddWithValue("@PageSize", 100);*/

                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    sdr = sqlCommand.ExecuteReader();

                    if (sdr.HasRows)
                    {
                        dt.Load(sdr);
                    }
                }
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                allUserAlertData = (from DataRow dr in dt.Rows
                                    select new UserAlertSPViewModel()
                                    {
                                        ID = Convert.ToInt32(dr["ID"]),
                                        Name = Convert.ToString(dr["Name"] ?? string.Empty),
                                        EmailTO = Convert.ToString(dr["EmailTo"] ?? string.Empty),
                                        Description = Convert.ToString(dr["Description"] ?? string.Empty),
                                        InternalUsers = Convert.ToString(dr["InternalUsers"] ?? string.Empty),
                                        ExternalContact = Convert.ToString(dr["ExternalContact"] ?? string.Empty),
                                        Active = Convert.ToString(dr["Active"] == null ? "false" : dr["Active"].ToString())

                                    }).ToList();
            }

            return await Task.FromResult<IEnumerable<UserAlertSPViewModel>>(allUserAlertData.AsEnumerable());
        }

        public async Task<bool> ActivateUserAlert(List<string> ids,bool isActive)
        {
            if (ids.Any())
            {
                List<int> UserAlertID = ids.ConvertAll(int.Parse);

                List<UserAlert> userAlerts = this.unitOfWork.UserAlertRepository.ListAsync(p => UserAlertID.Contains(p.Id)).Result.ToList();

                foreach (UserAlert userAlert in userAlerts)
                {
                    userAlert.Active = isActive;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }

        /// <summary>
        /// Delete All UserAlert Job.
        /// </summary>
        /// <param name="ids">List Ids</param>
        /// <returns>true on success/ false on fail.</returns>
        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<int> userAlertID = ids.ConvertAll(int.Parse);

                List<UserAlert> userAlerts = this.unitOfWork.UserAlertRepository.ListAsync(p => userAlertID.Contains(p.Id)).Result.ToList();

                foreach (UserAlert userAlert in userAlerts)
                {
                    userAlert.IsDeleted = false;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }
    }
}