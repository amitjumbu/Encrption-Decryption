﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class CriticalPatientMonitoringGridManager : BaseManager<CriticalPatientMonitoringGrid, CriticalPatientMonitoringGridViewModel>, ICriticalPatientMonitoringGridManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public CriticalPatientMonitoringGridManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        public async override Task<CriticalPatientMonitoringGridViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.CriticalPatientMonitoringRepository.GetAsync(id);
            var comments = await this._unitOfWork.CriticalPatientMonitoringRepository.ListAsync(x => x.IsDeleted == false && x.ClientId == module.ClientId && x.Id == module.Id);
            var viewModel = this._mapper.Map<CriticalPatientMonitoringGridViewModel>(module);
            return viewModel;
        }





        #region Save List of Critical Patient Monitoring  Chart records
        public async Task<bool> SaveAll(IEnumerable<CriticalPatientMonitoringGridViewModel> ViewModels)
        {
            if (ViewModels.Any())
            {
                foreach (CriticalPatientMonitoringGridViewModel ViewModel in ViewModels)
                {
                    var result = await this._unitOfWork.CriticalPatientMonitoringRepository.AddAsync(this._mapper.Map<CriticalPatientMonitoringGrid>(ViewModel)).ConfigureAwait(false);
                }

                var finalResult = this._unitOfWork.Save();

                return await Task.FromResult<bool>(finalResult).ConfigureAwait(false);

            }
            else
            {
                return await Task.FromResult<bool>(false).ConfigureAwait(false);
            }
        }
        #endregion

        public async override Task<int> CountAsync(CriticalPatientMonitoringGridViewModel viewModel)
        {
            Expression<Func<CriticalPatientMonitoringGrid, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
            {
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            }
            else
            {
                condition = condition.And(c => c.IsDeleted == false);
            }

            return await this._unitOfWork.CriticalPatientMonitoringRepository.CountAsync(condition);
        }

        public async override Task<bool> AddAsync(CriticalPatientMonitoringGridViewModel viewModel)
        {
            var module = this._mapper.Map<CriticalPatientMonitoringGridViewModel>(viewModel);
            //var data = this._unitOfWork.MedicationChartGridRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }
        public async override Task<IEnumerable<CriticalPatientMonitoringGridViewModel>> RangeAsync(int recordCount, CriticalPatientMonitoringGridViewModel viewModel)
        {
            Expression<Func<CriticalPatientMonitoringGrid, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.CriticalPatientMonitoringRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<CriticalPatientMonitoringGridViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<CriticalPatientMonitoringGridViewModel>> ListAsync(CriticalPatientMonitoringGridViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<CriticalPatientMonitoringGrid, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.CriticalPatientMonitoringRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CriticalPatientMonitoringGridViewModel>>(module);
        }



        #region Update record
        public async override Task<bool> UpdateAsync(CriticalPatientMonitoringGridViewModel viewModel)
        {
            var module = this._mapper.Map<CriticalPatientMonitoringGrid>(viewModel);
            var data = this._unitOfWork.CriticalPatientMonitoringRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
        #endregion

        public async Task<IEnumerable<CriticalPatientMonitoringGridViewModel>> GetCriticalPatientMonitoringGridList(CriticalPatientMonitoringGridViewModel criticalPatientMonitoring)
        {
            List<CriticalPatientMonitoringGridViewModel> usersList = new List<CriticalPatientMonitoringGridViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("PartogrpahID", criticalPatientMonitoring.PartogrpahId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_CriticalPatientMonitoringList", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new CriticalPatientMonitoringGridViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        PartogrpahId = Convert.ToInt32(dr["PartogrpahID"]),
                        Date1 = Convert.ToDateTime(dr["Date1"]),
                        Time1 = dr["Time1"].ToString(),
                        Temp = Convert.ToDecimal(dr["Temp"] == DBNull.Value ? 0 : dr["Temp"]),
                        PulseRate = Convert.ToDecimal(dr["PulseRate"]),
                        BloodPressure = dr["BloodPressure"].ToString(),
                        RespiratoryRate = Convert.ToDecimal(dr["RespiratoryRate"]),
                        Spo2 = Convert.ToDecimal(dr["SPO2"]),
                        AbdominalGirth = Convert.ToDecimal(dr["AbdominalGirth"]),
                        PerAbdominalExam = dr["PerAbdominalExam"].ToString(),
                        LocalExamination = dr["LocalExamination"].ToString(),

                        UrinaryOutput = dr["UrinaryOutput"].ToString(),
                        Drain = dr["Drain"].ToString(),
                        KneeReflex = dr["Knee/Reflex"].ToString(),
                        RyleTube = dr["RyleTube"].ToString(),
                        Comments = dr["Comments"].ToString(),
                        IsDeleted = Convert.ToBoolean(dr["IsDeleted"]),
                        ClientId = Convert.ToInt32(dr["ClientID"]),

                        SourceSystemId = Convert.ToInt32(dr["SourceSystemID"]),
                        UpdatedBy = dr["UpdatedBy"].ToString(),
                        UpdateDateTimeServer = Convert.ToDateTime(dr["UpdateDateTimeServer"]),
                        UpdateDateTimeBrowser = Convert.ToDateTime(dr["UpdateDateTimeBrowser"]),
                        CreatedBy = dr["CreatedBy"].ToString(),
                        CreateDateTimeBrowser = Convert.ToDateTime(dr["CreateDateTimeBrowser"]),
                        CreateDateTimeServer = Convert.ToDateTime(dr["CreateDateTimeServer"])
                    });
                }
            }

            return usersList;
        }
    }
}