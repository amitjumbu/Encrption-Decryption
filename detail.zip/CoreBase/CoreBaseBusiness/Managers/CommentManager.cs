﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;

namespace CoreBaseBusiness.Managers
{

    public class CommentManager : BaseManager<Comment, CommentViewModel>, ICommentManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public CommentManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<CommentViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.CommentRepository.GetById(id);
            return this._mapper.Map<CommentViewModel>(module);
        }

        /// <summary>
        ///  Retrieves  All data from Package Details.
        /// </summary>
        public async override Task<IEnumerable<CommentViewModel>> ListAsync(CommentViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Comment, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.CommentRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CommentViewModel>>(module);
        }

        /// <summary>
        /// Address varification Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(CommentViewModel viewModel)
        {
            var module = this._mapper.Map<Comment>(viewModel);
            var data = this._unitOfWork.CommentRepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.ID = module.ID;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for Package Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(CommentViewModel viewModel)
        {
            var module = this._mapper.Map<Comment>(viewModel);
            var data = this._unitOfWork.CommentRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from package Details.
        /// </summary>
        public async override Task<int> CountAsync(CommentViewModel viewModel)
        {
            Expression<Func<Comment, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

           

            return await this._unitOfWork.CommentRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves  All data from  Package Id wise.
        /// </summary>
        public async override Task<IEnumerable<CommentViewModel>> RangeAsync(int recordCount, CommentViewModel viewModel)
        {
            Expression<Func<Comment, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.CommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            return this._mapper.Map<IEnumerable<CommentViewModel>>(module);
        } 


        /// <summary>
        ///  Deletes record from Comment by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.CommentRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }
    }
}


