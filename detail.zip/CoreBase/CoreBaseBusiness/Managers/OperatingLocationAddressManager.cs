﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class OperatingLocationAddressManager : BaseManager<OperatingLocationAddress, OperatingLocationAddressViewModel >, IOperatingLocationAddressManager
    {
            
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;

        public OperatingLocationAddressManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext): base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  Retrieves  All data from OperatingLocationAddress.
        /// </summary>
        public async override Task<IEnumerable<OperatingLocationAddressViewModel>> ListAsync(OperatingLocationAddressViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<OperatingLocationAddress, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.OperatingLocationAddressRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<OperatingLocationAddressViewModel>>(module);
        }



        /// <summary>
        /// Operating Location Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(OperatingLocationAddressViewModel viewModel)
        {
            var module = this._mapper.Map<OperatingLocationAddress>(viewModel);
            var data = this._unitOfWork.OperatingLocationAddressRepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.ID = module.ID;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates Operating Location Add Data.
        /// </summary>
        public async override Task<bool> UpdateAsync(OperatingLocationAddressViewModel viewModel)
        {
            var module = this._mapper.Map<OperatingLocationAddress>(viewModel);
            var data = this._unitOfWork.OperatingLocationAddressRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Deletes Operating Location Add Data.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.OperatingLocationAddressRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }


    }
}
