﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System;
    using System.Collections.Generic;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Security.Cryptography.X509Certificates;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    //using CoreBaseData.Helpers.PredicateExtension;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Helpers;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Newtonsoft.Json;

    public class CervixManager : BaseManager<MeasurementCervixMeasurementValue, CervixViewModel>, ICervixManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public CervixManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<CervixViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.CervixRepository.GetAsync(id);
            var viewModel = this._mapper.Map<CervixViewModel>(module);

            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_CervixMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<CervixViewModel>> ListAsync(CervixViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementCervixMeasurementValue, bool>> condition = c => !c.IsDeleted;

            var module = await this._unitOfWork.CervixRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CervixViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_CervixMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(CervixViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementCervixMeasurementValue>(viewModel);
            var data = this._unitOfWork.CervixRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_CervixMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(CervixViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementCervixMeasurementValue>(viewModel);
            var data = this._unitOfWork.CervixRepository.UpdateAsync(module);


            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_CervixMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(CervixViewModel viewModel)
        {
            Expression<Func<MeasurementCervixMeasurementValue, bool>> condition = c => !c.IsDeleted || c.IsDeleted;

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.CervixRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_CervixMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<CervixViewModel>> RangeAsync(int recordCount, CervixViewModel viewModel)
        {
            Expression<Func<MeasurementCervixMeasurementValue, bool>> condition = c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0);
            var module = await this._unitOfWork.CervixRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var cervixModel = this._mapper.Map<IEnumerable<CervixViewModel>>(module);


            return cervixModel;
        }


        /// <summary>
        ///  Deletes record Measurement_CervixMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.CervixRepository.DeleteAsync(id, deletedBy);

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


