﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using NPOI.SS.Formula.Functions;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class MaterialPropertyDetailManager : BaseManager<MaterialPropertyDetail, MaterialPropertyDetailViewModel>, IMaterialPropertyDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        public MaterialPropertyDetailManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            this._unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(MaterialPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MaterialPropertyDetailViewModel>> GetMaterialPropertyDetailByCode(MaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientId);
                parameters.Add("Code", viewModel.Code);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialPropertyDetailByCode", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialPropertyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialPropertyDetailViewModel>>(finalResult);
            }

            return null;
        }

        public override Task<IEnumerable<MaterialPropertyDetailViewModel>> ListAsync(MaterialPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(MaterialPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }
  
        public async Task<IEnumerable<MaterialPropertyDetailViewModel>> SaveAll(List<MaterialPropertyDetailViewModel> viewModels)
        {
            var materialPropDetailall = new List<MaterialPropertyDetailViewModel>();

            foreach (MaterialPropertyDetailViewModel viewModel in viewModels)
            {
                var result = await this._unitOfWork.MaterialPropertyDetailRepository.AddAsync(this._mapper.Map<MaterialPropertyDetail>(viewModel)).ConfigureAwait(false);
                if (result)
                {
                    this._unitOfWork.Save();
                    materialPropDetailall.Add(viewModel);
                }
            }

            return materialPropDetailall;
        }

        public async Task<IEnumerable<MatPropDetailFromSelectedMatViewModel>> GetMaterialPropertyDetailFromSelectedMaterial(MatPropDetailFromSelectedMatViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("Frist", viewModel.First);
                parameters.Add("Second", viewModel.Second);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_CopyDefineProperty", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                //ds.Tables[0].Rows[0].Field<string>("Status")
                var finalResult = ConvertDataTabe.CreateListFromTable<MatPropDetailFromSelectedMatViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MatPropDetailFromSelectedMatViewModel>>(finalResult);
            }

            return null;
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> iD = ids.ConvertAll(long.Parse);

                List<MaterialPropertyDetail> materialProps = this._unitOfWork.MaterialPropertyDetailRepository.ListAsync(p => iD.Contains(p.Id)).Result.ToList();

                foreach (MaterialPropertyDetail materialProp in materialProps)
                {
                    await this._unitOfWork.MaterialPropertyDetailRepository.DeleteAsync(materialProp.Id);
                    var result = this._unitOfWork.Save();
                }

                return await Task.FromResult<bool>(true);
            }

            return await Task.FromResult<bool>(false);
        }
    }
}
