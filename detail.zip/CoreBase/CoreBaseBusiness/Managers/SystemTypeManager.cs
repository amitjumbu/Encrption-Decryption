﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;

    public class SystemTypeManager : BaseManager<SystemType, SystemTypeViewModel>, ISystemTypeManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;


        public SystemTypeManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<SystemTypeViewModel> GetAsync(long id)
        {
            var module = await this.unitOfWork.SystemTypeRepository.GetAsync(id);
            var viewModel = this.mapper.Map<SystemTypeViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<SystemTypeViewModel>> ListAsync(SystemTypeViewModel viewModel)
        {
            Expression<Func<SystemType, bool>> condition = c => !c.IsDeleted && (c.SystemTypeCategoryId == viewModel.SystemTypeCategoryId || viewModel.SystemTypeCategoryId == 0) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.GroupSystemTypeId == viewModel.GroupSystemTypeId || viewModel.GroupSystemTypeId == 0);
            var module = await this.unitOfWork.SystemTypeRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<SystemTypeViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async override Task<bool> AddAsync(SystemTypeViewModel viewModel)
        {
            var module = this.mapper.Map<SystemType>(viewModel);
            var data = this.unitOfWork.SystemTypeRepository.AddAsync(module);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();

                viewModel.ID = finalResult ? module.Id : 0;
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(SystemTypeViewModel viewModel)
        {
            var module = this.mapper.Map<SystemType>(viewModel);
            var data = this.unitOfWork.SystemTypeRepository.UpdateAsync(module);
            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(SystemTypeViewModel viewModel)
        {
            Expression<Func<SystemType, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.SystemTypeRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        public async override Task<IEnumerable<SystemTypeViewModel>> RangeAsync(int recordCount, SystemTypeViewModel viewModel)
        {
            Expression<Func<SystemType, bool>> condition = c => !c.IsDeleted && (c.SystemTypeCategoryId == viewModel.SystemTypeCategoryId || viewModel.SystemTypeCategoryId == 0) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.GroupSystemTypeId == viewModel.GroupSystemTypeId || viewModel.GroupSystemTypeId == 0);
            var module = await this.unitOfWork.SystemTypeRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            if (module.Any())
            {
                var SystemTypeModel = this.mapper.Map<IEnumerable<SystemTypeViewModel>>(module);
                return SystemTypeModel;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.SystemTypeRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// this method send all system type list with the help of category code.
        /// </summary>
        /// <param name="viewModel">filter data viewmodel.</param>
        /// <returns>list of systemtype.</returns>
        public async Task<IEnumerable<SystemTypeViewModel>> GetSystemTypeByCategoryCode(RequestedSystemCategoryViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", viewModel.ClientID);
            parameters.Add("Code", viewModel.Code);

            DataSet dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetSystemTypeByCategory", parameters);

            if (dsResult != null && dsResult.Tables != null)
            {
                List<SystemTypeViewModel> systemTypeViewModels = ConvertDataTabe.CreateListFromTable<SystemTypeViewModel>(dsResult.Tables[0]);
                return await Task.FromResult<IEnumerable<SystemTypeViewModel>>(systemTypeViewModels);
            }
            else
            {
                return await Task.FromResult<IEnumerable<SystemTypeViewModel>>(null);
            }
        }
    }
}