﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    //using System.Data;
    using CoreBaseBusiness.Helpers;
    //using CoreBaseData.Helpers.PredicateExtension;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;



    public class FuelPriceManager : BaseManager<FuelPrice, FuelPriceViewModel>, IFuelPriceManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public FuelPriceManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            //this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;

        }

        /// <summary>
        ///User can get Retrieves data from Location by id.
        /// </summary>
        public override async Task<FuelPriceViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.FuelPriceRepository.GetAsync(id).ConfigureAwait(false);
            return this._mapper.Map<FuelPriceViewModel>((FuelPrice)module);
        }

        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async override Task<IEnumerable<FuelPriceViewModel>> ListAsync(FuelPriceViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<FuelPrice, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.FuelPriceRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<FuelPriceViewModel>>(module);
        }

        /// <summary>
        /// Contract Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(FuelPriceViewModel viewModel)
        {
            viewModel.FuelPriceDateTime = Convert.ToDateTime(viewModel.FuelPriceDateTimePicker);
                var module = this._mapper.Map<FuelPrice>(viewModel);
                var data = this._unitOfWork.FuelPriceRepository.AddAsync(module);
            

            var finalResult = this._unitOfWork.Save();

            //viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }
        //public async Task<IEnumerable<LocationViewModel>> SaveAll(List<LocationViewModel> ViewModels)
        //{
        //    OperatingLocationPropertyDetail operatingLocationPropertyDetail = null;
        //    var freightalls = new List<LocationViewModel>();

        //    foreach (LocationViewModel ViewModel in ViewModels)
        //    {
        //        var module = this._mapper.Map<Location>(ViewModel);
        //        var result = await this._unitOfWork.LocationRepository.AddAsync(module);
        //        //var result = await this._unitOfWork.LocationRepository.AddAsync(this._mapper.Map<Location>(ViewModel)).ConfigureAwait(false);
        //        if (result)
        //        {
        //            this._unitOfWork.Save();
        //            if (ViewModel.CovidAccepting != null)
        //            {

        //                operatingLocationPropertyDetail = new OperatingLocationPropertyDetail();
        //                operatingLocationPropertyDetail.LocationId = module.Id;
        //                operatingLocationPropertyDetail.PropertyValue = ViewModel.CovidAccepting;
        //                operatingLocationPropertyDetail.CreateDateTimeServer = DateTime.UtcNow;
        //                operatingLocationPropertyDetail.UpdateDateTimeServer = DateTime.UtcNow;
        //                operatingLocationPropertyDetail.CreateDateTimeBrowser = DateTime.UtcNow;
        //                operatingLocationPropertyDetail.UpdateDateTimeBrowser = DateTime.UtcNow;
        //                var data2 = this._mapper.Map<OperatingLocationPropertyDetail>(operatingLocationPropertyDetail);
        //                _unitOfWork.OperatingLocationPropertyDetailRepository.AddAsync(data2);
        //                var result2 = this._unitOfWork.Save();

        //            }
        //            freightalls.Add(ViewModel);
        //        }
        //    }
        //    return freightalls;
        //}
        /// <summary>
        ///  Updates existing record for Location Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(FuelPriceViewModel viewModel)
        {
            viewModel.FuelPriceDateTime = Convert.ToDateTime(viewModel.FuelPriceDateTimePicker);
            var module = this._mapper.Map<FuelPrice>(viewModel);
            var data = this._unitOfWork.FuelPriceRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Location.
        /// </summary>
        public async override Task<int> CountAsync(FuelPriceViewModel viewModel)
        {
            Expression<Func<FuelPrice, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.ID > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => (c.IsDeleted == false));

            return await this._unitOfWork.FuelPriceRepository.CountAsync(condition);
        }
        public async Task<IEnumerable<FuelPriceViewModel>> GetFuelPriceListById(FuelPriceViewModel viewModel)
        {            
            Expression<Func<FuelPriceViewModel, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.FuelPriceRepository.GetById(viewModel.SelectedIds);
            //module.Material = null;
            //module.Uom = null;
            var mappedData = this._mapper.Map<IEnumerable<FuelPriceViewModel>>(module);
            return mappedData;            
        }

        public async Task<IEnumerable<FuelPriceViewModel>> GetFuelPriceListByDateAndRate(FuelPriceViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("FuelPriceDate", viewModel.FuelPriceDateTimePicker);
                parameters.Add("Rate", viewModel.Rate);
                

            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuelPriceListbyDateAndRate", parameters);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FuelPriceViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<FuelPriceViewModel>>(finalResult);
            }

            return null;
        }


        /// <summary>
        /// Get Customer By Location.
        /// </summary>
        /// <param name="fuelPriceViewModel">data model for pagination.</param>
        /// <returns> Returns a list of Fuel Price Details </returns>
        public async Task<IEnumerable<FuelPriceViewModel>> GetFuelPriceList(
                FuelPriceViewModel viewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();
            if (viewModel != null
                && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                storedProcedureParameter.Add("PageNumber", viewModel.PageNo);
                storedProcedureParameter.Add("PageSize", viewModel.PageSize);
            }

            storedProcedureParameter.Add("ClientId", viewModel.ClientID);

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                storedProcedureParameter.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                storedProcedureParameter.Add("SortOrder", viewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuelPriceList", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FuelPriceViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<FuelPriceViewModel>>(
                    FilterResult<FuelPriceViewModel>.GetFilteredResult(
                        finalResult,
                        viewModel.FilterOn,
                        viewModel.PageSize));
            }

            return null;
        }

        /// <summary>
        /// Softly remove UserAddress from the system.
        /// </summary>
        /// <param name="id">Existing UserAddress ID</param>
        /// <param name="deletedBy">Name of user who wants to remove UserAddress from the system.</param>
        /// <returns>on sucees return true and return false on fail</returns>
        public async Task<bool> DeleteAllAsync(FuelPriceViewModel viewModel)
        {
            int flag = 1;
            if (viewModel.SelectedIds.Length > 0)
            {
                var values = await this._unitOfWork.FuelPriceRepository.GetById(viewModel.SelectedIds);
                foreach (var item in values)
                {
                    //item.UpdatedBy = viewModel.DeletedBy;
                    //item.IsDeleted = true;
                    //item.IsActive = false;
                    var data = this._unitOfWork.FuelPriceRepository.DeleteAsync(item.Id, viewModel.UpdatedBy);
                    flag++;
                }
                
                var finalResult = this._unitOfWork.Save();
                return await Task.FromResult(finalResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(false).ConfigureAwait(false);
            }
        }

        ///// <summary>
        ///// Get All List for Location Data List
        ///// </summary>
        //public async override Task<IEnumerable<LocationViewModel>> RangeAsync(int recordCount, LocationViewModel viewModel)
        //{
        //    //Expression<Func<Location, bool>> condition = c => (c.IsDeleted == false && (viewModel.LocationTypeId == 0 || c.LocationTypeId == viewModel.LocationTypeId));
        //    Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && (c.ClientId == viewModel.ClientID || viewModel.ClientID == 0 || viewModel.ClientID == null) && (c.OrganizationId == viewModel.OrganizationId || viewModel.OrganizationId == 0 || viewModel.OrganizationId == null) && (c.LocationFunctionId == viewModel.LocationFunctionId || viewModel.LocationFunctionId == 0||viewModel.LocationFunctionId == null) && (c.LocationTypeId == viewModel.LocationTypeId || viewModel.LocationTypeId == 0 || viewModel.LocationTypeId == null);
        //    var module = await this._unitOfWork.LocationRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        //    return mappedData;
        //}


        ///// <summary>
        ///// User can get list by locatinId.
        ///// </summary>
        //public async Task<IEnumerable<LocationViewModel>> GetList(int id)
        //{
        //    Expression<Func<Location, bool>> condition = (c => c.IsDeleted == false && c.LocationTypeId == id);
        //    var module = await this._unitOfWork.LocationRepository.GetList(condition);
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        //    return mappedData;
        //}

        //public async Task<long> GetLocationTypedId(string code)
        //{
        //    Expression<Func<LocationType, bool>> condition = c => c.IsDeleted == false && c.Code == code;
        //    var module = await this._unitOfWork.LocationTypeRepository.GetLocationTypeId(condition);
        //    return module.ID;
        //}

        ///// <summary>
        /////  Deletes record from location id.
        ///// </summary>
        //public async Task<bool> DeleteAsync(int id, string deletedBy)
        //{
        //    var data = this._unitOfWork.LocationRepository.DeleteAsync(id, deletedBy);
        //    this._unitOfWork.Save();

        //    return await Task.FromResult<bool>(data.Result);
        //}

        //public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel)
        //{
        //    long locationTypeId = await this.GetLocationTypedId(viewModel.LocationTypeCode);

        //    Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationTypeId == locationTypeId && c.ClientId == viewModel.ClientID && c.IsActive == true;
        //    var module = await this._unitOfWork.LocationRepository.GetList(condition);
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        //    return mappedData;

        //}

        //public async Task<IEnumerable<LocationViewModel>> GetToFromLocation(LocationViewModel viewModel)
        //{
        //    Dictionary<string, object> parameters = new Dictionary<string, object>();

        //    if (viewModel != null)
        //    {
        //        parameters.Add("locationId", viewModel.LocationId);

        //    }

        //    DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetToFromLocation", parameters);

        //    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
        //    {
        //        var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
        //        return await Task.FromResult<IEnumerable<LocationViewModel>>(finalResult);
        //    }

        //    return null;

        //}

        //public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel[] viewModel)
        //{
        //    var locationList = new List<Location>();
        //    foreach (var item in viewModel)
        //    {
        //        Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationFunctionId == item.LocationTypeId && c.ClientId == item.ClientID && c.IsActive == true;
        //        var module = await this._unitOfWork.LocationRepository.GetList(condition);
        //        locationList.AddRange(module);
        //    }
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(locationList);
        //    return mappedData;

        //}

        //#region  Api for get all Hospital list
        //public async Task<IEnumerable<LocationViewModel>> GetHospitalList(LocationViewModel locationViewModel)
        //{
        //    Dictionary<string, object> Parameter = new Dictionary<string, object>();
        //    //if (locationViewModel != null && string.IsNullOrWhiteSpace(locationViewModel.FilterOn))
        //    //{
        //    //    Parameter.Add("PageNumber", locationViewModel.PageNo);
        //    //    Parameter.Add("PageSize", locationViewModel.PageSize);
        //    //}
        //    if (locationViewModel != null && string.IsNullOrWhiteSpace(locationViewModel.FilterOn))
        //    {
        //        Parameter.Add("ClientID", locationViewModel.ClientID);
        //        Parameter.Add("PageNumber", locationViewModel.PageNo);
        //        Parameter.Add("PageSize", locationViewModel.PageSize);
        //    }
        //    if (!string.IsNullOrWhiteSpace(locationViewModel.SortColumn))
        //    {
        //        Parameter.Add("SortColumn", locationViewModel.SortColumn);
        //    }
        //    if (!string.IsNullOrWhiteSpace(locationViewModel.SortOrder))
        //    {
        //        Parameter.Add("SortOrder", locationViewModel.SortOrder);
        //    }

        //    DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetHospitalSetupList", Parameter);

        //    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
        //    {
        //        var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
        //        return await Task.FromResult<IEnumerable<LocationViewModel>>(FilterResult<LocationViewModel>.GetFilteredResult(finalResult, locationViewModel.FilterOn, locationViewModel.PageSize));
        //    }

        //    return null;
        //}
        //#endregion


        //#region Active/Inactive Hospital
        //public async Task<bool> ActivateHospitalStatus(List<string> ids, bool isActive)
        //{
        //    if (ids.Any())
        //    {
        //        List<long> HospitalStatusID = ids.ConvertAll(long.Parse);

        //        List<Location> Hospitalstatus = this._unitOfWork.LocationRepository.ListAsync(p => HospitalStatusID.Contains(p.Id)).Result.ToList();

        //        foreach (Location hospitalaction in Hospitalstatus)
        //        {
        //            hospitalaction.IsActive = isActive;
        //        }

        //        var result = this._unitOfWork.Save();

        //        return await Task.FromResult<bool>(result);
        //    }

        //    return await Task.FromResult<bool>(false);
        //}
        //#endregion

        //#region Delete multiple Hosital 
        //public async Task<string> DeleteAllAsync(List<string> ids)
        //{
        //    string msg = "";
        //    if (ids.Any())
        //    {
        //        List<long> HospitalStatusID = ids.ConvertAll(long.Parse);

        //        List<Location> hospitalstatus = this._unitOfWork.LocationRepository.ListAsync(p => HospitalStatusID.Contains(p.Id)).Result.ToList();
        //        foreach (Location hospitalAlert in hospitalstatus)
        //        {
        //            hospitalAlert.IsDeleted = true;
        //        }

        //        var result = this._unitOfWork.Save();
        //        if (result == true)
        //        {
        //            msg = Constants.Identifire.DeleteMessageSingle;
        //        }
        //        return await Task.FromResult<string>(msg);
        //    }

        //    return await Task.FromResult<string>("");
        //}

        //public async Task<IEnumerable<LocationViewModel>> ManufacturerList(LocationViewModel LLocationViewModel)
        //{

        //    Dictionary<string, object> parameters = new Dictionary<string, object>();
        //    parameters.Add("ClientID", LLocationViewModel.ClientID);

        //    DataSet ds = this._unitOfWork.ExecuteProcedure("Sp_GetManufacturerDetails", parameters);
        //    if (ds != null && ds.Tables.Count > 0)
        //    {
        //        List<LocationViewModel> orders = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);

        //        if (orders.Count > 0)
        //        {
        //            return await Task.FromResult<IEnumerable<LocationViewModel>>(orders.AsEnumerable());
        //        }
        //        else
        //        {
        //            return null;
        //        }
        //    }

        //    return null;

        //}


        //#endregion

        //public async Task<bool> UpdateLocationStatus(List<LocationViewModel> viewModels)
        //{
        //    foreach (LocationViewModel locationView in viewModels)
        //    {
        //        var module = this._mapper.Map<Location>(locationView);
        //        module.UpdateDateTimeServer = DateTime.UtcNow;
        //        await this._unitOfWork.LocationRepository.UpdateStatusAsync(module);
        //    }

        //    return this._unitOfWork.Save();
        //}


        //public async Task<IEnumerable<LocationViewModel>> GetSalesBroker(LocationViewModel viewModel)
        //{
        //    Dictionary<string, object> parameter = new Dictionary<string, object>();
        //    if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
        //    {
        //        parameter.Add("PageNumber", viewModel.PageNo);
        //        parameter.Add("PageSize", viewModel.PageSize);
        //    }

        //    if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
        //    {
        //        parameter.Add("SortColumn", viewModel.SortColumn);
        //    }

        //    if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
        //    {
        //        parameter.Add("SortOrder", viewModel.SortOrder);
        //    }

        //    DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetSalesBroker", parameter);

        //    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
        //    {
        //        var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
        //        return await Task.FromResult<IEnumerable<LocationViewModel>>(finalResult.AsEnumerable());
        //    }

        //    return null;

        //}
        //#region Bind operating Location 
        //public async Task<IEnumerable<OperatingLocationListViewModel>> GetOperatingLocationList(OperatingLocationListViewModel locationViewModel)
        //{
        //    Dictionary<string, object> Parameter = new Dictionary<string, object>();
        //    if (locationViewModel != null && string.IsNullOrWhiteSpace(locationViewModel.FilterOn))
        //    {
        //        Parameter.Add("ClientID", locationViewModel.ClientID);
        //        Parameter.Add("PageNumber", locationViewModel.PageNo);
        //        Parameter.Add("PageSize", locationViewModel.PageSize);
        //    }
        //    if (!string.IsNullOrWhiteSpace(locationViewModel.SortColumn))
        //    {
        //        Parameter.Add("SortColumn", locationViewModel.SortColumn);
        //    }
        //    if (!string.IsNullOrWhiteSpace(locationViewModel.SortOrder))
        //    {
        //        Parameter.Add("SortOrder", locationViewModel.SortOrder);
        //    }

        //    DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetOperatingLocationList", Parameter);

        //    if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
        //    {
        //        var finalResult = ConvertDataTabe.CreateListFromTable<OperatingLocationListViewModel>(ds.Tables[0]);
        //        return await Task.FromResult<IEnumerable<OperatingLocationListViewModel>>(FilterResult<OperatingLocationListViewModel>.GetFilteredResult(finalResult, locationViewModel.FilterOn, locationViewModel.PageSize));
        //    }

        //    return null;
        //}
        //#endregion
    }
}
