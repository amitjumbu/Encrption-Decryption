﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using System.Data;
    using CoreBaseBusiness.Services;
    using System.Text;
    using System.Data.SqlClient;
    using Dapper;

    public class ShipmentManager : BaseManager<Shipment, ShipmentViewModel>, IShipmentManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;
        private readonly IHangfireOperation hangfireOperation;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public ShipmentManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext, IHangfireOperation hangfireOperation)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.unitOfWork.ConnectionString = this.BaseConnectionString;
            this.hangfireOperation = hangfireOperation;
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<ShipmentViewModel> GetAsync(long id)
        {
            var module = await this.unitOfWork.ShipmentRepository.GetAsync(id);
            var viewModel = this.mapper.Map<ShipmentViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<ShipmentViewModel>> ListAsync(ShipmentViewModel viewModel)
        {
            Expression<Func<Shipment, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0);
            var module = await this.unitOfWork.ShipmentRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ShipmentViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async Task<bool> AddAsync(Shipment viewModel)
        {
            var module = this.mapper.Map<Shipment>(viewModel);
            var data = this.unitOfWork.ShipmentRepository.AddAsync(module);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();

                viewModel.Id = finalResult ? module.Id : 0;
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(ShipmentViewModel viewModel)
        {
            var module = this.mapper.Map<Shipment>(viewModel);
            var data = this.unitOfWork.ShipmentRepository.UpdateAsync(module);
            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(ShipmentViewModel viewModel)
        {
            Expression<Func<Shipment, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.ShipmentRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        public async override Task<IEnumerable<ShipmentViewModel>> RangeAsync(int recordCount, ShipmentViewModel viewModel)
        {
            Expression<Func<Shipment, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0);
            var module = await this.unitOfWork.ShipmentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            if (module.Any())
            {
                var ShipmentModel = this.mapper.Map<IEnumerable<ShipmentViewModel>>(module);
                return ShipmentModel;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.ShipmentRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        public async Task<Object> GetShipmentOrders(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentOrders", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShippingOrder>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetApcharges(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetApcharges", parameters);
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<Apcharges>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }


        public async Task<Object> GetLoctionsForShipment(LocationForshipmentParameter viewmodel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentType", viewmodel.ShipmentType);
            parameters.Add("ClientID", viewmodel.ClientID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetLoctionsForShipment", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {

                return ConvertDataTabe.CreateListFromTable<LocationForshipment>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }


        public async Task<Object> GetTenderStatusForShipment()
        {

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetTenderStatusForShipment");

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<TenderStatusForshipment>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetShipmentDetails(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentDetailsBYID", parameters);
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentByIDViewModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetShipmentDetails()
        {

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentDetails");

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentDetailsViewModel>(dsResult.Tables[0]);

            }
            else
            {
                return null;
            }
        }


        public override Task<bool> AddAsync(ShipmentViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<object> SaveShipmentDetails(ShipmentSaveData shipmentdetails)
        {
            var Shipmentdetails = shipmentdetails;

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", Shipmentdetails.id);
            parameters.Add("ShipDate", Shipmentdetails.shipDate);
            parameters.Add("OrderType", Shipmentdetails.orderTypeID);
            parameters.Add("shipmentTenderStatusID", Shipmentdetails.shipmentTenderStatusID);
            parameters.Add("TrailerNumber", Shipmentdetails.trailerNumber);
            parameters.Add("TrailerSealNumber", Shipmentdetails.trailerSealNumber);
            parameters.Add("ApprovedBy", Shipmentdetails.approvedBy);
            parameters.Add("ApprovedDateTime", Shipmentdetails.approvedDateTime);
            parameters.Add("CompliedWithShippingInstructions", Shipmentdetails.compliedWithShippingInstructions);
            parameters.Add("DropTrailer", Shipmentdetails.dropTrailer);
            parameters.Add("TrailerCheckInTime", Shipmentdetails.trailerCheckInTime);
            parameters.Add("TrailerCheckOutTime", Shipmentdetails.trailerCheckOutTime);
            parameters.Add("SortStartTime", Shipmentdetails.sortStartTime);
            parameters.Add("SortEndTime", Shipmentdetails.sortEndTime);
            parameters.Add("ClientID", Shipmentdetails.clientID);
            parameters.Add("UpdateBy", Shipmentdetails.updateby);

            

            DataTable dtcpdata = ShipmentSaveParametersData.CreateCpdata(Shipmentdetails);
            if (dtcpdata != null)
            {
                parameters.Add("cpdata", dtcpdata);
            }
            DataTable dtcsddata = ShipmentSaveParametersData.CreateCsddata(Shipmentdetails);
            if (dtcsddata != null)
            {
                parameters.Add("csddata", dtcsddata);
            }

            DataTable dtordercomments = ShipmentSaveParametersData.CreateOrdercomments(Shipmentdetails);
            if (dtordercomments != null)
            {
                parameters.Add("ordercomments", dtordercomments);
            }
            DataTable dtapcharges = ShipmentSaveParametersData.CreateApcharges(Shipmentdetails);
            parameters.Add("apcharges", dtapcharges);
            DataTable dtsalesOrderDetail = ShipmentSaveParametersData.CreateSalesOrderDetail(Shipmentdetails);
            parameters.Add("salesorderdetailT", dtsalesOrderDetail);
            DataTable dtDeletesalesOrderDetail = ShipmentSaveParametersData.CreateDeletesalesOrderDetail(Shipmentdetails);
            parameters.Add("deletesalesorderdetailT", dtDeletesalesOrderDetail);
            DataTable dtsalesorderlocations = ShipmentSaveParametersData.CreateSalesorderlocations(Shipmentdetails);
            parameters.Add("solocations", dtsalesorderlocations);
            DataTable dtsalesorderappointments = ShipmentSaveParametersData.CreateSalesorderappointments(Shipmentdetails);
            parameters.Add("soappointments", dtsalesorderappointments);
            DataTable dterroResponse = new DataTable();
            dterroResponse.Columns.Add("Status");
            dterroResponse.Columns.Add("Message");
            DataRow dr = dterroResponse.NewRow();
            dr[0] = "FAIL";
            dr[1] = "Shipment details Not Updated";
            dterroResponse.Rows.Add(dr);

            var dsResult = this.unitOfWork.ExecuteUpdateProcedure("SPO_UpdateShipmentDetails", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables.Count > 0 && dsResult.Tables[dsResult.Tables.Count - 1].Rows.Count > 0)
            {
                var finalResponse = ConvertDataTabe.CreateListFromTable<ShipsaveResponseModel>(dsResult.Tables[dsResult.Tables.Count - 1]);
                return finalResponse;
            }
            else
            {
                var errorResposne = ConvertDataTabe.CreateListFromTable<ShipResponseModel>(dterroResponse);
                return errorResposne;
            }
        }

        Task IShipmentManager.AddAsync(Shipment shipment)
        {
            throw new NotImplementedException();
        }

        public async Task<Object> GetShipmentOrdersDetails(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetOrderDetailsforshipmentByID", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentOrderDetailViewModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<bool> ApproveSendShipmentToMAS(ShipmentCommonModel flagViewModel)
        {

            //var carrierInDate = this.ConvertDateStringToDateTime(flagViewModel.CarrierInTime);
            //var carrierOutDate = this.ConvertDateStringToDateTime(flagViewModel.CarrierOutTime);

            this.hangfireOperation.SendShipmentTOMAS(flagViewModel.ShipmentID);

            return true;
        }


        /// <summary>
        /// string datetime convert to DateTime Format.
        /// </summary>
        /// <param name="date">YYYY-mm-DDTHH:MM</param>
        /// <returns>datetime</returns>
        private DateTime ConvertDateStringToDateTime(string date)
        {

            var datesplit = date.Split('T', StringSplitOptions.RemoveEmptyEntries);
            var datesData = datesplit[0].Split('-', StringSplitOptions.RemoveEmptyEntries);
            var timeData = datesplit[1].Split(':', StringSplitOptions.RemoveEmptyEntries);
            var selectedDate = new DateTime(Convert.ToInt32(datesData[0]), Convert.ToInt32(datesData[1]), Convert.ToInt32(datesData[2]), Convert.ToInt32(timeData[0]), Convert.ToInt32(timeData[1]), 0);

            return selectedDate;

        }

        public async Task<Object> GetShipmentOrdersDetailsForShipmentId(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentOrderDetailsByShipmentId", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentOrderDetailsVM>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<Object> GetOrderAmountforAPCharges(apchargesInputModel apchargesInput)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", apchargesInput.ShipmentID);
            parameters.Add("BusinessPartnerID", apchargesInput.BusinessPartnerID);
            parameters.Add("ChargeType", apchargesInput.ChargeType);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetOrderAmountforAPCharges", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                // return ConvertDataTabe.CreateListFromTable<Object>(dsResult.Tables[0]);
                return dsResult.Tables[0].Rows[0].ItemArray[0];
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetOrderTypeForShipment()
        {

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetOrderTypeForShipment");

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<DropdownlistModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetShipmentStatusForShipment()
        {

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentStatusForShipment");

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<DropdownlistModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetShipmentConditionForShipment()
        {

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentConditionForShipment");

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<DropdownlistModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetModeForShipment()
        {
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetModeForShipment");
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<DropdownlistModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<Object> Tonu(ShipmentUpdateModel TonuInput)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", TonuInput.ShipmentID);
            parameters.Add("UpdateBy", TonuInput.UpdateBy);
            var Result = this.unitOfWork.ExecuteUpdateProcedure("SPO_Tonu", parameters);
            var finalResponse = ConvertDataTabe.CreateListFromTable<ShipResponseModel>(Result.Tables[Result.Tables.Count - 1]);
            return finalResponse;
        }
        public async Task<Object> Cancel(ShipmentUpdateModel CancelInput)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", CancelInput.ShipmentID);
            parameters.Add("UpdateBy", CancelInput.UpdateBy);
            var Result = this.unitOfWork.ExecuteUpdateProcedure("SPO_CancelShipment", parameters);
            var finalResponse = ConvertDataTabe.CreateListFromTable<ShipResponseModel>(Result.Tables[Result.Tables.Count - 1]);
            return finalResponse;
        }
        public async Task<Object> SaveShipmentOrders(ShipmentOrdersSaveModel shipmentOrdersdetails)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", shipmentOrdersdetails.ShipmentID);
            parameters.Add("UpdateBy", shipmentOrdersdetails.UpdateBy);

            var Result = this.unitOfWork.ExecuteUpdateProcedure("SPO_ShipmentOrdersLocationCommentsUpdate", parameters);
            return await Task.FromResult<object>(Result).ConfigureAwait(false);
        }

        public async Task<Object> ShipSelectedShipment(ShipmentSaveData Shipmentdetails)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", Shipmentdetails.id);
            parameters.Add("ShipDate", Shipmentdetails.shipDate);
            parameters.Add("OrderType", Shipmentdetails.orderTypeID);
            parameters.Add("shipmentTenderStatusID", Shipmentdetails.shipmentTenderStatusID);
            parameters.Add("TrailerNumber ", Shipmentdetails.trailerNumber);
            parameters.Add("TrailerSealNumber", Shipmentdetails.trailerSealNumber);
            parameters.Add("ApprovedBy", Shipmentdetails.approvedBy);
            parameters.Add("ApprovedDateTime ", Shipmentdetails.approvedDateTime);
            parameters.Add("CompliedWithShippingInstructions ", Shipmentdetails.compliedWithShippingInstructions);
            parameters.Add("DropTrailer ", Shipmentdetails.dropTrailer);
            parameters.Add("TrailerCheckInTime", Shipmentdetails.trailerCheckInTime);
            parameters.Add("TrailerCheckOutTime", Shipmentdetails.trailerCheckOutTime);
            parameters.Add("SortStartTime", Shipmentdetails.sortStartTime);
            parameters.Add("SortEndTime", Shipmentdetails.sortEndTime);
            parameters.Add("ClientID", 100);
            parameters.Add("UpdateBy", Shipmentdetails.approvedBy);
            parameters.Add("browserDateTime", Shipmentdetails.browserDateTime);
            // parameters.Add("apchargesModidifed", Shipmentdetails.apchargesModidifed);

            DataTable dtcpdata = ShipmentSaveParametersData.CreateCpdata(Shipmentdetails);
            if (dtcpdata != null)
            {
                parameters.Add("cpdata", dtcpdata);
            }
            DataTable dtcsddata = ShipmentSaveParametersData.CreateCsddata(Shipmentdetails);
            if (dtcsddata != null)
            {
                parameters.Add("csddata", dtcsddata);
            }

            DataTable dtordercomments = ShipmentSaveParametersData.CreateOrdercomments(Shipmentdetails);
            if (dtordercomments != null)
            {
                parameters.Add("ordercomments", dtordercomments);
            }
            DataTable dtapcharges = ShipmentSaveParametersData.CreateApcharges(Shipmentdetails);
            parameters.Add("apcharges", dtapcharges);
            DataTable dtsalesOrderDetail = ShipmentSaveParametersData.CreateSalesOrderDetail(Shipmentdetails);
            parameters.Add("salesorderdetailT", dtsalesOrderDetail);
            DataTable dtDeletesalesOrderDetail = ShipmentSaveParametersData.CreateDeletesalesOrderDetail(Shipmentdetails);
            parameters.Add("deletesalesorderdetailT", dtDeletesalesOrderDetail);
            DataTable dtsalesorderlocations = ShipmentSaveParametersData.CreateSalesorderlocations(Shipmentdetails);
            parameters.Add("solocations", dtsalesorderlocations);
            DataTable dtsalesorderappointments = ShipmentSaveParametersData.CreateSalesorderappointments(Shipmentdetails);
            parameters.Add("soappointments", dtsalesorderappointments);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_ShipSelectedShipment", parameters);
            ShipResponseModel MasResponse = new ShipResponseModel();
            MasResponse.Status = "FAIL";
            MasResponse.Message = "Send to MAS Unsuccessful";
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables.Count > 0 && dsResult.Tables[dsResult.Tables.Count - 1].Rows.Count > 0)
            {
                var finalResponse = ConvertDataTabe.CreateListFromTable<ShipResponseModel>(dsResult.Tables[dsResult.Tables.Count - 1]);

                // this section sends the final response of validation and also call asynchornous call of Entire Shipment TO MAS
                if (finalResponse != null && finalResponse.Any())
                {
                    var firstResponseData = finalResponse.FirstOrDefault();

                    if (firstResponseData != null && !string.IsNullOrEmpty(firstResponseData.Status) && firstResponseData.Status != "FAIL")
                    {
                        var result = this.hangfireOperation.SendShipmentTOMAS(Shipmentdetails.id);
                        if (result != null && result.Count() > 0)
                        {
                            var Status = ((IDictionary<string, object>)result.FirstOrDefault())["Status"].ToString();
                            var Message = ((IDictionary<string, object>)result.FirstOrDefault())["Text"].ToString();
                            MasResponse.Status = Status;
                            MasResponse.Message = Message;
                        }
                        else
                        {
                            MasResponse.Status = "FAIL";
                            MasResponse.Message = "Send to MAS Unsuccessful";
                        }
                        return MasResponse;
                    }
                    else
                    {
                        MasResponse.Status = firstResponseData.Status;
                        MasResponse.Message = firstResponseData.Message;
                        return MasResponse;
                    }
                }
                return MasResponse;
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> ReceiveSelectedShipment(ShipmentSaveData Shipmentdetails)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", Shipmentdetails.id);
            parameters.Add("ShipDate", DateTime.Now);
            parameters.Add("shipmentTenderStatusID", Shipmentdetails.shipmentTenderStatusID);
            parameters.Add("TrailerNumber ", Shipmentdetails.trailerNumber);
            parameters.Add("TrailerSealNumber", Shipmentdetails.trailerSealNumber);
            parameters.Add("ApprovedBy", Shipmentdetails.approvedBy);
            parameters.Add("ApprovedDateTime ", Shipmentdetails.approvedDateTime);
            parameters.Add("CompliedWithShippingInstructions ", Shipmentdetails.compliedWithShippingInstructions);
            parameters.Add("DropTrailer ", Shipmentdetails.dropTrailer);
            parameters.Add("TrailerCheckInTime", Shipmentdetails.trailerCheckInTime);
            parameters.Add("TrailerCheckOutTime", Shipmentdetails.trailerCheckOutTime);
            parameters.Add("SortStartTime", Shipmentdetails.sortStartTime);
            parameters.Add("SortEndTime", Shipmentdetails.sortEndTime);
            parameters.Add("ClientID", 100);
            parameters.Add("UpdateBy", Shipmentdetails.approvedBy);

            DataTable dtcpdata = ShipmentSaveParametersData.CreateCpdata(Shipmentdetails);
            if (dtcpdata != null)
            {
                parameters.Add("cpdata", dtcpdata);
            }
            DataTable dtcsddata = ShipmentSaveParametersData.CreateCpdata(Shipmentdetails);
            if (dtcsddata != null)
            {
                parameters.Add("csddata", dtcsddata);
            }

            DataTable dtordercomments = ShipmentSaveParametersData.CreateOrdercomments(Shipmentdetails);
            if (dtordercomments != null)
            {
                parameters.Add("ordercomments", dtordercomments);
            }

            DataTable dtapcharges = ShipmentSaveParametersData.CreateApcharges(Shipmentdetails);
            parameters.Add("apcharges", dtapcharges);
            DataTable dtsalesOrderDetail = ShipmentSaveParametersData.CreateSalesOrderDetail(Shipmentdetails);
            parameters.Add("salesorderdetailT", dtsalesOrderDetail);
            DataTable dtDeletesalesOrderDetail = ShipmentSaveParametersData.CreateDeletesalesOrderDetail(Shipmentdetails);
            parameters.Add("deletesalesorderdetailT", dtDeletesalesOrderDetail);
            DataTable dtsalesorderlocations = ShipmentSaveParametersData.CreateSalesorderlocations(Shipmentdetails);
            parameters.Add("solocations", dtsalesorderlocations);
            DataTable dtsalesorderappointments = ShipmentSaveParametersData.CreateSalesorderlocations(Shipmentdetails);
            parameters.Add("soappointments", dtsalesorderappointments);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_ReceiveSelectedShipment", parameters);
            // return await Task.FromResult<object>(Result).ConfigureAwait(false);
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables.Count > 0 && dsResult.Tables[dsResult.Tables.Count - 1].Rows.Count > 0)
            {
                var finalResponse = ConvertDataTabe.CreateListFromTable<ShipResponseModel>(dsResult.Tables[dsResult.Tables.Count - 1]);

                // this section sends the final response of validation and also call asynchornous call of Entire Shipment TO MAS
                if (finalResponse != null && finalResponse.Any())
                {
                    var firstResponseData = finalResponse.FirstOrDefault();
                    if (firstResponseData != null && !string.IsNullOrEmpty(firstResponseData.Status) && firstResponseData.Status == "SUCCESS")
                    {
                        this.hangfireOperation.SendShipmentTOMAS(Shipmentdetails.id);
                    }
                }
                return finalResponse;
            }
            else
            {
                return null;
            }
        }

        //public async Task<Object> GetShipmentAllDetails(ShipmentSaveData Shipmentdetails)
        //{

        //    var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentDetails");

        //    if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
        //    {
        //        return ConvertDataTabe.CreateListFromTable<ShipmentDetailsViewModel>(dsResult.Tables[0]);

        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}

        public async Task<IEnumerable<ShipmentDetailsViewModel>> GetShipmentAllDetails(ShipmentOrderDetailViewModel shipmentSaveDataViewModal)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (shipmentSaveDataViewModal != null)
            {
                Parameter.Add("PageNumber", shipmentSaveDataViewModal.PageNo);
                //chargeParameter.Add("PageSize", shipmentSaveDataViewModal.PageSize);

                if (!string.IsNullOrEmpty(shipmentSaveDataViewModal.FilterOn))
                    Parameter.Add("PageSize", 0);
                else
                    Parameter.Add("PageSize", shipmentSaveDataViewModal.PageSize);

                Parameter.Add("ClientId", shipmentSaveDataViewModal.ClientID);
                Parameter.Add("InboundOutbound", shipmentSaveDataViewModal.InboundOutbound);
            }

            if (!string.IsNullOrWhiteSpace(shipmentSaveDataViewModal.SortColumn))
            {
                Parameter.Add("SortColumn", shipmentSaveDataViewModal.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(shipmentSaveDataViewModal.SortOrder))
            {
                Parameter.Add("SortOrder", shipmentSaveDataViewModal.SortOrder);
            }

            if (shipmentSaveDataViewModal.ShipmentworkbenchFilterModel != null)
            {
                Parameter.Add("WhereClause", this.GetWhereClause(shipmentSaveDataViewModal.ShipmentworkbenchFilterModel));
            }
            if (shipmentSaveDataViewModal.UpdatedBy != null)
            {
                Parameter.Add("UpdatedBy", shipmentSaveDataViewModal.UpdatedBy);
            }


            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentDetails", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ShipmentDetailsViewModel>(ds.Tables[0]);
                //  return await Task.FromResult<IEnumerable<ShipmentOrderDetailViewModel>>(FilterResult<ShipmentOrderDetailViewModel>.GetFilteredResult(finalResult, shipmentSaveDataViewModal.FilterOn, shipmentSaveDataViewModal.PageSize));
                return await Task.FromResult<IEnumerable<ShipmentDetailsViewModel>>(FilterResult<ShipmentDetailsViewModel>.GetFilteredResult(finalResult, shipmentSaveDataViewModal.FilterOn, shipmentSaveDataViewModal.PageSize));
            }

            return null;
        }

        public string GetWhereClause(ShipmentWorkbenchFilterModel shipmentworkbenchFilterModel)
        {
            StringBuilder whereClause = new StringBuilder();
            whereClause.Append("(");
            if (shipmentworkbenchFilterModel.ShipmentConditionSelected != null
                && shipmentworkbenchFilterModel.ShipmentConditionSelected.Count > 0)
            {
                whereClause.Append(" AND ");
                whereClause.Append("s.ShipmentConditionID in ( ");
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.ShipmentConditionSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.ShipmentTypeSelected != null
                && shipmentworkbenchFilterModel.ShipmentTypeSelected.Count > 0)
            {
                whereClause.Append(" AND ");
                whereClause.Append("OrderTypeID in ( ");
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.ShipmentTypeSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.ShipmentStatusSelected != null
                && shipmentworkbenchFilterModel.ShipmentStatusSelected.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("s.ShipmentStatusID in ( ");
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.ShipmentStatusSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.CarrierSelected != null
                && shipmentworkbenchFilterModel.CarrierSelected.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("CarrierID in ( ");//SO.
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.CarrierSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.TenderStatusSelected != null
                && shipmentworkbenchFilterModel.TenderStatusSelected.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("S.ShipmentTenderStatusID in ( ");
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.TenderStatusSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.LocationFromSelected != null
                && shipmentworkbenchFilterModel.LocationFromSelected.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("FromLocationID in ( ");//SO
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.LocationFromSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.LocationToSelected != null
                && shipmentworkbenchFilterModel.LocationToSelected.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("ToLocationID in ( ");//SO
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.LocationToSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.OrderNumber != string.Empty && shipmentworkbenchFilterModel.OrderNumber != null)
            {
                var orderNoStr = string.Empty;
                var orderNoVersionStr = string.Empty;
                string[] orderNoList = shipmentworkbenchFilterModel.OrderNumber.Trim().Split(",");
                foreach (string orderno in orderNoList)
                {
                    int count = 0;
                    string[] orderNoListN = orderno.Split(".");
                    foreach (string order in orderNoListN)
                    {
                        count = count + 1;
                        if (count == 1)
                        {
                            orderNoStr = orderNoStr + "'" + order.Trim() + "',";
                        }
                        else
                        {
                            orderNoVersionStr = orderNoVersionStr + "" + order.Trim() + ",";
                        }
                    }
                }
                orderNoStr = orderNoStr.Remove(orderNoStr.Length - 1);
                whereClause.Append(" AND ");//or
                whereClause.Append("OrderNumber in ( ");
                whereClause.Append(string.Join(",", orderNoStr));
                whereClause.Append(" )");

                if (orderNoVersionStr.Length > 0)
                {
                    orderNoVersionStr = orderNoVersionStr.Remove(orderNoVersionStr.Length - 1);
                    whereClause.Append(" AND ");//or
                    whereClause.Append("OrderVersionNumber in ( ");
                    whereClause.Append(string.Join(",", orderNoVersionStr));
                    whereClause.Append(" )");
                }

            }

            if (shipmentworkbenchFilterModel.PoNumber != string.Empty && shipmentworkbenchFilterModel.PoNumber != null)
            {
                string source = shipmentworkbenchFilterModel.PoNumber;
                string[] items = source.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                var joined = string.Join(",", items.Select(item => '\'' + item + '\''));
                whereClause.Append(" AND ");//or
                whereClause.Append("PurchaseOrderNumber in ( ");
                whereClause.Append(string.Join(",", joined));
                whereClause.Append(" )");
            }

            if (shipmentworkbenchFilterModel.ShipmentNumber != string.Empty && shipmentworkbenchFilterModel.ShipmentNumber != null)
            {
                var shipmentNoStr = string.Empty;
                var shipmentNoVersionStr = string.Empty;
                string[] shipmentNoList = shipmentworkbenchFilterModel.ShipmentNumber.Trim().Split(",");
                foreach (string shipmentno in shipmentNoList)
                {
                    int count = 0;
                    string[] shipmentNoListN = shipmentno.Split(".");
                    foreach (string shipment in shipmentNoListN)
                    {
                        count = count + 1;
                        if (count == 1)
                        {
                            shipmentNoStr = shipmentNoStr + "'" + shipment.Trim() + "',";
                        }
                        else
                        {
                            // shipmentNoVersionStr = shipmentNoVersionStr + "'" + shipment.Trim() + "',";
                            shipmentNoVersionStr = shipmentNoVersionStr + "" + shipment.Trim() + ",";
                        }
                    }
                }
                shipmentNoStr = shipmentNoStr.Remove(shipmentNoStr.Length - 1);

                whereClause.Append(" AND ");//or
                whereClause.Append("ShipmentNumber in ( ");
                whereClause.Append(string.Join(",", shipmentNoStr));
                whereClause.Append(" )");

                if (shipmentNoVersionStr.Length > 0)
                {
                    shipmentNoVersionStr = shipmentNoVersionStr.Remove(shipmentNoVersionStr.Length - 1);
                    whereClause.Append(" AND ");//or
                    whereClause.Append("ShipmentVersion in ( ");
                    whereClause.Append(string.Join(",", shipmentNoVersionStr));
                    whereClause.Append(" )");
                }
            }

            if (shipmentworkbenchFilterModel.ShipWith != null)
            {
                if (shipmentworkbenchFilterModel.ShipWith == true)
                {
                    whereClause.Append(" AND ");
                    whereClause.Append(" ShipWithOrderID IS NOT NULL AND IsShipWith = 1 ");
                }
                else if (shipmentworkbenchFilterModel.ShipWith == false)
                {
                    whereClause.Append(" AND ");
                    whereClause.Append(" (ShipWithOrderID IS NOT NULL OR ShipWithOrderID IS NULL)");
                }
            }

            if (shipmentworkbenchFilterModel.PickupAppointment != null
                && shipmentworkbenchFilterModel.PickupAppointment.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("PickupAppointment BETWEEN ");
                whereClause.Append(string.Join(" and ", shipmentworkbenchFilterModel.PickupAppointment.Select(item => '\'' + Convert.ToDateTime(item.AddDays(1)).ToString("yyyy-MM-dd") + '\'')));
            }

            if (shipmentworkbenchFilterModel.DeliveryAppointment != null
                && shipmentworkbenchFilterModel.DeliveryAppointment.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("DeliveryAppointment BETWEEN ");
                whereClause.Append(string.Join(" and ", shipmentworkbenchFilterModel.DeliveryAppointment.Select(item => '\'' + Convert.ToDateTime(item.AddDays(1)).ToString("yyyy-MM-dd") + '\'')));
            }

            if (shipmentworkbenchFilterModel.ShipDate != null
                && shipmentworkbenchFilterModel.ShipDate.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("ShipDate BETWEEN ");//S
                whereClause.Append(string.Join(" and ", shipmentworkbenchFilterModel.ShipDate.Select(item => '\'' + Convert.ToDateTime(item.AddDays(1)).ToString("yyyy-MM-dd") + '\'')));
            }

            if (shipmentworkbenchFilterModel.ReqDeliveryDate != null
                && shipmentworkbenchFilterModel.ReqDeliveryDate.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("RequestedDeliveryDate BETWEEN ");//S
                whereClause.Append(string.Join(" and ", shipmentworkbenchFilterModel.ReqDeliveryDate.Select(item => '\'' + Convert.ToDateTime(item.AddDays(1)).ToString("yyyy-MM-dd") + '\'')));
            }

            if (shipmentworkbenchFilterModel.ActDeliveryDate != null
                && shipmentworkbenchFilterModel.ActDeliveryDate.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("ActualDeliveryDate BETWEEN ");//S
                whereClause.Append(string.Join(" and ", shipmentworkbenchFilterModel.ActDeliveryDate.Select(item => '\'' + Convert.ToDateTime(item.AddDays(1)).ToString("yyyy-MM-dd") + '\'')));
            }

            if (shipmentworkbenchFilterModel.MustArriveByDate != null
                && shipmentworkbenchFilterModel.MustArriveByDate.Count > 0)
            {
                whereClause.Append(" AND ");//or
                whereClause.Append("MustArriveByDate BETWEEN ");//S
                whereClause.Append(string.Join(" and ", shipmentworkbenchFilterModel.MustArriveByDate.Select(item => '\'' + Convert.ToDateTime(item.AddDays(1)).ToString("yyyy-MM-dd") + '\'')));
            }
            if (shipmentworkbenchFilterModel.LocationTypeFromSelected != null
               && shipmentworkbenchFilterModel.LocationTypeFromSelected.Count > 0)
            {
                whereClause.Append(" AND ");
                whereClause.Append("LocationTypeID in ( ");
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.LocationTypeFromSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }
            if (shipmentworkbenchFilterModel.LocationTypeToSelected != null
               && shipmentworkbenchFilterModel.LocationTypeToSelected.Count > 0)
            {
                whereClause.Append(" AND ");
                whereClause.Append("LocationTypeID in ( ");
                whereClause.Append(string.Join(",", shipmentworkbenchFilterModel.LocationTypeToSelected.Select(x => x.ID)));
                whereClause.Append(" )");
            }

            whereClause.Append(")");

            //to remove first AND from the string
            if (whereClause.Length > 5)
                whereClause = whereClause.Remove(2, 3);

            return whereClause.ToString();
        }

        public async Task<IEnumerable<ShipmentOrderDetailViewModel>> GetShipmentAllDetailsCount(ShipmentOrderDetailViewModel shipmentSaveDataViewModal)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (shipmentSaveDataViewModal != null)
            {
                chargeParameter.Add("PageNumber", 0);
                chargeParameter.Add("PageSize", 0);
                chargeParameter.Add("ClientId", shipmentSaveDataViewModal.ClientID);
                chargeParameter.Add("InboundOutbound", shipmentSaveDataViewModal.InboundOutbound);

            }

            if (string.IsNullOrWhiteSpace(shipmentSaveDataViewModal.SortColumn))
            {
                chargeParameter.Add("SortColumn", shipmentSaveDataViewModal.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(shipmentSaveDataViewModal.SortOrder))
            {
                chargeParameter.Add("SortOrder", shipmentSaveDataViewModal.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentDetails", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ShipmentOrderDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<ShipmentOrderDetailViewModel>>(FilterResult<ShipmentOrderDetailViewModel>.GetFilteredResult(finalResult, shipmentSaveDataViewModal.FilterOn, shipmentSaveDataViewModal.PageSize));
            }

            return null;
        }

        public async Task<object> GetshipFromtypeAll(ShipmentSaveData flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientId", flagViewModel.clientID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetshipFromtypeAll", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentLocation>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<object> GetshiptotypeAll(ShipmentSaveData flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientId", flagViewModel.clientID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetshiptotypeAll", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentLocation>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<object> GetshipFromAllData(ShipmentSaveData flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientId", flagViewModel.clientID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetshipFromAllData", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentLocation>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<object> GetshipToAllData(ShipmentSaveData flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientId", flagViewModel.clientID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetshipToAllData", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentLocation>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> ReSendSelectedShipmentToMAS(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_ShipmentReSendToMAS", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[dsResult.Tables.Count - 1].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipResponseModel>(dsResult.Tables[dsResult.Tables.Count - 1]);
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> GetChargetypeforApcharges(apchargesInputModel apchargesInput)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("LocationID", apchargesInput.BusinessPartnerID);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetChargeTypeForShipmentApcharges", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<DropdownlistModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<List<ShippmentCciViewModel>> GetCciReportById(long shipmentId)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentId", shipmentId);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentCciReport", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                List<ShippmentCciViewModel> shipmentCcilist = ConvertDataTabe.CreateListFromTable<ShippmentCciViewModel>(dsResult.Tables[0]);

                foreach (ShippmentCciViewModel cci in shipmentCcilist)
                {
                    Dictionary<string, object> orderParam = new Dictionary<string, object>();
                    orderParam.Add("OrderId", cci.OrderID);
                    var orderResult = this.unitOfWork.ExecuteProcedure("SPO_GetShipmentCciReport", orderParam);
                    if (orderResult != null
                        && orderResult.Tables != null
                        && orderResult.Tables[0].Rows.Count > 0)
                    {
                        cci.ShippmentCciOrderDetails = ConvertDataTabe.
                            CreateListFromTable<ShipmentCciOrderDetail>(orderResult.Tables[0]);
                    }

                    if (cci.ShippmentCciOrderDetails != null)
                    {
                        foreach (ShipmentCciOrderDetail orderDetails in cci.ShippmentCciOrderDetails)
                        {
                            cci.TotalPackages += orderDetails.NumberOfPackages;
                            cci.TotalQuantity += orderDetails.Quantity;
                            cci.NetWeight += int.Parse(orderDetails.NetWeight);
                            cci.GrossWeight += int.Parse(orderDetails.GrossWeight);
                            cci.TotalTotal += orderDetails.Total;

                        }

                    }
                }

                return shipmentCcilist;
            }
            else
            {
                return null;
            }
        }

        public async Task<Object> TPQFailSendShipmentToMAS(ShipmentCommonModel flagViewModel)
        {
            ShipResponseModel MasResponse = new ShipResponseModel();
            var result = this.hangfireOperation.SendShipmentTOMAS(flagViewModel.ShipmentID);
            if (result != null && result.Count() > 0)
            {
                var Status = ((IDictionary<string, object>)result.FirstOrDefault())["Status"].ToString();
                var Message = ((IDictionary<string, object>)result.FirstOrDefault())["Text"].ToString();
                MasResponse.Status = Status;
                MasResponse.Message = Message;
            }
            else
            {
                MasResponse.Status = "FAIL";
                MasResponse.Message = "Send to MAS Unsuccessful";
            }
            return MasResponse;
        }
        //manage custom filter
        public async Task<bool> SaveCreateManageFilter(CreateFilter createFilter)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CreateManageCustomFilterShipment", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", createFilter.ClientID);
                    cmd.Parameters.AddWithValue("@FilterName", createFilter.FilterName);
                    cmd.Parameters.AddWithValue("@IsDefault", createFilter.IsDefault);
                    cmd.Parameters.AddWithValue("@FilterExpression", createFilter.FilterExpression);
                    cmd.Parameters.AddWithValue("@UserID", createFilter.UserID);
                    //cmd.Parameters.AddWithValue("@InboundOutbound", createFilter.SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }
        public async Task<IEnumerable<CreateFilter>> GetAllCustomManageFiltersData(int clientId, int userId, string selectedTab)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", clientId);
                parameter.Add("@UserID", userId);
               // parameter.Add("@InboundOutbound", selectedTab);
                var createFilterViewModels = con.Query<CreateFilter>("SPO_GetManageCustomFiltersDataShipment", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return createFilterViewModels;
            }
        }
        public async Task<bool> UpdateManageFilters(CreateFilter createFilter)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_UpdateManageCustomFilterShipment", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", createFilter.ClientID);
                    cmd.Parameters.AddWithValue("@Id", createFilter.Id);
                    cmd.Parameters.AddWithValue("@FilterName", createFilter.FilterName);
                    cmd.Parameters.AddWithValue("@IsDefault", createFilter.IsDefault);
                    cmd.Parameters.AddWithValue("@FilterExpression", createFilter.FilterExpression);
                    cmd.Parameters.AddWithValue("@UserID", createFilter.UserID);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }
        public async Task<bool> DeleteManageFilters(CreateFilter createFilter)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_DeleteManageCustomFilterShipment", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", createFilter.ClientID);
                    cmd.Parameters.AddWithValue("@Id", createFilter.Id);
                    cmd.Parameters.AddWithValue("@UserID", createFilter.UserID);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }
   
        public async Task<Object> GetUOMforApcharespopup()
        {

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetUOMforApcharespopup");

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<UOMApcherges>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public async Task<ValidationResponse> RecalculateShipment(ShipmentViewModel shipmentViewModel)
        {
            ValidationResponse validationResponse = new ValidationResponse();

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", shipmentViewModel.Id);
            parameters.Add("UpdateBy", shipmentViewModel.UpdatedBy);

            var result = this.unitOfWork.ExecuteProcedure("SPO_ReCalculateAPChargesForShipment", parameters);

            if (result != null && result.Tables.Count > 0)
            {
                int response = Convert.ToInt32(result.Tables[0].Rows[0]["Status"]);

                if (response == 1)
                {
                    validationResponse.IsValid = true;
                    validationResponse.Message = "Updated.";
                }
                else if (response == -1)
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = "shipment already send to mas.";
                }
                else
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = "there is some issue contact to admin.";
                }
            }
            else
            {
                validationResponse.IsValid = false;
                validationResponse.Message = "there is some issue contact to admin.";
            }

            return validationResponse;
        }
        public async Task<Object> GetProformaInvoiceData(ShipmentCommonModel flagViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", flagViewModel.ShipmentID);
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetProformaInvoiceData", parameters);
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentProformaInvoiceModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<Object> GetProformaInvoiceOrganizationAddress()
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("OrgCode", "tos");
            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetProformaInvoiceOrganizationAddress", parameters);
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ShipmentProformaInvoiceOrgAddressModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }
        public async Task<Object> GetApchargesDuetoLocChange(ApchargeLocChangeModel apchargeLocChangeModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ShipmentID", apchargeLocChangeModel.shipmentid);


            DataTable dtOrderdata = ShipmentSaveParametersData.CreateOrdApcData(apchargeLocChangeModel);
            if (dtOrderdata != null)
            {
                parameters.Add("Orderdata", dtOrderdata);
            }
            DataTable dtOrderDetata = ShipmentSaveParametersData.CreateOrdDetApcData(apchargeLocChangeModel);
            if (dtOrderDetata != null)
            {
                parameters.Add("OrdDetailsdata", dtOrderDetata);
            }


             var dsResult = this.unitOfWork.ExecuteProcedure("", parameters);
            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<Apcharges>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

    }
}