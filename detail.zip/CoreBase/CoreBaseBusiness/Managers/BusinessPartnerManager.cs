﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Dapper;
    using Microsoft.Extensions.Configuration;

    public class BusinessPartnerManager : IBusinessPartnerManager
    {
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;

        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessPartnerManager"/> class.
        /// which user to implement dependancy injection into manager.
        /// </summary>
        /// <param name="unitOfWork">database communication unit of work.</param>
        public BusinessPartnerManager(ADecTecCoreBaseDBContext eICDBContext)
        {
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }


        /// <summary>
        /// Get Business Partner By Location.
        /// </summary>
        /// <param name="businessPartnerByLocationViewModel">data model for pagination.</param>
        /// <returns> Returns a list of BusinessPartnerByLocation models</returns>
        public async Task<IEnumerable<BusinessPartnerByLocationViewModel>>
            GetBusinessPartnerByLocation(BusinessPartnerByLocationViewModel businessPartnerByLocationViewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();
            if (businessPartnerByLocationViewModel != null
                && string.IsNullOrWhiteSpace(businessPartnerByLocationViewModel.FilterOn))
            {
                storedProcedureParameter.Add("PageNumber", businessPartnerByLocationViewModel.PageNo);
                storedProcedureParameter.Add("PageSize", businessPartnerByLocationViewModel.PageSize);
            }
            storedProcedureParameter.Add("ClientId", businessPartnerByLocationViewModel.ClientID);
            storedProcedureParameter.Add("SortColumn", businessPartnerByLocationViewModel.SortColumn);
            storedProcedureParameter.Add("SortOrder", businessPartnerByLocationViewModel.SortOrder);

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetBusinessPartnerByLocationDetails", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<BusinessPartnerByLocationViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<BusinessPartnerByLocationViewModel>>
                    (FilterResult<BusinessPartnerByLocationViewModel>.GetFilteredResult(finalResult, businessPartnerByLocationViewModel.FilterOn, businessPartnerByLocationViewModel.PageSize, businessPartnerByLocationViewModel));
            }

            return null;
        }


        /// <summary>
        /// Get Business Partner By Location.
        /// </summary>
        /// <param name="businessPartnerByLocationViewModel">data model for pagination.</param>
        /// <returns> Returns a list of BusinessPartnerByLocation models</returns>
        public async Task<IEnumerable<BusinessPartnerByCarrierViewModel>>
            GetBusinessPartnerByCarrier(BusinessPartnerByCarrierViewModel businessPartnerByCarrierViewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();
            if (businessPartnerByCarrierViewModel != null
                && string.IsNullOrWhiteSpace(businessPartnerByCarrierViewModel.FilterOn))
            {
                storedProcedureParameter.Add("PageNumber", businessPartnerByCarrierViewModel.PageNo);
                storedProcedureParameter.Add("PageSize", businessPartnerByCarrierViewModel.PageSize);
            }

            storedProcedureParameter.Add("ClientId", businessPartnerByCarrierViewModel.ClientID);

            if (!string.IsNullOrWhiteSpace(businessPartnerByCarrierViewModel.SortColumn))
            {
                storedProcedureParameter.Add("SortColumn", businessPartnerByCarrierViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(businessPartnerByCarrierViewModel.SortOrder))
            {
                storedProcedureParameter.Add("SortOrder", businessPartnerByCarrierViewModel.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetBusinessPartnerByCarrierDetails", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<BusinessPartnerByCarrierViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<BusinessPartnerByCarrierViewModel>>
                    (FilterResult<BusinessPartnerByCarrierViewModel>.GetFilteredResult(finalResult,
                    businessPartnerByCarrierViewModel.FilterOn, businessPartnerByCarrierViewModel.PageSize, businessPartnerByCarrierViewModel));
            }

            return null;
        }

        public async Task<bool> UpdateBusinessPartnerByLocation(BusinessPartnerByLocationViewModel editModel)
        {
            var location = new Location();
            location.Id = editModel.BusinessPartnerId;
            location.LoadingComment = editModel.LoadingComment;
            location.TransportationComment = editModel.TransportationComment;
            location.UpdateDateTimeBrowser = editModel.UpdateDateTimeBrowser;
            location.SetupComplete = editModel.SetupDone;
            location.SetupCompleteDateTime = editModel.SetupDoneDateTime;
            location.SetupCompleteBy = editModel.SetupDoneBy;
            location.LocationFunctionId = Convert.ToInt32(editModel.LocationFunctionID);
            location.UpdatedBy = editModel.UpdatedBy;
            var updateSuccsessful = await this.unitOfWork.LocationRepository.UpdateBusinessPartnerAsync(location);
            if (!updateSuccsessful)
            {
                return false;
            }

            var saveAll = this.unitOfWork.Save();
            if (saveAll)
            {
                return true;
            }

            return false;
        }

        public async Task<bool> UpdateBusinessPartnerByCarrier(BusinessPartnerByCarrierViewModel editModel)
        {
            var carrier = new Carrier();
            carrier.Id = editModel.BusinessPartnerId;
            carrier.UpdateDateTimeBrowser = editModel.UpdateDateTimeBrowser;
            carrier.SetupComplete = editModel.SetupDone;
            carrier.SetupCompleteDateTime = editModel.SetupDoneDateTime;
            carrier.SetupCompleteBy = editModel.SetupDoneBy;
            carrier.UpdatedBy = editModel.UpdatedBy;
            var updateSuccsessful = await this.unitOfWork.CarrierRepository.UpdateBusinessPartnerAsync(carrier);
            if (!updateSuccsessful)
            {
                return false;
            }

            var saveAll = this.unitOfWork.Save();
            if (saveAll)
            {
                return true;
            }

            return false;
        }



        public async Task<bool> AddCarrier(BusinessPartnerByCarrierViewModel editModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();
            Dictionary<string, object> storedProcedureOutParameter = new Dictionary<string, object>();
            if (editModel != null)
            {
                storedProcedureParameter.Add("CarrierName", editModel.BusinessPartnerName);
                storedProcedureParameter.Add("SCACCode", editModel.ScacValue);
                storedProcedureParameter.Add("SourceSystemID", editModel.SourceSystemID);
                storedProcedureParameter.Add("CreatedBY", editModel.CreatedBy);
                storedProcedureParameter.Add("CreateDateTimeBrowser", editModel.CreateDateTimeBrowser);
                storedProcedureOutParameter.Add("Out_OrganizationID", 0);
                storedProcedureOutParameter.Add("Out_CarrierID", 0);
            }

            var outputParameters = this.unitOfWork.ExecuteProcedureForResultValue("SPO_InsertOrUpdateCarrier",
                storedProcedureParameter,
                storedProcedureOutParameter);

            if (outputParameters != null && outputParameters["Out_CarrierID"] != null)
            {
                return true;
            }

            return false;
        }
        #region Active/Inactive location Businesspartner
        public async Task<bool> ActivateLocationBusinessPartner(List<string> ids, bool isActive)
        {
            if (ids.Any())
            {
                List<long> BusinessPartnerID = ids.ConvertAll(long.Parse);

                List<Location> Businesspartnerstatus = this.unitOfWork.LocationRepository.ListAsync(p => BusinessPartnerID.Contains(p.Id)).Result.ToList();
                if (Businesspartnerstatus.Count != 0)
                {
                    foreach (Location businespartner in Businesspartnerstatus)
                    {
                        businespartner.IsActive = isActive;
                        if (!businespartner.IsActive)
                        {
                            var configurationBuild = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
                            string strConnectionString = configurationBuild["ConnectionString:CoreBaseDB"];
                            using (IDbConnection con = new SqlConnection(strConnectionString))
                            {
                                if (con.State == ConnectionState.Closed)
                                    con.Open();

                                DynamicParameters parameter = new DynamicParameters();
                                parameter.Add("@LocationId", businespartner.Id);
                                parameter.Add("@updatedby", businespartner.UpdatedBy);
                                var usersViewModels = con.Query<object>("SPO_UpdateContractByLocation", parameter, commandType: CommandType.StoredProcedure).ToList();
                                con.Close();
                            }
                        }
                    }

                    var result = this.unitOfWork.Save();
                    return await Task.FromResult<bool>(result);
                }
                return await Task.FromResult<bool>(false);
            }

            return await Task.FromResult<bool>(false);
        }
        #endregion
        #region Active/Inactive Carrier
        public async Task<bool> ActivateCarrier(List<string> ids, bool isActive)
        {
            if (ids.Any())
            {
                List<long> carrierID = ids.ConvertAll(long.Parse);

                List<Carrier> Carrierstatus = this.unitOfWork.CarrierRepository.ListAsync(p => carrierID.Contains(p.Id)).Result.ToList();
                if (Carrierstatus.Count != 0)
                {
                    foreach (Carrier carrriers in Carrierstatus)
                    {
                        carrriers.IsActive = isActive;
                    }

                    var result = this.unitOfWork.Save();

                    return await Task.FromResult<bool>(result);
                }
                return await Task.FromResult<bool>(false);
            }

            return await Task.FromResult<bool>(false);
        }
        #endregion

        #region Get All Billing Entity
        public async Task<IEnumerable<BusinessPartnerBilingEntityViewModel>>
           GetAllBillingEntity(BusinessPartnerBilingEntityViewModel businessPartnerBilingEntityViewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();


            storedProcedureParameter.Add("ClientId", businessPartnerBilingEntityViewModel.ClientID);
            storedProcedureParameter.Add("BusinessPartnerTypeId", businessPartnerBilingEntityViewModel.BusinessPartnerTypeId);

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetAllBillingEntity", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<BusinessPartnerBilingEntityViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<BusinessPartnerBilingEntityViewModel>>(finalResult);
            }

            return null;
        }
        #endregion
        #region Get All Billing Entity For Carrier
        public async Task<IEnumerable<BusinessPartnerBilingEntityViewModel>>
           GetAllBillingEntityforCarrier(BusinessPartnerBilingEntityViewModel businessPartnerBilingEntityViewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();


            storedProcedureParameter.Add("ClientId", businessPartnerBilingEntityViewModel.ClientID);

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetAllBillingEntityForCarrier", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<BusinessPartnerBilingEntityViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<BusinessPartnerBilingEntityViewModel>>(finalResult);
            }

            return null;
        }
        #endregion
        #region Get Custom All Billing Entity
        public async Task<IEnumerable<BusinessPartnerBilingEntityViewModel>>
           GetAllCustomBillingEntity(BusinessPartnerBilingEntityViewModel businessPartnerBilingEntityViewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();


            storedProcedureParameter.Add("ClientId", businessPartnerBilingEntityViewModel.ClientID);
            storedProcedureParameter.Add("LocationTypeCode", businessPartnerBilingEntityViewModel.LocationTypeCode);

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetCustomBillingEntity", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<BusinessPartnerBilingEntityViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<BusinessPartnerBilingEntityViewModel>>(finalResult);
            }

            return null;
        }
        #endregion
    }
}
