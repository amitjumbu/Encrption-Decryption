﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientMensturalHistoryManager : BaseManager<PatientMensturalHistory, PatientMensturalHistoryViewModel>, IPatientMensturalHistoryManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientMensturalHistoryManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        

        public async override Task<int> CountAsync(PatientMensturalHistoryViewModel viewModel)
        {
            Expression<Func<PatientMensturalHistory, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientMensturalHistoryRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientMensturalHistoryViewModel>> RangeAsync(int recordCount, PatientMensturalHistoryViewModel viewModel)
        {
            Expression<Func<PatientMensturalHistory, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientMensturalHistoryRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientMensturalHistoryViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientMensturalHistoryViewModel>> ListAsync(PatientMensturalHistoryViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientMensturalHistory, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientMensturalHistoryRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientMensturalHistoryViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientMensturalHistoryViewModel viewModel)
        {
            var module = this._mapper.Map<PatientMensturalHistory>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientMensturalHistoryRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientMensturalHistoryViewModel viewModel)
        {
            var module = this._mapper.Map<PatientMensturalHistory>(viewModel);
            var data = this._unitOfWork.PatientMensturalHistoryRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
    }
}