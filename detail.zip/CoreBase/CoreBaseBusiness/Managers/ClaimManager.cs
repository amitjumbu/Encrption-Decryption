﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{

    public class ClaimManager : BaseManager<Claim, ClaimViewModel>, IClaimManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;



        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.BaseConnectionString; } }

        private IHangfireOperation hangfireOperation;
        private IConvertEnglishToSpanish convertEnglishToSpanish;


        public ClaimManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext, IHangfireOperation hangfireOperation, IConvertEnglishToSpanish convertEnglishToSpanish)
            : base()
        {
            this._mapper = mapper;

            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;
            this.hangfireOperation = hangfireOperation;
            this.convertEnglishToSpanish = convertEnglishToSpanish;

        }

        public override Task<bool> AddAsync(ClaimViewModel viewModel)
        {

            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(ClaimViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<ClaimViewModel>> ListAsync(ClaimViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<ChargeViewModel>> GetChageListForAdjustChageSection(ChargeViewModel chargeViewModel)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<ChargeViewModel>> UpdateModelsAsync(List<ChargeViewModel> chargeViewModels)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<ChargeViewModel>> GetAllChargeDetails(ChargeViewModel chargeViewModel)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<ClaimViewModel>> GetAllClaimData(ClaimViewModel claimViewModel, ref int TotalCount)
        {

            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (claimViewModel != null)
            {
                chargeParameter.Add("PageNumber", claimViewModel.PageNo);
                if (!string.IsNullOrEmpty(claimViewModel.FilterOn))
                    chargeParameter.Add("PageSize", 0);
                else
                    chargeParameter.Add("PageSize", claimViewModel.PageSize);

                chargeParameter.Add("ClientId", claimViewModel.ClientID);
            }

            if (string.IsNullOrWhiteSpace(claimViewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", claimViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(claimViewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", claimViewModel.SortOrder);
            }
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetClaimData", chargeParameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ClaimViewModel>(ds.Tables[0]);
                TotalCount = Convert.ToInt32(ds.Tables[1].Rows[0][0]);
                return Task.FromResult<IEnumerable<ClaimViewModel>>(FilterResult<ClaimViewModel>.GetFilteredResult(finalResult, claimViewModel.FilterOn, claimViewModel.PageSize));
            }
            else
                return null;
        }



        public async Task<object> GetFilterClaimData(ClaimFilterParameter ViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ShipmentID", ViewModel.ShipmentID);
                parameter.Add("@ClientID", ViewModel.ClientID);
                parameter.Add("@OrderID", ViewModel.OrderID);
                parameter.Add("@ClaimID", ViewModel.ClaimID);
                parameter.Add("@ClaimFor", ViewModel.ClaimFor);
                var FilterClaimData = con.Query<Object>("SPO_GetClaimFilterData", parameter, commandType: CommandType.StoredProcedure);

                con.Close();


                return FilterClaimData;
            }
        }

        public async Task<int> GetAllClaimDataCount(ClaimViewModel claimViewModel)
        {

            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (claimViewModel != null)
            {
                chargeParameter.Add("PageNumber", 0);
                chargeParameter.Add("PageSize", 0);
                chargeParameter.Add("ClientId", claimViewModel.ClientID);
            }

            if (!string.IsNullOrWhiteSpace(claimViewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", claimViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(claimViewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", claimViewModel.SortOrder);
            }
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetClaimData", chargeParameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ClaimViewModel>(ds.Tables[0]);
                return finalResult.Count();
            }
            else
                return 0;
        }

        public async Task<object> GetClaimDetailsByClaimId(int ClaimId, int ClientId)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientID", ClientId);
                parameter.Add("@ClaimId", ClaimId);
                var getClaimDetailById = con.Query<Object>("SPO_GetClaimDetailByClaimId", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return getClaimDetailById;
            }
        }

        public async Task<object> CompleteSetupAndNotify(int clientId, int claimId, bool isCompleteSetupAndNotify, int claimStatusId, int userId)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", clientId);
                parameter.Add("@ClaimId", claimId);
                parameter.Add("@ClaimStatusId", claimStatusId);
                parameter.Add("@IsCompleteSetupAndNotify", isCompleteSetupAndNotify);
                parameter.Add("@UserId", userId);
                var claimSetup = con.Query<object>("SPO_CompleteSetupAndNotifyForClaim", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return claimSetup;
            }
        }
        public async Task<object> SetClaimApproved(int clientId, int claimId, bool isApproved, int claimStatusId, int userId)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", clientId);
                parameter.Add("@ClaimId", claimId);
                parameter.Add("@ClaimStatusId", claimStatusId);
                parameter.Add("@IsCompleteSetupAndNotify", isApproved);
                parameter.Add("@UserId", userId);
                var claimApproved = con.Query<object>("SPO_IsApprovedForClaim", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return claimApproved;
            }
        }


        public async Task<object> SaveClaimDetail(ClaimDetailModel ViewModel)
        {

            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            DataTable dterroResponse = new DataTable();
            dterroResponse.Columns.Add("Status");
            dterroResponse.Columns.Add("Message");
            DataRow dr = dterroResponse.NewRow();
            dr[0] = "FAIL";
            dr[1] = "Claim details Not Saved";
            dterroResponse.Rows.Add(dr);
            Parameter.Add("ID", ViewModel.ID);
            Parameter.Add("ClaimID", ViewModel.ClaimID);
            Parameter.Add("ClientID", ViewModel.ClientID);
            Parameter.Add("ChargeID", ViewModel.ChargeID);
            Parameter.Add("InvoicedAmount", ViewModel.InvoicedAmount);
            Parameter.Add("ClaimedQuantity", ViewModel.ClaimedQuantity);
            Parameter.Add("ClaimAmount", ViewModel.ClaimAmount);
            Parameter.Add("RecommendedAmount", ViewModel.RecommendedAmount);
            Parameter.Add("ApprovedAmount", ViewModel.ApprovedAmount);
            Parameter.Add("InvoiceNumber", ViewModel.InvoiceNumber);
            Parameter.Add("StatusID", ViewModel.StatusID);
            Parameter.Add("ApproverComment", ViewModel.ApproverComment);
            Parameter.Add("CreatedBy", ViewModel.CreatedBy);
            Parameter.Add("CreateDateTimeBrowser", ViewModel.CreateDateTimeBrowser);


            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_SaveUpdateClaimDetail", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ResponseModel>(ds.Tables[0]);
                return finalResult;
            }
            else
            {
                var errorResposne = ConvertDataTabe.CreateListFromTable<ResponseModel>(dterroResponse);
                return errorResposne;
            }
        }

        public async Task<object> CompleteSetupAndNotifyAlert(int clientId, int claimId, bool isCompleteSetupAndNotify)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", clientId);
                parameter.Add("@ClaimId", claimId);
                parameter.Add("@IsCompleteSetupAndNotify", isCompleteSetupAndNotify);
                var ClaimNotification = con.Query<object>("SPO_BookClaimNotification", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return ClaimNotification;
            }
        }
        public async Task<object> SetClaimApprovedAlert(int clientId, int claimId, bool isApproved)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", clientId);
                parameter.Add("@ClaimId", claimId);
                parameter.Add("@IsApproved", isApproved);
                var claimApprovedAlert = con.Query<object>("SPO_BookClaimNotification", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return claimApprovedAlert;
            }
        }

        public async Task<object> SaveClaim(ClaimModel ViewModel)
        {

            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            DataTable dterroResponse = new DataTable();
            dterroResponse.Columns.Add("Status");
            dterroResponse.Columns.Add("Message");
            DataRow dr = dterroResponse.NewRow();
            dr[0] = "FAIL";
            dr[1] = "Claim Not Saved";
            dterroResponse.Rows.Add(dr);

            Parameter.Add("InvoNumber", ViewModel.InvoiceNumber);
            Parameter.Add("DateSubmitted", ViewModel.DateSubmitted);
            Parameter.Add("EntityID", ViewModel.EntityId);
            Parameter.Add("EntityKeyID", ViewModel.EntityKeyId);
            Parameter.Add("LocationID", ViewModel.LocationId);
            Parameter.Add("ClaimStatusID", ViewModel.ClaimStatusID);
            Parameter.Add("ClaimForID", ViewModel.ClaimForID);
            Parameter.Add("ClaimComments", ViewModel.ClaimComments);
            Parameter.Add("IsDeleted", ViewModel.IsDeleted);
            Parameter.Add("ClientID", ViewModel.ClientID);
            Parameter.Add("CreatedBy", ViewModel.CreatedBy);
            Parameter.Add("CreateDateTimeBrowser", ViewModel.CreateDateTimeBrowser);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_SaveUpdateClaim", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ResponseModel>(ds.Tables[0]);
                return finalResult;
            }
            else
            {
                var errorResposne = ConvertDataTabe.CreateListFromTable<ResponseModel>(dterroResponse);
                return errorResposne;
            }
        }

        public async Task<object> UpdateClaim(ClaimModel ViewModel)
        {

            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            DataTable dterroResponse = new DataTable();
            dterroResponse.Columns.Add("Status");
            dterroResponse.Columns.Add("Message");
            DataRow dr = dterroResponse.NewRow();
            dr[0] = "FAIL";
            dr[1] = "Claim Not Update";
            dterroResponse.Rows.Add(dr);



            Parameter.Add("ClaimComments", ViewModel.ClaimComments);
            Parameter.Add("ClaimId", ViewModel.ClaimID);
            Parameter.Add("ClientID", ViewModel.ClientID);
            Parameter.Add("UpdatedBy", ViewModel.CreatedBy);
            Parameter.Add("UpdateDateTimeBrowser", ViewModel.CreateDateTimeBrowser);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_UpdateClaim", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ResponseModel>(ds.Tables[0]);
                return finalResult;
            }
            else
            {
                var errorResposne = ConvertDataTabe.CreateListFromTable<ResponseModel>(dterroResponse);
                return errorResposne;
            }
        }




        public async Task<object> SaveMultiClaimDetail(MultiClaimModel multiClaimModel)
        {

            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            DataTable dterroResponse = new DataTable();
            dterroResponse.Columns.Add("Status");
            dterroResponse.Columns.Add("Message");
            DataRow dr = dterroResponse.NewRow();
            dr[0] = "FAIL";
            dr[1] = "Claim details Not Saved";
            dterroResponse.Rows.Add(dr);


            Parameter.Add("CreateDateTimeBrowser", multiClaimModel.CreateDateTimeBrowser);


            DataTable dtClaimDetail = new DataTable();
            dtClaimDetail.Columns.Add("ID");
            dtClaimDetail.Columns.Add("ClaimID");
            dtClaimDetail.Columns.Add("MaterialID");
            dtClaimDetail.Columns.Add("ChargeID");
            dtClaimDetail.Columns.Add("InvoicedQuantity");
            dtClaimDetail.Columns.Add("InvoicedAmount");
            dtClaimDetail.Columns.Add("InvoicedAmountUOMID");
            dtClaimDetail.Columns.Add("ApprovedAmount");
            dtClaimDetail.Columns.Add("ClaimAmount");
            dtClaimDetail.Columns.Add("ClaimedQuantity");
            dtClaimDetail.Columns.Add("ApprovedQuantity");
            dtClaimDetail.Columns.Add("LocationID");
            dtClaimDetail.Columns.Add("Comments");
            dtClaimDetail.Columns.Add("ClaimStatusID");
            dtClaimDetail.Columns.Add("InvoiceNumber");
            dtClaimDetail.Columns.Add("RecommendedAmount");
            dtClaimDetail.Columns.Add("ClientID");
            dtClaimDetail.Columns.Add("CreatedBy");
            dtClaimDetail.Columns.Add("IsDeleted");

            foreach (var claimData in multiClaimModel.claimDetailModelUP)
            {
                DataRow Cdr = dtClaimDetail.NewRow();
                Cdr[0] = claimData.ID;
                Cdr[1] = claimData.ClaimID;
                Cdr[2] = claimData.MaterialID;
                Cdr[3] = claimData.ChargeID;
                Cdr[4] = claimData.InvoicedQuantity;
                Cdr[5] = claimData.InvoicedAmount;
                Cdr[6] = claimData.InvoicedAmountUOMID;
                Cdr[7] = claimData.ApprovedAmount;
                Cdr[8] = claimData.ClaimAmount;
                Cdr[9] = claimData.ClaimedQuantity;
                Cdr[10] = claimData.ApprovedQuantity;
                Cdr[11] = claimData.LocationID;
                Cdr[12] = claimData.Comments;
                Cdr[13] = claimData.ClaimStatusID;
                Cdr[14] = claimData.InvoiceNumber;
                Cdr[15] = claimData.RecommendedAmount;
                Cdr[16] = claimData.ClientID;
                Cdr[17] = claimData.CreatedBy;
                Cdr[18] = claimData.IsDeleted;

                dtClaimDetail.Rows.Add(Cdr);
            }

            Parameter.Add("ClaimDetailType", dtClaimDetail);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_SaveUpdateMultiClaimDetails", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ResponseModel>(ds.Tables[0]);
                return finalResult;
            }
            else
            {
                var errorResposne = ConvertDataTabe.CreateListFromTable<ResponseModel>(dterroResponse);
                return errorResposne;
            }
        }


        public async Task<object> DeleteClaimDetail(MultiClaimModel multiClaimModel)
        {

            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            DataTable dterroResponse = new DataTable();
            dterroResponse.Columns.Add("Status");
            dterroResponse.Columns.Add("Message");
            DataRow dr = dterroResponse.NewRow();
            dr[0] = "FAIL";
            dr[1] = "Claim details Not Saved";
            dterroResponse.Rows.Add(dr);


            Parameter.Add("CreateDateTimeBrowser", multiClaimModel.CreateDateTimeBrowser);


            DataTable dtClaimDetail = new DataTable();
            dtClaimDetail.Columns.Add("ID");
            dtClaimDetail.Columns.Add("ClaimID");
            dtClaimDetail.Columns.Add("MaterialID");
            dtClaimDetail.Columns.Add("ChargeID");
            dtClaimDetail.Columns.Add("InvoicedQuantity");
            dtClaimDetail.Columns.Add("InvoicedAmount");
            dtClaimDetail.Columns.Add("InvoicedAmountUOMID");
            dtClaimDetail.Columns.Add("ApprovedAmount");
            dtClaimDetail.Columns.Add("ClaimAmount");
            dtClaimDetail.Columns.Add("ClaimedQuantity");
            dtClaimDetail.Columns.Add("ApprovedQuantity");
            dtClaimDetail.Columns.Add("LocationID");
            dtClaimDetail.Columns.Add("Comments");
            dtClaimDetail.Columns.Add("ClaimStatusID");
            dtClaimDetail.Columns.Add("InvoiceNumber");
            dtClaimDetail.Columns.Add("RecommendedAmount");
            dtClaimDetail.Columns.Add("ClientID");
            dtClaimDetail.Columns.Add("CreatedBy");
            dtClaimDetail.Columns.Add("IsDeleted");
            foreach (var claimData in multiClaimModel.claimDetailModelUP)
            {
                DataRow Cdr = dtClaimDetail.NewRow();
                Cdr[0] = claimData.ID;
                Cdr[1] = claimData.ClaimID;
                Cdr[2] = claimData.MaterialID;
                Cdr[3] = claimData.ChargeID;
                Cdr[4] = claimData.InvoicedQuantity;
                Cdr[5] = claimData.InvoicedAmount;
                Cdr[6] = claimData.InvoicedAmountUOMID;
                Cdr[7] = claimData.ApprovedAmount;
                Cdr[8] = claimData.ClaimAmount;
                Cdr[9] = claimData.ClaimedQuantity;
                Cdr[10] = claimData.ApprovedQuantity;
                Cdr[11] = claimData.LocationID;
                Cdr[12] = claimData.Comments;
                Cdr[13] = claimData.ClaimStatusID;
                Cdr[14] = claimData.InvoiceNumber;
                Cdr[15] = claimData.RecommendedAmount;
                Cdr[16] = claimData.ClientID;
                Cdr[17] = claimData.CreatedBy;
                Cdr[18] = claimData.IsDeleted;


                dtClaimDetail.Rows.Add(Cdr);
            }

            Parameter.Add("ClaimDetailType", dtClaimDetail);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_DeleteUpdateMultiClaimDetails", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ResponseModel>(ds.Tables[0]);
                return finalResult;
            }
            else
            {
                var errorResposne = ConvertDataTabe.CreateListFromTable<ResponseModel>(dterroResponse);
                return errorResposne;
            }
        }

        public async Task<bool> ClaimSelectedRecordsDelete(int userId, int clientID, string selectedRecords)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_DeleteClaimRecords", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", clientID);
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@SelectedRecords", selectedRecords);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }



    }
}