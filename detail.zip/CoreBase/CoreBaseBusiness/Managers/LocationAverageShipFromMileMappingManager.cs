﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.Helpers;
using System.Data;

namespace CoreBaseBusiness.Managers
{

    public class LocationAverageShipFromMileMappingManager : BaseManager<LocationAverageShipFromMileMapping, LocationAverageShipFromMileMappingViewModel>, ILocationAverageShipFromMileMappingManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }


        public LocationAverageShipFromMileMappingManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;
        }

        /// <summary>
        ///User can get Retrieves data from LocationContact by id.
        /// </summary>
        //public override async Task<LocationPreferredMaterialViewModel> GetAsync(int id)
        //{
        //    var module = await _unitOfWork.LocationPreferredMaterialRepository.GetById(id).ConfigureAwait(false);
        //    return this._mapper.Map<LocationPreferredMaterialViewModel>((LocationPreferredMaterial)module);
        //}


        ///// <summary>
        ///// Commodity Add Data.
        ///// </summary>
        //public async override Task<bool> AddAsync(LocationContactViewModel viewModel)
        //{
        //    var module = this._mapper.Map<LocationContact>(viewModel);
        //    var data = this._unitOfWork.LocationContactRepository.AddAsync(module);

        //    var finalResult = this._unitOfWork.Save();

        //    viewModel.Id = finalResult ? module.Id : 0;

        //    return await Task.FromResult<bool>(finalResult);
        //}


        /// <summary>
        ///  Retrieves  All data from LocationContact.
        /// </summary>
        public async override Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> ListAsync(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<LocationAverageShipFromMileMapping, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.LocationAverageShipFromMileMappingRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<LocationAverageShipFromMileMappingViewModel>>(module);
        }

        /// <summary>
        /// LocationContact Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            var module = this._mapper.Map<LocationAverageShipFromMileMapping>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            
            var data = this._unitOfWork.LocationAverageShipFromMileMappingRepository.AddAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for LocationContact Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            //if (viewModel.PageAction == Constants.PageActionType.Location)
            //{
                var module = this._mapper.Map<LocationAverageShipFromMileMapping>(viewModel);
                module.IsDeleted = false;
                module.UpdateDateTimeServer = DateTime.Now;
                module.CreateDateTimeServer = DateTime.Now;
                
                var data = this._unitOfWork.LocationAverageShipFromMileMappingRepository.UpdateAsync(module);
                this._unitOfWork.Save();
                return await Task.FromResult<bool>(data.Result);
            //}
            //else
            //{
            //    return false;
            //}
        }

        /// <summary>
        ///  Retrieves Count Of All data from LocationContact.
        /// </summary>
        public async override Task<int> CountAsync(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            Expression<Func<LocationAverageShipFromMileMapping, bool>> condition = (c => !c.IsDeleted);


           
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.LocationAverageShipFromMileMappingRepository.CountAsync(condition);
        }

        /// <summary>
        /// Get All List for LocationContact Data List
        /// </summary>
        public async override Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> RangeAsync(int recordCount, LocationAverageShipFromMileMappingViewModel viewModel)
        {
            Expression<Func<LocationAverageShipFromMileMapping, bool>> condition = c => c.IsDeleted == false && (c.ClientId == viewModel.ClientID || viewModel.ClientID == 0 || viewModel.ClientID == null);
            var module = await this._unitOfWork.LocationAverageShipFromMileMappingRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationAverageShipFromMileMappingViewModel>>(module);
            return mappedData;
        }


        /// <summary>
        /// Get All List for LocationShippingMiles Data List
        /// </summary>
        public async Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> RangeAsyncMilesList(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (viewModel != null)
            {
                parameters.Add("toLocationId", viewModel.ShipToLocationId);

            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetShipfromLocationList", parameters);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationAverageShipFromMileMappingViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationAverageShipFromMileMappingViewModel>>(finalResult);
            }

            return null;
        }


        public async Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> GetDistanceAsync(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (viewModel != null)
            {
                parameters.Add("fromLocationId", viewModel.ShipFromLocationId);
                parameters.Add("fromCountry", viewModel.FromCountry);
                parameters.Add("fromState", viewModel.FromState);
                parameters.Add("fromCityCode", viewModel.FromCityCode);
                parameters.Add("toLocationId", viewModel.ShipToLocationId);
                parameters.Add("toCountry", viewModel.ToCountry);
                parameters.Add("toState", viewModel.ToState);
                parameters.Add("toCityCode", viewModel.ToCityCode);

            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetDistance", parameters);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationAverageShipFromMileMappingViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationAverageShipFromMileMappingViewModel>>(finalResult);
            }

            return null;
        }

        /// <summary>
        /// User can get list by locatinId.
        /// </summary>
        public async Task<IEnumerable<LocationAverageShipFromMileMappingViewModel>> GetList(int id)
        {
            //Expression<Func<LocationAverageShipFromMileMapping, bool>> condition = (c => c.IsDeleted == false && c.Id == id);
            //var module = await this._unitOfWork.LocationAverageShipFromMileMappingRepository.GetList(condition);
            //var mappedData = this._mapper.Map<IEnumerable<LocationAverageShipFromMileMappingViewModel>>(module);
            //return mappedData;

            Dictionary<string, object> parameters = new Dictionary<string, object>();

            
                parameters.Add("Id", id);

            
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetShipfromLocationById", parameters);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationAverageShipFromMileMappingViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationAverageShipFromMileMappingViewModel>>(finalResult);
            }

            return null;
        }





        /// <summary>
        ///  Deletes record from LocationContact id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.LocationAverageShipFromMileMappingRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        //public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel)
        //{
        //    long locationTypeId = await this.GetLocationTypedId(viewModel.LocationTypeCode);

        //    Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationTypeId == locationTypeId && c.ClientId == viewModel.ClientId && c.IsActive == true;
        //    var module = await this._unitOfWork.LocationRepository.GetList(condition);
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        //    return mappedData;

        //}


        /// <summary>
        /// Softly remove UserAddress from the system.
        /// </summary>
        /// <param name="id">Existing UserAddress ID</param>
        /// <param name="deletedBy">Name of user who wants to remove UserAddress from the system.</param>
        /// <returns>on sucees return true and return false on fail</returns>
        public async Task<bool> DeleteAllAsync(LocationAverageShipFromMileMappingViewModel viewModel)
        {
            int flag = 1;
            if (viewModel.SelectedIds.Length > 0)
            {
                string[] selectedIdsList = viewModel.SelectedIds.Split(",");
                //var values = await this._unitOfWork.LocationAddressRepository.GetByIds(ids).ConfigureAwait(false);

                var values = await this._unitOfWork.LocationAverageShipFromMileMappingRepository.GetByIds(viewModel.SelectedIds);
                    foreach (var item in values)
                    {
                        //item.UpdatedBy = viewModel.DeletedBy;
                        //item.IsDeleted = true;
                        //item.IsActive = false;
                        var data = this._unitOfWork.LocationAverageShipFromMileMappingRepository.DeleteAsync(item.Id, viewModel.UpdatedBy);
                        flag++;
                    }
                
                var finalResult = this._unitOfWork.Save();
                return await Task.FromResult(finalResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(false).ConfigureAwait(false);
            }
        }

    }
}


