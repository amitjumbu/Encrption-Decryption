﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;

namespace CoreBaseBusiness.Managers
{

    public class ContractionsPer10MinManager : BaseManager<MeasurementContractionsMeasurementValue, ContractionsPer10MinViewModel>, IContractionsPer10MinManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public ContractionsPer10MinManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<ContractionsPer10MinViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.ContractionsPer10MinRepository.GetAsync(id);
            var viewModel = this._mapper.Map<ContractionsPer10MinViewModel>(module);
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<ContractionsPer10MinViewModel>> ListAsync(ContractionsPer10MinViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementContractionsMeasurementValue, bool>> condition = (c => !c.IsDeleted);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            var module = await this._unitOfWork.ContractionsPer10MinRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<ContractionsPer10MinViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_ContractionsMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(ContractionsPer10MinViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementContractionsMeasurementValue>(viewModel);
            var data = this._unitOfWork.ContractionsPer10MinRepository.AddAsync(module);



            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(ContractionsPer10MinViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementContractionsMeasurementValue>(viewModel);
            var data = this._unitOfWork.ContractionsPer10MinRepository.UpdateAsync(module);



            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(ContractionsPer10MinViewModel viewModel)
        {
            Expression<Func<MeasurementContractionsMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

           
            return await this._unitOfWork.ContractionsPer10MinRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_ContractionsMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<ContractionsPer10MinViewModel>> RangeAsync(int recordCount, ContractionsPer10MinViewModel viewModel)
        {
            Expression<Func<MeasurementContractionsMeasurementValue, bool>> condition;

            if (viewModel.IsAll)
            {
                condition = (c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId && c.StagesId == viewModel.StagesId);
            }
            else
            {
                condition = (c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId && c.StagesId == viewModel.StagesId);
            }

            //if (!viewModel.IsVisible)
            //{
            //    condition = c => c.IsDeleted == false && c.IsVisible == true && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0);
            //}
            //else
            //{
            //    condition = c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0);
            //}

            var module = await this._unitOfWork.ContractionsPer10MinRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var ContractionsPer10MinModel = this._mapper.Map<IEnumerable<ContractionsPer10MinViewModel>>(module);
            //foreach (var ContractionsPer10MinData in ContractionsPer10MinModel.ToList())
            //{
            //    var comments = await this._unitOfWork.ContractionsPer10MinRepository.ListAsync(x => x.IsDeleted == false && x.ClientId == ContractionsPer10MinData.ClientId && x.Id == ContractionsPer10MinData.Id);
            //    if (comments != null && comments.Any())
            //    {
            //        ContractionsPer10MinData.Comments = this._mapper.Map<ICollection<ContractionsPer10MinCommentViewModel>>(comments);
            //    }
            //}

            return ContractionsPer10MinModel;
        }


        /// <summary>
        ///  Deletes record Measurement_ContractionsMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.ContractionsPer10MinRepository.DeleteAsync(id, deletedBy);


            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


