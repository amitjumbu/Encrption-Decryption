﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{

    public class AcetonManager : BaseManager<MeasurementUrineAcetoneMeasurementValue, AcetonViewModel>, IAcetonManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public AcetonManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary> 
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<AcetonViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.AcetonRepository.GetAsync(id);

            var comments = await this._unitOfWork.AcetonRepository.ListAsync(x => x.IsDeleted == false && x.ClientId == module.ClientId && x.Id == module.Id);


            var viewModel = this._mapper.Map<AcetonViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_UrineAcetoneMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<AcetonViewModel>> ListAsync(AcetonViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementUrineAcetoneMeasurementValue, bool>> condition = (c => !c.IsDeleted);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }

            var module = await this._unitOfWork.AcetonRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<AcetonViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_UrineAcetoneMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(AcetonViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementUrineAcetoneMeasurementValue>(viewModel);
            var data = this._unitOfWork.AcetonRepository.AddAsync(module);

            

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_UrineAcetoneMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(AcetonViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementUrineAcetoneMeasurementValue>(viewModel);
            var data = this._unitOfWork.AcetonRepository.UpdateAsync(module);

            

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_UrineAcetoneMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(AcetonViewModel viewModel)
        {
            Expression<Func<MeasurementUrineAcetoneMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.AcetonRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_UrineAcetoneMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<AcetonViewModel>> RangeAsync(int recordCount, AcetonViewModel viewModel)
        {
            Expression<Func<MeasurementUrineAcetoneMeasurementValue, bool>> condition = (c => c.IsDeleted == false);// && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            var module = await this._unitOfWork.AcetonRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var AcetonModel = this._mapper.Map<IEnumerable<AcetonViewModel>>(module);
            

            return AcetonModel;
        }


        /// <summary>
        ///  Deletes record Measurement_UrineAcetoneMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.AcetonRepository.DeleteAsync(id, deletedBy);

            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


