﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Dapper;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class ContractManager : BaseManager<CustomerContract, CustomerContractViewModel>, IContractManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public ContractManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            unitOfWork.ConnectionString = this.ConnectionString;
        }



        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async override Task<IEnumerable<CustomerContractViewModel>> ListAsync(CustomerContractViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<CustomerContract, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientId || viewModel.ClientId == null || viewModel.ClientId == 0);

            var module = await this.unitOfWork.CustomerContractRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CustomerContractViewModel>>(module);
        }


        public async Task<IEnumerable<object>> AddContractAsync(List<ContractDetailViewModel> ViewModels)
        {
            var updatedViewModel = new List<object>();

            foreach (ContractDetailViewModel ViewModel in ViewModels)
            {
                ViewModel.MaterialId = ViewModel.MaterialId == 0 ? null : ViewModel.MaterialId;
                ViewModel.ChargeId = ViewModel.ChargeId == 0 ? null : ViewModel.ChargeId;
                ViewModel.CommodityId = ViewModel.CommodityId == 0 ? null : ViewModel.CommodityId;
                ViewModel.SalesTaxClassId = ViewModel.SalesTaxClassId == 0 ? null : ViewModel.SalesTaxClassId;
                ViewModel.PriceIncreaseMethodTypeId = ViewModel.PriceIncreaseMethodTypeId == 0 ? null : ViewModel.PriceIncreaseMethodTypeId;
                if (ViewModel.ContractTypeId == 3 || ViewModel.ContractTypeId == 4 || ViewModel.ContractTypeId == 5)
                {
                    var contractDetail = this._mapper.Map<CustomerContractDetail>(ViewModel);

                    var response = await this.unitOfWork.CustomerContractDetailRepository.AddAsync(contractDetail);
                    if (response)
                    {
                        this.unitOfWork.Save();
                        updatedViewModel.Add(contractDetail);
                    }
                }
                else
                {
                    var contractDetail = this._mapper.Map<BusinessPartnerContractDetail>(ViewModel);

                    var response = await this.unitOfWork.BusinessPartnerContractDetailRepository.AddAsync(contractDetail);
                    if (response)
                    {
                        this.unitOfWork.Save();
                        updatedViewModel.Add(contractDetail);
                    }
                }

            }

            return updatedViewModel;
        }

        public async Task<bool> CheckExist(CustomerContractViewModel viewModel)
        {
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                Expression<Func<CustomerContract, bool>> condition = c => (!c.IsDeleted && c.LocationId == viewModel.LocationId && c.ContractTypeId == viewModel.ContractTypeId);
                var data = await this.unitOfWork.CustomerContractRepository.ListAsync(condition).ConfigureAwait(false);
                // var module = this._mapper.Map<IEnumerable<CustomerContractViewModel>>(viewModel);
                if (data.Count() == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }

            }
            else
            {

                Expression<Func<BusinessPartnerContract, bool>> condition = c => (!c.IsDeleted && c.LocationId == viewModel.LocationId && c.ContractTypeId == viewModel.ContractTypeId);
                var data = await this.unitOfWork.BusinessPartnerContractRepository.ListAsync(condition).ConfigureAwait(false);
                //var module = this._mapper.Map< IEnumerable<BusinessPartnerContract>>(viewModel);
                if (data.Count() == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public async Task<object> AddAsyncData(CustomerContractViewModel viewModel)
        {
            var dataReturn = new object();
            viewModel.Id = 0;
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                var module = this._mapper.Map<CustomerContract>(viewModel);
                var data = this.unitOfWork.CustomerContractRepository.AddAsync(module);
                this.unitOfWork.Save();
                if (module.ContractVersion > 0)
                {
                    using (IDbConnection con = new SqlConnection(this.ConnectionString))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        DynamicParameters parameter = new DynamicParameters();
                        parameter.Add("@ContractId", module.ParentId);
                        parameter.Add("@ContractTypeID", module.ContractTypeId);
                        parameter.Add("@UpdatedBy", module.CreatedBy);
                        var usersViewModels = con.Query<object>("SPO_UpdateContractDetails", parameter, commandType: CommandType.StoredProcedure).ToList();

                        con.Close();
                        // return usersViewModels;
                    }
                }
                return await Task.FromResult<object>(module);
            }
            else
            {
                var module = this._mapper.Map<BusinessPartnerContract>(viewModel);
                var data = this.unitOfWork.BusinessPartnerContractRepository.AddAsync(module);
                this.unitOfWork.Save();

                if (module.ContractVersion > 0)
                {
                    using (IDbConnection con = new SqlConnection(this.ConnectionString))
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        DynamicParameters parameter = new DynamicParameters();
                        parameter.Add("@ContractId", module.ParentId);
                        parameter.Add("@ContractTypeID", module.ContractTypeId);
                        parameter.Add("@UpdatedBy", module.CreatedBy);
                        var usersViewModels = con.Query<object>("SPO_UpdateContractDetails", parameter, commandType: CommandType.StoredProcedure).ToList();

                        con.Close();
                    }

                }

                // dataReturn = module;
                return await Task.FromResult<object>(module);
            }

            // var finalResult = this.unitOfWork.Save();

            //viewModel.Id = finalResult ? module.Id : 0;

            // return await Task.FromResult<object>(dataReturn);
        }

        public async override Task<bool> UpdateAsync(CustomerContractViewModel viewModel)
        {
            return false;
        }
        /// <summary>
        /// Contract Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(CustomerContractViewModel viewModel)
        {
            return false;
        }

        /// <summary>
        ///  Updates existing record for Contract Details.
        /// </summary>
        public async Task<object> UpdateContractAsync(CustomerContractViewModel viewModel)
        {
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                var module = this._mapper.Map<CustomerContract>(viewModel);
                var data = this.unitOfWork.CustomerContractRepository.UpdateAsync(module);
                this.unitOfWork.Save();
                return await Task.FromResult<object>(module);
            }
            else
            {
                var module = this._mapper.Map<BusinessPartnerContract>(viewModel);
                var data = this.unitOfWork.BusinessPartnerContractRepository.UpdateAsync(module);
                this.unitOfWork.Save();
                return await Task.FromResult<object>(module);
            }

        }

        /// <summary>
        ///  Retrieves Count Of All data from Commodity.
        /// </summary>
        public async override Task<int> CountAsync(CustomerContractViewModel viewModel)
        {
            Expression<Func<Commodity, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
            {
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            }
            else
            {
                condition = condition.And(c => c.IsDeleted == false);
            }

            return await this.unitOfWork.CommodityRepository.CountAsync(condition);
        }

        /// <summary>
        ///Get All List for Commodity Data List
        /// </summary>
        public async override Task<IEnumerable<CustomerContractViewModel>> RangeAsync(int recordCount, CustomerContractViewModel viewModel)
        {
            if (viewModel.ScreenAction == Constants.Identifire.BusinessPartner)
            {
                Expression<Func<BusinessPartnerContract, bool>> condition = (c => c.IsDeleted == false && c.SetupComplete == true && (c.LocationId == viewModel.LocationId || viewModel.LocationId == 0 || viewModel.LocationId == null));
                var module = await this.unitOfWork.BusinessPartnerContractRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
                var mappedData = this._mapper.Map<IEnumerable<CustomerContractViewModel>>(module);
                return mappedData;
            }
            else
            {
                Expression<Func<CustomerContract, bool>> condition = (c => c.IsDeleted == false && (c.LocationId == viewModel.LocationId || viewModel.LocationId == 0 || viewModel.LocationId == null));
                var module = await this.unitOfWork.CustomerContractRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
                var mappedData = this._mapper.Map<IEnumerable<CustomerContractViewModel>>(module);
                return mappedData;
            }


        }
        /// <summary>
        ///  Deletes record from location id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.CustomerContractRepository.DeleteAsync(id, deletedBy);
            this.unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<IEnumerable<ContractDetailViewModel>> GetContractDetailsByIds(CustomerContractViewModel viewModel)
        {
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                Expression<Func<CustomerContractDetail, bool>> condition = (c => c.ClientId == viewModel.ClientId && c.CustomerContractId == viewModel.ParentId && c.IsDeleted == false);
                var module = await this.unitOfWork.CustomerContractDetailRepository.ListAsync(condition).ConfigureAwait(false);
                var mappedData = this._mapper.Map<IEnumerable<ContractDetailViewModel>>(module);
                return mappedData;
            }
            else
            {
                Expression<Func<BusinessPartnerContractDetail, bool>> condition = (c => c.ClientId == viewModel.ClientId && c.BusinessPartnerContractId == viewModel.ParentId && c.IsDeleted == false);
                var module = await this.unitOfWork.BusinessPartnerContractDetailRepository.ListAsync(condition).ConfigureAwait(false);
                var mappedData = this._mapper.Map<IEnumerable<ContractDetailViewModel>>(module);
                return mappedData;
            }

        }

        public async Task<object> GetByIdContract(ContractViewModel viewModel)
        {

            return await this.GetContractFullDetailsByID(viewModel);
            //if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            //{
            //    Expression<Func<CustomerContract, bool>> condition = (c => c.ClientId == viewModel.ClientID && c.Id == viewModel.ID && c.IsDeleted == false);
            //    var module = await this.unitOfWork.CustomerContractRepository.ListAsync(condition).ConfigureAwait(false);
            //    var mappedData = this._mapper.Map<CustomerContractViewModel>(module.FirstOrDefault());
            //    return mappedData;
            //}
            //else
            //{
            //    Expression<Func<BusinessPartnerContract, bool>> condition = (c => c.ClientId == viewModel.ClientID && c.Id == viewModel.ID && c.IsDeleted == false);
            //    var module = await this.unitOfWork.BusinessPartnerContractRepository.ListAsync(condition).ConfigureAwait(false);
            //    var mappedData = this._mapper.Map<BusinessPartnerContractViewModel>(module.FirstOrDefault());
            //    return mappedData;
            //}
        }

        public async Task<object> GetContractFullDetailsByID(ContractViewModel viewModel)
        {
            CustomerContractViewModel customerContractViewModel = new CustomerContractViewModel();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ContractID", viewModel.ID);
            parameters.Add("ContractTypeID", viewModel.ContractTypeId);
            parameters.Add("ClientID", viewModel.ClientID);

            var result = this.unitOfWork.ExecuteProcedure("SPO_GetContractFullData", parameters);

            if (result != null && result.Tables.Count > 2)
            {
                var listContract = ConvertDataTabe.CreateListFromTable<CustomerContractViewModel>(result.Tables[0]);

                if (listContract.Any())
                {
                    customerContractViewModel = listContract.FirstOrDefault();
                    customerContractViewModel.lineItems = ConvertDataTabe.CreateListFromTable<ContractDetailsListItemViewModel>(result.Tables[1]);
                    customerContractViewModel.contractCharacterstics = ConvertDataTabe.CreateListFromTable<ContractDataCharacteriStics>(result.Tables[2]);
                }
            }

            return customerContractViewModel;
        }


        public async Task<object> GetContractDetails(CustomerContractViewModel viewModel)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientId);
                parameters.Add("ContractTypeId", viewModel.ContractTypeId);
                parameters.Add("ContractId", viewModel.ParentId);
            }
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetContractDetails", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ContractShowDetail>(ds.Tables[0]);
                return await Task.FromResult<object>(finalResult);
            }
            return null;
        }


        public async Task<bool> ContractApprove(ContractViewModel viewModel)
        {
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                CustomerContract models = await this.unitOfWork.CustomerContractRepository.GetById(Convert.ToInt32(viewModel.ID));
                models.SetupComplete = true;
                models.SetupCompleteDateTime = DateTime.UtcNow;
                var result = this.unitOfWork.Save();
                return result;
            }
            else
            {
                BusinessPartnerContract models = await this.unitOfWork.BusinessPartnerContractRepository.GetById(Convert.ToInt32(viewModel.ID));
                models.SetupComplete = true;
                models.SetupCompleteDateTime = DateTime.UtcNow;
                var result = this.unitOfWork.Save();
                return result;
            }
        }

        public async Task<IEnumerable<ContractViewModel>> GetAllContract(ContractViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (requestCommonViewModel != null && string.IsNullOrWhiteSpace(requestCommonViewModel.FilterOn))
            {
                parameters.Add("ClientID", requestCommonViewModel.ClientID);
                parameters.Add("PageNumber", requestCommonViewModel.PageNo);
                parameters.Add("PageSize", requestCommonViewModel.PageSize);
                parameters.Add("SortColumn", requestCommonViewModel.SortColumn);
                parameters.Add("SortOrder", requestCommonViewModel.SortOrder);
                // parameters.Add("LocationId", requestCommonViewModel.LocationID);

            }
            else
            {
                parameters.Add("ClientID", requestCommonViewModel.ClientID);
                parameters.Add("SortOrder", requestCommonViewModel.SortOrder);
            }
            DataTable dt = new DataTable();
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetContract", parameters);
            dt = ds.Tables[0];
            if (requestCommonViewModel.LocationID > 0)
            {
                ds.Tables[0].DefaultView.RowFilter = "LocationID=" + requestCommonViewModel.LocationID;
                dt = (ds.Tables[0].DefaultView).ToTable();
            }
            if (dt != null && dt.Rows.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ContractViewModel>(dt);
                var result = FilterResult<ContractViewModel>.GetFilteredResult(finalResult, requestCommonViewModel.FilterOn, requestCommonViewModel.PageSize, requestCommonViewModel);
                return await Task.FromResult<IEnumerable<ContractViewModel>>(result);
            }

            return null;
        }
        public async Task<IEnumerable<object>> GetCharacteristic()
        {
            using (IDbConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@EntityName", "Contract");
                var usersViewModels = con.Query<object>("SPO_GetEntityPropertyDetails", parameter, commandType: CommandType.StoredProcedure).ToList();

                con.Close();
                return usersViewModels;
            }
        }




        public async Task<IEnumerable<DefiningCharacteristicsViewModel>> GetCharacteristicsData(ContractViewModel viewModel)
        {
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                Expression<Func<CustomerContractPropertyDetail, bool>> condition = (c => c.CustomerContractId == viewModel.ID && c.IsDeleted == false);
                var module = await this.unitOfWork.CustomerContractPropertyDetailRepository.ListAsync(condition).ConfigureAwait(false);
                var mappedData = this._mapper.Map<IEnumerable<DefiningCharacteristicsViewModel>>(module);
                return mappedData;
            }
            else
            {
                Expression<Func<BusinessPartnerContractPropertyDetail, bool>> condition = (c => c.BusinessPartnerContractId == viewModel.ID && c.IsDeleted == false);
                var module = await this.unitOfWork.BusinessPartnerContractPropertyDetailRepository.ListAsync(condition).ConfigureAwait(false);
                var mappedData = this._mapper.Map<IEnumerable<DefiningCharacteristicsViewModel>>(module);
                return mappedData;

            }
        }

        public async Task<IEnumerable<object>> AddCharacteristicsAsyncData(List<DefiningCharacteristicsViewModel> ViewModels)
        {
            var updatedViewModel = new List<object>();




            foreach (DefiningCharacteristicsViewModel ViewModel in ViewModels)
            {
                if (ViewModel.ContractTypeId == 3 || ViewModel.ContractTypeId == 4 || ViewModel.ContractTypeId == 5)
                {
                    var PropertyDetail = this._mapper.Map<CustomerContractPropertyDetail>(ViewModel);


                    var response = await this.unitOfWork.CustomerContractPropertyDetailRepository.AddAsync(PropertyDetail);
                    if (response)
                    {
                        this.unitOfWork.Save();
                        updatedViewModel.Add(PropertyDetail);
                    }
                }
                else
                {
                    var PropertyDetail = this._mapper.Map<BusinessPartnerContractPropertyDetail>(ViewModel);

                    var response = await this.unitOfWork.BusinessPartnerContractPropertyDetailRepository.AddAsync(PropertyDetail);
                    if (response)
                    {
                        this.unitOfWork.Save();
                        updatedViewModel.Add(PropertyDetail);
                    }
                }

            }

            return updatedViewModel;
        }

        public async Task<bool> DeleteDefiningCharacteristics(List<DefiningCharacteristicsViewModel> ViewModels)
        {

            foreach (DefiningCharacteristicsViewModel ViewModel in ViewModels)
            {
                if (ViewModel.ContractTypeId == 3 || ViewModel.ContractTypeId == 4 || ViewModel.ContractTypeId == 5)
                {
                    List<CustomerContractPropertyDetail> models = this.unitOfWork.CustomerContractPropertyDetailRepository.GetById(Convert.ToString(ViewModel.Id)).Result.ToList();
                    foreach (CustomerContractPropertyDetail model in models)
                    {
                        model.IsDeleted = true;
                    }

                    var result = this.unitOfWork.Save();
                }
                else
                {
                    List<BusinessPartnerContractPropertyDetail> models = this.unitOfWork.BusinessPartnerContractPropertyDetailRepository.GetById(Convert.ToString(ViewModel.Id)).Result.ToList();
                    foreach (BusinessPartnerContractPropertyDetail model in models)
                    {
                        model.IsDeleted = true;
                    }

                    var result = this.unitOfWork.Save();
                }
            }

            return true;
        }

        public async Task<bool> DeleteContracts(List<ContractViewModel> ViewModels)
        {
            foreach (ContractViewModel ViewModel in ViewModels)
            {
                if (ViewModel.ContractTypeId == 3 || ViewModel.ContractTypeId == 4 || ViewModel.ContractTypeId == 5)
                {
                    if (ViewModel.ContractApproved.ToLower() != "yes")
                    {
                        CustomerContract models = this.unitOfWork.CustomerContractRepository.GetById(Convert.ToInt32(ViewModel.ID)).Result;
                        models.IsDeleted = true;
                        var result = this.unitOfWork.Save();
                    }
                }
                else
                {
                    if (ViewModel.ContractApproved.ToLower() != "yes")
                    {
                        BusinessPartnerContract models = this.unitOfWork.BusinessPartnerContractRepository.GetById(Convert.ToInt32(ViewModel.ID)).Result;
                        models.IsDeleted = true;
                        var result = this.unitOfWork.Save();
                    }

                }
            }

            return true;
        }

        public async Task<bool> DeleteContractDetails(ContractDetailViewModel viewModel)
        {
            if (viewModel.ContractTypeId == 3 || viewModel.ContractTypeId == 4 || viewModel.ContractTypeId == 5)
            {
                CustomerContractDetail modal = this.unitOfWork.CustomerContractDetailRepository.GetById(Convert.ToInt32(viewModel.Id)).Result;
                modal.IsDeleted = true;
                return this.unitOfWork.Save();
            }
            else
            {
                BusinessPartnerContractDetail modal = this.unitOfWork.BusinessPartnerContractDetailRepository.GetById(Convert.ToInt32(viewModel.Id)).Result;
                modal.IsDeleted = true;
                return this.unitOfWork.Save();
            }
        }
        public async Task<bool> ActivateContracts(List<ContractViewModel> ViewModels)
        {
            foreach (ContractViewModel ViewModel in ViewModels)
            {
                if (ViewModel.ContractTypeId == 3 || ViewModel.ContractTypeId == 4 || ViewModel.ContractTypeId == 5)
                {
                    CustomerContract models = this.unitOfWork.CustomerContractRepository.GetById(Convert.ToInt32(ViewModel.ID)).Result;
                    models.IsActive = 1;
                    var result = this.unitOfWork.Save();
                }
                else
                {
                    BusinessPartnerContract models = this.unitOfWork.BusinessPartnerContractRepository.GetById(Convert.ToInt32(ViewModel.ID)).Result;
                    models.IsActive = 1;
                    var result = this.unitOfWork.Save();
                }
            }

            return true;
        }
        public async Task<bool> InactiveContracts(List<ContractViewModel> ViewModels)
        {
            foreach (ContractViewModel ViewModel in ViewModels)
            {
                if (ViewModel.ContractTypeId == 3 || ViewModel.ContractTypeId == 4 || ViewModel.ContractTypeId == 5)
                {
                    CustomerContract models = this.unitOfWork.CustomerContractRepository.GetById(Convert.ToInt32(ViewModel.ID)).Result;
                    models.IsActive = 0;
                    var result = this.unitOfWork.Save();
                }
                else
                {
                    BusinessPartnerContract models = this.unitOfWork.BusinessPartnerContractRepository.GetById(Convert.ToInt32(ViewModel.ID)).Result;
                    models.IsActive = 0;
                    var result = this.unitOfWork.Save();
                }
            }

            return true;
        }
        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> ID = ids.ConvertAll(long.Parse);

                List<CustomerContract> contracts = this.unitOfWork.CustomerContractRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();

                foreach (CustomerContract contract in contracts)
                {
                    contract.IsDeleted = true;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }

        public async Task<bool> SendApprovalNotification(CustomerContractViewModel viewModel)
        {
            using (IDbConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ContractTypeId", viewModel.ContractTypeId);
                parameter.Add("@ClientId", viewModel.ClientId);
                parameter.Add("@EntityKeyId", viewModel.Id);
                var usersViewModels = con.Query<object>("SPO_InsertCalendarEntryContract", parameter, commandType: CommandType.StoredProcedure).ToList();

                con.Close();
                return true;
            }
        }
        public async Task<IEnumerable<object>> GetLocationsIds(CustomerContractViewModel viewModel)
        {
            using (IDbConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ContractTypeId", viewModel.ContractTypeId);
                parameter.Add("@ClientId", viewModel.ClientId);
                var usersViewModels = con.Query<object>("SPO_GetContractLocationIds", parameter, commandType: CommandType.StoredProcedure).ToList();

                con.Close();
                return usersViewModels;
            }
        }
        #region Get Customer By Contract Type
        public async Task<object> GetCustomerByContactType(CustomerContractViewModel viewModel)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientId);
                parameters.Add("ContractTypeId", viewModel.ContractTypeId);
            }
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetCustomerByContractType", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CustomerContractViewModel>(ds.Tables[0]);
                return await Task.FromResult<object>(finalResult);
            }
            return null;
        }
        #endregion

        #region Get Business Partner By Contract Type
        public async Task<object> GetBusinessPartnerOnContactType(BusinessPartnerContractViewModel viewModel)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientId);
                parameters.Add("ContractTypeId", viewModel.ContractTypeId);
            }
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetBusinessPartnerByContractType", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CustomerContractViewModel>(ds.Tables[0]);
                return await Task.FromResult<object>(finalResult);
            }
            return null;
        }
        #endregion

        public async Task<IEnumerable<object>> GetChargesAndCharacteristicsFrom(CustomerContractViewModel viewModel)
        {
            using (IDbConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ContractTypeId", viewModel.ContractTypeId);
                parameter.Add("@ContractId", viewModel.Id);
                parameter.Add("@LocationId", viewModel.LocationId);
                var usersViewModels = con.Query<object>("SPO_GetChargesAndCharacteristicsFrom", parameter, commandType: CommandType.StoredProcedure).ToList();

                con.Close();
                return usersViewModels;
            }
        }


        private bool IsContractModified(CustomerContractViewModel initialCustomerContractViewModel, CustomerContractViewModel finalCustomerContractViewModel)
        {
            bool isContractModified = false;

            if (initialCustomerContractViewModel.contractCharacterstics.Count != finalCustomerContractViewModel.contractCharacterstics.Count
             || initialCustomerContractViewModel.lineItems.Count != finalCustomerContractViewModel.lineItems.Count)
            {
                return true;
            }

            if (initialCustomerContractViewModel.OrderComment != finalCustomerContractViewModel.OrderComment
                || initialCustomerContractViewModel.LoadingComment != finalCustomerContractViewModel.LoadingComment
                || initialCustomerContractViewModel.TransportationComment != finalCustomerContractViewModel.TransportationComment
                || initialCustomerContractViewModel.ContractComment != finalCustomerContractViewModel.ContractComment
                )
            {
                return true;
            }

            if (initialCustomerContractViewModel.ContractEndAlertDays.Value != finalCustomerContractViewModel.ContractEndAlertDays.Value)
            {
                return true;
            }

            if (initialCustomerContractViewModel.TermEndDateStr != finalCustomerContractViewModel.TermEndDateStr || initialCustomerContractViewModel.TermStartDateStr != finalCustomerContractViewModel.TermStartDateStr)
            {
                return true;
            }



            return isContractModified;
        }


        public async Task<object> SaveAndUpdateContract(CustomerContractViewModel initialCustomerContractViewModel, CustomerContractViewModel finalCustomerContractViewModel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();

            if (initialCustomerContractViewModel != null && initialCustomerContractViewModel.Id > 0 && finalCustomerContractViewModel != null && finalCustomerContractViewModel.Id > 0 && IsContractModified(initialCustomerContractViewModel, finalCustomerContractViewModel))
            {
                parameter.Add("IsNewVersion", 1);
                parameter.Add("OldVersionID", initialCustomerContractViewModel.Id);
            }
            else if (initialCustomerContractViewModel == null && finalCustomerContractViewModel.Id == 0 && finalCustomerContractViewModel != null && finalCustomerContractViewModel.lineItems.Count() > 0)
            {
                parameter.Add("IsNewVersion", 1);
                parameter.Add("OldVersionID", 0);
            }
            else
            {
                parameter.Add("IsNewVersion", 0);
                parameter.Add("OldVersionID", initialCustomerContractViewModel.Id);
            }

            parameter.Add("ContractTypeID", finalCustomerContractViewModel.ContractTypeId);
            parameter.Add("StartDate", finalCustomerContractViewModel.TermStartDateStr);
            parameter.Add("EndDate", finalCustomerContractViewModel.TermEndDateStr);
            parameter.Add("AlertDays", finalCustomerContractViewModel.ContractEndAlertDays);
            parameter.Add("TransportationComment", finalCustomerContractViewModel.TransportationComment);
            parameter.Add("LoadingComment", finalCustomerContractViewModel.LoadingComment);
            parameter.Add("OrderComment", finalCustomerContractViewModel.OrderComment);
            parameter.Add("ContractComment", finalCustomerContractViewModel.ContractComment);
            parameter.Add("LocationId", finalCustomerContractViewModel.LocationId);
            parameter.Add("ClientID", finalCustomerContractViewModel.ClientId);
            parameter.Add("UpdateBy", finalCustomerContractViewModel.UpdatedBy);
            parameter.Add("CreatedBy", finalCustomerContractViewModel.CreatedBy);
            parameter.Add("UpdateDateTimeBrowser", finalCustomerContractViewModel.UpdateDateTimeBrowser);
            parameter.Add("CreateDateTimeBrowser", finalCustomerContractViewModel.CreateDateTimeBrowser);

            parameter.Add("ContractName", finalCustomerContractViewModel.ContractNumber);
            parameter.Add("SetupComplete", finalCustomerContractViewModel.SetupComplete);
            parameter.Add("SetupCompleteDateTime", finalCustomerContractViewModel.SetupCompleteDateTime);

            if (finalCustomerContractViewModel.lineItems != null && finalCustomerContractViewModel.lineItems.Count > 0)
            {
                parameter.Add("ContractDetail", this.convertContractIntoXML(finalCustomerContractViewModel));
            }

            if (finalCustomerContractViewModel.contractCharacterstics != null && finalCustomerContractViewModel.contractCharacterstics.Count > 0)
            {
                parameter.Add("Characterstics", this.convertConvertCharacterSticIntoXML(finalCustomerContractViewModel.contractCharacterstics));
            }

            DataSet result = this.unitOfWork.ExecuteProcedure("SPO_CreateAndUpdateContract", parameter);

            if (result != null && result.Tables.Count > 0)
            {
                int TotalCount = result.Tables.Count - 1;

                if (Convert.ToInt32(result.Tables[TotalCount].Rows[0]["Status"]) == 1)
                {
                    return new { ContractID = Convert.ToInt32(result.Tables[TotalCount].Rows[0]["ContractID"]), ContractTypeID = Convert.ToInt32(result.Tables[TotalCount].Rows[0]["ContractType"]), ContractVersion = Convert.ToInt32(result.Tables[TotalCount].Rows[0]["ContractVersion"]), status = result.Tables[TotalCount].Rows[0]["ContractOperation"] , ContractNumber = finalCustomerContractViewModel.ContractNumber };
                }
            }

            return new { ContractID = finalCustomerContractViewModel.Id, ContractTypeID = finalCustomerContractViewModel.ContractTypeId, ContractVersion = finalCustomerContractViewModel.ContractVersion, status = "Error" };
        }

        private string convertContractIntoXML(CustomerContractViewModel finalCustomerContractViewModel)
        {
            string contractData = "<ContractData>";

            foreach (ContractDetailsListItemViewModel items in finalCustomerContractViewModel.lineItems)
            {

                contractData = contractData + string.Format(
                    "<LineItems MaterialID=\"{0}\" ChargeID=\"{1}\" CommodityID=\"{2}\" RateTypeID=\"{3}\" Rate=\"{4}\" UOMID=\"{5}\" ChargeUnit=\"{6}\" SalesTaxID=\"{7}\" PriceMethodTypeID=\"{8}\" ShowOnBOL=\"{9}\" AutoAdded=\"{10}\" PalletAdded=\"{11}\" PriceIncreaseMethodID=\"{12}\" StartDate=\"{13}\" EndDate=\"{14}\"></LineItems>",
                                                                        items.MaterialID, items.ChargeID, items.CommodityID, items.RateTypeID, items.Rate, items.UOMID, items.Quantity_per_UOM, items.SalesTaxClassID, items.PriceMethodTypeID, items.ShowOnBOL, items.AutoAdded, items.AddPallet, items.PriceIncreaseMethodTypeID, ConvertDateFormatUI(items.EffectiveStartStr), ConvertDateFormatUI(items.EffectiveEndStr));

            }

            contractData = contractData + "</ContractData>";

            return contractData;
        }

        private string convertConvertCharacterSticIntoXML(List<ContractDataCharacteriStics> finalCustomerContractViewModel)
        {
            string contractData = "<DefineCharacterstic>";

            foreach (ContractDataCharacteriStics items in finalCustomerContractViewModel)
            {

                contractData = contractData + string.Format(
                    "<Data EntityId=\"{0}\" Code=\"{1}\" Value=\"{2}\" UOM=\"{3}\" ></Data>",
                                                                        items.EntityId, items.Code, items.Value, items.UOM);

            }

            contractData = contractData + "</DefineCharacterstic>";

            return contractData;
        }

        private string ConvertDateFormatUI(string dateData)
        {
            var orignalDateFactor = dateData.Split('/', StringSplitOptions.RemoveEmptyEntries);

            return orignalDateFactor[2] + "-" + orignalDateFactor[0] + "-" + orignalDateFactor[1];


        }
    }
}