﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class CommodityTypeManager : BaseManager<CommodityType, CommodityTypeViewModel>, ICommodityTypeManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public CommodityTypeManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public async override Task<bool> AddAsync(CommodityTypeViewModel viewModel)
        {
            var module = this._mapper.Map<CommodityType>(viewModel);
            var data = this.unitOfWork.CommodityTypeRepository.AddAsync(module);

            this.unitOfWork.Save();

            viewModel.ID = data.Result ? module.ID : 0;

            return await Task.FromResult<bool>(data.Result);
        }

        public override async Task<IEnumerable<CommodityTypeViewModel>> ListAsync(CommodityTypeViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<CommodityType, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientID || viewModel.ClientID == null || viewModel.ClientID == 0);

            var module = await this.unitOfWork.CommodityTypeRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CommodityTypeViewModel>>(module);
        }

        public override async Task<bool> UpdateAsync(CommodityTypeViewModel viewModel)
        {
            var module = this._mapper.Map<CommodityType>(viewModel);
            var data = this.unitOfWork.CommodityTypeRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<bool> UpdateAll(IEnumerable<CommodityTypeViewModel> viewModels)
        {
            if (viewModels.Any())
            {
                foreach (CommodityTypeViewModel viewModel in viewModels)
                {
                    var result = await this.unitOfWork.CommodityTypeRepository.UpdateAsync(this._mapper.Map<CommodityType>(viewModel)).ConfigureAwait(false);
                }

                var finalResult = this.unitOfWork.Save();

                return await Task.FromResult<bool>(finalResult).ConfigureAwait(false);

            }
            else
            {
                return await Task.FromResult<bool>(false).ConfigureAwait(false);
            }
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> iD = ids.ConvertAll(long.Parse);

                List<CommodityType> commoditytypes = this.unitOfWork.CommodityTypeRepository.ListAsync(p => iD.Contains(p.ID)).Result.ToList();

                foreach (CommodityType comd in commoditytypes)
                {
                    comd.IsDeleted = true;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }

        public async Task<object> getComTypExist(string ComtypCode)
        {
            var comtypedata = await unitOfWork.CommodityTypeRepository.GetById(ComtypCode); //await this.orha.GetOrganization(users.OrgCode);

            var mappedData = this._mapper.Map<CommodityType>(comtypedata);
            if (mappedData != null)
            {
                return mappedData;
            }
            else
            {
                return false;
            }
            //if (mappedData != null && mappedData.IsDeleted == true)
            //{
            //    return "true,true";
            //}
            //else if (mappedData != null && mappedData.IsDeleted == false)
            //{
            //    return "true,false";
            //}
            //else
            //{
            //    return "false,false";
            //}
        }
    }
}