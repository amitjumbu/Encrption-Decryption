﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
//using CoreBaseData.Models.Entity;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class PartographManager : BaseManager<Partograph, PartographViewModel>, IPartographManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public PartographManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override async Task<bool> AddAsync(PartographViewModel viewModel)
        {
            bool result = false;
            if (viewModel != null)
            {
                var partographData = this._mapper.Map<CoreBaseData.Models.Entity2.Partograph>(viewModel);

                // get Data from patient table(name etc.)
                var patientInformation = await this._unitOfWork.Patientrepository.GetPatientInformation(partographData.PatientId);

                // check data already exist in partograph table then get partographid
                var data = await this._unitOfWork.PartographRepository.GetPatient(partographData.PatientId);
                if (data != null)
                {
                    if (viewModel.PatientRegistration != null)
                    {
                        viewModel.PatientRegistration.PartographID = data.Id;
                        var partographregistration = this._mapper.Map<PatientRegistration>(viewModel.PatientRegistration);
                        var patientRegistrationDetail = this._unitOfWork.PatientRegistrationRepository.GetPatientRegistrationDetailByPartographId(partographregistration.PatientID, partographregistration.PartographID);

                        if (patientRegistrationDetail.Result != null)
                        {
                            PatientRegistration obj = patientRegistrationDetail.Result;

                            partographregistration.Id = obj.Id;

                            var module = this._mapper.Map<PatientRegistration>(partographregistration);
                            var pUpdate = this._unitOfWork.PatientRegistrationRepository.UpdateAsync(module);
                            result =this._unitOfWork.Save();

                        }
                        else
                        {
                            this._unitOfWork.PatientRegistrationRepository.AddAsync(partographregistration);
                            result = this._unitOfWork.Save();
                        }
                    }
                    else
                    {
                        if (partographData != null)
                        {
                            var addParto = this._unitOfWork.PartographRepository.UpdateAsync(partographData);
                           
                            result = this._unitOfWork.Save();
                            long id = partographData.Id;
                            viewModel.ID = id;
                            return await Task.FromResult<bool>(result);
                        }
                    }
                }
                else
                {
                    //if (patientInformation != null)
                    //{
                    //    partographData.Name = patientInformation.FirstName + " " + patientInformation.MiddleName + " " + patientInformation.LastName;
                    //}
                    var addParto = this._unitOfWork.PartographRepository.AddAsync(partographData);

                    result = this._unitOfWork.Save();
                    long id = partographData.Id;

                    if (addParto.Result && viewModel.PatientRegistration != null)
                    {
                        viewModel.PatientRegistration.PartographID = partographData.Id;
                        var partographregistration = this._mapper.Map<PatientRegistration>(viewModel.PatientRegistration);
                        _ = this._unitOfWork.PatientRegistrationRepository.AddAsync(partographregistration);
                        result = this._unitOfWork.Save();
                    }
                    else
                    {
                        viewModel.ID = id;
                        
                    }


                    return await Task.FromResult<bool>(result);
                }
            }

            return await Task.FromResult<bool>(result);
        }

        //public Task<bool> Delete(EntityRecordRemoveRequestPacketForSmallID entityRecordRemoveRequestPacket)
        //{
        //    var commentsList = this._unitOfWork.PartographCommentRepository.GetAllAsync(2000, 1, 2000, x => x.PartographID == entityRecordRemoveRequestPacket.ID).Result;
        //    var mediaList = this._unitOfWork.PartographMediaRepository.GetAllAsync(2000, 1, 2000, x => x.PartographID == entityRecordRemoveRequestPacket.ID).Result;


        //    foreach (var comment in commentsList)
        //    {
        //        this._unitOfWork.PartographCommentRepository.DeleteAsync(comment.ID, entityRecordRemoveRequestPacket.UserName);
        //    }

        //    foreach (var media in mediaList)
        //    {
        //        this._unitOfWork.PartographCommentRepository.DeleteAsync(media.ID, entityRecordRemoveRequestPacket.UserName);
        //    }

        //   var result =  this._unitOfWork.PartographRepository.DeleteAsync(entityRecordRemoveRequestPacket.ID, entityRecordRemoveRequestPacket.UserName);

        //   var transresult =  this._unitOfWork.Save();

        //    return Task.FromResult<bool>(transresult);
        //}

        /// <summary>
        ///  Retrieves  All data from  Package Id wise.

        /// </summary>


        public async Task<IEnumerable<object>> GetAllPatientList(int recordCount, PartographViewModel viewModel)
        {

            Expression<Func<Partograph, bool>> condition = c => c.ClientId == viewModel.ClientID && (c.PatientId == viewModel.PatientID || viewModel.PatientID == 0) && c.IsDeleted == false;

            IEnumerable<object> viewModelList = await this._unitOfWork.PartographRepository.GetAllPatient(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

            return viewModelList;
        }


        public async override Task<IEnumerable<PartographViewModel>> RangeAsync(int recordCount, PartographViewModel viewModel)
        {
           
            Expression<Func<Partograph, bool>> condition = c => c.ClientId == viewModel.ClientID && (c.PatientId == viewModel.PatientID || viewModel.PatientID == 0) && c.IsDeleted == false;

            var module = await this._unitOfWork.PartographRepository.GetAllAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

            Expression<Func<PatientRegistration, bool>> conditionP = c => c.ClientId == viewModel.ClientID && (c.PatientID == viewModel.PatientID || viewModel.PatientID == 0) && c.IsDeleted == false;

            var module1 = await this._unitOfWork.PatientRegistrationRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, conditionP);

            var mappedData = this._mapper.Map<IEnumerable<PatientRegistrationViewModel>>(module1);

            IEnumerable<PatientRegistrationViewModel> ViewlIst = mappedData;

            var partographListData = module.ToList().ConvertAll(p => new PartographViewModel()
            {

                
                ClientID = p.ClientId,
                Code = p.Code,
                CreateDateTimeBrowser =Convert.ToDateTime(p.CreateDateTimeBrowser),
                CreateDateTimeServer = p.CreateDateTimeServer,
                CreatedBy = p.CreatedBy,
                Description = p.Description,
                ID = p.Id,
                IsActive = p.IsActive,
                IsDeleted = p.IsDeleted,
                Name = p.Name,
                PatientID = p.PatientId,
                PatientRegistration = ViewlIst.FirstOrDefault(),
                //Patient = this._mapper.Map<PatientViewModel>(p.Patient),
                ReferenceNo = p.ReferenceNo,
                SourceSystemID = p.SourceSystemId,
                TeamID =0,// p.TeamId,
                UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                UpdateDateTimeServer = p.UpdateDateTimeServer,
                UpdatedBy = p.UpdatedBy


            }).AsEnumerable();

            return partographListData;
            //return this._mapper.Map< IEnumerable<Partograph>,IEnumerable <PartographViewModel>>(module);
        }

        //public Task<PartographViewModel> GetAsync(long id)
        //{
        //    var partographData = this._unitOfWork.PartographRepository.GetAsync(id);

        //    var partographComments = this._unitOfWork.PartographCommentRepository.GetAllAsync(2000, 1, 2000, x => x.PartographID == id);

        //    var partographMedia = this._unitOfWork.PartographMediaRepository.GetAllAsync(2000, 1, 2000, x => x.PartographID == id);

        //    var partographViewModelData = this._mapper.Map<PartographViewModel>(partographData.Result);

        //    if (partographComments.Result.Any())
        //    {
        //        partographViewModelData.PartographComments = this._mapper.Map<ICollection<PartographCommentViewModel>>(partographComments.Result);
        //    }

        //    if (partographMedia.Result.Any())
        //    {
        //        partographViewModelData.PartographMedia= this._mapper.Map<ICollection<PartographMediaViewModel>>(partographMedia.Result);
        //    }

        //    return Task.FromResult<PartographViewModel>(partographViewModelData);

        //}

        public override Task<PartographViewModel> GetAsync(int id)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<PartographViewModel>> ListAsync(PartographViewModel viewModel)
        {
            throw new NotImplementedException();
        }


        public async override Task<int> CountAsync(PartographViewModel viewModel)
        {
            Expression<Func<Partograph, bool>> condition = (c => !c.IsDeleted);          

            return await this._unitOfWork.PartographRepository.CountAsync(condition);
        }

        public override Task<bool> UpdateAsync(PartographViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public Task<bool> Delete(EntityRecordRemoveRequestPacketForSmallID entityRecordRemoveRequestPacket)
        {
            throw new NotImplementedException();
        }

        //public override Task<bool> UpdateAsync(PartographViewModel viewModel)
        //{
        //    bool result = false;
        //    if (viewModel != null)
        //    {
        //        var partographData = this._mapper.Map<Partograph>(viewModel);

        //       var modifiedParto =  this._unitOfWork.PartographRepository.UpdateAsync(partographData);

        //        if (modifiedParto.Result && viewModel.PartographComments != null && viewModel.PartographComments.Count > 0)
        //        {
        //            foreach (PartographCommentViewModel partographCommentViewModel in viewModel.PartographComments)
        //            {
        //                var partographComments = this._mapper.Map<PartographCommentViewModel>(partographCommentViewModel);

        //                //partographComments.Partograph = partographData;

        //                if (partographCommentViewModel.ID == 0)
        //                {
        //                    this._unitOfWork.PartographCommentRepository.AddAsync(partographComments);
        //                }
        //                else
        //                {
        //                    this._unitOfWork.PartographCommentRepository.UpdateAsync(partographComments);
        //                }
        //            }
        //        }

        //        if (modifiedParto.Result &&  viewModel.PartographMedia != null && viewModel.PartographMedia.Count > 0)
        //        {
        //            foreach (PartographMediaViewModel partographMediaViewModel in viewModel.PartographMedia)
        //            {
        //                var partographMedia = this._mapper.Map<PartographMedia>(partographMediaViewModel);

        //               // partographMedia.Partograph = partographData;

        //                if (partographMediaViewModel.ID == 0)
        //                {
        //                    this._unitOfWork.PartographMediaRepository.AddAsync(partographMedia);
        //                }
        //                else
        //                {
        //                    this._unitOfWork.PartographMediaRepository.UpdateAsync(partographMedia);
        //                }
        //            }
        //        }

        //        result = this._unitOfWork.Save();
        //    }

        //    return Task.FromResult<bool>(result);

        //}
    }
}
