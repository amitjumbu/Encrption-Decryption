﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class WebControlTypePossibleValueManager : BaseManager<WebControlTypePossibleValue, WebControlTypePossibleValueViewModel>, IWebControlTypePossibleValueManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public WebControlTypePossibleValueManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<WebControlTypePossibleValueViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.WebControlTypePossibleValueRepository.GetAsync(id);
            var viewModel = this._mapper.Map<WebControlTypePossibleValueViewModel>(module);
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<WebControlTypePossibleValueViewModel>> ListAsync(WebControlTypePossibleValueViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<WebControlTypePossibleValue, bool>> condition = (c => !c.IsDeleted);
            
            var module = await this._unitOfWork.WebControlTypePossibleValueRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<WebControlTypePossibleValueViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_ContractionsMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(WebControlTypePossibleValueViewModel viewModel)
        {
            var module = this._mapper.Map<WebControlTypePossibleValue>(viewModel);
            var data = this._unitOfWork.WebControlTypePossibleValueRepository.AddAsync(module);



            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(WebControlTypePossibleValueViewModel viewModel)
        {
            var module = this._mapper.Map<WebControlTypePossibleValue>(viewModel);
            var data = this._unitOfWork.WebControlTypePossibleValueRepository.UpdateAsync(module);



            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(WebControlTypePossibleValueViewModel viewModel)
        {
            Expression<Func<WebControlTypePossibleValue, bool>> condition = c => !c.IsDeleted;


            return await this._unitOfWork.WebControlTypePossibleValueRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_ContractionsMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<WebControlTypePossibleValueViewModel>> RangeAsync(int recordCount, WebControlTypePossibleValueViewModel viewModel)
        {
            Expression<Func<WebControlTypePossibleValue, bool>> condition = c => !c.IsDeleted && c.WebControlTypeID == viewModel.WebControlTypeID;

            var module = await this._unitOfWork.WebControlTypePossibleValueRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var webcontrolTypeviewmodel = this._mapper.Map<IEnumerable<WebControlTypePossibleValueViewModel>>(module);

            return webcontrolTypeviewmodel;
        }


        /// <summary>
        ///  Deletes record Measurement_ContractionsMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.ContractionsPer10MinCommentRepository.DeleteAsync(id, deletedBy);


            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }

        public async Task<List<DynamicWebcontrolParameterViewModel>> GetDynamicWebcontrolParameterTable(DynamicWebcontrolParameterViewModel chartData)
        {

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_GetDynamicWebcontrolParameter", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StageCode", chartData.StageCode);
                    cmd.Parameters.AddWithValue("@PatientID", chartData.PatientID);
                    cmd.Parameters.AddWithValue("@PartographID", chartData.PartographID);
                    cmd.Parameters.AddWithValue("@Mode", chartData.Mode);
                    cmd.Parameters.AddWithValue("@ClientId", chartData.ClientId);
                    cmd.Parameters.AddWithValue("@WebControlTypeID", chartData.WebControlTypeID);
                    con.Open();
                    sqla = new SqlDataAdapter(cmd);
                    sqla.Fill(ds);
                }
            }
            List<DynamicWebcontrolParameterViewModel> chartHistoryViewModel = new List<DynamicWebcontrolParameterViewModel>();

            chartHistoryViewModel = this.GetDynamicControlList(ds);

            return chartHistoryViewModel;
        }


        public async Task<List<DynamicWebcontrolParameterViewModel>> SaveDynamicParameter(AddDynamicMeasurementParameterViewModel chartData)
        {

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;
            List<DynamicWebcontrolParameterViewModel> chartHistoryViewModel = new List<DynamicWebcontrolParameterViewModel>();
            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_InsertDynamicMeasurementParameter", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StageCode", chartData.StageCode);

                    cmd.Parameters.AddWithValue("@WebControlTypeID", chartData.WebControlTypeID);
                    cmd.Parameters.AddWithValue("@Name", chartData.Name);
                    cmd.Parameters.AddWithValue("@CreatedBy", chartData.CreatedBy);
                    cmd.Parameters.AddWithValue("@SourceSystemID", chartData.SourceSystemId);
                    cmd.Parameters.AddWithValue("@CreateDateTimeBrowser", chartData.UpdateDateTimeBrowser);
                    cmd.Parameters.AddWithValue("@ClientId", chartData.ClientId);
                    cmd.Parameters.AddWithValue("@UOM", chartData.UOM);

                    cmd.Parameters.AddWithValue("@PatientID", chartData.PatientID);
                    cmd.Parameters.AddWithValue("@PartographID", chartData.PartographID);

                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;

                    try
                    {
                        con.Open();

                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);

                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                        chartHistoryViewModel = this.GetDynamicControlList(ds);

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }

                    // con.Open();
                    // sqla = new SqlDataAdapter(cmd);
                    // sqla.Fill(ds);
                }
            }

            return chartHistoryViewModel;
        }

        public async Task<int> FinalSaveDynamicParameter(List<DynamicMeasurementParameterValueViewModel> listData)
        {

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0; DateTime Datetime = DateTime.UtcNow;
            DataTable dt = new DataTable();

            dt.Columns.AddRange(new DataColumn[9] { new DataColumn("StageCode", typeof(string)),
                    new DataColumn("DynamicMeasurementParameterID", typeof(int)),
                    new DataColumn("ParameterValue",typeof(string)),
                    new DataColumn("ParameterValueComment",typeof(string)),
                    new DataColumn("PartographID",typeof(int)),
                    new DataColumn("PatientID",typeof(int)),
                    new DataColumn("ClientID",typeof(int)),
                    new DataColumn("SourceSystemID",typeof(int)),
                    new DataColumn("createdBy",typeof(string))
                  
            });

            foreach (var item in listData)
            {
                Datetime = (DateTime)item.CreateDateTimeBrowser;

                dt.Rows.Add(
                    item.StageCode,
                    item.DynamicMeasurementParameterID,
                    item.ParameterValue,
                    item.ParameterValueComment,
                    item.PartographID,
                    item.PatientID,
                    item.ClientID,
                    item.SourceSystemID,
                    item.createdBy
                    //item.CreateDateTimeBrowser
                    );
            }

                using (SqlConnection con = new SqlConnection(strConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("SPO_InsertDynamicMeasurementParameterValue", con))
                    {

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ItemDataTable", dt);
                    //cmd.Parameters.AddWithValue("@StageCode", item.StageCode);
                    //cmd.Parameters.AddWithValue("@DynamicMeasurementParameterID", item.DynamicMeasurementParameterID);
                    //cmd.Parameters.AddWithValue("@ParameterValue", item.ParameterValue);
                    //cmd.Parameters.AddWithValue("@ParameterValueComment", item.ParameterValueComment);
                    //cmd.Parameters.AddWithValue("@PartographID", item.PartographID);
                    //cmd.Parameters.AddWithValue("@PatientID", item.PatientID);
                    //cmd.Parameters.AddWithValue("@ClientID", item.ClientID);
                    //cmd.Parameters.AddWithValue("@SourceSystemID", item.SourceSystemID);
                    //cmd.Parameters.AddWithValue("@createdBy", item.createdBy);
                    cmd.Parameters.AddWithValue("@CreateDateTimeBrowser", Datetime);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                        cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;

                        try
                        {
                            con.Open();

                             int i = cmd.ExecuteNonQuery();
                            //sqla = new SqlDataAdapter(cmd);
                            //sqla.Fill(ds);

                            result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);



                        }
                        catch (Exception ex)
                        {
                            // throw the exception
                        }
                        finally
                        {
                            con.Close();
                        }


                    }
                }

            return result;
        }



            
       // }

        public List<DynamicWebcontrolParameterViewModel> GetDynamicControlList(DataSet ds)
        {
            List<DynamicWebcontrolParameterViewModel> chartHistoryViewModel = new List<DynamicWebcontrolParameterViewModel>();

            chartHistoryViewModel = (List<DynamicWebcontrolParameterViewModel>)
                            (from DataRow dr in ds.Tables[0].Rows
                             select new DynamicWebcontrolParameterViewModel()
                             {
                                 ClientId = Convert.ToInt32(dr["ClientID"]),
                                 HeadName = dr["HeadName"].ToString(),
                                 ControlName = dr["ControlName"].ToString(),
                                 WebControlTypeID = Convert.ToInt32(dr["WebControlTypeID"]),
                                 Code = dr["Code"].ToString(),
                                 webControlType = dr["webControlType"].ToString(),
                                 CreateDateTimeServer = Convert.ToDateTime(dr["CreateDateTimeServer"]),
                                 CreatedBy = dr["CreatedBy"].ToString(),
                                 ParameterValue = Convert.ToString(dr["ParameterValue"]),
                                 ParameterValueComment = Convert.ToString(dr["ParameterValueComment"]),
                                 PartographID = Convert.ToInt32(dr["PartographID"]),
                                 PatientID = Convert.ToInt32(dr["PatientID"]),
                                 StageCode = dr["StageCode"].ToString(),
                                 UOM = Convert.ToString(dr["UOM"]),
                                 DynamicMeasurementParameterID = Convert.ToInt32(dr["dynamicParameterId"]),
                                 webcontorlTypePossibleValues = this._unitOfWork.WebControlTypePossibleValueRepository.GetByIds(Convert.ToInt32(dr["WebControlTypeID"])),
                                 validations = this._unitOfWork.ValidationRepository.GetById(Convert.ToInt32(dr["validationId"]))
                             }).ToList();

            return chartHistoryViewModel;
        }

    }
}


