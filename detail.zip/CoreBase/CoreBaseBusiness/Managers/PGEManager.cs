﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class PGEManager : BaseManager<PGE, PGEViewModel>, IPGEManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public PGEManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<PGEViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.PGERepository.GetAsync(id);

           
            var viewModel = this._mapper.Map<PGEViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from PGE Details.
        /// </summary>
        public async override Task<IEnumerable<PGEViewModel>> ListAsync(PGEViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PGE, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PGERepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PGEViewModel>>(module);
        }

        /// <summary>
        /// Add New PGE Data into System
        /// </summary>
        public async override Task<bool> AddAsync(PGEViewModel viewModel)
        {
            var module = this._mapper.Map<PGE>(viewModel);
            var data = this._unitOfWork.PGERepository.AddAsync(module);

           

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.ID : 0;

            return await Task.FromResult<bool>(finalResult);
        } 

        /// <summary>
        ///  Updates existing record for PGE Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(PGEViewModel viewModel)
        {
            var module = this._mapper.Map<PGE>(viewModel);
            var data = this._unitOfWork.PGERepository.UpdateAsync(module);

          
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from PGE Details.
        /// </summary>
        public async override Task<int> CountAsync(PGEViewModel viewModel)
        {
            Expression<Func<PGE, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsActive == viewModel.IsActive);
            else
                condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.PGERepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  PGE details of Patient 
        /// </summary>
        public async override Task<IEnumerable<PGEViewModel>> RangeAsync(int recordCount, PGEViewModel viewModel)
        {
            Expression<Func<PGE, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientID == viewModel.PaientId || viewModel.PaientId == 0) && (c.StageId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.PGERepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var PGEModel = this._mapper.Map<IEnumerable<PGEViewModel>>(module);
            

            return PGEModel;
        }


        /// <summary>
        ///  Deletes record PGE from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.PGERepository.DeleteAsync(id, deletedBy);

            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


