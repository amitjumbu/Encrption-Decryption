﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class FetalHeartRateManager : BaseManager<MeasurementFetalHeartrateMeasurementValue, FetalHeartRateViewModel>, IFetalHeartRateManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public FetalHeartRateManager(IMapper mapper, IHostingEnvironment hostingEnvironment,ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<FetalHeartRateViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.FetalHeartRateRepository.GetAsync(id);

            
            var viewModel = this._mapper.Map<FetalHeartRateViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from MeasurementFetalHeartrateMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<FetalHeartRateViewModel>> ListAsync(FetalHeartRateViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementFetalHeartrateMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.FetalHeartRateRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<FetalHeartRateViewModel>>(module);
        }

        /// <summary>
        /// Add New MeasurementFetalHeartrateMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(FetalHeartRateViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementFetalHeartrateMeasurementValue>(viewModel);
            var data = this._unitOfWork.FetalHeartRateRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0; 

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for MeasurementFetalHeartrateMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(FetalHeartRateViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementFetalHeartrateMeasurementValue>(viewModel);
            var data = this._unitOfWork.FetalHeartRateRepository.UpdateAsync(module);

           

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from MeasurementFetalHeartrateMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(FetalHeartRateViewModel viewModel)
        {
            Expression<Func<MeasurementFetalHeartrateMeasurementValue, bool>> condition = (c => !c.IsDeleted);


            return await this._unitOfWork.FetalHeartRateRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  MeasurementFetalHeartrateMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<FetalHeartRateViewModel>> RangeAsync(int recordCount, FetalHeartRateViewModel viewModel)
        {
            Expression<Func<MeasurementFetalHeartrateMeasurementValue, bool>> condition = (c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.FetalHeartRateRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var FetalHeartRateModel = this._mapper.Map<IEnumerable<FetalHeartRateViewModel>>(module);
            

            return FetalHeartRateModel;
        }


        /// <summary>
        ///  Deletes record MeasurementFetalHeartrateMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.FetalHeartRateRepository.DeleteAsync(id, deletedBy);

            
            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


