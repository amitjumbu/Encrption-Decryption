﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using System.Data;
using System.Data.SqlClient;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class DrugsGivenIVFluidsManager : BaseManager<Measurement_DrugsIVMeasurementValue, DrugsGivenIVFluidsViewModel>, IDrugsGivenIVFluidsManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public DrugsGivenIVFluidsManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<DrugsGivenIVFluidsViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.DrugsGivenIVFluidsRepository.GetAsync(id);

            
            var viewModel = this._mapper.Map<DrugsGivenIVFluidsViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_DrugsIVMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<DrugsGivenIVFluidsViewModel>> ListAsync(DrugsGivenIVFluidsViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Measurement_DrugsIVMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.DrugsGivenIVFluidsRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<DrugsGivenIVFluidsViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_DrugsIVMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(DrugsGivenIVFluidsViewModel viewModel)
        {
            var module = this._mapper.Map<Measurement_DrugsIVMeasurementValue>(viewModel);
            var data = this._unitOfWork.DrugsGivenIVFluidsRepository.AddAsync(module);

           

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.ID : 0;

            return await Task.FromResult<bool>(finalResult);
        }
         
        /// <summary>
        ///  Updates existing record for Measurement_DrugsIVMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(DrugsGivenIVFluidsViewModel viewModel)
        {
            var module = this._mapper.Map<Measurement_DrugsIVMeasurementValue>(viewModel);
            var data = this._unitOfWork.DrugsGivenIVFluidsRepository.UpdateAsync(module);


            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_DrugsIVMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(DrugsGivenIVFluidsViewModel viewModel)
        {
            Expression<Func<Measurement_DrugsIVMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.DrugsGivenIVFluidsRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_DrugsIVMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<DrugsGivenIVFluidsViewModel>> RangeAsync(int recordCount, DrugsGivenIVFluidsViewModel viewModel)
        {
            Expression<Func<Measurement_DrugsIVMeasurementValue, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientID == viewModel.PatientId || viewModel.PatientId == 0) && (c.StageId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.DrugsGivenIVFluidsRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var DrugsGivenIVFluidsModel = this._mapper.Map<IEnumerable<DrugsGivenIVFluidsViewModel>>(module);
            
            return DrugsGivenIVFluidsModel;
        }


        /// <summary>
        ///  Deletes record Measurement_DrugsIVMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.DrugsGivenIVFluidsRepository.DeleteAsync(id, deletedBy);

            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }

        public async Task<int> DrugsGivenFluidsInsertUpdate(List<DrugsGivenIVFluidsViewModel> listData)
        {
            long? patientId = 0; long? partographId = 0; int? sourcesytemId = 0;
            string createdBy = string.Empty; DateTime? browserTime = DateTime.UtcNow;
            int? clientId; clientId = 0; decimal? x_AxisPosition = 0; decimal? y_AxisPosition = 0;

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0; DateTime Datetime = DateTime.UtcNow;
            DataTable dt = new DataTable();

            foreach (var item in listData)
            {
                patientId = item.PatientId;
                partographId = item.PartographId;
                clientId = item.ClientId;
                sourcesytemId = item.SourceSystemId;
                createdBy = item.UpdatedBy;
                browserTime = item.UpdateDateTimeBrowser;
                x_AxisPosition = item.XAxisPosition;
                y_AxisPosition = item.YAxisPosition;
            }

                dt.Columns.AddRange(new DataColumn[13]
            {
                    new DataColumn("ItemId", typeof(int)),
                    new DataColumn("Drug", typeof(string)),
                    new DataColumn("Dose", typeof(string)),
                    new DataColumn("Route", typeof(string)),
                    new DataColumn("Frequency", typeof(string)),
                    new DataColumn("Days", typeof(string)),
                    new DataColumn("Instructions", typeof(string)),
                    new DataColumn("Drug1", typeof(string)),
                    new DataColumn("Dose1", typeof(string)),
                    new DataColumn("Route1", typeof(string)),
                    new DataColumn("Frequency1", typeof(string)),
                    new DataColumn("Days1", typeof(string)),
                    new DataColumn("Instructions1", typeof(string))
            });

            foreach (var item in listData)
            {
                Datetime = (DateTime)item.CreateDateTimeBrowser;

                dt.Rows.Add(
                    item.Id,
                    item.Drug,
                    item.Dose,
                    item.Route,
                    item.Frequency,
                    item.Days,
                    item.Instructions,
                    item.Drug1,
                    item.Dose1,
                    item.Route1,
                    item.Frequency1,
                    item.Days1,
                    item.Instructions1);
            }

            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_InsertUpdateDrugGivenFluidValue", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ItemDataTable", dt);
                    cmd.Parameters.AddWithValue("@PatientID", patientId);
                    cmd.Parameters.AddWithValue("@SourceSystemID", sourcesytemId);
                    cmd.Parameters.AddWithValue("@PartographID", partographId);
                    cmd.Parameters.AddWithValue("@x_AxisPosition", x_AxisPosition);
                    cmd.Parameters.AddWithValue("@y_AxisPosition", y_AxisPosition);
                    cmd.Parameters.AddWithValue("@StageId", partographId);
                    cmd.Parameters.AddWithValue("@ClientId", clientId);
                    cmd.Parameters.AddWithValue("@UpdateBy", createdBy);
                    cmd.Parameters.AddWithValue("@updateBrowserTime", Datetime);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;

                    try
                    {
                        con.Open();

                        int i = cmd.ExecuteNonQuery();

                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }

            return result;
        }
    }
}
