﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    //using System.Data;
    using CoreBaseBusiness.Helpers;
    //using CoreBaseData.Helpers.PredicateExtension;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Dapper;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using static CoreBaseBusiness.Helpers.Constants;

    public class LocationManager : BaseManager<Location, LocationViewModel>, ILocationManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public LocationManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            //this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;

        }

        /// <summary>
        ///User can get Retrieves data from Location by id.
        /// </summary>
        public override async Task<LocationViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.LocationRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<LocationViewModel>((Location)module);
        }

        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async override Task<IEnumerable<LocationViewModel>> ListAsync(LocationViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Location, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.LocationRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        }

        /// <summary>
        /// Location Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(LocationViewModel viewModel)
        {
            //var module = this._mapper.Map<Location>(viewModel);
            //module.IsDeleted = false;
            //module.UpdateDateTimeServer = DateTime.Now;
            //module.CreateDateTimeServer = DateTime.Now;

            //var data = this._unitOfWork.LocationRepository.AddAsync(module);
            //this._unitOfWork.Save();
            //return await Task.FromResult<bool>(data.Result);
            bool result = false;
            OperatingLocationPropertyDetail operatingLocationPropertyDetail = null;
            if (viewModel != null)
            {
                var module = this._mapper.Map<Location>(viewModel);
                var data = this._unitOfWork.LocationRepository.AddAsync(module);
                result = this._unitOfWork.Save();
                if (data.Result && viewModel.CovidAccepting != null)
                {
                    operatingLocationPropertyDetail = new OperatingLocationPropertyDetail();
                    operatingLocationPropertyDetail.LocationId = module.Id;
                    operatingLocationPropertyDetail.PropertyValue = viewModel.CovidAccepting;
                    operatingLocationPropertyDetail.CreateDateTimeServer = DateTime.UtcNow;
                    operatingLocationPropertyDetail.UpdateDateTimeServer = DateTime.UtcNow;
                    operatingLocationPropertyDetail.CreateDateTimeBrowser = DateTime.UtcNow;
                    operatingLocationPropertyDetail.UpdateDateTimeBrowser = DateTime.UtcNow;
                    var data2 = this._mapper.Map<OperatingLocationPropertyDetail>(operatingLocationPropertyDetail);
                    _unitOfWork.OperatingLocationPropertyDetailRepository.AddAsync(data2);
                    var result2 = this._unitOfWork.Save();
                }
                //var data1 = this._unitOfWork.OperatingLocationPropertyDetailRepository.AddAsync(module);
                //if (data.Result && viewModel.LocationAddress != null && viewModel.LocationAddress.Count > 0)
                //{
                //    foreach (LocationAddressViewModel locationAddressViewModel in viewModel.LocationAddress)
                //    {
                //        var locationAddrs = this.mapper.Map<LocationAddress>(locationAddressViewModel);
                //        this.unitOfWork.LocationAddressRepository.AddAsync(locationAddrs);
                //    }
                //}

                //if (data.Result && viewModel.LocationContact != null && viewModel.LocationContact.Count > 0)
                //{
                //    foreach (LocationContactViewModel locationcontactViewModel in viewModel.LocationContact)
                //    {
                //        var locationContcts = this.mapper.Map<LocationContact>(locationcontactViewModel);
                //        this.unitOfWork.LocationContactRepository.AddAsync(locationContcts);
                //    }
                //}

            }

            return await Task.FromResult<bool>(result);
        }
        public async Task<IEnumerable<LocationViewModel>> SaveAll(List<LocationViewModel> ViewModels)
        {
            OperatingLocationPropertyDetail operatingLocationPropertyDetail = null;
            var freightalls = new List<LocationViewModel>();

            foreach (LocationViewModel ViewModel in ViewModels)
            {
                var module = this._mapper.Map<Location>(ViewModel);
                var result = await this._unitOfWork.LocationRepository.AddAsync(module);
                //var result = await this._unitOfWork.LocationRepository.AddAsync(this._mapper.Map<Location>(ViewModel)).ConfigureAwait(false);
                if (result)
                {
                    var finalResult=this._unitOfWork.Save();
                    ViewModel.ID = finalResult ? module.Id : 0;
                    if (ViewModel.CovidAccepting != null)
                    {

                        operatingLocationPropertyDetail = new OperatingLocationPropertyDetail();
                        operatingLocationPropertyDetail.LocationId = module.Id;
                        operatingLocationPropertyDetail.PropertyValue = ViewModel.CovidAccepting;
                        operatingLocationPropertyDetail.CreateDateTimeServer = DateTime.UtcNow;
                        operatingLocationPropertyDetail.UpdateDateTimeServer = DateTime.UtcNow;
                        operatingLocationPropertyDetail.CreateDateTimeBrowser = DateTime.UtcNow;
                        operatingLocationPropertyDetail.UpdateDateTimeBrowser = DateTime.UtcNow;
                        var data2 = this._mapper.Map<OperatingLocationPropertyDetail>(operatingLocationPropertyDetail);
                        _unitOfWork.OperatingLocationPropertyDetailRepository.AddAsync(data2);
                        var result2 = this._unitOfWork.Save();

                    }
                    freightalls.Add(ViewModel);
                }
            }
            return freightalls;
        }
        /// <summary>
        ///  Updates existing record for Location Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(LocationViewModel viewModel)
        {
            var module = this._mapper.Map<Location>(viewModel);
            var data = this._unitOfWork.LocationRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }


        public async Task<bool> UpdateLocationWithoutSetupCompleteAsync(LocationViewModel viewModel)
        {
            var module = this._mapper.Map<Location>(viewModel);
            var data = this._unitOfWork.LocationRepository.UpdateLocationWithoutSetupCompleteAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }


        /// <summary>
        ///  Retrieves Count Of All data from Location.
        /// </summary>
        public async override Task<int> CountAsync(LocationViewModel viewModel)
        {
            Expression<Func<Location, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.ID > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => (c.IsDeleted == false && (viewModel.LocationTypeId == 0 || c.LocationTypeId == viewModel.LocationTypeId)));

            return await this._unitOfWork.LocationRepository.CountAsync(condition);
        }

        /// <summary>
        /// Get All List for Location Data List
        /// </summary>
        public async override Task<IEnumerable<LocationViewModel>> RangeAsync(int recordCount, LocationViewModel viewModel)
        {
            //Expression<Func<Location, bool>> condition = c => (c.IsDeleted == false && (viewModel.LocationTypeId == 0 || c.LocationTypeId == viewModel.LocationTypeId));
            Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && (c.ClientId == viewModel.ClientID || viewModel.ClientID == 0 || viewModel.ClientID == null) && (c.OrganizationId == viewModel.OrganizationId || viewModel.OrganizationId == 0 || viewModel.OrganizationId == null) && (c.LocationFunctionId == viewModel.LocationFunctionId || viewModel.LocationFunctionId == 0||viewModel.LocationFunctionId == null) && (c.LocationTypeId == viewModel.LocationTypeId || viewModel.LocationTypeId == 0 || viewModel.LocationTypeId == null);
            var module = await this._unitOfWork.LocationRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
            return mappedData;
        }


        /// <summary>
        /// User can get list by locatinId.
        /// </summary>
        public async Task<IEnumerable<LocationViewModel>> GetList(int id)
        {
            Expression<Func<Location, bool>> condition = (c => c.IsDeleted == false && c.LocationTypeId == id);
            var module = await this._unitOfWork.LocationRepository.GetList(condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
            return mappedData;
        }

        public async Task<long> GetLocationTypedId(string code)
        {
            Expression<Func<LocationType, bool>> condition = c => c.IsDeleted == false && c.Code == code;
            var module = await this._unitOfWork.LocationTypeRepository.GetLocationTypeId(condition);
            return module.ID;
        }

        /// <summary>
        ///  Deletes record from location id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.LocationRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel)
        {
            long locationTypeId = await this.GetLocationTypedId(viewModel.LocationTypeCode);

            Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationTypeId == locationTypeId && c.ClientId == viewModel.ClientID && c.IsActive == true;
            var module = await this._unitOfWork.LocationRepository.GetList(condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
            return mappedData;

        }

        public async Task<IEnumerable<LocationViewModel>> GetLocationByLocationFunctionID(LocationViewModel viewModel)
        {
            Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationFunctionId == viewModel.LocationFunctionId && c.ClientId == viewModel.ClientID && c.IsActive == true;
            var module = await this._unitOfWork.LocationRepository.GetLocation(condition);
            var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
            return mappedData;
        }

        public async Task<IEnumerable<LocationViewModel>> GetToFromLocation(LocationViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            
            if (viewModel != null)
            {
                parameters.Add("locationId", viewModel.LocationId);
                
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetToFromLocation", parameters);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationViewModel>>(finalResult);
            }

            return null;

        }

        public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel[] viewModel)
        {
            var locationList = new List<Location>();
            foreach (var item in viewModel)
            {
                Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationFunctionId == item.LocationTypeId && c.ClientId == item.ClientID && c.IsActive == true;
                var module = await this._unitOfWork.LocationRepository.GetList(condition);
                locationList.AddRange(module);
            }
            var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(locationList);
            return mappedData;

        }
        #region Get Hospitals by Multiple Id
        public async Task<IEnumerable<LocationViewModel>> GetHospitalListByIDs(CollectHospialIDs collectHospialIDs)
        {
            Dictionary<string,object> Parameter = new Dictionary<string,object>();
            Parameter.Add("IDs", collectHospialIDs.IDs);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetHospitalSetupListByIDs", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
                return finalResult;
            }
            return null;
        }
        #endregion
        #region  Api for get all Hospital list
        public async Task<IEnumerable<LocationViewModel>> GetHospitalList(LocationViewModel locationViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            //if (locationViewModel != null && string.IsNullOrWhiteSpace(locationViewModel.FilterOn))
            //{
            //    Parameter.Add("PageNumber", locationViewModel.PageNo);
            //    Parameter.Add("PageSize", locationViewModel.PageSize);
            //}
            if (locationViewModel != null && string.IsNullOrWhiteSpace(locationViewModel.FilterOn))
            {
                Parameter.Add("ClientID", locationViewModel.ClientID);
                Parameter.Add("PageNumber", locationViewModel.PageNo);
                Parameter.Add("PageSize", locationViewModel.PageSize);
            }
            if (!string.IsNullOrWhiteSpace(locationViewModel.SortColumn))
            {
                Parameter.Add("SortColumn", locationViewModel.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(locationViewModel.SortOrder))
            {
                Parameter.Add("SortOrder", locationViewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetHospitalSetupList", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationViewModel>>(FilterResult<LocationViewModel>.GetFilteredResult(finalResult, locationViewModel.FilterOn, locationViewModel.PageSize));
            }

            return null;
        }
        #endregion


        #region Active/Inactive Hospital
        public async Task<bool> ActivateHospitalStatus(List<string> ids, bool isActive)
        {
            if (ids.Any())
            {
                List<long> HospitalStatusID = ids.ConvertAll(long.Parse);

                List<Location> Hospitalstatus = this._unitOfWork.LocationRepository.ListAsync(p => HospitalStatusID.Contains(p.Id)).Result.ToList();
                if(Hospitalstatus.Count != 0) {
                    foreach (Location hospitalaction in Hospitalstatus)
                    {
                        hospitalaction.IsActive = isActive;
                    }

                    var result = this._unitOfWork.Save();                   

                    return await Task.FromResult<bool>(result);
                }

               

                return await Task.FromResult<bool>(false);
            }

            return await Task.FromResult<bool>(false);
        }
        #endregion

        #region Delete multiple Hosital 
        public async Task<string> DeleteAllAsync(List<string> ids)
        {
            string msg = "";
            if (ids.Any())
            {
                List<long> HospitalStatusID = ids.ConvertAll(long.Parse);

                List<Location> hospitalstatus = this._unitOfWork.LocationRepository.ListAsync(p => HospitalStatusID.Contains(p.Id)).Result.ToList();
                foreach (Location hospitalAlert in hospitalstatus)
                {
                    hospitalAlert.IsDeleted = true;
                }

                var result = this._unitOfWork.Save();
                if (result == true)
                {
                    msg = Constants.Identifire.DeleteMessageSingle;
                }
                return await Task.FromResult<string>(msg);
            }

            return await Task.FromResult<string>("");
        }

        public async Task<IEnumerable<LocationViewModel>> ManufacturerList(LocationViewModel LLocationViewModel)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", LLocationViewModel.ClientID);

            DataSet ds = this._unitOfWork.ExecuteProcedure("Sp_GetManufacturerDetails", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                List<LocationViewModel> orders = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);

                if (orders.Count > 0)
                {
                    return await Task.FromResult<IEnumerable<LocationViewModel>>(orders.AsEnumerable());
                }
                else
                {
                    return null;
                }
            }

            return null;

        }


        #endregion

        public async Task<bool> UpdateLocationStatus(List<LocationViewModel> viewModels)
        {
            foreach (LocationViewModel locationView in viewModels)
            {
                var module = this._mapper.Map<Location>(locationView);
                module.UpdateDateTimeServer = DateTime.UtcNow;
                await this._unitOfWork.LocationRepository.UpdateStatusAsync(module);
                if (!locationView.IsActive)
                {
                    Dictionary<string, object> parameters = new Dictionary<string, object>();
                    parameters.Add("LocationId", locationView.ID);
                    parameters.Add("updatedby", locationView.UpdatedBy);
                    var res = this._unitOfWork.ExecuteProcedure("SPO_UpdateContractByLocation", parameters);
                }
            }

            return this._unitOfWork.Save();
        }


        public async Task<IEnumerable<LocationViewModel>> GetSalesBroker(LocationViewModel viewModel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameter.Add("PageNumber", viewModel.PageNo);
                parameter.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameter.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameter.Add("SortOrder", viewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetSalesBroker", parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<LocationViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<LocationViewModel>>(finalResult.AsEnumerable());
            }

            return null;

        }
        #region Bind operating Location 
        public async Task<IEnumerable<OperatingLocationListViewModel>> GetOperatingLocationList(OperatingLocationListViewModel locationViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (locationViewModel != null && string.IsNullOrWhiteSpace(locationViewModel.FilterOn))
            {
                
                Parameter.Add("PageNumber", locationViewModel.PageNo);
                Parameter.Add("PageSize", locationViewModel.PageSize);
            }
            Parameter.Add("ClientID", locationViewModel.ClientID);

            if (!string.IsNullOrWhiteSpace(locationViewModel.SortColumn))
            {
                Parameter.Add("SortColumn", locationViewModel.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(locationViewModel.SortOrder))
            {
                Parameter.Add("SortOrder", locationViewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetOperatingLocationList", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<OperatingLocationListViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<OperatingLocationListViewModel>>(
                    FilterResult<OperatingLocationListViewModel>.GetFilteredResult(
                        finalResult,
                        locationViewModel.FilterOn,
                        locationViewModel.PageSize, locationViewModel));
                //var finalResult = ConvertDataTabe.CreateListFromTable<OperatingLocationListViewModel>(ds.Tables[0]);
                //return await Task.FromResult<IEnumerable<OperatingLocationListViewModel>>(FilterResult<OperatingLocationListViewModel>.GetFilteredResult(finalResult, locationViewModel.FilterOn, locationViewModel.PageSize));
            }

            return null;
        }
        #endregion

        public async Task<bool> DeleteByIdsAsync(int[] ids, string deletedBy)
        {
            foreach (int id in ids)
            {
                var setupDelete = await this._unitOfWork.LocationRepository.DeleteAsync(id, deletedBy);
                if (!setupDelete)
                {
                    // if fails during any items delete , then return failure
                    return false;
                }
            }

            var saveResponse = this._unitOfWork.Save();

            return await Task.FromResult<bool>(saveResponse);
        }
        #region Get Operating Location Characteristics
        public async Task<IEnumerable<EntityPropertyViewModel>> GetLocationCharacteristics(EntityPropertyViewModel ModeViewModel)
        {
            //IEnumerable<EntityPropertyViewModel> entityPropertyViewModel = null;
            List<EntityPropertyViewModel> entityPropertyViewModels = new List<EntityPropertyViewModel>();

            EntityPropertyViewModel entityProperty = new EntityPropertyViewModel();
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            Parameter.Add("EntityCode", ModeViewModel.EntityCode);
            Parameter.Add("ClientId", ModeViewModel.ClientId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetLocationCharacteristics", Parameter);
            entityPropertyViewModels = ConvertDataTabe.CreateListFromTable<EntityPropertyViewModel>(ds.Tables[0]);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {

                foreach (var item in entityPropertyViewModels)
                {
                    Dictionary<string, object> EntityClientPropertyControlValueParameter = new Dictionary<string, object>();
                    //@EntityClientPropertyID
                    EntityClientPropertyControlValueParameter.Add("EntityClientPropertyID", item.EntityClientPropertyId);
                    DataSet PropertyControlValueds = this._unitOfWork.ExecuteProcedure("SPO_GetClientPropertyControlValueonEntityClientPropertyID", EntityClientPropertyControlValueParameter);
                    List<EntityClientPropertyControlValueViewModel> entityClientPropertyControlValue =
                        ConvertDataTabe.CreateListFromTable<EntityClientPropertyControlValueViewModel>(PropertyControlValueds.Tables[0]);
                    if (entityClientPropertyControlValue != null)
                    {
                        item.entityclientPropertyControlValueViewModel = entityClientPropertyControlValue;
                    }
                }
                return entityPropertyViewModels;
            }

            return null;
            //throw new NotImplementedException();
        }
        #endregion
        #region Get Existing Location characterstics
        public async Task<IEnumerable<OperatingLocationPropertyDetailViewModel>> GetExistingLocationCharacteristics(OperatingLocationPropertyDetailViewModel operatingLocation)
        {
            
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("LocationId", operatingLocation.LocationId);
            parameter.Add("ClientId", operatingLocation.ClientId);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetExistingLocationCharacteristics", parameter);
            if (ds != null && ds.Tables[0] != null)
            {
                List<OperatingLocationPropertyDetailViewModel> entityPropertyViewModels = new List<OperatingLocationPropertyDetailViewModel>();
                entityPropertyViewModels = ConvertDataTabe.CreateListFromTable<OperatingLocationPropertyDetailViewModel>(ds.Tables[0]);
                return entityPropertyViewModels;
            }

            return null;
        }
        #endregion

        /// <summary>
        /// Delete  Existing Characterstics for a location.
        /// </summary>
        /// <param name="deleteModel">Contains details of items to be deleted.</param>
        /// <returns>A success/Failure.</returns>
        public async Task<bool> DeleteExistingCharacteristics(LocationPropertyDeleteModel deleteModel)
        {
            if (deleteModel.LocationTypeCode == ModelEntityCodeValue.LocationType.Customer)
            {
                foreach (int id in deleteModel.Ids)
                {

                    var setupDelete = await this._unitOfWork.CustomerPropertyDetailRepository
                        .DeleteAsync(id, deleteModel.DeletedBy);
                    if (!setupDelete)
                    {
                        // if fails during any items delete , then return failure
                        return false;
                    }
                }

            }

            if (deleteModel.LocationTypeCode == ModelEntityCodeValue.LocationType.Location)
            {
                foreach (int id in deleteModel.Ids)
                {

                    var setupDelete = await this._unitOfWork.OperatingLocationPropertyDetailRepository
                        .DeleteAsync(id, deleteModel.DeletedBy);
                    if (!setupDelete)
                    {
                        // if fails during any items delete , then return failure
                        return false;
                    }
                }

            }

            if (deleteModel.LocationTypeCode == ModelEntityCodeValue.LocationType.BusinessPartner)
            {
                foreach (int id in deleteModel.Ids)
                {

                    var setupDelete = await this._unitOfWork.BusinessPartnerPropertyDetailRepository
                        .DeleteAsync(id, deleteModel.DeletedBy);
                    if (!setupDelete)
                    {
                        // if fails during any items delete , then return failure
                        return false;
                    }
                }

            }

            // add more conditions and respective logic 

            var saveResponse = this._unitOfWork.Save();

            return await Task.FromResult<bool>(saveResponse);
        }

        public async Task<VerifyOrderLocationViewModel> VerifyOrderLocationStatus(VerifyOrderLocationViewModel verifyOrderLocationViewModel)
        {

            if (verifyOrderLocationViewModel.TolocationID.HasValue && verifyOrderLocationViewModel.TolocationID.Value > 0)
            {
                int result = await this._unitOfWork.LocationRepository.CountAsync(x => x.Id == verifyOrderLocationViewModel.TolocationID.Value && x.IsActive && x.IsDeleted == false).ConfigureAwait(true);

                if (result > 0)
                {
                    verifyOrderLocationViewModel.IsValidToLocation = true;
                }
                else
                {
                    verifyOrderLocationViewModel.IsValidToLocation = false;
                }
            }
            else
            {
                verifyOrderLocationViewModel.IsValidToLocation = true;
            }

            if (verifyOrderLocationViewModel.FromlocationID.HasValue && verifyOrderLocationViewModel.FromlocationID.Value > 0)
            {
                int result = await this._unitOfWork.LocationRepository.CountAsync(x => x.Id == verifyOrderLocationViewModel.FromlocationID.Value && x.IsActive && x.IsDeleted == false).ConfigureAwait(true);

                if (result > 0)
                {
                    verifyOrderLocationViewModel.IsValidFromLocation = true;
                }
                else
                {
                    verifyOrderLocationViewModel.IsValidFromLocation = false;
                }
            }
            else
            {
                verifyOrderLocationViewModel.IsValidFromLocation = true;
            }
            return await Task.FromResult<VerifyOrderLocationViewModel>(verifyOrderLocationViewModel);
        }

        public async Task<IEnumerable<LocationForClaim>> BillingEntityForBPlist(LocationViewModel viewModel)
        {
            string strConnectionString = _unitOfWork.ConnectionString;
            using IDbConnection con = new SqlConnection(strConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@ClientID", viewModel.ClientID);
            var usersViewModels = con.Query<LocationForClaim>("SPO_BusinessPartnerLocation", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();
            return usersViewModels;

        }

        public async Task<IEnumerable<LocationForClaim>> BillingEntityForCustomerlist(LocationViewModel viewModel)
        {
            string strConnectionString = _unitOfWork.ConnectionString;
            using IDbConnection con = new SqlConnection(strConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@ClientID", viewModel.ClientID);
            var usersViewModels = con.Query<LocationForClaim>("SPO_CustomerPartnerLocation", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();
            return usersViewModels;

        }
    }
}
