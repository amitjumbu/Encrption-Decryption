﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;

    public class CurrentMaterialOnhandManager : BaseManager<CurrentMaterialOnhand, CurrentMaterialOnhandViewModel>, ICurrentMaterialOnhandManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public CurrentMaterialOnhandManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public async override Task<bool> AddAsync(CurrentMaterialOnhandViewModel viewModel)
        {
            viewModel.InventoryTypeID = viewModel.InventoryTypeID == 0 ? null : viewModel.InventoryTypeID;
            viewModel.CreateDateTimeServer = DateTime.Now;
            viewModel.UpdateDateTimeServer = DateTime.Now;
            viewModel.CreateDateTimeBrowser = DateTime.Now;
            viewModel.UpdateDateTimeBrowser = DateTime.Now;
            var module = this.mapper.Map<CurrentMaterialOnhand>(viewModel);
            var data = await this.unitOfWork.CurrentMaterialOnhandRepository.AddAsync(module);
            if (data)
            {
                this.unitOfWork.Save();
            }

            return await Task.FromResult<bool>(data);
        }

        /// <summary>
        ///  Retrieves All data from Charge Table along with the foriend key details
        /// </summary>
        /// <returns> Returns list of CurrentMaterialOnhand Details</returns>
        public async Task<IEnumerable<CurrentMaterialOnhandViewModel>> GetAllCurrentMaterialOnhand(CurrentMaterialOnhandViewModel inventoryViewModel)
        {
            Dictionary<string, object> inventoryParameter = new Dictionary<string, object>();
            if (inventoryViewModel != null && string.IsNullOrWhiteSpace(inventoryViewModel.FilterOn))
            {
                inventoryParameter.Add("PageNumber", inventoryViewModel.PageNo);
                inventoryParameter.Add("PageSize", inventoryViewModel.PageSize);
            }

            inventoryParameter.Add("ClientId", inventoryViewModel.ClientID);
            if (!string.IsNullOrWhiteSpace(inventoryViewModel.SortColumn))
            {
                inventoryParameter.Add("SortColumn", inventoryViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(inventoryViewModel.SortOrder))
            {
                inventoryParameter.Add("SortOrder", inventoryViewModel.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetCurrentMaterialOnhand", inventoryParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CurrentMaterialOnhandViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CurrentMaterialOnhandViewModel>>(FilterResult<CurrentMaterialOnhandViewModel>.GetFilteredResult(finalResult, inventoryViewModel.FilterOn, inventoryViewModel.PageSize));
            }

            return null;
        }

        public override Task<IEnumerable<CurrentMaterialOnhandViewModel>> ListAsync(CurrentMaterialOnhandViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<int> RcordCountAsync(CurrentMaterialOnhandViewModel viewModel)
        {
            var module = this.mapper.Map<CurrentMaterialOnhand>(viewModel);
            var count = await this.unitOfWork.CurrentMaterialOnhandRepository.RcordCountAsync(module).ConfigureAwait(false);
            return await Task.FromResult<int>(count);
        }

        public async Task<string> GetSumQuantity(CurrentMaterialOnhandViewModel viewModel)
        {
            var module = this.mapper.Map<CurrentMaterialOnhand>(viewModel);
            var count = await this.unitOfWork.CurrentMaterialOnhandRepository.GetSumQuantity(module).ConfigureAwait(false);
            return await Task.FromResult<string>(count.ToString());
        }

        public async override Task<bool> UpdateAsync(CurrentMaterialOnhandViewModel viewModel)
        {
            var module = this.mapper.Map<CurrentMaterialOnhand>(viewModel);
            var data = await this.unitOfWork.CurrentMaterialOnhandRepository.UpdateAsync(module);
            if (data)
            {
                this.unitOfWork.Save();
            }

            return await Task.FromResult<bool>(data);
        }

        public async Task<bool> UpdateCommentAsync(CurrentMaterialOnhandViewModel viewModel)
        {
            var module = this.mapper.Map<CurrentMaterialOnhand>(viewModel);
            var data = await this.unitOfWork.CurrentMaterialOnhandRepository.UpdateCommentAsync(module);
            if (data)
            {
                this.unitOfWork.Save();
            }

            return await Task.FromResult<bool>(data);
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> iD = ids.ConvertAll(long.Parse);

                List<CurrentMaterialOnhand> inventories = this.unitOfWork.CurrentMaterialOnhandRepository.ListAsync(p => iD.Contains(p.Id)).Result.ToList();

                foreach (CurrentMaterialOnhand inventory in inventories)
                {
                    await this.unitOfWork.CurrentMaterialOnhandRepository.DeleteAsync(inventory.Id);
                    var result = this.unitOfWork.Save();
                }

                return await Task.FromResult<bool>(true);
            }

            return await Task.FromResult<bool>(false);
        }
    }
}