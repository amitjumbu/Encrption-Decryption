﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ChargeComputationMethodManager : BaseManager<ChargeComputationMethod, ChargeComputationMethodViewModel>, IChargeComputationMethodManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public ChargeComputationMethodManager(IMapper mapper,  ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> AddAsync(ChargeComputationMethodViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  List all the Charge Computation Method.
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async override Task<IEnumerable<ChargeComputationMethodViewModel>> ListAsync(ChargeComputationMethodViewModel viewModel)
        {
            var module = await this.unitOfWork.ChargeComputationMethodRepository.ListAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ChargeComputationMethodViewModel>>(module);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> UpdateAsync(ChargeComputationMethodViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}