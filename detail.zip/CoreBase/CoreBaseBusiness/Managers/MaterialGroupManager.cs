﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using NPOI.SS.Formula.Functions;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class MaterialGroupManager : BaseManager<MaterialGroup, MaterialGroupViewModel>, IMaterialGroupManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        public MaterialGroupManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        
        //public async override Task<IEnumerable<MaterialGroupViewModel>> ListAsync(MaterialGroupViewModel viewModel)
        //{
        //    // TODO: This can be used for contains 




        //    //Expression<Func<MaterialGroup, bool>> condition = c => !c.IsDeleted;

        //    //var module = await this._unitOfWork.MaterialGroupRepository.ListAsync(condition).ConfigureAwait(false);
        //    ////var module2 = await this._unitOfWork.MaterialGroupRepository.ListAsync(condition).ConfigureAwait(false);
        //    //var query = from p in module.ToList()
        //    //            join q in module.ToList() on p.ParentGroupId equals q.Id into t
        //    //    select new
        //    //            {
        //    //               ID= p.Id,
        //    //               Code= p.Code,
        //    //               Name= p.Name,
        //    //               ParentCode=( from m in t select new {Name=m.Name }).Select(x => x.Name).ToString(),//mo.Name != null ? mo.Name : "None",
        //    //               Description=p.Description
        //    //            };
        //    //return this._mapper.Map<IEnumerable<MaterialGroupViewModel>>(query);
        //}


        public override Task<bool> UpdateAsync(MaterialGroupViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> AddAsync(MaterialGroupViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<MaterialGroupViewModel>> ListAsync(MaterialGroupViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MaterialGroupViewModel>> GetAllMaterialGroupData(MaterialGroupViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (requestCommonViewModel != null)
            {
                parameters.Add("ClientID", requestCommonViewModel.ClientID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialGroupList", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialGroupViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialGroupViewModel>>(finalResult);
            }

            return null;
        }
    }
}
