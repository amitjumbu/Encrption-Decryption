﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;

    public class SystemAlertManager : BaseManager<SystemAlert, SystemAlertViewModel>, ISystemAlertManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;


        public SystemAlertManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<SystemAlertViewModel> GetAsync(long id)
        {
            var module = await this.unitOfWork.SystemAlertRepository.GetAsync(id);
            var viewModel = this.mapper.Map<SystemAlertViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<SystemAlertViewModel>> ListAsync(SystemAlertViewModel viewModel)
        {
            Expression<Func<SystemAlert, bool>> condition = c => !c.IsDeleted && (c.AlertActivationTypeID == viewModel.AlertActivationTypeID || viewModel.AlertActivationTypeID == 0) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.SystemEventsId == viewModel.SystemEventsId || viewModel.SystemEventsId == 0);
            var module = await this.unitOfWork.SystemAlertRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<SystemAlertViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async override Task<bool> AddAsync(SystemAlertViewModel viewModel)
        {
            var module = this.mapper.Map<SystemAlert>(viewModel);
            var data = this.unitOfWork.SystemAlertRepository.AddAsync(module);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();

                viewModel.Id = finalResult ? module.Id : 0;
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(SystemAlertViewModel viewModel)
        {
            var module = this.mapper.Map<SystemAlert>(viewModel);
            var data = this.unitOfWork.SystemAlertRepository.UpdateAsync(module);
            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(SystemAlertViewModel viewModel)
        {
            Expression<Func<SystemAlert, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.SystemAlertRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        public async override Task<IEnumerable<SystemAlertViewModel>> RangeAsync(int recordCount, SystemAlertViewModel viewModel)
        {
            Expression<Func<SystemAlert, bool>> condition = c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.AlertActivationTypeID == viewModel.AlertActivationTypeID || viewModel.AlertActivationTypeID == 0) && (c.SystemEventsId == viewModel.SystemEventsId || viewModel.SystemEventsId == 0);
            var module = await this.unitOfWork.SystemAlertRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            if (module.Any())
            {
                var systemAlertModel = this.mapper.Map<IEnumerable<SystemAlertViewModel>>(module);
                return systemAlertModel;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.SystemAlertRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }
    }
}