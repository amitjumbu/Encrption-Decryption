﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientResourceListManager : BaseManager<PatientResourceList, PatientResourceListViewModel>, IPatientResourceListManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientResourceListManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        public override async Task<PatientResourceListViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.PatientResourceListRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<PatientResourceListViewModel>((PatientResourceList)module);
        }

        public async override Task<int> CountAsync(PatientResourceListViewModel viewModel)
        {
            Expression<Func<PatientResourceList, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientResourceListRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientResourceListViewModel>> RangeAsync(int recordCount, PatientResourceListViewModel viewModel)
        {
            Expression<Func<PatientResourceList, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientResourceListRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientResourceListViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientResourceListViewModel>> ListAsync(PatientResourceListViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientResourceList, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientResourceListRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientResourceListViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientResourceListViewModel viewModel)
        {
            var module = this._mapper.Map<PatientResourceList>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientResourceListRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientResourceListViewModel viewModel)
        {
            var module = this._mapper.Map<PatientResourceList>(viewModel);
            var data = this._unitOfWork.PatientResourceListRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<bool> CheckPhysicianMappedWithPatient(PatientResourceMapppingViewModel pData)
        {

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CheckPhysicianMappedWithPatient", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PatientId", pData.PatientId);
                    cmd.Parameters.AddWithValue("@ResourceRoleId", pData.ResourceRoleId);
                    cmd.Parameters.AddWithValue("@ResourceId", pData.ResourceId);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;

                    try
                    {
                        con.Open();

                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);

                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }


                }
            }

            return false;
        }

        public async Task<IEnumerable<PatientResourceListViewModel>> GetPhysiciansByPatientId(PatientResourceListViewModel ViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("PatientID", ViewModel.PatientId);
            parameters.Add("ClientID", ViewModel.ClientId);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetPhysicanList", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                List<PatientResourceListViewModel> PhysicinList = ConvertDataTabe.CreateListFromTable<PatientResourceListViewModel>(ds.Tables[0]);
                //List<FuelPriceTypeViewModel> fuelpricetypes = ConvertDataTableToGenericList<FuelPriceTypeViewModel>(ds.Tables[0]);

                if (PhysicinList.Count > 0)
                {
                    return await Task.FromResult<IEnumerable<PatientResourceListViewModel>>(PhysicinList.AsEnumerable());
                }
                else
                {
                    return null;
                }
                return await Task.FromResult<IEnumerable<PatientResourceListViewModel>>(PhysicinList.AsEnumerable());
            }

            return null;
        }


        public async Task<bool> DeleteAllAsync(string ids, string deletedBy)
        {
            int flag = 1;
            if (ids.Length > 0)
            {
                var values = await this._unitOfWork.PatientResourceListRepository.GetByIds(ids).ConfigureAwait(false);

                foreach (var item in values)
                {
                    item.UpdatedBy = deletedBy;
                    item.IsDeleted = true;
                    
                    var data = this._unitOfWork.PatientResourceListRepository.DeleteAsync(item);
                    flag++;
                }
                var finalResult = this._unitOfWork.Save();
                return await Task.FromResult(finalResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(false).ConfigureAwait(false);
            }
        }

        }
}