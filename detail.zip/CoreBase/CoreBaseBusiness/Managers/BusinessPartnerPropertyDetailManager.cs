﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.Helpers;
using System.Data.SqlClient;
using System.Data;
using System.Linq;

namespace CoreBaseBusiness.Managers
{

    public class BusinessPartnerPropertyDetailManager :
        BaseManager<BusinessPartnerPropertyDetail, BusinessPartnerPropertyDetailViewModel>, 
        IBusinessPartnerPropertyDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public BusinessPartnerPropertyDetailManager(IMapper mapper,
            IHostingEnvironment hostingEnvironment,
            ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;
        }

        public override Task<bool> AddAsync(BusinessPartnerPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(BusinessPartnerPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<BusinessPartnerPropertyDetailViewModel>> ListAsync(BusinessPartnerPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> MergeBusinessPartnerPropertyDetails(List<BusinessPartnerPropertyDetailViewModel> mergeModels)
        {
            foreach (BusinessPartnerPropertyDetailViewModel model in mergeModels)
            {
                Expression<Func<BusinessPartnerPropertyDetail, bool>> condition =
                        c => c.Id == model.ID
                        || (c.LocationId == model.LocationId && c.EntityPropertyId == model.EntityPropertyId);
                var recordExists = await this._unitOfWork.BusinessPartnerPropertyDetailRepository.GetList(condition);
                if (recordExists != null && recordExists.FirstOrDefault() != null)
                {
                    // update
                    BusinessPartnerPropertyDetail updateObj = recordExists.FirstOrDefault();
                    updateObj.PropertyValue = model.PropertyValue;
                    updateObj.PropertiesUom = model.PropertiesUom;
                    updateObj.UpdatedBy = model.UpdatedBy;
                    updateObj.UpdateDateTimeBrowser = model.UpdateDateTimeBrowser;
                    updateObj.UpdateDateTimeServer = DateTime.UtcNow;
                    updateObj.IsDeleted = model.IsDeleted;
                    updateObj.ClientId = model.ClientID;
                    updateObj.SourceSystemId = model.SourceSystemID;
                    var updateScuccessful = await this._unitOfWork.BusinessPartnerPropertyDetailRepository.UpdateAsync(updateObj);
                    if (!updateScuccessful)
                        return false;
                }
                else
                {
                    // insert
                    var insertObj = this._mapper.Map<BusinessPartnerPropertyDetail>(model);
                    insertObj.UpdateDateTimeServer = DateTime.Now;
                    insertObj.CreateDateTimeServer = DateTime.Now;
                    insertObj.Location = null;
                    var insertSuccessful = await this._unitOfWork.BusinessPartnerPropertyDetailRepository.AddAsync(insertObj);
                    if (!insertSuccessful)
                        return false;
                }
            }

            return this._unitOfWork.Save();
        }

        
    }
}