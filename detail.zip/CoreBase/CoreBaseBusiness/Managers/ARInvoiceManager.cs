﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class ARInvoiceManager : BaseManager<ArinvoiceAgeDetail, ARInvoiceAgeDetailViewModel>, IARInvoiceManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public ARInvoiceManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(ARInvoiceAgeDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<ARInvoiceAgeDetailViewModel>> GetInvoiceCount(ARInvoiceAgeDetailViewModel aRInvoiceAgeDetailViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@OrganizationID", aRInvoiceAgeDetailViewModel.OrganizationID);
                parameter.Add("@SystemTypeCode", aRInvoiceAgeDetailViewModel.SystemTypeCode);
                var usersViewModels = con.Query<ARInvoiceAgeDetailViewModel>("SPO_GetAllInvoices", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }


        public async Task<IEnumerable<ARInvoiceAgeDetailViewModel>> GetInvoiceList(ARInvoiceAgeDetailViewModel aRInvoiceAgeDetailViewModel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            if (aRInvoiceAgeDetailViewModel != null && string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.FilterOn))
            {
                parameter.Add("PageNumber", aRInvoiceAgeDetailViewModel.PageNo);
                parameter.Add("PageSize", aRInvoiceAgeDetailViewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.SortColumn))
            {
                parameter.Add("SortColumn", aRInvoiceAgeDetailViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.SortOrder))
            {
                parameter.Add("SortOrder", aRInvoiceAgeDetailViewModel.SortOrder);
            }
            parameter.Add("OrganizationID", aRInvoiceAgeDetailViewModel.OrganizationID);
            parameter.Add("SystemTypeCode", aRInvoiceAgeDetailViewModel.SystemTypeCode);

            //if (!string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.SortColumn))
            //{
            //    invoiceParameter.Add("SortColumn", aRInvoiceAgeDetailViewModel.SortColumn);
            //}

            //if (!string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.SortOrder))
            //{
            //    invoiceParameter.Add("SortOrder", aRInvoiceAgeDetailViewModel.SortOrder);
            //}


            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetAllInvoices", parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ARInvoiceAgeDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<ARInvoiceAgeDetailViewModel>>(FilterResult<ARInvoiceAgeDetailViewModel>.GetFilteredResult(finalResult, aRInvoiceAgeDetailViewModel.FilterOn, aRInvoiceAgeDetailViewModel.PageSize));
            }

            return null;
        }

        public override Task<IEnumerable<ARInvoiceAgeDetailViewModel>> ListAsync(ARInvoiceAgeDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(ARInvoiceAgeDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}
