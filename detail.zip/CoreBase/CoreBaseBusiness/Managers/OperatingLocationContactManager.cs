﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class OperatingLocationContactManager : BaseManager<OperatingLocationContact, OperatingLocationContactViewModel>, IOperatingLocationContactManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;

        public OperatingLocationContactManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  Retrieves  All data from OperatingLocationContact.
        /// </summary>
        public async override Task<IEnumerable<OperatingLocationContactViewModel>> ListAsync(OperatingLocationContactViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<OperatingLocationContact, bool>> condition = (c => c.IsDeleted == false && c.OperatingLocationID== viewModel.OperatingLocationID);
            var module = await this._unitOfWork.OperatingLocationContactRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<OperatingLocationContactViewModel>>(module);
        }

        /// <summary>
        /// Operating Location Add Contact Data.
        /// </summary>
        public async override Task<bool> AddAsync(OperatingLocationContactViewModel viewModel)
        {
            var module = this._mapper.Map<OperatingLocationContact>(viewModel);
            var data = this._unitOfWork.OperatingLocationContactRepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.ID = module.ID;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates Operating Location Contact Data.
        /// </summary>
        public async override Task<bool> UpdateAsync(OperatingLocationContactViewModel viewModel)
        {
            var module = this._mapper.Map<OperatingLocationContact>(viewModel);
            var data = this._unitOfWork.OperatingLocationContactRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Deletes Operating Location Contact Data.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.OperatingLocationContactRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

    }
}
