﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class GraphCommonMediaManager : IGraphCommonMediaManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public GraphCommonMediaManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }


        /// <summary>
        /// Add Medias for graph 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<bool> AddAsync(GraphCommonMediaViewModel viewModel)
        {
            if (viewModel.MediaModule == "bp")
            {
                Measurement_BPMeasurementMedia BPMedia = this._mapper.Map<Measurement_BPMeasurementMedia>(viewModel);
                BPMedia.Measurement_BPMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.BPMediaRepository.AddAsync(BPMedia);

            }
            else if (viewModel.MediaModule == "aceton")
            {
                Measurement_UrineAcetoneMeasurementMedia AcetonMedia = this._mapper.Map<Measurement_UrineAcetoneMeasurementMedia>(viewModel);
                AcetonMedia.Measurement_UrineAcetoneMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.AcetonMediaRepository.AddAsync(AcetonMedia);
            }
            else if (viewModel.MediaModule == "amnioticfluid")
            {
                Measurement_AmnioticFluidMeasurementMedia AmnioticFluidMedia = this._mapper.Map<Measurement_AmnioticFluidMeasurementMedia>(viewModel);
                AmnioticFluidMedia.Measurement_AmnioticFluidMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.AmnioticFluidMediaRepository.AddAsync(AmnioticFluidMedia);
            }
            else if (viewModel.MediaModule == "caput")
            {
                Measurement_CaputMeasurementMedia CaputMedia = this._mapper.Map<Measurement_CaputMeasurementMedia>(viewModel);
                CaputMedia.Measurement_CaputMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.CaputMediaRepository.AddAsync(CaputMedia);
            }
            else if (viewModel.MediaModule == "cervix")
            {
                Measurement_CervixMeasurementMedia CervixMedia = this._mapper.Map<Measurement_CervixMeasurementMedia>(viewModel);
                CervixMedia.Measurement_CervixMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.CervixMediaRepository.AddAsync(CervixMedia);
            }
            else if (viewModel.MediaModule == "contractionsper10min")
            {
                Measurement_ContractionsMeasurementMedia ContractionsPer10MinMedia = this._mapper.Map<Measurement_ContractionsMeasurementMedia>(viewModel);
                ContractionsPer10MinMedia.Measurement_ContractionsMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.ContractionsPer10MinMediaRepository.AddAsync(ContractionsPer10MinMedia);
            }
            else if (viewModel.MediaModule == "decentofhead")
            {
                Measurement_HeadDescentMeasurementMedia DecentofHeadMedia = this._mapper.Map<Measurement_HeadDescentMeasurementMedia>(viewModel);
                DecentofHeadMedia.Measurement_HeadDescentMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.DecentofHeadMediaRepository.AddAsync(DecentofHeadMedia);
            }
            else if (viewModel.MediaModule == "dropsmin")
            {
                Measurement_DropsMinMeasurementMedia DropsMinMedia = this._mapper.Map<Measurement_DropsMinMeasurementMedia>(viewModel);
                DropsMinMedia.Measurement_DropsMinMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.DropsMinMediaRepository.AddAsync(DropsMinMedia);
            }
            else if (viewModel.MediaModule == "fetalheartrate")
            {
                Measurement_FetalHeartrateMeasurementMedia FetalHeartRateMedia = this._mapper.Map<Measurement_FetalHeartrateMeasurementMedia>(viewModel);
                FetalHeartRateMedia.Measurement_FetalHeartrateMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.FetalHeartRateMediaRepository.AddAsync(FetalHeartRateMedia);
            }
            else if (viewModel.MediaModule == "moulding")
            {
                Measurement_MouldingMeasurementMedia MouldingMedia = this._mapper.Map<Measurement_MouldingMeasurementMedia>(viewModel);
                MouldingMedia.Measurement_MouldingMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.MouldingMediaRepository.AddAsync(MouldingMedia);
            }
            else if (viewModel.MediaModule == "oxytocinul")
            {
                Measurement_OxytocinMeasurementMedia OxytocinULMedia = this._mapper.Map<Measurement_OxytocinMeasurementMedia>(viewModel);
                OxytocinULMedia.Measurement_OxytocinMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.OxytocinULMediaRepository.AddAsync(OxytocinULMedia);
            }
            else if (viewModel.MediaModule == "pgealertpopup")
            {
                PGEAlertPopUpMedia PGEAlertPopUpMedia = this._mapper.Map<PGEAlertPopUpMedia>(viewModel);
                PGEAlertPopUpMedia.PGEAlertPopUpID = viewModel.ParentID;
                this._unitOfWork.PGEAlertPopUpMediaRepository.AddAsync(PGEAlertPopUpMedia);

            }
            else if (viewModel.MediaModule == "pge")
            {
                PGEMedia PGEMedia = this._mapper.Map<PGEMedia>(viewModel);
                PGEMedia.PGEID = viewModel.ParentID;
                this._unitOfWork.PGEMediaRepository.AddAsync(PGEMedia);
            }
            else if (viewModel.MediaModule == "pulse")
            {
                Measurement_PulseMeasurementMedia PulseMedia = this._mapper.Map<Measurement_PulseMeasurementMedia>(viewModel);
                PulseMedia.Measurement_PulseMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.PulseMediaRepository.AddAsync(PulseMedia);
            }
            else if (viewModel.MediaModule == "protein")
            {
                Measurement_UrineProtienMeasurementMedia ProteinMedia = this._mapper.Map<Measurement_UrineProtienMeasurementMedia>(viewModel);
                ProteinMedia.Measurement_UrineProtienMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.ProteinMediaRepository.AddAsync(ProteinMedia);
            }
            else if (viewModel.MediaModule == "thirdchart")
            {
                Measurement_ComplicationsMeasurementMedia ThirdChartMedia = this._mapper.Map<Measurement_ComplicationsMeasurementMedia>(viewModel);
                ThirdChartMedia.Measurement_ComplicationsMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.Measurement_ComplicationsMeasurementMediaRepository.AddAsync(ThirdChartMedia);

            }
            else if (viewModel.MediaModule == "volume")
            {
                Measurement_UrineVolumeMeasurementMedia VolumeMedia = this._mapper.Map<Measurement_UrineVolumeMeasurementMedia>(viewModel);
                VolumeMedia.Measurement_UrineVolumeMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.VolumeMediaRepository.AddAsync(VolumeMedia);
            }


            var finalResult = this._unitOfWork.Save();

            return Task.FromResult<bool>(finalResult);
        }


        /// <summary>
        /// Delete Medias for graph according to id and deleteby user name
        /// </summary>
        /// <param name="viewModel"></param>
        /// <param name="DeletedBy"></param>
        /// <returns></returns>
        public Task<bool> DeleteAsync(GraphCommonMediaViewModel viewModel, string DeletedBy)
        {
            if (viewModel.MediaModule == "bp")
            {

                this._unitOfWork.BPMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);

            }
            else if (viewModel.MediaModule == "aceton")
            {

                this._unitOfWork.AcetonMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "amnioticfluid")
            {

                this._unitOfWork.AmnioticFluidMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "caput")
            {

                this._unitOfWork.CaputMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "cervix")
            {

                this._unitOfWork.CervixMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "contractionsper10min")
            {

                this._unitOfWork.ContractionsPer10MinMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "decentofhead")
            {

                this._unitOfWork.DecentofHeadMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "dropsmin")
            {

                this._unitOfWork.DropsMinMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "fetalheartrate")
            {

                this._unitOfWork.FetalHeartRateMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "moulding")
            {

                this._unitOfWork.MouldingMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "oxytocinul")
            {

                this._unitOfWork.OxytocinULMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "pgealertpopup")
            {

                this._unitOfWork.PGEAlertPopUpMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);

            }
            else if (viewModel.MediaModule == "pge")
            {

                this._unitOfWork.PGEMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "pulse")
            {

                this._unitOfWork.PulseMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "protein")
            {

                this._unitOfWork.ProteinMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }
            else if (viewModel.MediaModule == "thirdchart")
            {

                this._unitOfWork.Measurement_ComplicationsMeasurementMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);

            }
            else if (viewModel.MediaModule == "volume")
            {

                this._unitOfWork.VolumeMediaRepository.DeleteAsync(viewModel.ID, DeletedBy);
            }


            var finalResult = this._unitOfWork.Save();

            return Task.FromResult<bool>(finalResult);
        }

        
        /// <summary>
        /// get all comments of graph by its type
        /// </summary>
        /// <param name="recordCount"></param>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<IEnumerable<GraphCommonMediaViewModel>> GetAllAsync(int recordCount, GraphCommonMediaViewModel viewModel)
        {
            if (viewModel.MediaModule == "bp")
            {

                Expression<Func<Measurement_BPMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_BPMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.BPMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel() {
                
                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_BPMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);

            }
            else if (viewModel.MediaModule == "aceton")
            {

                Expression<Func<Measurement_UrineAcetoneMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_UrineAcetoneMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.AcetonMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_UrineAcetoneMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);

            }
            else if (viewModel.MediaModule == "amnioticfluid")
            {
                Expression<Func<Measurement_AmnioticFluidMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_AmnioticFluidMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.AmnioticFluidMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                  
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_AmnioticFluidMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "caput")
            {

                Expression<Func<Measurement_CaputMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_CaputMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.CaputMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_CaputMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "cervix")
            {

                Expression<Func<Measurement_CervixMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_CervixMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.CervixMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_CervixMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "contractionsper10min")
            {

                Expression<Func<Measurement_ContractionsMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_ContractionsMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.ContractionsPer10MinMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                  
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_ContractionsMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "decentofhead")
            {

                Expression<Func<Measurement_HeadDescentMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_HeadDescentMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.DecentofHeadMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_HeadDescentMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "dropsmin")
            {
                Expression<Func<Measurement_DropsMinMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_DropsMinMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.DropsMinMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                    
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_DropsMinMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);

            }
            else if (viewModel.MediaModule == "fetalheartrate")
            {

                Expression<Func<Measurement_FetalHeartrateMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_FetalHeartrateMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.FetalHeartRateMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                    
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_FetalHeartrateMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "moulding")
            {

                Expression<Func<Measurement_MouldingMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_MouldingMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.MouldingMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_MouldingMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "oxytocinul")
            {

                Expression<Func<Measurement_OxytocinMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_OxytocinMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.OxytocinULMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_OxytocinMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "pgealertpopup")
            {

                Expression<Func<PGEAlertPopUpMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.PGEAlertPopUpID == viewModel.ParentID);
                var module = this._unitOfWork.PGEAlertPopUpMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.PGEAlertPopUpID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "pge")
            {

                Expression<Func<PGEMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.PGEID == viewModel.ParentID);
                var module = this._unitOfWork.PGEMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.PGEID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "pulse")
            {

                Expression<Func<Measurement_PulseMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_PulseMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.PulseMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_PulseMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "protein")
            {

                Expression<Func<Measurement_UrineProtienMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_UrineProtienMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.ProteinMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_UrineProtienMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "thirdchart")
            {
                Expression<Func<Measurement_ComplicationsMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_ComplicationsMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.Measurement_ComplicationsMeasurementMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_ComplicationsMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);
            }
            else if (viewModel.MediaModule == "volume")
            {

                Expression<Func<Measurement_UrineVolumeMeasurementMedia, bool>> condition = (c =>  (c.ClientID == viewModel.ClientID || viewModel.ClientID == 0) && c.Measurement_UrineVolumeMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.VolumeMediaRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonMediaViewModel()
                {

                    MediaModule = viewModel.MediaModule,
                    ClientID = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    DocumentID = p.DocumentID,
                   
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_UrineVolumeMeasurementValueID,
                    ID = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(finalResult);

            }

            return Task.FromResult<IEnumerable<GraphCommonMediaViewModel>>(null);

        }

        /// <summary>
        /// Get Medias from system for perticular graph
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<GraphCommonMediaViewModel> GetByIDAsync(GraphCommonMediaViewModel viewModel)
        {
            if (viewModel.MediaModule == "bp")
            {
                var ResultData =  this._unitOfWork.BPMediaRepository.GetAsync(viewModel.ID).Result;

                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);

            }
            else if (viewModel.MediaModule == "aceton")
            {

                var ResultData =  this._unitOfWork.AcetonMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "amnioticfluid")
            {

                var ResultData = this._unitOfWork.AmnioticFluidMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "caput")
            {

                var ResultData = this._unitOfWork.CaputMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "cervix")
            {

                var ResultData = this._unitOfWork.CervixMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "contractionsper10min")
            {

                var ResultData = this._unitOfWork.ContractionsPer10MinMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "decentofhead")
            {

                var ResultData = this._unitOfWork.DecentofHeadMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "dropsmin")
            {

                var ResultData = this._unitOfWork.DropsMinMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "fetalheartrate")
            {

                var ResultData = this._unitOfWork.FetalHeartRateMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "moulding")
            {

                var ResultData = this._unitOfWork.MouldingMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "oxytocinul")
            {

                var ResultData = this._unitOfWork.OxytocinULMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "pgealertpopup")
            {

                var ResultData = this._unitOfWork.PGEAlertPopUpMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);

            }
            else if (viewModel.MediaModule == "pge")
            {

                var ResultData = this._unitOfWork.PGEMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "pulse")
            {

                var ResultData = this._unitOfWork.PulseMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "protein")
            {

                var ResultData = this._unitOfWork.ProteinMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }
            else if (viewModel.MediaModule == "thirdchart")
            {

                var ResultData = this._unitOfWork.Measurement_ComplicationsMeasurementMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);

            }
            else if (viewModel.MediaModule == "volume")
            {

                var ResultData = this._unitOfWork.VolumeMediaRepository.GetAsync(viewModel.ID);
                viewModel = this._mapper.Map<GraphCommonMediaViewModel>(ResultData);
            }


            return Task.FromResult<GraphCommonMediaViewModel>(viewModel);
        }


        /// <summary>
        /// Graph Media Update by its id
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<bool> UpdateAsync(GraphCommonMediaViewModel viewModel)
        {
            if (viewModel.MediaModule == "bp")
            {
                Measurement_BPMeasurementMedia BPMedia = this._mapper.Map<Measurement_BPMeasurementMedia>(viewModel);
                BPMedia.Measurement_BPMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.BPMediaRepository.UpdateAsync(BPMedia);

            }
            else if (viewModel.MediaModule == "aceton")
            {
                Measurement_UrineAcetoneMeasurementMedia AcetonMedia = this._mapper.Map<Measurement_UrineAcetoneMeasurementMedia>(viewModel);
                AcetonMedia.Measurement_UrineAcetoneMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.AcetonMediaRepository.UpdateAsync(AcetonMedia);
            }
            else if (viewModel.MediaModule == "amnioticfluid")
            {
                Measurement_AmnioticFluidMeasurementMedia AmnioticFluidMedia = this._mapper.Map<Measurement_AmnioticFluidMeasurementMedia>(viewModel);
                AmnioticFluidMedia.Measurement_AmnioticFluidMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.AmnioticFluidMediaRepository.UpdateAsync(AmnioticFluidMedia);
            }
            else if (viewModel.MediaModule == "caput")
            {
                Measurement_CaputMeasurementMedia CaputMedia = this._mapper.Map<Measurement_CaputMeasurementMedia>(viewModel);
                CaputMedia.Measurement_CaputMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.CaputMediaRepository.UpdateAsync(CaputMedia);
            }
            else if (viewModel.MediaModule == "cervix")
            {
                Measurement_CervixMeasurementMedia CervixMedia = this._mapper.Map<Measurement_CervixMeasurementMedia>(viewModel);
                CervixMedia.Measurement_CervixMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.CervixMediaRepository.UpdateAsync(CervixMedia);
            }
            else if (viewModel.MediaModule == "contractionsper10min")
            {
                Measurement_ContractionsMeasurementMedia ContractionsPer10MinMedia = this._mapper.Map<Measurement_ContractionsMeasurementMedia>(viewModel);
                ContractionsPer10MinMedia.Measurement_ContractionsMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.ContractionsPer10MinMediaRepository.UpdateAsync(ContractionsPer10MinMedia);
            }
            else if (viewModel.MediaModule == "decentofhead")
            {
                Measurement_HeadDescentMeasurementMedia DecentofHeadMedia = this._mapper.Map<Measurement_HeadDescentMeasurementMedia>(viewModel);
                DecentofHeadMedia.Measurement_HeadDescentMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.DecentofHeadMediaRepository.UpdateAsync(DecentofHeadMedia);
            }
            else if (viewModel.MediaModule == "dropsmin")
            {
                Measurement_DropsMinMeasurementMedia DropsMinMedia = this._mapper.Map<Measurement_DropsMinMeasurementMedia>(viewModel);
                DropsMinMedia.Measurement_DropsMinMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.DropsMinMediaRepository.UpdateAsync(DropsMinMedia);
            }
            else if (viewModel.MediaModule == "fetalheartrate")
            {
                Measurement_FetalHeartrateMeasurementMedia FetalHeartRateMedia = this._mapper.Map<Measurement_FetalHeartrateMeasurementMedia>(viewModel);
                FetalHeartRateMedia.Measurement_FetalHeartrateMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.FetalHeartRateMediaRepository.UpdateAsync(FetalHeartRateMedia);
            }
            else if (viewModel.MediaModule == "moulding")
            {
                Measurement_MouldingMeasurementMedia MouldingMedia = this._mapper.Map<Measurement_MouldingMeasurementMedia>(viewModel);
                MouldingMedia.Measurement_MouldingMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.MouldingMediaRepository.UpdateAsync(MouldingMedia);
            }
            else if (viewModel.MediaModule == "oxytocinul")
            {
                Measurement_OxytocinMeasurementMedia OxytocinULMedia = this._mapper.Map<Measurement_OxytocinMeasurementMedia>(viewModel);
                OxytocinULMedia.Measurement_OxytocinMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.OxytocinULMediaRepository.UpdateAsync(OxytocinULMedia);
            }
            else if (viewModel.MediaModule == "pgealertpopup")
            {
                PGEAlertPopUpMedia PGEAlertPopUpMedia = this._mapper.Map<PGEAlertPopUpMedia>(viewModel);
                PGEAlertPopUpMedia.PGEAlertPopUpID = viewModel.ParentID;
                this._unitOfWork.PGEAlertPopUpMediaRepository.UpdateAsync(PGEAlertPopUpMedia);

            }
            else if (viewModel.MediaModule == "pge")
            {
                PGEMedia PGEMedia = this._mapper.Map<PGEMedia>(viewModel);
                PGEMedia.PGEID = viewModel.ParentID;
                this._unitOfWork.PGEMediaRepository.UpdateAsync(PGEMedia);
            }
            else if (viewModel.MediaModule == "pulse")
            {
                Measurement_PulseMeasurementMedia PulseMedia = this._mapper.Map<Measurement_PulseMeasurementMedia>(viewModel);
                PulseMedia.Measurement_PulseMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.PulseMediaRepository.UpdateAsync(PulseMedia);
            }
            else if (viewModel.MediaModule == "protein")
            {
                Measurement_UrineProtienMeasurementMedia ProteinMedia = this._mapper.Map<Measurement_UrineProtienMeasurementMedia>(viewModel);
                ProteinMedia.Measurement_UrineProtienMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.ProteinMediaRepository.UpdateAsync(ProteinMedia);
            }
            else if (viewModel.MediaModule == "thirdchart")
            {
                Measurement_ComplicationsMeasurementMedia ThirdChartMedia = this._mapper.Map<Measurement_ComplicationsMeasurementMedia>(viewModel);
                ThirdChartMedia.Measurement_ComplicationsMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.Measurement_ComplicationsMeasurementMediaRepository.UpdateAsync(ThirdChartMedia);

            }
            else if (viewModel.MediaModule == "volume")
            {
                Measurement_UrineVolumeMeasurementMedia VolumeMedia = this._mapper.Map<Measurement_UrineVolumeMeasurementMedia>(viewModel);
                VolumeMedia.Measurement_UrineVolumeMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.VolumeMediaRepository.UpdateAsync(VolumeMedia);
            }

            var finalResult = this._unitOfWork.Save();

            return Task.FromResult<bool>(finalResult);

        }
    }
}


