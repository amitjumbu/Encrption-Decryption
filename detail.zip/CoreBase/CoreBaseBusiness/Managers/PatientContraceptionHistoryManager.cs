﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientContraceptionHistoryManager : BaseManager<PatientContraceptionHistory, PatientContraceptionHistoryViewModel>, IPatientContraceptionHistoryManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientContraceptionHistoryManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        

        public async override Task<int> CountAsync(PatientContraceptionHistoryViewModel viewModel)
        {
            Expression<Func<PatientContraceptionHistory, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientContraceptionHistoryRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientContraceptionHistoryViewModel>> RangeAsync(int recordCount, PatientContraceptionHistoryViewModel viewModel)
        {
            Expression<Func<PatientContraceptionHistory, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientContraceptionHistoryRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientContraceptionHistoryViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientContraceptionHistoryViewModel>> ListAsync(PatientContraceptionHistoryViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientContraceptionHistory, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientContraceptionHistoryRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientContraceptionHistoryViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientContraceptionHistoryViewModel viewModel)
        {
            var module = this._mapper.Map<PatientContraceptionHistory>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientContraceptionHistoryRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientContraceptionHistoryViewModel viewModel)
        {
            var module = this._mapper.Map<PatientContraceptionHistory>(viewModel);
            var data = this._unitOfWork.PatientContraceptionHistoryRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
    }
}