﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.EntityFrameworkCore.Internal;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading.Tasks;

    public class ChargeComputationMethodMappingManager :
        BaseManager<ChargeComputationMethodMapping,
            ChargeComputationMethodMappingViewModel>, IChargeComputationMethodMappingManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public ChargeComputationMethodMappingManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> AddAsync(ChargeComputationMethodMappingViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<ChargeComputationMethodMappingViewModel>>
            GetChargeCompuationMethodMappingDetails(ChargeComputationMethodMappingViewModel viewModel)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                chargeParameter.Add("PageNumber", viewModel.PageNo);
                chargeParameter.Add("PageSize", viewModel.PageSize);
            }
            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", viewModel.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", viewModel.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetChargeComputationMethodMapping", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ChargeComputationMethodMappingViewModel>(ds.Tables[0]);
                foreach (ChargeComputationMethodMappingViewModel model in finalResult)
                {
                    if (!string.IsNullOrWhiteSpace(model.ComputationMapping))
                    {
                        model.ComputationMapping =
                        string.Join(',', model.ComputationMapping.Split(',').Distinct());
                        model.ComputationMappingDescription =
                            string.Join(',', model.ComputationMappingDescription.Split(',').Distinct());
                        model.ComputationMappings = await this.GetComputationMethodMapped(model.ComputationMapping);
                    }
                }
                return await Task.FromResult(FilterResult<ChargeComputationMethodMappingViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        private async Task<List<ChargeComputationMethodViewModel>> GetComputationMethodMapped(string computationMapping)
        {
            List<ChargeComputationMethodViewModel> mappings = new List<ChargeComputationMethodViewModel>();
            if (!string.IsNullOrWhiteSpace(computationMapping))
            {

                foreach (string methodId in computationMapping.Split(',').Distinct())
                {
                    try
                    {
                        mappings.Add(
                            this.mapper.Map<ChargeComputationMethodViewModel>(
                                await this.unitOfWork.ChargeComputationMethodRepository.GetAsync(int.Parse(methodId))));
                    }
                    catch (Exception ex)
                    {
                        // iterate through the next item
                        // TODO handle exception
                    }
                }
            }

            return mappings;
        }

        /// <summary>
        ///  List all the Charge Computation Method.
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async override Task<IEnumerable<ChargeComputationMethodMappingViewModel>> ListAsync(ChargeComputationMethodMappingViewModel viewModel)
        {
            var module = await this.unitOfWork.ChargeComputationMethodMappingRepository.ListAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ChargeComputationMethodMappingViewModel>>(module);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async override Task<bool> UpdateAsync(ChargeComputationMethodMappingViewModel viewModel)
        {
            var response = await this.unitOfWork.ChargeComputationMethodMappingRepository
                .TruncateByChargeIdAsync(viewModel.ChargeId, viewModel.UpdatedBy);
            this.unitOfWork.Save();
            foreach (ChargeComputationMethodViewModel mappedItem in viewModel.ComputationMappings)
            {
                var mapping = this.mapper.Map<ChargeComputationMethodMapping>(viewModel);
                mapping.ChargeComputationMethodId = (int)mappedItem.ID;
                mapping.Id = 0;
                if (string.IsNullOrEmpty(mapping.CreatedBy) && !string.IsNullOrEmpty(mapping.UpdatedBy))
                {
                    mapping.CreatedBy = mapping.UpdatedBy;
                }
                await this.unitOfWork.ChargeComputationMethodMappingRepository.AddAsync(mapping);
            }
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(true);
        }

        /// <summary>
        /// this method returns all Computationmethod(RateType) which are mapped with charge.
        /// </summary>
        /// <param name="viewModel">filters records on basis of chagre and clientid.</param>
        /// <returns>return list of all mapped RateType</returns>
        public async Task<IEnumerable<ChargeComputationMethodMappingForOrderViewModel>> GetChargeComputationMethodsForPerticularCharge(ChargeComputationMethodMappingViewModel viewModel)
        {
            var module = await this.unitOfWork.ChargeComputationMethodMappingRepository.ListAsync(c => c.IsDeleted == viewModel.IsDeleted && (c.ChargeId == viewModel.ChargeId || viewModel.ChargeId == 0) && (c.ClientId == viewModel.ClientID || c.ClientId == null)).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ChargeComputationMethodMappingForOrderViewModel>>(module);
        }
    }
}