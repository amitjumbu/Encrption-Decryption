﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Formatters.Xml;
//using CoreBaseData.Helpers.PredicateExtension;

namespace CoreBaseBusiness.Managers
{

    public class ChartMeasurementValueManager : BaseManager<ChartMeasurementValue, ChartMeasurementValueViewModel>, IChartMeasurementValueManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public ChartMeasurementValueManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }


        /// <summary>
        /// Add Chart measurement data into table
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public async override Task<bool> AddAsync(ChartMeasurementValueViewModel viewModel)
        {

            if (!this.IsAllReferenceExists(viewModel)) return await Task.FromResult<bool>(false);

            var chartMeasurementData = this._mapper.Map<ChartMeasurementValue>(viewModel);



            var data = this._unitOfWork.ChartMeasurementValueRepository.AddAsync(chartMeasurementData);


            if (!string.IsNullOrEmpty(viewModel.Comment))
            {
                var otherCommentData = new ChartMeasurementComment()
                {
                    //ChartMeasurementValue = chartMeasurementData,
                    Description = viewModel.Comment,
                    SourceSystemID = viewModel.SourceSystemID,
                    ClientID = viewModel.ClientID,
                    CreateDateTimeBrowser = viewModel.CreateDateTimeBrowser,
                    CreateDateTimeServer = viewModel.CreateDateTimeServer,
                    CreatedBy = viewModel.CreatedBy,
                    UpdateDateTimeBrowser = viewModel.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = viewModel.UpdateDateTimeServer,
                    IsDeleted = false,
                    UpdatedBy = viewModel.UpdatedBy

                };

                _unitOfWork.ChartMeasurementCommentRepository.AddAsync(otherCommentData);



            }
            var resultSave = this._unitOfWork.Save();
            return await Task.FromResult<bool>(resultSave);
        }




        /// <summary>
        /// Retrieves data id wise from Chart measuremnet table.
        /// </summary>
        public async override Task<ChartMeasurementValueViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.ChartMeasurementValueRepository.GetAsync(id);



            return this._mapper.Map<ChartMeasurementValueViewModel>(module);
        }

        /// <summary>
        /// Get All Data For Chart Measurement table 
        /// </summary>
        /// <param name="recordCount">No of record count</param>
        /// <param name="viewModel">Chart Measurement View Model</param>
        /// <returns></returns>
        public async Task<IEnumerable<ChartMeasurementValueViewModel>> GetAllAsync(int recordCount, ChartMeasurementValueViewModel viewModel)
        {
            Expression<Func<ChartMeasurementValue, bool>> condition = (c => c.ChartID == viewModel.ChartID && c.PartographID == viewModel.PartographID && c.ClientID == viewModel.ClientID && !c.IsDeleted);
            IEnumerable<ChartMeasurementValue> module = await this._unitOfWork.ChartMeasurementValueRepository.GetAllAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);


            var finalResult = module.ToList().ConvertAll(p => new ChartMeasurementValueViewModel()
            {
                ID = p.ID,
                MeasurementParameterID = p.MeasurementParameterID,
                CreateDateTimeServer = p.CreateDateTimeServer,
                ChartID = p.ChartID,
                ClientID = p.ClientID,
                CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                CreatedBy = p.CreatedBy,
                IsDeleted = p.IsDeleted,
                PartographID = p.PartographID,
                PatientID = p.PatientID,
                ReferenceNo = p.ReferenceNo,
                SourceSystemID = p.SourceSystemID,
                UOMID = p.UOMID,
                UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                UpdateDateTimeServer = p.UpdateDateTimeServer,
                UpdatedBy = p.UpdatedBy,
                Value = p.Value,
                X_axis_Position = p.X_axis_Position,
                Y_axis_Position = p.Y_axis_Position

            });
            // return this._mapper.Map<IEnumerable<ChartMeasurementValueViewModel>>(module);

            return finalResult.AsEnumerable();



        }

        public override Task<IEnumerable<ChartMeasurementValueViewModel>> ListAsync(ChartMeasurementValueViewModel viewModel)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Update Chart measurement with comment data into the table
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public override Task<bool> UpdateAsync(ChartMeasurementValueViewModel viewModel)
        {
            if (!this.IsAllReferenceExists(viewModel)) return Task.FromResult<bool>(false);

            var chartMeasurementData = this._mapper.Map<ChartMeasurementValue>(viewModel);


            var data = this._unitOfWork.ChartMeasurementValueRepository.UpdateAsync(chartMeasurementData);

            if (!string.IsNullOrEmpty(viewModel.Comment))
            {
                var allComments = this._unitOfWork.ChartMeasurementCommentRepository.GetAllAsync(1000, 1, 1000, p => p.ChartMeasurementValueID == viewModel.ID);

                var latestComment = allComments.Result.ToList().OrderByDescending(p => p.ID).FirstOrDefault();

                bool newlyAdd = true;
                if (latestComment != null)
                {
                    if (latestComment.Description.Trim().ToLower().Equals(viewModel.Comment.ToLower().Trim()))
                        newlyAdd = false;
                }

                if (latestComment == null || (latestComment != null && newlyAdd))
                {
                    var otherCommentData = new ChartMeasurementComment()
                    {
                        //ChartMeasurementValue = chartMeasurementData,
                        Description = viewModel.Comment,
                        SourceSystemID = viewModel.SourceSystemID,
                        ClientID = viewModel.ClientID,
                        CreateDateTimeBrowser = viewModel.CreateDateTimeBrowser,
                        CreateDateTimeServer = viewModel.CreateDateTimeServer,
                        CreatedBy = viewModel.CreatedBy,
                        UpdateDateTimeBrowser = viewModel.UpdateDateTimeBrowser,
                        UpdateDateTimeServer = viewModel.UpdateDateTimeServer,
                        IsDeleted = false,
                        UpdatedBy = viewModel.UpdatedBy

                    };

                    _unitOfWork.ChartMeasurementCommentRepository.AddAsync(otherCommentData);


                }



            }

            var saveDataStatus = this._unitOfWork.Save();

            return Task.FromResult<bool>(saveDataStatus);
        }


        /// <summary>
        /// Update list of Chart measuremnet data into the table with comments
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>

        public Task<bool> UpdateAllAsync(List<ChartMeasurementValueViewModel> viewModel)
        {



            if (viewModel != null && viewModel.Count > 0)
            {
                List<ChartMeasurementValue> chartMeasurementValuesList = new List<ChartMeasurementValue>();

                foreach (ChartMeasurementValueViewModel chartMeasurementValueViewModel in viewModel)
                {
                    if (!this.IsAllReferenceExists(chartMeasurementValueViewModel)) return Task.FromResult<bool>(false);

                    var chartMeasurementData = this._mapper.Map<ChartMeasurementValue>(chartMeasurementValueViewModel);


                    var data = this._unitOfWork.ChartMeasurementValueRepository.UpdateAsync(chartMeasurementData);




                    if (!string.IsNullOrEmpty(chartMeasurementValueViewModel.Comment))
                    {
                        var allComments = this._unitOfWork.ChartMeasurementCommentRepository.GetAllAsync(1000, 1, 1000, p => p.ChartMeasurementValueID == chartMeasurementValueViewModel.ID);

                        var latestComment = allComments.Result.ToList().OrderByDescending(p => p.ID).FirstOrDefault();

                        bool newlyAdd = true;
                        if (latestComment != null)
                        {
                            if (latestComment.Description.Trim().ToLower().Equals(chartMeasurementValueViewModel.Comment.ToLower().Trim()))
                                newlyAdd = false;
                        }

                        if (latestComment == null || (latestComment != null && newlyAdd))
                        {
                            var otherCommentData = new ChartMeasurementComment()
                            {
                                ChartMeasurementValueID = chartMeasurementData.ID,
                                Description = chartMeasurementValueViewModel.Comment,
                                SourceSystemID = chartMeasurementValueViewModel.SourceSystemID,
                                ClientID = chartMeasurementValueViewModel.ClientID,
                                CreateDateTimeBrowser = chartMeasurementValueViewModel.CreateDateTimeBrowser,
                                CreateDateTimeServer = chartMeasurementValueViewModel.CreateDateTimeServer,
                                CreatedBy = chartMeasurementValueViewModel.CreatedBy,
                                IsDeleted = false

                            };

                            _unitOfWork.ChartMeasurementCommentRepository.AddAsync(otherCommentData);


                        }



                    }



                    if (data.Result)
                        chartMeasurementValuesList.Add(chartMeasurementData);


                }

                if (chartMeasurementValuesList.Count > 0)
                {
                    var saveDataStatus = this._unitOfWork.Save();
                    return Task.FromResult<bool>(saveDataStatus);
                }
                else
                    return Task.FromResult<bool>(false);

            }
            else
                return Task.FromResult<bool>(false);
        }



        /// <summary>
        /// this method check all referencial data is available or not
        /// this method need to implement 
        /// </summary>
        /// <param name="chartMeasurementValueView"></param>
        /// <returns></returns>
        private bool IsAllReferenceExists(ChartMeasurementValueViewModel chartMeasurementValueView)
        {

            if (chartMeasurementValueView != null && (chartMeasurementValueView.MeasurementParameterID == null || chartMeasurementValueView.MeasurementParameterID == 0) && !string.IsNullOrEmpty(chartMeasurementValueView.MeasurementParameterName))
            {
                var measuremnetparameter = this._unitOfWork.MeasurementParameterRepository.GetAllAsync(1000, 1, 1000, x => x.IsDeleted == false && x.ClientID == chartMeasurementValueView.ClientID && x.Name.ToLower().Trim().Equals(chartMeasurementValueView.MeasurementParameterName.ToLower().Trim()));

                var measurementData = measuremnetparameter.Result.FirstOrDefault();

                if (measurementData != null)
                {
                    chartMeasurementValueView.MeasurementParameterID = measurementData.ID;
                }
                else
                {
                    return false;
                }

            }

            if (chartMeasurementValueView != null && (chartMeasurementValueView.ChartID == null || chartMeasurementValueView.ChartID == 0) && !string.IsNullOrEmpty(chartMeasurementValueView.ChartName))
            {
                var chartparameter = this._unitOfWork.ChartRepository.GetAllAsync(1000, 1, 1000, x => x.IsDeleted == false && x.ClientID == chartMeasurementValueView.ClientID && x.Name.ToLower().Trim().Equals(chartMeasurementValueView.ChartName.ToLower().Trim()));

                var chartData = chartparameter.Result.FirstOrDefault();

                if (chartData != null)
                {
                    chartMeasurementValueView.ChartID = chartData.ID;
                }
                else
                {
                    return false;
                }
            }


                return true;
        }


        /// <summary>
        /// Soft delete the chart measuremnt Data
        /// </summary>
        /// <param name="chartMeasurementRequestPacket"></param>
        /// <returns></returns>
        Task<bool> IChartMeasurementValueManager.Delete(EntityRecordRemoveRequestPacket chartMeasurementRequestPacket)
        {
            var data = this._unitOfWork.ChartMeasurementValueRepository.DeleteAsync(chartMeasurementRequestPacket.ID, chartMeasurementRequestPacket.UserName);

            var deletestatus = this._unitOfWork.Save();
            return Task.FromResult<bool>(deletestatus);
        }


        /// <summary>
        /// Add multiple Chartmeasuremnet Data into tables with comments
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        Task<bool> IChartMeasurementValueManager.AddAllAsync(List<ChartMeasurementValueViewModel> viewModel)
        {
            bool resultSave = false;

            List<ChartMeasurementValue> chartMeasurementValues = new List<ChartMeasurementValue>();
            if (viewModel.Count > 0)
            {
                foreach (ChartMeasurementValueViewModel chartMeasurementValueViewModel in viewModel)
                {
                    if (this.IsAllReferenceExists(chartMeasurementValueViewModel))
                    {
                        var chartMeasurementData = this._mapper.Map<ChartMeasurementValue>(chartMeasurementValueViewModel);

                        var data = this._unitOfWork.ChartMeasurementValueRepository.AddAsync(chartMeasurementData);

                        if (data.Result)
                        {
                            chartMeasurementValues.Add(chartMeasurementData);

                            if (!string.IsNullOrEmpty(chartMeasurementValueViewModel.Comment))
                            {
                                ChartMeasurementComment chartMeasurementComment = new ChartMeasurementComment()
                                {

                                    //ChartMeasurementValue = chartMeasurementData,

                                    Description = chartMeasurementValueViewModel.Comment,
                                    ClientID = chartMeasurementData.ClientID,
                                    SourceSystemID = chartMeasurementData.SourceSystemID,
                                    CreateDateTimeBrowser = chartMeasurementData.CreateDateTimeBrowser,
                                    CreateDateTimeServer = chartMeasurementData.CreateDateTimeServer,
                                    CreatedBy = chartMeasurementData.CreatedBy,
                                    IsDeleted = false,
                                    UpdateDateTimeBrowser = chartMeasurementData.UpdateDateTimeBrowser,
                                    UpdateDateTimeServer = chartMeasurementData.UpdateDateTimeServer,
                                    UpdatedBy = chartMeasurementData.UpdatedBy
                                };


                                this._unitOfWork.ChartMeasurementCommentRepository.AddAsync(chartMeasurementComment);

                            }

                        }
                    }



                }

                if (chartMeasurementValues.Count > 0)
                {
                    resultSave = this._unitOfWork.Save();
                }


            }
            return Task.FromResult<bool>(resultSave);
        }
    }
}