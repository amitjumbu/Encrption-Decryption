﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    //using CoreBaseData.Helpers.PredicateExtension;
    using CoreBaseBusiness.Helpers;

    public class UserAlertHistoryManager : BaseManager<UserAlertHistory, UserAlertHistoryViewModel>, IUserAlertHistoryManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;
        private readonly IConfiguration configuration;

        public UserAlertHistoryManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext, IConfiguration configuration)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        /// <summary>
        /// this method sends the UserAlert on ID Basis.
        /// </summary>
        /// <param name="id">Id of UserAlert</param>
        /// <returns>UserAlert Entity View Model.</returns>
        public async override Task<UserAlertHistoryViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWork.UserAlertHistoryRepository.GetAsync(id);
            var viewModel = this.mapper.Map<UserAlertHistoryViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<UserAlertHistoryViewModel>> ListAsync(UserAlertHistoryViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<UserAlertHistory, bool>> condition = (c => !c.IsDeleted);

            var module = await this.unitOfWork.UserAlertHistoryRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<UserAlertHistoryViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async override Task<bool> AddAsync(UserAlertHistoryViewModel viewModel)
        {


            //CountryOfOriginOfMaterialViewModel entity = new CountryOfOriginOfMaterialViewModel();
            // viewModel.CountryId = viewModel.CountryId;

            viewModel.IsDeleted = false;
            viewModel.UpdateDateTimeServer = DateTime.Now;
            viewModel.CreateDateTimeServer = DateTime.Now;

            // var module = this._mapper.Map<NamePrefix>(entity);
            var module = this.mapper.Map<UserAlertHistory>(viewModel);
            var data = this.unitOfWork.UserAlertHistoryRepository.AddAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(UserAlertHistoryViewModel viewModel)
        {
            viewModel.UpdateDateTimeServer = DateTime.Now;
            var module = this.mapper.Map<UserAlertHistory>(viewModel);
            var data = this.unitOfWork.UserAlertHistoryRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(UserAlertHistoryViewModel viewModel)
        {
            Expression<Func<UserAlert, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.UserAlertRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        //public async override Task<IEnumerable<UserAlertHistoryViewModel>> RangeAsync(int recordCount, UserAlertHistoryViewModel viewModel)
        //{
        //    Expression<Func<UserAlert, bool>> condition = c => c.IsDeleted == false && (c.AlertActivationTypeId == viewModel.AlertActivationTypeId || viewModel.AlertActivationTypeId == 0 || viewModel.AlertActivationTypeId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.SystemEventsId == viewModel.SystemEventsId || viewModel.SystemEventsId == 0 || viewModel.SystemAlertId == null) && (c.SystemAlertId == viewModel.SystemAlertId || viewModel.SystemAlertId == 0 || viewModel.SystemAlertId == null);
        //    var module = await this.unitOfWork.UserAlertRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
        //    if (module.Any())
        //    {
        //        var UserAlertModel = this.mapper.Map<IEnumerable<UserAlertViewModel>>(module);
        //        return UserAlertHistoryModel;
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.UserAlertHistoryRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

        /// <summary>
        /// this method get the Data From Procedure.
        /// </summary>
        /// <param name="viewModel">View model have filter like client and others.</param>
        /// <returns>return list of user alerts</returns>
        public async Task<IEnumerable<UserAlertHistoryViewModel>> GetAllAlertHistory(UserAlertHistoryViewModel ViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (ViewModel != null && string.IsNullOrWhiteSpace(ViewModel.FilterOn))
            {
                Parameter.Add("PageNumber", ViewModel.PageNo);
                Parameter.Add("PageSize", ViewModel.PageSize);
            }
            if (!string.IsNullOrWhiteSpace(ViewModel.SortColumn))
            {
                Parameter.Add("SortColumn", ViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(ViewModel.SortOrder))
            {
                Parameter.Add("SortOrder", ViewModel.SortOrder);
            }
            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetAllUserAlertHistoryDetails", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<UserAlertHistoryViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<UserAlertHistoryViewModel>>(FilterResult<UserAlertHistoryViewModel>.GetFilteredResult(finalResult, ViewModel.FilterOn, ViewModel.PageSize));
            }

            return null;
        }
        public async Task<IEnumerable<UserAlertHistoryViewModel>> GetAllSearchResult(UserAlertHistoryViewModel ViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
           
                Parameter.Add("@alertId", ViewModel.alertId);
                Parameter.Add("@startDate", ViewModel.startDate);
                Parameter.Add("@EndDate", ViewModel.endDate);
          
           
            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetAlertFilterData", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<UserAlertHistoryViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<UserAlertHistoryViewModel>>(FilterResult<UserAlertHistoryViewModel>.GetFilteredResult(finalResult, null, 0));
            }

            return null;
        }


        //public async Task<bool> ActivateUserAlert(List<string> ids,bool isActive)
        //{
        //    if (ids.Any())
        //    {
        //        List<int> UserAlertID = ids.ConvertAll(int.Parse);

        //        List<UserAlert> userAlerts = this.unitOfWork.UserAlertRepository.ListAsync(p => UserAlertID.Contains(p.Id)).Result.ToList();

        //        foreach (UserAlert userAlert in userAlerts)
        //        {
        //            userAlert.Active = isActive;
        //        }

        //        var result = this.unitOfWork.Save();

        //        return await Task.FromResult<bool>(result);
        //    }

        //    return await Task.FromResult<bool>(false);
        //}

        /// <summary>
        /// Delete All UserAlert Job.
        /// </summary>
        /// <param name="ids">List Ids</param>
        /// <returns>true on success/ false on fail.</returns>
        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> ID = ids.ConvertAll(long.Parse);

                List<UserAlertHistory> userAlertHistory = this.unitOfWork.UserAlertHistoryRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();

                foreach (UserAlertHistory alert in userAlertHistory)
                {
                    alert.IsDeleted = true;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }
    }
}