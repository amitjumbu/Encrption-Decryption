﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class PatientContactValueManager : BaseManager<PatientContact, PatientContactValueViewModel>, IPatientContactValueManager 
    {
        private readonly IMapper _mapper; 
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public PatientContactValueManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Patient Contact.
        /// </summary>
        public async override Task<PatientContactValueViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.PatientContactrepository.GetById(id);
            return this._mapper.Map<PatientContactValueViewModel>(module);
        }

        /// <summary>
        ///  Retrieves  All data from Patient Contact.
        /// </summary>
        public async override Task<IEnumerable<PatientContactValueViewModel>> ListAsync(PatientContactValueViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientContact, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientContactrepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientContactValueViewModel>>(module);
        }

        /// <summary>
        /// PatientContact Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(PatientContactValueViewModel viewModel)
        {
            var module = this._mapper.Map<PatientContact>(viewModel);
            var data = this._unitOfWork.PatientContactrepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.ID = module.ID;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for PatientContact.
        /// </summary>
        public async override Task<bool> UpdateAsync(PatientContactValueViewModel viewModel)
        {
            var module = this._mapper.Map<PatientContact>(viewModel);
            var data = this._unitOfWork.PatientContactrepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Patient Contact 
        /// </summary>
        public async override Task<int> CountAsync(PatientContactValueViewModel viewModel)
        {
            Expression<Func<PatientContact, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            if (viewModel.ID > 0)
                condition = condition.And(c => c.IsActive == viewModel.IsActive);
            else
                condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.PatientContactrepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves  All data from  PatientContact Id wise.
        /// </summary>
        public async override Task<IEnumerable<PatientContactValueViewModel>> RangeAsync(int recordCount, PatientContactValueViewModel viewModel)
        {
            Expression<Func<PatientContact, bool>> condition = (c => c.PatientID == viewModel.PatientID && c.ClientID == viewModel.ClientID);
            var module = await this._unitOfWork.PatientContactrepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            return this._mapper.Map<IEnumerable<PatientContactValueViewModel>>(module);
        }


        /// <summary>
        ///  Deletes record from PatientContact by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.PatientContactrepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }


    }
}
