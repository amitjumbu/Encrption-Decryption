﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{

    public class PulseManager : BaseManager<MeasurementPulseMeasurementValue, PulseViewModel>, IPulseManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public PulseManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<PulseViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.PulseRepository.GetAsync(id);

           
            var viewModel = this._mapper.Map<PulseViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_PulseMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<PulseViewModel>> ListAsync(PulseViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementPulseMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PulseRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PulseViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_PulseMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(PulseViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementPulseMeasurementValue>(viewModel);
            var data = this._unitOfWork.PulseRepository.AddAsync(module);

            
            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }
         
        /// <summary>
        ///  Updates existing record for Measurement_PulseMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(PulseViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementPulseMeasurementValue>(viewModel);
            var data = this._unitOfWork.PulseRepository.UpdateAsync(module);

            

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_PulseMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(PulseViewModel viewModel)
        {
            Expression<Func<MeasurementPulseMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.PulseRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_PulseMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<PulseViewModel>> RangeAsync(int recordCount, PulseViewModel viewModel)
        {
            Expression<Func<MeasurementPulseMeasurementValue, bool>> condition = (c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.PulseRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var PulseModel = this._mapper.Map<IEnumerable<PulseViewModel>>(module);
            

            return PulseModel;
        }


        /// <summary>
        ///  Deletes record Measurement_PulseMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.PulseRepository.DeleteAsync(id, deletedBy);

           

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


