﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using NPOI.SS.Formula.Functions;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class MaterialPropertyManager : BaseManager<MaterialProperty, MaterialPropertyViewModel>, IMaterialPropertyManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        public MaterialPropertyManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            this._unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(MaterialPropertyViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<MaterialPropertyViewModel>> ListAsync(MaterialPropertyViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MaterialPropertyViewModel>> ListMaterialPropertyAsync(MaterialPropertyViewModel viewModel)
        {
            Expression<Func<MaterialProperty, bool>> condition = c => !c.IsDeleted;
            var module = await this._unitOfWork.MaterialPropertyRepository.ListMaterialPropertyAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<MaterialPropertyViewModel>>(module);
        }

        public async Task<IEnumerable<MaterialPropertyControlValueViewModel>> GetMaterialPropertyControlValue(MaterialPropertyControlValueViewModel viewModel)
        {
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialPropertyControlValue", null);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialPropertyControlValueViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialPropertyControlValueViewModel>>(finalResult);
            }

            return null;
        }

        public override Task<bool> UpdateAsync(MaterialPropertyViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}
