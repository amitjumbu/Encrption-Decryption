﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class ThirdChartManager : BaseManager<Measurement_ComplicationsMeasurementValue, ThirdChartViewModel>, IThirdChartManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public ThirdChartManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<ThirdChartViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.Measurement_ComplicationsMeasurementRepository.GetAsync(id);

            
            var viewModel = this._mapper.Map<ThirdChartViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from ThirdChart Details.
        /// </summary>
        public async override Task<IEnumerable<ThirdChartViewModel>> ListAsync(ThirdChartViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Measurement_ComplicationsMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.Measurement_ComplicationsMeasurementRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<ThirdChartViewModel>>(module);
        }

        /// <summary>
        /// Add New ThirdChart Data into System
        /// </summary>
        public async override Task<bool> AddAsync(ThirdChartViewModel viewModel)
        {
            var module = this._mapper.Map<Measurement_ComplicationsMeasurementValue>(viewModel);
            var data = this._unitOfWork.Measurement_ComplicationsMeasurementRepository.AddAsync(module);

            
            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.ID : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for ThirdChart Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(ThirdChartViewModel viewModel)
        {
            var module = this._mapper.Map<Measurement_ComplicationsMeasurementValue>(viewModel); 
            var data = this._unitOfWork.Measurement_ComplicationsMeasurementRepository.UpdateAsync(module);

           

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from ThirdChart Details.
        /// </summary>
        public async override Task<int> CountAsync(ThirdChartViewModel viewModel)
        {
            Expression<Func<Measurement_ComplicationsMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsActive == viewModel.IsActive);
            else
                condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.Measurement_ComplicationsMeasurementRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  ThirdChart details of Patient 
        /// </summary>
        public async override Task<IEnumerable<ThirdChartViewModel>> RangeAsync(int recordCount, ThirdChartViewModel viewModel)
        {
            Expression<Func<Measurement_ComplicationsMeasurementValue, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientID == viewModel.PaientId || viewModel.PaientId == 0) && (c.StageId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.Measurement_ComplicationsMeasurementRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var ThirdChartModel = this._mapper.Map<IEnumerable<ThirdChartViewModel>>(module);
           

            return ThirdChartModel;
        }


        /// <summary>
        ///  Deletes record ThirdChart from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.Measurement_ComplicationsMeasurementRepository.DeleteAsync(id, deletedBy);

            
            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


