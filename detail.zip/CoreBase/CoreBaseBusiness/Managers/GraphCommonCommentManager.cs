﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{

    public class GraphCommonCommentManager : IGraphCommonCommentManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;
        private ADecTecCoreBaseUnitOfWork _adecUnitOfWork;


        public GraphCommonCommentManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext, CoreBaseData.Models.Entity2.ADecTecCoreBaseDBContext adectecDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
            _adecUnitOfWork = new ADecTecCoreBaseUnitOfWork(adectecDBContext);
        }


        /// <summary>
        /// Add Comments for graph 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<bool> AddAsync(GraphCommonCommentViewModel viewModel)
        {

            if (viewModel.CommentModule == "TEMP") // TEMP
            {
                CoreBaseData.Models.Entity2.MeasurementTemperatureMeasurementComment temperatureMeasurementComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementTemperatureMeasurementComment>(viewModel);
                temperatureMeasurementComment.Measurement_TemperatureMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.TemperatureCommentRepository.AddAsync(temperatureMeasurementComment);

            }

            if (viewModel.CommentModule == "BP") // BP
            {
                CoreBaseData.Models.Entity2.MeasurementBPMeasurementComment BPComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementBPMeasurementComment>(viewModel);
                BPComment.Measurement_BPMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.BPCommentRepository.AddAsync(BPComment);

            }
            else if (viewModel.CommentModule == "ACT") // Aceton
            {
                CoreBaseData.Models.Entity2.MeasurementUrineAcetoneMeasurementComment AcetonComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementUrineAcetoneMeasurementComment>(viewModel);
                AcetonComment.Measurement_UrineAcetoneMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.AcetonCommentRepository.AddAsync(AcetonComment);
            }
            else if (viewModel.CommentModule == "AMF") // Amniotic Fuild
            {
                CoreBaseData.Models.Entity2.MeasurementAmnioticFluidMeasurementComment AmnioticFluidComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementAmnioticFluidMeasurementComment>(viewModel);
                AmnioticFluidComment.Measurement_AmnioticFluidMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.AmnioticFluidCommentRepository.AddAsync(AmnioticFluidComment);
            }

            else if (viewModel.CommentModule == "MD") // Moulding
            {
                CoreBaseData.Models.Entity2.MeasurementMouldingMeasurementComment MouldingComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementMouldingMeasurementComment>(viewModel);
                MouldingComment.Measurement_MouldingMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.MouldingCommentRepository.AddAsync(MouldingComment);
            }
            

            //else if (viewModel.CommentModule == "CAPUT") // Caput
            //{
            //    Measurement_CaputMeasurementComment CaputComment = this._mapper.Map<Measurement_CaputMeasurementComment>(viewModel);
            //    CaputComment.Measurement_CaputMeasurementValueID = viewModel.ParentID;
            //    this._unitOfWork.CaputCommentRepository.AddAsync(CaputComment);
            //}
            else if (viewModel.CommentModule == "CERVIX") // Cervix
            {
                CoreBaseData.Models.Entity2.MeasurementCervixMeasurementComment CervixComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementCervixMeasurementComment>(viewModel);
                CervixComment.Measurement_CervixMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.CervixCommentRepository.AddAsync(CervixComment);
            }
            else if (viewModel.CommentModule == "CN") // Contractionper10min
            {
                CoreBaseData.Models.Entity2.MeasurementContractionsMeasurementComment ContractionsPer10MinComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementContractionsMeasurementComment>(viewModel);
                ContractionsPer10MinComment.Measurement_ContractionsMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.ContractionsPer10MinCommentRepository.AddAsync(ContractionsPer10MinComment);
            }
            else if (viewModel.CommentModule == "DESCENT") // DESCENT OF HEAD
            {
                CoreBaseData.Models.Entity2.MeasurementHeadDescentMeasurementComment DecentofHeadComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementHeadDescentMeasurementComment>(viewModel);
                DecentofHeadComment.Measurement_HeadDescentMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.DecentofHeadCommentRepository.AddAsync(DecentofHeadComment);
            }
            else if (viewModel.CommentModule == "DROPS") // DROPS
            {
                CoreBaseData.Models.Entity2.MeasurementDropsMinMeasurementComment DropsMinComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementDropsMinMeasurementComment>(viewModel);
                DropsMinComment.Measurement_DropsMinMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.DropsMinCommentRepository.AddAsync(DropsMinComment);
            }
            else if (viewModel.CommentModule == "FHR") // fetal Heart Rate
            {
                CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementComment FetalHeartRateComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementComment>(viewModel);
                FetalHeartRateComment.Measurement_FetalHeartrateMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.FetalHeartRateCommentRepository.AddAsync(FetalHeartRateComment);
            }
            
            else if (viewModel.CommentModule == "OXY") // OXYTOCIN
            {
                CoreBaseData.Models.Entity2.MeasurementOxytocinMeasurementComment OxytocinULComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementOxytocinMeasurementComment>(viewModel);
                OxytocinULComment.Measurement_OxytocinMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.OxytocinULCommentRepository.AddAsync(OxytocinULComment);
            }
            else if (viewModel.CommentModule == "pgealertpopup")
            {
                PGEAlertPopUpComment PGEAlertPopUpComment = this._mapper.Map<PGEAlertPopUpComment>(viewModel);
                PGEAlertPopUpComment.PGEAlertPopUpID = viewModel.ParentID;
                this._unitOfWork.PGEAlertPopUpCommentRepository.AddAsync(PGEAlertPopUpComment);

            }
            else if (viewModel.CommentModule == "pge")
            {
                PGEComment PGEComment = this._mapper.Map<PGEComment>(viewModel);
                PGEComment.PGEID = viewModel.ParentID;
                this._unitOfWork.PGECommentRepository.AddAsync(PGEComment);
            }
            else if (viewModel.CommentModule == "PL") // PULSE
            {
                CoreBaseData.Models.Entity2.MeasurementPulseMeasurementComment PulseComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementPulseMeasurementComment>(viewModel);
                PulseComment.Measurement_PulseMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.PulseCommentRepository.AddAsync(PulseComment);
            }
            else if (viewModel.CommentModule == "PT") /// Protein
            {
                CoreBaseData.Models.Entity2.MeasurementUrineProtienMeasurementComment ProteinComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementUrineProtienMeasurementComment>(viewModel);
                ProteinComment.Measurement_UrineProtienMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.ProteinCommentRepository.AddAsync(ProteinComment);
            }
            else if (viewModel.CommentModule == "thirdchart")
            {
                Measurement_ComplicationsMeasurementComment ThirdChartComment = this._mapper.Map<Measurement_ComplicationsMeasurementComment>(viewModel);
                ThirdChartComment.Measurement_ComplicationsMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.Measurement_ComplicationsMeasurementCommentRepository.AddAsync(ThirdChartComment);

            }
            else if (viewModel.CommentModule == "VL") // Volumes
            {
                CoreBaseData.Models.Entity2.MeasurementUrineVolumeMeasurementComment VolumeComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementUrineVolumeMeasurementComment>(viewModel);
                VolumeComment.Measurement_UrineVolumeMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.VolumeCommentRepository.AddAsync(VolumeComment);
            }


            var finalResult = this._adecUnitOfWork.Save();

            return Task.FromResult<bool>(finalResult);
        }


        /// <summary>
        /// Delete Comments for graph according to id and deleteby user name
        /// </summary>
        /// <param name="viewModel"></param>
        /// <param name="DeletedBy"></param>
        /// <returns></returns>
        public Task<bool> DeleteAsync(GraphCommonCommentViewModel viewModel, string DeletedBy)
        {
            if (viewModel.CommentModule == "BP")
            {

                this._adecUnitOfWork.BPCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);

            }
            else if (viewModel.CommentModule == "ACT")
            {

                this._adecUnitOfWork.AcetonCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "AMF")
            {

                this._adecUnitOfWork.AmnioticFluidCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "CAPUT")
            {

                this._unitOfWork.CaputCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "CERVIX")
            {

                this._adecUnitOfWork.CervixCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "CN")
            {

                this._adecUnitOfWork.ContractionsPer10MinCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "DESCENT")
            {

                this._adecUnitOfWork.DecentofHeadCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "DROPS")
            {

                this._adecUnitOfWork.DropsMinCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "FHR")
            {

                this._adecUnitOfWork.FetalHeartRateCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "MD")
            {

                this._adecUnitOfWork.MouldingCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "OXY")
            {

                this._adecUnitOfWork.OxytocinULCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "pgealertpopup")
            {

                this._unitOfWork.PGEAlertPopUpCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);

            }
            else if (viewModel.CommentModule == "pge")
            {

                this._unitOfWork.PGECommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "PL")
            {

                this._adecUnitOfWork.PulseCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "PT")
            {

                this._adecUnitOfWork.ProteinCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }
            else if (viewModel.CommentModule == "thirdchart")
            {

                this._unitOfWork.Measurement_ComplicationsMeasurementCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);

            }
            else if (viewModel.CommentModule == "VL")
            {

                this._adecUnitOfWork.VolumeCommentRepository.DeleteAsync(viewModel.Id, DeletedBy);
            }


            var finalResult = this._unitOfWork.Save();

            return Task.FromResult<bool>(finalResult);
        }

        
        /// <summary>
        /// get all comments of graph by its type
        /// </summary>
        /// <param name="recordCount"></param>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<IEnumerable<GraphCommonCommentViewModel>> GetAllAsync(int recordCount, GraphCommonCommentViewModel viewModel)
        {
            if (viewModel.CommentModule == "BP")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementBPMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_BPMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.BPCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel() {
                
                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                   // IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_BPMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);

            }
            else if (viewModel.CommentModule == "ACT")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementUrineAcetoneMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_UrineAcetoneMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.AcetonCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_UrineAcetoneMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);

            }
            else if (viewModel.CommentModule == "AMF")
            {
                Expression<Func<CoreBaseData.Models.Entity2.MeasurementAmnioticFluidMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_AmnioticFluidMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.AmnioticFluidCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                   // IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_AmnioticFluidMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "CAPUT")
            {

                Expression<Func<Measurement_CaputMeasurementComment, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_CaputMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.CaputCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_CaputMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "CERVIX")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementCervixMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_CervixMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.CervixCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_CervixMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "CN")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementContractionsMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_ContractionsMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.ContractionsPer10MinCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_ContractionsMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "DESCENT")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementHeadDescentMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_HeadDescentMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.DecentofHeadCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_HeadDescentMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "DROPS")
            {
                Expression<Func<CoreBaseData.Models.Entity2.MeasurementDropsMinMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_DropsMinMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.DropsMinCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_DropsMinMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);

            }
            else if (viewModel.CommentModule == "FHR")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_FetalHeartrateMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.FetalHeartRateCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_FetalHeartrateMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "MD")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementMouldingMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_MouldingMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.MouldingCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_MouldingMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "OXY")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementOxytocinMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_OxytocinMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.OxytocinULCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_OxytocinMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "pgealertpopup")
            {

                Expression<Func<PGEAlertPopUpComment, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.PGEAlertPopUpID == viewModel.ParentID);
                var module = this._unitOfWork.PGEAlertPopUpCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.PGEAlertPopUpID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "pge")
            {

                Expression<Func<PGEComment, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.PGEID == viewModel.ParentID);
                var module = this._unitOfWork.PGECommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.PGEID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "PL")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementPulseMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_PulseMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.PulseCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_PulseMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "PT")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementUrineProtienMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_UrineProtienMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.ProteinCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_UrineProtienMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "thirdchart")
            {
                Expression<Func<Measurement_ComplicationsMeasurementComment, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_ComplicationsMeasurementValueID == viewModel.ParentID);
                var module = this._unitOfWork.Measurement_ComplicationsMeasurementCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_ComplicationsMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);
            }
            else if (viewModel.CommentModule == "VL")
            {

                Expression<Func<CoreBaseData.Models.Entity2.MeasurementUrineVolumeMeasurementComment, bool>> condition = (c => c.IsDeleted == false && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && c.Measurement_UrineVolumeMeasurementValueID == viewModel.ParentID);
                var module = this._adecUnitOfWork.VolumeCommentRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

                var finalResult = module.Result.ToList().ConvertAll(p => new GraphCommonCommentViewModel()
                {

                    CommentModule = viewModel.CommentModule,
                    ClientId = p.ClientID,
                    CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                    CreateDateTimeServer = p.CreateDateTimeServer,
                    CreatedBy = p.CreatedBy,
                    Description = p.Description,
                    //IsActive = p.IsActive,
                    IsUrgent = p.IsUrgent,
                    ParentID = p.Measurement_UrineVolumeMeasurementValueID,
                    Id = p.ID,
                    SourceSystemID = p.SourceSystemID,
                    UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                    UpdateDateTimeServer = p.UpdateDateTimeServer,
                    UpdatedBy = p.UpdatedBy,
                    IsDeleted = p.IsDeleted

                }).AsEnumerable();


                return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(finalResult);

            }

            return Task.FromResult<IEnumerable<GraphCommonCommentViewModel>>(null);

        }

        /// <summary>
        /// Get Comments from system for perticular graph
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<GraphCommonCommentViewModel> GetByIDAsync(GraphCommonCommentViewModel viewModel)
        {
            if (viewModel.CommentModule == "BP")
            {
                var ResultData =  this._adecUnitOfWork.BPCommentRepository.GetAsync(viewModel.Id).Result;

                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);

            }
            else if (viewModel.CommentModule == "ACT")
            {

                var ResultData =  this._adecUnitOfWork.AcetonCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "AMF")
            {

                var ResultData = this._adecUnitOfWork.AmnioticFluidCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "CAPUT")
            {

                var ResultData = this._unitOfWork.CaputCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "CERVIX")
            {

                var ResultData = this._adecUnitOfWork.CervixCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "CN")
            {

                var ResultData = this._adecUnitOfWork.ContractionsPer10MinCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "DESCENT")
            {

                var ResultData = this._adecUnitOfWork.DecentofHeadCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "DROPS")
            {

                var ResultData = this._adecUnitOfWork.DropsMinCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "FHR")
            {

                var ResultData = this._adecUnitOfWork.FetalHeartRateCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "MD")
            {

                var ResultData = this._adecUnitOfWork.MouldingCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "OXY")
            {

                var ResultData = this._adecUnitOfWork.OxytocinULCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "pgealertpopup")
            {

                var ResultData = this._unitOfWork.PGEAlertPopUpCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);

            }
            else if (viewModel.CommentModule == "pge")
            {

                var ResultData = this._unitOfWork.PGECommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "PL")
            {

                var ResultData = this._adecUnitOfWork.PulseCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "PT")
            {

                var ResultData = this._adecUnitOfWork.ProteinCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }
            else if (viewModel.CommentModule == "thirdchart")
            {

                var ResultData = this._unitOfWork.Measurement_ComplicationsMeasurementCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);

            }
            else if (viewModel.CommentModule == "VL")
            {

                var ResultData = this._adecUnitOfWork.VolumeCommentRepository.GetAsync(viewModel.Id);
                viewModel = this._mapper.Map<GraphCommonCommentViewModel>(ResultData);
            }


            return Task.FromResult<GraphCommonCommentViewModel>(viewModel);
        }


        /// <summary>
        /// Graph Comment Update by its id
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<bool> UpdateAsync(GraphCommonCommentViewModel viewModel)
        {
            if (viewModel.CommentModule == "BP")
            {
                MeasurementBPMeasurementComment BPComment = this._mapper.Map<MeasurementBPMeasurementComment>(viewModel);
                BPComment.Measurement_BPMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.BPCommentRepository.UpdateAsync(BPComment);

            }
            else if (viewModel.CommentModule == "ACT")
            {
                MeasurementUrineAcetoneMeasurementComment AcetonComment = this._mapper.Map<MeasurementUrineAcetoneMeasurementComment>(viewModel);
                AcetonComment.Measurement_UrineAcetoneMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.AcetonCommentRepository.UpdateAsync(AcetonComment);
            }
            else if (viewModel.CommentModule == "AMF")
            {
                MeasurementAmnioticFluidMeasurementComment AmnioticFluidComment = this._mapper.Map<MeasurementAmnioticFluidMeasurementComment>(viewModel);
                AmnioticFluidComment.Measurement_AmnioticFluidMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.AmnioticFluidCommentRepository.UpdateAsync(AmnioticFluidComment);
            }
            else if (viewModel.CommentModule == "CAPUT")
            {
                Measurement_CaputMeasurementComment CaputComment = this._mapper.Map<Measurement_CaputMeasurementComment>(viewModel);
                CaputComment.Measurement_CaputMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.CaputCommentRepository.UpdateAsync(CaputComment);
            }
            else if (viewModel.CommentModule == "CR")
            {
                MeasurementCervixMeasurementComment CervixComment = this._mapper.Map<MeasurementCervixMeasurementComment>(viewModel);
                CervixComment.Measurement_CervixMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.CervixCommentRepository.UpdateAsync(CervixComment);
            }
            else if (viewModel.CommentModule == "CN")
            {
                MeasurementContractionsMeasurementComment ContractionsPer10MinComment = this._mapper.Map<MeasurementContractionsMeasurementComment>(viewModel);
                ContractionsPer10MinComment.Measurement_ContractionsMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.ContractionsPer10MinCommentRepository.UpdateAsync(ContractionsPer10MinComment);
            }
            else if (viewModel.CommentModule == "DESCENT")
            {
                MeasurementHeadDescentMeasurementComment DecentofHeadComment = this._mapper.Map<MeasurementHeadDescentMeasurementComment>(viewModel);
                DecentofHeadComment.Measurement_HeadDescentMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.DecentofHeadCommentRepository.UpdateAsync(DecentofHeadComment);
            }
            else if (viewModel.CommentModule == "DROPS")
            {
                MeasurementDropsMinMeasurementComment DropsMinComment = this._mapper.Map<MeasurementDropsMinMeasurementComment>(viewModel);
                DropsMinComment.Measurement_DropsMinMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.DropsMinCommentRepository.UpdateAsync(DropsMinComment);
            }
            else if (viewModel.CommentModule == "FHR")
            {
                CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementComment FetalHeartRateComment = this._mapper.Map<CoreBaseData.Models.Entity2.MeasurementFetalHeartrateMeasurementComment>(viewModel);
                FetalHeartRateComment.Measurement_FetalHeartrateMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.FetalHeartRateCommentRepository.UpdateAsync(FetalHeartRateComment);
            }
            else if (viewModel.CommentModule == "MD")
            {
                MeasurementMouldingMeasurementComment MouldingComment = this._mapper.Map<MeasurementMouldingMeasurementComment>(viewModel);
                MouldingComment.Measurement_MouldingMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.MouldingCommentRepository.UpdateAsync(MouldingComment);
            }
            else if (viewModel.CommentModule == "OXY")
            {
                MeasurementOxytocinMeasurementComment OxytocinULComment = this._mapper.Map<MeasurementOxytocinMeasurementComment>(viewModel);
                OxytocinULComment.Measurement_OxytocinMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.OxytocinULCommentRepository.UpdateAsync(OxytocinULComment);
            }
            else if (viewModel.CommentModule == "pgealertpopup")
            {
                PGEAlertPopUpComment PGEAlertPopUpComment = this._mapper.Map<PGEAlertPopUpComment>(viewModel);
                PGEAlertPopUpComment.PGEAlertPopUpID = viewModel.ParentID;
                this._unitOfWork.PGEAlertPopUpCommentRepository.UpdateAsync(PGEAlertPopUpComment);

            }
            else if (viewModel.CommentModule == "pge")
            {
                PGEComment PGEComment = this._mapper.Map<PGEComment>(viewModel);
                PGEComment.PGEID = viewModel.ParentID;
                this._unitOfWork.PGECommentRepository.UpdateAsync(PGEComment);
            }
            else if (viewModel.CommentModule == "PL")
            {
                MeasurementPulseMeasurementComment PulseComment = this._mapper.Map<MeasurementPulseMeasurementComment>(viewModel);
                PulseComment.Measurement_PulseMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.PulseCommentRepository.UpdateAsync(PulseComment);
            }
            else if (viewModel.CommentModule == "PT")
            {
                MeasurementUrineProtienMeasurementComment ProteinComment = this._mapper.Map<MeasurementUrineProtienMeasurementComment>(viewModel);
                ProteinComment.Measurement_UrineProtienMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.ProteinCommentRepository.UpdateAsync(ProteinComment);
            }
            else if (viewModel.CommentModule == "thirdchart")
            {
                Measurement_ComplicationsMeasurementComment ThirdChartComment = this._mapper.Map<Measurement_ComplicationsMeasurementComment>(viewModel);
                ThirdChartComment.Measurement_ComplicationsMeasurementValueID = viewModel.ParentID;
                this._unitOfWork.Measurement_ComplicationsMeasurementCommentRepository.UpdateAsync(ThirdChartComment);

            }
            else if (viewModel.CommentModule == "VL")
            {
                MeasurementUrineVolumeMeasurementComment VolumeComment = this._mapper.Map<MeasurementUrineVolumeMeasurementComment>(viewModel);
                VolumeComment.Measurement_UrineVolumeMeasurementValueID = viewModel.ParentID;
                this._adecUnitOfWork.VolumeCommentRepository.UpdateAsync(VolumeComment);
            }

            var finalResult = this._unitOfWork.Save();

            return Task.FromResult<bool>(finalResult);

        }
    }
}


