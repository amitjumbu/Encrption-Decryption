﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;

namespace CoreBaseBusiness.Managers
{

    public class TemperatureManager : BaseManager<MeasurementTemperatureMeasurementValue, TemperatureViewModel>, ITemperatureManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public TemperatureManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<TemperatureViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.TemperatureRepository.GetById(id);
            return this._mapper.Map<TemperatureViewModel>(module);
        }

        /// <summary>
        ///  Retrieves  All data from Package Details.
        /// </summary>
        public async override Task<IEnumerable<TemperatureViewModel>> ListAsync(TemperatureViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementTemperatureMeasurementValue, bool>> condition = (c => !c.IsDeleted);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            var module = await this._unitOfWork.TemperatureRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<TemperatureViewModel>>(module);
        }

        /// <summary>
        /// Address varification Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(TemperatureViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementTemperatureMeasurementValue>(viewModel);
            var data = this._unitOfWork.TemperatureRepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.Id = module.Id;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for Package Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(TemperatureViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementTemperatureMeasurementValue>(viewModel);
            var data = this._unitOfWork.TemperatureRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from package Details.
        /// </summary>
        public async override Task<int> CountAsync(TemperatureViewModel viewModel)
        {
            Expression<Func<MeasurementTemperatureMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            return await this._unitOfWork.TemperatureRepository.CountAsync(condition);
        }
         
        /// <summary>
        ///  Retrieves  All data from  Package Id wise.
        /// </summary>
        public async override Task<IEnumerable<TemperatureViewModel>> RangeAsync(int recordCount, TemperatureViewModel viewModel)
        {

            Expression<Func<MeasurementTemperatureMeasurementValue, bool>> condition = (c => c.IsDeleted == false);

            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }

            var module = await this._unitOfWork.TemperatureRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            return this._mapper.Map<IEnumerable<TemperatureViewModel>>(module);
        } 


        /// <summary>
        ///  Deletes record from Measurement_TemperatureMeasurementValue by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.TemperatureRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }
    }
}


