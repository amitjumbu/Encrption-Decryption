﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;

    public class ChargeManager : BaseManager<Charge, ChargeViewModel>, IChargeManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public ChargeManager(IMapper mapper,  ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(ChargeViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// this method return charge into application.
        /// </summary>
        /// <param name="chargeViewModel">ViewModel which is using for filter.</param>
        /// <returns>list of chagres.</returns>
        public async Task<IEnumerable<ChargeViewModel>> GetChageListForAdjustChageSection(ChargeViewModel chargeViewModel)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            chargeParameter.Add("ClientID", chargeViewModel.ClientID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetChargesForDD", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ChargeViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<ChargeViewModel>>(finalResult.AsEnumerable());
            }

            return null;
        }

        /// <summary>
        ///  Retrieves Count Of All data from Charge Table.
        /// </summary>
        public async override Task<int> CountAsync(ChargeViewModel viewModel)
        {
            Expression<Func<Charge, bool>> condition = c => !c.IsDeleted || c.IsDeleted;

            return await this.unitOfWork.ChargeRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves All data from Charge Table.
        /// </summary>
        public async override Task<IEnumerable<ChargeViewModel>> ListAsync(ChargeViewModel viewModel = null)
        {
            var module = await this.unitOfWork.ChargeRepository.ListAsync(c => viewModel != null ? viewModel.IsDeleted :!c.IsDeleted).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ChargeViewModel>>(module);
        }

      

        public override Task<bool> UpdateAsync(ChargeViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  Update all the view models.
        /// </summary>
        /// <param name="chargeViewModels">List of ChargeViewModels which will be updated.</param>
        /// <returns>Returns the list of Charges which was updated successfully.</returns>
        public async Task<IEnumerable<ChargeViewModel>> UpdateModelsAsync(List<ChargeViewModel> chargeViewModels)
        {
            var updatedViewModel = new List<ChargeViewModel>();
            foreach (ChargeViewModel chargeViewModel in chargeViewModels)
            {
                var charge = this.mapper.Map<Charge>(chargeViewModel);
                var response = await this.unitOfWork.ChargeRepository.UpdateAsync(charge).ConfigureAwait(false);
                if (response)
                {
                    this.unitOfWork.Save();
                    updatedViewModel.Add(chargeViewModel);
                }
            }

            return updatedViewModel;
        }

        /// <summary>
        ///  Retrieves All data from Charge Table along with the foriend key details
        /// </summary>
        /// <returns> Returns list of Charge Details</returns>
        public async Task<IEnumerable<ChargeViewModel>> GetAllChargeDetails(ChargeViewModel chargeViewModel)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (chargeViewModel != null && string.IsNullOrWhiteSpace(chargeViewModel.FilterOn))
            {
                chargeParameter.Add("PageNumber", chargeViewModel.PageNo);
                chargeParameter.Add("PageSize", chargeViewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(chargeViewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", chargeViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(chargeViewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", chargeViewModel.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetAllCharges", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ChargeViewModel>(ds.Tables[0]);
                var result = FilterResult<ChargeViewModel>.GetFilteredResult(finalResult, chargeViewModel.FilterOn, chargeViewModel.PageSize);
                if(chargeViewModel.ID > 0)
                {
                    result = result.Where(x => x.ID == chargeViewModel.ID).ToList();
                }
                return await Task.FromResult<IEnumerable<ChargeViewModel>>(result);
            }

            return null;
        }

        /// <summary>
        ///  Retrieves All data from Charge Table by category
        /// </summary>
        /// <returns> Returns list of Charge </returns>

        public async Task<object> GetCharge(ParameterModel parameterModel)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            
                chargeParameter.Add("ClientID", parameterModel.ClientID);
                chargeParameter.Add("Category", parameterModel.Category);
               DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetChargeByCategory", chargeParameter);
              var FilterClaimData = ConvertDataTabe.CreateListFromTable<ChargeModel>(ds.Tables[0]);
               
            return FilterClaimData;
            }
        }
    }
