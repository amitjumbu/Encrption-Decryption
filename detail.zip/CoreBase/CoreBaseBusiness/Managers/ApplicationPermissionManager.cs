﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Formatters.Xml;
//using CoreBaseData.Helpers.PredicateExtension;

namespace CoreBaseBusiness.Managers
{

    public class ApplicationPermissionManager : BaseManager<ApplicationPermission, ApplicationPermissionViewModel>, IApplicationPermissionManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public ApplicationPermissionManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }


        /// <summary>
        /// this method get the permission of any Application Element on role basis
        /// 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public Task<ApplicationPermissionViewModel> GetElementPermission(ApplicationPermissionViewModel viewModel)
        {

            //this line will be remove and in place of this we will call store procedure
            //ajij will implement the storeprocedure work flow in this
            var currentElement = this._unitOfWork.ApplicationPermissionRepository.GetAllAsync(1000, 1, 1000, x => x.ApplicationElementDetailID == viewModel.ApplicationElementDetailID);



            bool AllowView = false;
            bool AllowUpdate = false;
            bool AllowApprove = false;

            if (currentElement != null)
            {
                AllowView = currentElement.Result.ToList().Any(p => p.AllowView.Value && (!p.AllowView.Value || p.AllowUpdate.Value || p.AllowApprove.Value) && p.ApplicationElementDetailID == viewModel.ApplicationElementDetailID);

                AllowUpdate = currentElement.Result.ToList().Any(p => (p.AllowUpdate.Value && (!p.AllowUpdate.Value || p.AllowApprove.Value) && p.ApplicationElementDetailID == viewModel.ApplicationElementDetailID) && (p.ApplicationElementDetailID != viewModel.ApplicationElementDetailID && p.AllowUpdate.Value));

                AllowApprove = currentElement.Result.ToList().Any(p => (p.AllowApprove.Value && p.ApplicationElementDetailID == viewModel.ApplicationElementDetailID) && (p.ApplicationElementDetailID != viewModel.ApplicationElementDetailID && p.AllowApprove.Value));

            }

            viewModel.AllowView = AllowView;
            viewModel.AllowUpdate = AllowUpdate;
            viewModel.AllowApprove = AllowApprove;

            return Task.FromResult<ApplicationPermissionViewModel>(new ApplicationPermissionViewModel());
        }

        /// <summary>
        /// Add New Application Permssion into table
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public override Task<bool> AddAsync(ApplicationPermissionViewModel viewModel)
        {
            if (viewModel != null)
            {
                var applicationPermission = this._mapper.Map<ApplicationPermission>(viewModel);

                if (this._unitOfWork.ApplicationPermissionRepository.AddAsync(applicationPermission).Result)
                {
                    var resultData = this._unitOfWork.Save();

                    return Task.FromResult<bool>(resultData);
                }
                else
                {
                    return Task.FromResult<bool>(false);
                }
            }
            else
            {
                return Task.FromResult<bool>(false);
            }
        }

        public override Task<ApplicationPermissionViewModel> GetAsync(int id)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<ApplicationPermissionViewModel>> ListAsync(ApplicationPermissionViewModel viewModel)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Update the Application Permission for the users
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        public override Task<bool> UpdateAsync(ApplicationPermissionViewModel viewModel)
        {
            if (viewModel != null)
            {
                var applicationPermission = this._mapper.Map<ApplicationPermission>(viewModel);

                if (this._unitOfWork.ApplicationPermissionRepository.UpdateAsync(applicationPermission).Result)
                {
                    var resultData = this._unitOfWork.Save();

                    return Task.FromResult<bool>(resultData);
                }
                else
                {
                    return Task.FromResult<bool>(false);
                }
            }
            else
            {
                return Task.FromResult<bool>(false);
            }
        }



        /// <summary>
        /// Soft delete the chart measuremnt Data
        /// </summary>
        /// <param name="entityRecordRemoveRequestPacket">send ID and UserName</param>
        /// <returns></returns>

        Task<bool> IApplicationPermissionManager.Delete(EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket)
        {
            var data = this._unitOfWork.ApplicationPermissionRepository.DeleteAsync(entityRecordRemoveRequestPacket.ID, entityRecordRemoveRequestPacket.UserName);

            var deletestatus = this._unitOfWork.Save();
            return Task.FromResult<bool>(deletestatus);
        }
    }
}