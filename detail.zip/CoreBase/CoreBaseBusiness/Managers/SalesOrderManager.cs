﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{

    public class SalesOrderManager : BaseManager<SalesOrder, SalesOrderViewModel>, ISalesOrderManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;



        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.BaseConnectionString; } }

        private IHangfireOperation hangfireOperation;
        private IConvertEnglishToSpanish convertEnglishToSpanish;


        public SalesOrderManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext, IHangfireOperation hangfireOperation, IConvertEnglishToSpanish convertEnglishToSpanish)
            : base()
        {
            this._mapper = mapper;

            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;
            this.hangfireOperation = hangfireOperation;
            this.convertEnglishToSpanish = convertEnglishToSpanish;

        }

        /// <summary>
        ///User can get Retrieves data from SalesOrder by id.
        /// </summary>
        public override async Task<SalesOrderViewModel> GetAsync(long id)
        {
            var module = await _unitOfWork.SalesOrderRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<SalesOrderViewModel>((SalesOrder)module);
        }

        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async override Task<IEnumerable<SalesOrderViewModel>> ListAsync(SalesOrderViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<SalesOrder, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.SalesOrderRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<SalesOrderViewModel>>(module);
        }

        /// <summary>
        /// SalesOrder Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(SalesOrderViewModel viewModel)
        {
            var module = this._mapper.Map<SalesOrder>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;

            var data = this._unitOfWork.SalesOrderRepository.AddAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for SalesOrder Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(SalesOrderViewModel viewModel)
        {
            var module = this._mapper.Map<SalesOrder>(viewModel);
            var data = this._unitOfWork.SalesOrderRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from SalesOrder.
        /// </summary>
        public async override Task<int> CountAsync(SalesOrderViewModel viewModel)
        {
            Expression<Func<SalesOrder, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.SalesOrderRepository.CountAsync(condition);
        }

        /// <summary>
        ///Get All List for SalesOrder Data List
        /// </summary>
        public async override Task<IEnumerable<SalesOrderViewModel>> RangeAsync(int recordCount, SalesOrderViewModel viewModel)
        {
            Expression<Func<SalesOrder, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.SalesOrderRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<SalesOrderViewModel>>(module);
            return mappedData;
        }
        /// <summary>
        ///  Deletes record from location id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.SalesOrderRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<int> ChangeOrderFileFlag(DataTable dt, AllSalesOrderViewModel viewModel)
        {
            string pickupDate = string.Empty;
            string delieveryDate = string.Empty;
            if (viewModel.salesorder.PickupApplointment.HasValue)
            {
                pickupDate = viewModel.salesorder.PickupApplointmentString;
            }

            if (viewModel.salesorder.DeliveryAppointment.HasValue)
            {
                delieveryDate = viewModel.salesorder.DeliveryAppointmentString;
            }

            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderId", viewModel.salesorder.Id);
            parameter.Add("OrderStatusId", viewModel.salesorder.OrderStatusId);
            parameter.Add("RequestedDeliveryDate", viewModel.salesorder.RequestedDeliveryDate);
            parameter.Add("ScheduledShipDate", viewModel.salesorder.ScheduledShipDate);
            parameter.Add("MustArriveByDate", viewModel.salesorder.MustArriveByDate);
            parameter.Add("ShipToLocationId", viewModel.salesorder.ToLocationId);
            parameter.Add("ShipFromLocationId", viewModel.salesorder.FromLocationId);
            parameter.Add("OrderTypeID", viewModel.salesorder.OrderTypeId);
            parameter.Add("PickupAppointment", pickupDate);
            parameter.Add("DeliveryAppointment", delieveryDate);
            parameter.Add("MaterialPalletsType", dt);

            Dictionary<string, object> outparameter = new Dictionary<string, object>();
            outparameter.Add("IntResult", 0);

            this._unitOfWork.ExecuteProcedure("SPO_ChangeOrderFileFlag", parameter, outparameter);

            return 1;

        }

        public async Task<object> SaveAll(AllSalesOrderViewModel viewModel)
        {
            var module = this._mapper.Map<SalesOrder>(viewModel.salesorder);

            var existingSalesOrdersDetailsListEnum = await this._unitOfWork.SalesOrderDetailRepository.ListAsync(x => x.SalesOrderId == module.Id);

            List<SalesOrderDetail> existingSalesOrdersDetailsList = null;
            bool isSaelsOrdersDetailsLists = false;
            if (existingSalesOrdersDetailsListEnum != null && existingSalesOrdersDetailsListEnum.Any())
            {
                existingSalesOrdersDetailsList = existingSalesOrdersDetailsListEnum.ToList();
                isSaelsOrdersDetailsLists = true;
            }

            if (module.Id == 0)
            {
                module.OrderNumber = "";
                module.RowVersion = BitConverter.GetBytes(2345);
                module.OrderDate = DateTime.UtcNow;
                module.OrderEntryDate = DateTime.UtcNow;
                module.IsDeleted = false;
                module.CreditHoldFlag = 0;
                module.HeaderHoldFlag = 0;
                module.OrderVersionNumber = 0;
                module.ArchargesSentToAccounting = 0;
                module.HasClaim = false;
            }
            else
            {
                var existingSalesOrderDetails = await this._unitOfWork.SalesOrderRepository.GetById(module.Id);
                var modulesales = this._mapper.Map<SalesOrder>(module);

                // this code is use to modify the order file status.

                if (viewModel.salesorder.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.AssignedToShipment)
                {
                    var materialPalletsTypeList =
                     viewModel.MaterialsList.Select(x => new OrderFileSalesOrderDetailsViewModel
                     {
                         SalesOrderID = existingSalesOrderDetails.Id,
                         MaterialID = x.MaterialID,
                         Quantity = x.Quantity,
                         EquivalentPallets = x.Pallets
                     }).ToArray();

                    ArrayToDataTable exec = new ArrayToDataTable();
                    DataTable dt = exec.ConvertArrayToDataTableXML(materialPalletsTypeList);
                    var existingReadFileStatus = await this.ChangeOrderFileFlag(dt, viewModel);
                }

                // end of code.
                if (module.OrderStatusId != existingSalesOrderDetails.OrderStatusId)
                {
                    module.RowVersion = existingSalesOrderDetails.RowVersion;
                    module.OrderDate = existingSalesOrderDetails.OrderDate;
                    module.OrderEntryDate = existingSalesOrderDetails.OrderEntryDate;
                    module.IsDeleted = existingSalesOrderDetails.IsDeleted;
                    module.CreditHoldFlag = existingSalesOrderDetails.CreditHoldFlag;
                    module.HeaderHoldFlag = existingSalesOrderDetails.HeaderHoldFlag;
                    module.OrderVersionNumber = existingSalesOrderDetails.OrderVersionNumber;
                    module.HasClaim = existingSalesOrderDetails.HasClaim;
                }
            }
            if (module.FromLocationId <= 0)
            {
                module.FromLocationId = null;
            }


            if (module.CarrierId <= 0)
            {
                module.CarrierId = null;
            }

            module.FromCustomerContractId = module.FromCustomerContractId <= 0 ? (long?)null : module.FromCustomerContractId;
            module.ToCustomerContractId = module.ToCustomerContractId <= 0 ? (long?)null : module.ToCustomerContractId;
            module.ShipFromLocationContactId = module.ShipFromLocationContactId <= 0 ? (long?)null : module.ShipFromLocationContactId;
            module.ShipToLocationContactId = module.ShipToLocationContactId <= 0 ? (long?)null : module.ShipToLocationContactId;
            module.ToAddressId = module.ToAddressId <= 0 ? (long?)null : module.ToAddressId;
            module.FromAddressId = module.FromAddressId <= 0 ? (long?)null : module.FromAddressId;
            module.FromLocationId = module.FromLocationId <= 0 ? (long?)null : module.FromLocationId;
            module.CarrierId = module.CarrierId <= 0 ? (long?)null : module.CarrierId;
            module.EquipmentTypeId = module.EquipmentTypeId <= 0 ? (long?)null : module.EquipmentTypeId;
            module.FreightModeId = module.FreightModeId <= 0 ? (int?)null : module.FreightModeId;
            module.FromBusinessPartnerContractId = module.FromBusinessPartnerContractId <= 0 ? (long?)null : module.FromBusinessPartnerContractId;
            module.ToBusinessPartnerContractId = module.ToBusinessPartnerContractId <= 0 ? (long?)null : module.ToBusinessPartnerContractId;
            module.TotalOrderQuantity = viewModel.MaterialsList.Where(x => !x.IsPackage.Value).Sum(X => X.Quantity);

            if (viewModel.MaterialsList.Any())
            {
                module.TotalEquivalentPallets = viewModel.MaterialsList.Where(x => x.IsPackage.Value != true).Sum(x => x.Pallets);
            }

            var result = false;

            if (module.Id == 0)
            {
                result = await this._unitOfWork.SalesOrderRepository.AddAsync(module).ConfigureAwait(false);
            }
            else
            {
                result = await this._unitOfWork.SalesOrderRepository.UpdateAsync(module).ConfigureAwait(false);
            }

            var finalResult = true;
            if (result == true)
            {
                var modulesales = this._mapper.Map<SalesOrder>(module);

                foreach (var matrial in viewModel.MaterialsList)
                {
                    SalesOrderDetail salesOrderDetailMat = new SalesOrderDetail();

                    if (matrial.Quantity <= 0 && matrial.ShippedQuantity <= 0)
                    {
                        continue;
                    }

                    if (modulesales.Id == 0)
                    {
                        salesOrderDetailMat.SalesOrder = modulesales;
                    }
                    else
                    {
                        salesOrderDetailMat.SalesOrderId = modulesales.Id;
                    }

                    salesOrderDetailMat.MaterialId = matrial.MaterialID;
                    salesOrderDetailMat.ChargeId = null;
                    salesOrderDetailMat.Quantity = matrial.Quantity;
                    salesOrderDetailMat.EquivalentPallets = matrial.Pallets;

                    // this need to check
                    salesOrderDetailMat.ChargeComputationMethodId = null;
                    salesOrderDetailMat.OverrideChargeComputationMethodId = null;
                    salesOrderDetailMat.CommodityId = null;
                    salesOrderDetailMat.OverrideCommodityId = null;
                    salesOrderDetailMat.PriceMethodTypeId = null;
                    salesOrderDetailMat.OverridePriceMethodTypeId = null;
                    salesOrderDetailMat.RateValue = null;
                    salesOrderDetailMat.ModifiedRateValue = null;
                    salesOrderDetailMat.InvoicedAmount = 0;
                    salesOrderDetailMat.QuantityFilled = matrial.ShippedQuantity > 0 ? (decimal?)matrial.ShippedQuantity : null;

                    bool showOnBol = true;

                    var materialCharge = viewModel.locationMaterial.FirstOrDefault(p => p.MaterialID == matrial.MaterialID && p.ChargeID > 0);

                    if (materialCharge != null)
                    {
                        showOnBol = materialCharge.ShowOnBOL;
                    }


                    salesOrderDetailMat.ShowOnBol = showOnBol;
                    salesOrderDetailMat.OverrideShowOnBol = null;
                    salesOrderDetailMat.IsRequired = false;
                    salesOrderDetailMat.ClientId = modulesales.ClientId;
                    salesOrderDetailMat.IsDeleted = false;
                    salesOrderDetailMat.CreatedBy = modulesales.CreatedBy;

                    salesOrderDetailMat.IsAutoAdded = false;
                    salesOrderDetailMat.IsDefault = false;
                    salesOrderDetailMat.IsModified = false;

                    // end varification


                    if (module.Id > 0)
                    {
                        var existingMaterail = isSaelsOrdersDetailsLists ? existingSalesOrdersDetailsList.FirstOrDefault(x => x.MaterialId == salesOrderDetailMat.MaterialId && x.ChargeId == null && x.SalesOrderId == module.Id && x.IsDeleted == false) : null;

                        if (existingMaterail != null)
                        {
                            var materialElements = existingMaterail;

                            //if (materialElements.Quantity != matrial.Quantity)
                            {
                                materialElements.Quantity = matrial.Quantity;
                                materialElements.QuantityFilled = matrial.ShippedQuantity > 0 ? (decimal?)matrial.ShippedQuantity : null;
                                materialElements.EquivalentPallets = matrial.Pallets;
                                await this._unitOfWork.SalesOrderDetailRepository.UpdateAsync(materialElements).ConfigureAwait(false);
                                existingSalesOrdersDetailsList.Remove(existingMaterail);
                            }
                        }
                        else
                        {
                            await this._unitOfWork.SalesOrderDetailRepository.AddAsync(salesOrderDetailMat).ConfigureAwait(false);
                        }

                    }
                    else
                    {
                        await this._unitOfWork.SalesOrderDetailRepository.AddAsync(salesOrderDetailMat).ConfigureAwait(false);
                    }
                }

                foreach (var orderMaterial in viewModel.locationMaterial)
                {
                    SalesOrderDetail saleOrderDetail = new SalesOrderDetail();
                    if (module.Id == 0)
                    {
                        saleOrderDetail.SalesOrder = modulesales;
                    }
                    else
                    {
                        saleOrderDetail.SalesOrderId = modulesales.Id;
                    }

                    saleOrderDetail.MaterialId = orderMaterial.MaterialID <= 0 ? (long?)null : orderMaterial.MaterialID;
                    saleOrderDetail.ChargeId = orderMaterial.ChargeID;
                    saleOrderDetail.Quantity = orderMaterial.ChargeUnit;
                    saleOrderDetail.ChargeComputationMethodId = Convert.ToInt32(orderMaterial.RateTypeID);
                    saleOrderDetail.OverrideChargeComputationMethodId = orderMaterial.overrideRateTypeID == 0 ? (int?)null : Convert.ToInt32(orderMaterial.overrideRateTypeID);
                    saleOrderDetail.CommodityId = orderMaterial.CommodityID > 0 ? orderMaterial.CommodityID : (long?)null;
                    saleOrderDetail.OverrideCommodityId = orderMaterial.overrideCommodityID == 0 ? (long?)null : orderMaterial.overrideCommodityID;
                    saleOrderDetail.PriceMethodTypeId = orderMaterial.PriceMethodID;
                    saleOrderDetail.OverridePriceMethodTypeId = orderMaterial.overridePriceMethodID == 0 ? (int?)null : Convert.ToInt32(orderMaterial.overridePriceMethodID);
                    saleOrderDetail.QuantityFilled = null;
                    saleOrderDetail.ShowOnBol = orderMaterial.ShowOnBOL;
                    saleOrderDetail.OverrideShowOnBol = orderMaterial.overrideShowOnBOL ? 1 : 0;
                    saleOrderDetail.IsRequired = orderMaterial.IsManual ? false : true;
                    saleOrderDetail.ClientId = modulesales.ClientId;
                    saleOrderDetail.IsDeleted = false;
                    saleOrderDetail.RateValue = orderMaterial.RateValue;
                    saleOrderDetail.ModifiedRateValue = orderMaterial.overrideRateValue;
                    saleOrderDetail.InvoicedAmount = orderMaterial.Amount;
                    saleOrderDetail.LineItemAdjustment = orderMaterial.overrideAmount;

                    if (module.Id == 0)
                    {
                        if (orderMaterial.IsAutoAdded)
                        {
                            saleOrderDetail.IsAutoAdded = true;
                            saleOrderDetail.IsModified = false;
                        }
                        else
                        {
                            saleOrderDetail.IsAutoAdded = false;
                            saleOrderDetail.IsModified = true;
                        }
                    }


                    if (module.Id > 0)
                    {
                        var existingMaterail = isSaelsOrdersDetailsLists ? existingSalesOrdersDetailsList.FirstOrDefault(x => x.SalesOrderId == module.Id && x.MaterialId == orderMaterial.MaterialID && x.IsDeleted == false && x.ChargeId == orderMaterial.ChargeID) : null;

                        if (orderMaterial.MaterialID <= 0)
                        {
                            existingMaterail = isSaelsOrdersDetailsLists ? existingSalesOrdersDetailsList.FirstOrDefault(x => x.SalesOrderId == module.Id && x.MaterialId == null && x.IsDeleted == false && x.ChargeId == orderMaterial.ChargeID) : null;
                        }

                        if (existingMaterail != null)
                        {
                            var materialElements = existingMaterail;
                            materialElements.SalesOrderId = modulesales.Id;
                            //materialElements.SalesOrder = modulesales;
                            materialElements.MaterialId = orderMaterial.MaterialID <= 0 ? (long?)null : orderMaterial.MaterialID;
                            materialElements.ChargeId = orderMaterial.ChargeID;
                            materialElements.Quantity = orderMaterial.ChargeUnit;
                            materialElements.ChargeComputationMethodId = Convert.ToInt32(orderMaterial.RateTypeID);
                            materialElements.OverrideChargeComputationMethodId = orderMaterial.overrideRateTypeID == 0 ? (int?)null : Convert.ToInt32(orderMaterial.overrideRateTypeID);
                            materialElements.CommodityId = orderMaterial.CommodityID > 0 ? orderMaterial.CommodityID : (long?)null;
                            materialElements.OverrideCommodityId = orderMaterial.overrideCommodityID == 0 ? (long?)null : orderMaterial.overrideCommodityID;
                            materialElements.PriceMethodTypeId = orderMaterial.PriceMethodID;
                            materialElements.OverridePriceMethodTypeId = orderMaterial.overridePriceMethodID == 0 ? (int?)null : Convert.ToInt32(orderMaterial.overridePriceMethodID);
                            //materialElements.QuantityFilled = null;
                            materialElements.ShowOnBol = orderMaterial.ShowOnBOL;
                            materialElements.OverrideShowOnBol = orderMaterial.overrideShowOnBOL ? 1 : 0;
                            materialElements.IsRequired = orderMaterial.IsManual ? false : true;
                            materialElements.ClientId = modulesales.ClientId;

                            materialElements.IsDeleted = false;

                            if (orderMaterial.IsAutoAdded)
                            {
                                materialElements.IsAutoAdded = orderMaterial.IsAutoAdded;

                                // this section recalcualted value of ratevalue and InvoiceAmount 
                            }
                            else
                            {
                                materialElements.IsAutoAdded = false;
                                materialElements.IsModified = true;
                                materialElements.ModifiedRateValue = orderMaterial.overrideRateValue;
                                materialElements.InvoicedAmount = orderMaterial.Amount;
                                materialElements.LineItemAdjustment = orderMaterial.overrideAmount;
                            }

                            await this._unitOfWork.SalesOrderDetailRepository.UpdateAsync(materialElements).ConfigureAwait(false);
                            existingSalesOrdersDetailsList.Remove(materialElements);

                        }
                        else
                        {
                            saleOrderDetail.CreatedBy = modulesales.CreatedBy;
                            await this._unitOfWork.SalesOrderDetailRepository.AddAsync(saleOrderDetail).ConfigureAwait(false);
                        }

                    }
                    else
                    {
                        saleOrderDetail.CreatedBy = modulesales.CreatedBy;
                        await this._unitOfWork.SalesOrderDetailRepository.AddAsync(saleOrderDetail).ConfigureAwait(false);
                    }
                }
            }

            if (existingSalesOrdersDetailsList != null && existingSalesOrdersDetailsList.Count() > 0)
            {
                foreach (var existingSaelsorderItems in existingSalesOrdersDetailsList)
                {
                    await this._unitOfWork.SalesOrderDetailRepository.RemoveAsync(existingSaelsorderItems).ConfigureAwait(false);
                }
            }


            finalResult = this._unitOfWork.Save();


            if (finalResult == true)
            {

                string pickupDate = string.Empty;
                string delieveryDate = string.Empty;
                if (viewModel.salesorder.PickupApplointment.HasValue)
                {
                    pickupDate = viewModel.salesorder.PickupApplointmentString;
                }

                if (viewModel.salesorder.DeliveryAppointment.HasValue)
                {
                    delieveryDate = viewModel.salesorder.DeliveryAppointmentString;

                }

                if (!string.IsNullOrEmpty(pickupDate) || !string.IsNullOrEmpty(delieveryDate))
                {
                    this.hangfireOperation.SendAppointmentDetails(pickupDate, delieveryDate, module.Id, module.OrderTypeId.Value);
                }



                var orderNumber = this.hangfireOperation.CreateOrderNumberAndSave(module.Id, module.OrderTypeId.Value, false);


                if (!string.IsNullOrEmpty(orderNumber))
                {
                    module.OrderNumber = orderNumber;
                }

                // this section send process to background job

                //if (viewModel.salesorder.Id == 0)
                {
                    // recalculate only for new order
                    this.hangfireOperation.CalculateARChargesAgain(module.Id);
                    this.hangfireOperation.CalculateAPChargesAgain(module.Id, module.OrderTypeId.Value);



                }

                // this line send the order for shipment.
                // this code comment on demand of Ram pyare yadav on 25-Nov-2020.
                // he is said due to this shipment service saving null value of shipemnet. 
                // this.hangfireOperation.SendForShippingOrder(module.Id, module.OrderTypeId.Value);

                return await Task.FromResult<object>(module).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult<object>(null).ConfigureAwait(false);
            }

        }

        public async Task<object> SaveAllStockTransfer(AllSalesOrderViewModel viewModel)
        {
            var module = this._mapper.Map<StockTransferOrder>(viewModel.salesorder);

            var existingSalesOrdersDetailsListEnum = await this._unitOfWork.StockTransferOrderDetailRepository.ListAsync(x => x.StockTransferOrderId == module.Id);



            List<StockTransferOrderDetail> existingSalesOrdersDetailsList = null;
            bool isSaelsOrdersDetailsLists = false;
            if (existingSalesOrdersDetailsListEnum != null && existingSalesOrdersDetailsListEnum.Any())
            {
                existingSalesOrdersDetailsList = existingSalesOrdersDetailsListEnum.ToList();
                isSaelsOrdersDetailsLists = true;
            }

            if (module.Id == 0)
            {
                module.OrderNumber = "";
                module.RowVersion = BitConverter.GetBytes(2345);
                module.OrderDate = DateTime.UtcNow;
                module.OrderEntryDate = DateTime.UtcNow;
                module.IsDeleted = false;
                module.CreditHoldFlag = 1;
                module.HeaderHoldFlag = 1;
                module.OrderVersionNumber = 0;
                module.ArchargesSentToAccounting = 0;
                module.HasClaim = false;
            }
            else
            {
                //update status on shipment table
                //this.hangfireOperation.UpdateOrderFileFlag(viewModel);

                var existingSalesOrderDetails = await this._unitOfWork.StockTransferOrderRepository.GetById(module.Id);


                var materialPalletsTypeList =
                   viewModel.MaterialsList.Select(x => new OrderFileSalesOrderDetailsViewModel
                   {
                       SalesOrderID = existingSalesOrderDetails.Id,
                       MaterialID = x.MaterialID,
                       Quantity = x.Quantity,
                       EquivalentPallets = x.Pallets
                   }).ToArray();

                ArrayToDataTable exec = new ArrayToDataTable();
                DataTable dt = exec.ConvertArrayToDataTableXML(materialPalletsTypeList);
                var existingReadFileStatus = await this.ChangeOrderFileFlag(dt, viewModel);




                if (module.OrderStatusId != existingSalesOrderDetails.OrderStatusId)
                {
                    module.RowVersion = existingSalesOrderDetails.RowVersion;
                    module.OrderDate = existingSalesOrderDetails.OrderDate;
                    module.OrderEntryDate = existingSalesOrderDetails.OrderEntryDate;
                    module.IsDeleted = existingSalesOrderDetails.IsDeleted;
                    module.CreditHoldFlag = existingSalesOrderDetails.CreditHoldFlag;
                    module.HeaderHoldFlag = existingSalesOrderDetails.HeaderHoldFlag;
                    module.OrderVersionNumber = existingSalesOrderDetails.OrderVersionNumber;
                    module.HasClaim = existingSalesOrderDetails.HasClaim;

                }

            }


            if (module.FromLocationId <= 0)
            {
                module.FromLocationId = null;
            }


            if (module.CarrierId <= 0)
            {
                module.CarrierId = null;
            }

            module.FromCustomerContractId = module.FromCustomerContractId <= 0 ? (long?)null : module.FromCustomerContractId;
            module.ToCustomerContractId = module.ToCustomerContractId <= 0 ? (long?)null : module.ToCustomerContractId;
            module.ShipFromLocationContactId = module.ShipFromLocationContactId <= 0 ? (long?)null : module.ShipFromLocationContactId;
            module.ShipToLocationContactId = module.ShipToLocationContactId <= 0 ? (long?)null : module.ShipToLocationContactId;
            module.ToAddressId = module.ToAddressId <= 0 ? (long?)null : module.ToAddressId;
            module.FromAddressId = module.FromAddressId <= 0 ? (long?)null : module.FromAddressId;
            module.FromLocationId = module.FromLocationId <= 0 ? (long?)null : module.FromLocationId;
            module.CarrierId = module.CarrierId <= 0 ? (long?)null : module.CarrierId;
            module.EquipmentTypeId = module.EquipmentTypeId <= 0 ? (long?)null : module.EquipmentTypeId;
            module.FreightModeId = module.FreightModeId <= 0 ? (int?)null : module.FreightModeId;
            module.FromBusinessPartnerContractId = module.FromBusinessPartnerContractId <= 0 ? (long?)null : module.FromBusinessPartnerContractId;
            module.ToBusinessPartnerContractId = module.ToBusinessPartnerContractId <= 0 ? (long?)null : module.ToBusinessPartnerContractId;
            module.TotalOrderQuantity = viewModel.MaterialsList.Where(x => !x.IsPackage.Value).Sum(X => X.Quantity);


            var result = false;

            if (module.Id == 0)
            {
                result = await this._unitOfWork.StockTransferOrderRepository.AddAsync(module).ConfigureAwait(false);
            }
            else
            {
                result = await this._unitOfWork.StockTransferOrderRepository.UpdateAsync(module).ConfigureAwait(false);
            }

            var finalResult = true;
            if (result == true)
            {
                var modulesales = this._mapper.Map<StockTransferOrder>(module);



                foreach (var matrial in viewModel.MaterialsList)
                {
                    StockTransferOrderDetail salesOrderDetailMat = new StockTransferOrderDetail();

                    if (matrial.Quantity == 0 && matrial.ShippedQuantity == 0)
                    {
                        continue;
                    }

                    if (modulesales.Id == 0)
                    {
                        salesOrderDetailMat.StockTransferOrder = modulesales;
                    }
                    else
                    {
                        salesOrderDetailMat.StockTransferOrderId = modulesales.Id;
                    }

                    salesOrderDetailMat.MaterialId = matrial.MaterialID;
                    salesOrderDetailMat.ChargeId = null;
                    salesOrderDetailMat.Quantity = matrial.Quantity;
                    salesOrderDetailMat.EquivalentPallets = matrial.Pallets;

                    // this need to check
                    salesOrderDetailMat.ChargeComputationMethodId = null;
                    salesOrderDetailMat.OverrideChargeComputationMethodId = null;
                    salesOrderDetailMat.CommodityId = null;
                    salesOrderDetailMat.OverrideCommodityId = null;
                    salesOrderDetailMat.PriceMethodTypeId = null;
                    salesOrderDetailMat.OverridePriceMethodTypeId = null;
                    salesOrderDetailMat.RateValue = null;
                    salesOrderDetailMat.ModifiedRateValue = null;
                    salesOrderDetailMat.InvoicedAmount = 0;
                    salesOrderDetailMat.QuantityFilled = null;

                    bool showOnBol = true;

                    var materialCharge = viewModel.locationMaterial.FirstOrDefault(p => p.MaterialID == matrial.MaterialID && p.ChargeID > 0);

                    if (materialCharge != null)
                    {
                        showOnBol = materialCharge.ShowOnBOL;
                    }


                    salesOrderDetailMat.ShowOnBol = showOnBol;
                    salesOrderDetailMat.OverrideShowOnBol = null;
                    salesOrderDetailMat.IsRequired = false;
                    salesOrderDetailMat.ClientId = modulesales.ClientId;
                    salesOrderDetailMat.IsDeleted = false;
                    salesOrderDetailMat.CreatedBy = modulesales.CreatedBy;

                    salesOrderDetailMat.IsAutoAdded = false;
                    salesOrderDetailMat.IsDefault = false;
                    salesOrderDetailMat.IsModified = false;

                    // end varification


                    if (module.Id > 0)
                    {
                        var existingMaterail = isSaelsOrdersDetailsLists ? existingSalesOrdersDetailsList.FirstOrDefault(x => x.MaterialId == salesOrderDetailMat.MaterialId && x.ChargeId == null && x.StockTransferOrderId == module.Id && x.IsDeleted == false) : null;

                        if (existingMaterail != null)
                        {
                            var materialElements = existingMaterail;

                            //if (materialElements.Quantity != matrial.Quantity)
                            {
                                materialElements.Quantity = matrial.Quantity;
                                materialElements.EquivalentPallets = matrial.Pallets;
                                await this._unitOfWork.StockTransferOrderDetailRepository.UpdateAsync(materialElements).ConfigureAwait(false);

                                existingSalesOrdersDetailsList.Remove(existingMaterail);
                            }
                        }
                        else
                        {
                            await this._unitOfWork.StockTransferOrderDetailRepository.AddAsync(salesOrderDetailMat).ConfigureAwait(false);
                        }

                    }
                    else
                    {
                        await this._unitOfWork.StockTransferOrderDetailRepository.AddAsync(salesOrderDetailMat).ConfigureAwait(false);
                    }
                }


            }

            if (existingSalesOrdersDetailsList != null && existingSalesOrdersDetailsList.Count() > 0)
            {
                foreach (var existingSaelsorderItems in existingSalesOrdersDetailsList)
                {
                    await this._unitOfWork.StockTransferOrderDetailRepository.RemoveAsync(existingSaelsorderItems).ConfigureAwait(false);
                }
            }


            finalResult = this._unitOfWork.Save();


            if (finalResult == true)
            {

                string pickupDate = string.Empty;
                string delieveryDate = string.Empty;
                if (viewModel.salesorder.PickupApplointment.HasValue)
                {
                    pickupDate = viewModel.salesorder.PickupApplointment.Value.ConvertToString();
                }

                if (viewModel.salesorder.DeliveryAppointment.HasValue)
                {
                    delieveryDate = viewModel.salesorder.DeliveryAppointment.Value.ConvertToString();

                }

                if (!string.IsNullOrEmpty(pickupDate) || !string.IsNullOrEmpty(delieveryDate))
                {
                    this.hangfireOperation.SendAppointmentDetails(pickupDate, delieveryDate, module.Id, module.OrderTypeId.Value);
                }

                var orderNumber = this.hangfireOperation.CreateOrderNumberAndSave(module.Id, module.OrderTypeId.Value, false);
                if (!string.IsNullOrEmpty(orderNumber))
                {
                    module.OrderNumber = orderNumber;
                }

                // this section send process to background job
                this.hangfireOperation.CalculateAPChargesAgain(module.Id, module.OrderTypeId.Value);
                //this.hangfireOperation.SendForShippingOrder(module.Id, module.OrderTypeId.Value);
                return await Task.FromResult<object>(module).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult<object>(null).ConfigureAwait(false);
            }

        }

        public async Task<CommentModel> GetComment(MaterialCommonModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ContractID", flagViewModel.ContractID);
                parameter.Add("@LocationID", flagViewModel.LocationID);
                parameter.Add("@ClientID", flagViewModel.ClientID);
                var usersViewModels = con.Query<CommentModel>("SPO_GetCommentByContractLocation", parameter, commandType: CommandType.StoredProcedure);

                if (flagViewModel.OrderID.HasValue && flagViewModel.OrderID.Value > 0)
                {
                    DynamicParameters parameterForOrders = new DynamicParameters();
                    parameterForOrders.Add("@OrderID", flagViewModel.OrderID.Value);
                    parameterForOrders.Add("@OrderTypeID", flagViewModel.OrderTypeID.Value);
                    var additionalComments = con.Query<string>("SPO_GetOrderAdditionalInstructionComments", parameterForOrders, commandType: CommandType.StoredProcedure);
                    usersViewModels.FirstOrDefault().AdditionalComment = additionalComments.FirstOrDefault();
                }

                con.Close();
                return usersViewModels.FirstOrDefault();
            }
        }

        public async Task<IEnumerable<SalesOrderViewModel>> OrderListCount(CommonOrder flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@OrgnizationID", flagViewModel.OrganizationID);
                parameter.Add("@IsMass", flagViewModel.IsMass);
                var usersViewModels = con.Query<SalesOrderViewModel>("SPO_GetOrderListCmByOrganization", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }
        public async Task<IEnumerable<CommonOrder>> OrderList(CommonOrder salesOrderViewModel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            if (salesOrderViewModel != null && string.IsNullOrWhiteSpace(salesOrderViewModel.FilterOn))
            {
                parameter.Add("PageNumber", salesOrderViewModel.PageNo);
                parameter.Add("PageSize", salesOrderViewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(salesOrderViewModel.SortColumn))
            {
                parameter.Add("SortColumn", salesOrderViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(salesOrderViewModel.SortOrder))
            {
                parameter.Add("SortOrder", salesOrderViewModel.SortOrder);
            }

            parameter.Add("OrgnizationID", salesOrderViewModel.OrganizationID);
            //parameter.Add("@IsMass", salesOrderViewModel.IsMass);


            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetOrderListCmByOrganization", parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CommonOrder>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CommonOrder>>(FilterResult<CommonOrder>.GetFilteredResult(finalResult, salesOrderViewModel.FilterOn, salesOrderViewModel.PageSize));
            }

            return null;
        }
        //public async Task<IEnumerable<SalesOrderViewModel>> OrderList(CommonOrder flagViewModel)
        //{
        //    using (SqlConnection con = new SqlConnection(this.ConnectionString))
        //    {
        //        if (con.State == ConnectionState.Closed)
        //        {
        //            con.Open();
        //        }
        //        Dictionary<string, object> parameter = new Dictionary<string, object>();
        //        if (flagViewModel != null && string.IsNullOrWhiteSpace(flagViewModel.FilterOn))
        //        {
        //            parameter.Add("PageNumber", flagViewModel.PageNo);
        //            parameter.Add("PageSize", flagViewModel.PageSize);
        //        }

        //        if (!string.IsNullOrWhiteSpace(flagViewModel.SortColumn))
        //        {
        //            parameter.Add("SortColumn", flagViewModel.SortColumn);
        //        }

        //        if (!string.IsNullOrWhiteSpace(flagViewModel.SortOrder))
        //        {
        //            parameter.Add("SortOrder", flagViewModel.SortOrder);
        //        }



        //        parameter.Add("@OrgnizationID", flagViewModel.OrgnizationID);
        //        parameter.Add("@IsMass", flagViewModel.IsMass);


        //        //DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetOrderListCmByOrganization", parameter);
        //        var usersViewModels = con.Query<SalesOrderViewModel>("SPO_GetOrderListCmByOrganization", parameter, commandType: CommandType.StoredProcedure);
        //        //if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
        //        //{
        //        //    var finalResult = ConvertDataTabe.CreateListFromTable<SalesOrderViewModel>(ds.Tables[0]);
        //        //    return await Task.FromResult<IEnumerable<SalesOrderViewModel>>(FilterResult<SalesOrderViewModel>.
        //        //        GetFilteredResult(finalResult, flagViewModel.FilterOn, flagViewModel.PageSize));
        //        //}

        //        //return null;
        //        con.Close();
        //        return usersViewModels;
        //       // return ds;
        //    }
        //}



        public async Task<List<BulkOrderViewModel>> SaveBulkOrder(BulkOrderViewModel[] flagViewModel)
        {
            ArrayToDataTable exec = new ArrayToDataTable();
            DataTable dt = exec.ConvertArrayToDataTableXML(flagViewModel);
            List<BulkOrderViewModel> result = new List<BulkOrderViewModel>();

            using (SqlConnection conn = new SqlConnection(this.ConnectionString))
            {
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                if (flagViewModel[0].Code == "STO" || flagViewModel[0].Code == "COL")
                {
                    cmd.CommandText = "SPO_BulkStockTransferOrderDetails";
                }
                else
                {
                    cmd.CommandText = "SPO_BulkOrderDetails";
                }
                SqlParameter param = cmd.Parameters.AddWithValue("@SalesOrderType", dt);
                conn.Open();
                //SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                //DataSet dsResult = new DataSet();
                //sqlDataAdapter.SelectCommand = cmd;
                //sqlDataAdapter.Fill(dsResult);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var data = new BulkOrderViewModel()
                        {
                            RequestedDeliveryDate = reader.GetString(reader.GetOrdinal("RequestedDeliveryDate")),
                            //         RequestedDeliveryDate = reader.IsDBNull(reader.GetOrdinal("RequestedDeliveryDate")) ?
                            //(DateTime?)null :
                            //(DateTime?)reader.GetDateTime(reader.GetOrdinal("RequestedDeliveryDate")),
                            //         ScheduledShipDate = reader.IsDBNull(reader.GetOrdinal("ScheduledShipDate")) ?
                            //(DateTime?)null :
                            //(DateTime?)reader.GetDateTime(reader.GetOrdinal("ScheduledShipDate")),
                            //         MustArriveByDate = reader.IsDBNull(reader.GetOrdinal("MustArriveByDate")) ?
                            //(DateTime?)null :
                            //(DateTime?)reader.GetDateTime(reader.GetOrdinal("MustArriveByDate")),
                            ScheduledShipDate = reader.GetString(reader.GetOrdinal("ScheduledShipDate")),
                            MustArriveByDate = reader.GetString(reader.GetOrdinal("MustArriveByDate")),
                            PurchaseOrderNumber = reader.GetString(reader.GetOrdinal("PurchaseOrderNumber")),
                            TrailerNumber = reader.GetString(reader.GetOrdinal("TrailerNumber")),
                            MaterialID = reader.GetInt64(reader.GetOrdinal("MaterialID")),
                            CarrierId = reader.GetInt64(reader.GetOrdinal("CarrierId")),
                            ToLocationId = reader.GetInt64(reader.GetOrdinal("ToLocationId")),
                            ShipToTypeId = reader.GetInt64(reader.GetOrdinal("ShipToTypeId")),
                            ToContractId = reader.GetInt64(reader.GetOrdinal("ToContractId")),
                            TransplaceOrderComment = reader.GetString(reader.GetOrdinal("TransplaceOrderComment")),
                            TransplaceDeliveryComment = reader.GetString(reader.GetOrdinal("TransplaceDeliveryComment")),
                            CreatedBy = reader.GetString(reader.GetOrdinal("CreatedBy")),
                            OrderNumber = reader.GetString(reader.GetOrdinal("OrderNumber")),
                            OrderStatusId = reader.GetInt32(reader.GetOrdinal("OrderStatusId")),
                            OrderTypeId = reader.GetInt32(reader.GetOrdinal("OrderTypeId")),
                            EquipmentTypeId = reader.GetInt64(reader.GetOrdinal("EquipmentTypeId")),
                            ClientId = reader.GetInt32(reader.GetOrdinal("ClientId")),
                            ShipFromTypeId = reader.GetInt64(reader.GetOrdinal("ShipFromTypeId")),
                            FromCustomerContractId = reader.GetInt64(reader.GetOrdinal("FromCustomerContractId")),
                            FromLocationId = reader.GetInt64(reader.GetOrdinal("FromLocationId")),
                            SupressEmailConfirmation = reader.GetString(reader.GetOrdinal("SupressEmailConfirmation")),
                            Code = reader.GetString(reader.GetOrdinal("Code")),
                            OrderQuantity = reader.GetDecimal(reader.GetOrdinal("OrderQuantity")),
                            MaterialName = reader.GetString(reader.GetOrdinal("MaterialName")),
                            Carrier = reader.GetString(reader.GetOrdinal("Carrier")),
                            ToLocationName = reader.GetString(reader.GetOrdinal("ToLocationName")),
                            ShipToTypeName = reader.GetString(reader.GetOrdinal("ShipToTypeName")),
                            ToContractName = reader.GetString(reader.GetOrdinal("ToContractName")),
                            ShipFromTypeName = reader.GetString(reader.GetOrdinal("ShipFromTypeName")),
                            FromContractName = reader.GetString(reader.GetOrdinal("FromContractName")),
                            FromLocationName = reader.GetString(reader.GetOrdinal("FromLocationName")),
                            EquipmentTypeName = reader.GetString(reader.GetOrdinal("EquipmentTypeName"))
                        };
                        result.Add(data);
                    }
                }
                conn.Close();
            }
            this.hangfireOperation.SaveOrderConvertLanguage(result);
            return result;
        }


        public async Task<bool> SendARChargesTOMASAsync(SalesOrderViewModel salesOrderViewModel)
        {
            this.hangfireOperation.ARChargeTOMAS(salesOrderViewModel.Id, salesOrderViewModel.OrderTypeId.Value);
            return false;
        }


        // public override async Task<SalesOrderViewModel> GetAsync(int id)
        public async Task<IEnumerable<SalesOrderViewModel>> GetAllShipToData(int id, int clientId, string SelectedTab)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@OrderID", id);
                parameter.Add("@ClientId", clientId);
                parameter.Add("@InboundOutbound", SelectedTab);
                var shipToDataViewModels = con.Query<SalesOrderViewModel>("SPO_GetAllDataOfShipToLocation", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return shipToDataViewModels;
            }
        }


        /// <summary>
        ///  Retrieves All data from Charge Table along with the foriend key details
        /// </summary>
        /// <returns> Returns list of Charge Details</returns>
        public async Task<IEnumerable<SalesOrderListViewModel>> GetAllSalesOrderList(SalesOrderListViewModel salesOrderViewModel)
        {
            string filterStr = GetFilterDataStr(salesOrderViewModel);

            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (salesOrderViewModel != null)
            {
                chargeParameter.Add("PageNumber", salesOrderViewModel.PageNo);
                if (!string.IsNullOrEmpty(salesOrderViewModel.FilterOn) || !string.IsNullOrEmpty(filterStr))
                    chargeParameter.Add("PageSize", 0);
                else
                    chargeParameter.Add("PageSize", salesOrderViewModel.PageSize);

                chargeParameter.Add("ClientId", salesOrderViewModel.ClientID);
                chargeParameter.Add("LocationType", salesOrderViewModel.LocationType);
                chargeParameter.Add("RoleName", salesOrderViewModel.RoleName);
                chargeParameter.Add("InboundOutbound", salesOrderViewModel.InboundOutbound);
                chargeParameter.Add("WhereClause", filterStr);
            }

            if (string.IsNullOrWhiteSpace(salesOrderViewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", salesOrderViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(salesOrderViewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", salesOrderViewModel.SortOrder);
            }

            chargeParameter.Add("UserID", salesOrderViewModel.UserLoginID);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetSalesOrderDetailsData", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<SalesOrderListViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<SalesOrderListViewModel>>(FilterResult<SalesOrderListViewModel>.GetFilteredResult(finalResult, salesOrderViewModel.FilterOn, salesOrderViewModel.PageSize));
            }

            return null;
        }

        public Task<IEnumerable<SalesOrderListViewModel>> GetAllSalesOrderList(SalesOrderListViewModel salesOrderViewModel,ref int TotalCount)
        {
            string filterStr = GetFilterDataStr(salesOrderViewModel);

            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (salesOrderViewModel != null)
            {
                chargeParameter.Add("PageNumber", salesOrderViewModel.PageNo);
                if (!string.IsNullOrEmpty(salesOrderViewModel.FilterOn) || !string.IsNullOrEmpty(filterStr))
                    chargeParameter.Add("PageSize", 0);
                else
                    chargeParameter.Add("PageSize", salesOrderViewModel.PageSize);

                chargeParameter.Add("ClientId", salesOrderViewModel.ClientID);
                chargeParameter.Add("LocationType", salesOrderViewModel.LocationType);
                chargeParameter.Add("RoleName", salesOrderViewModel.RoleName);
                chargeParameter.Add("InboundOutbound", salesOrderViewModel.InboundOutbound);
                chargeParameter.Add("WhereClause", filterStr);
            }

            if (string.IsNullOrWhiteSpace(salesOrderViewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", salesOrderViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(salesOrderViewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", salesOrderViewModel.SortOrder);
            }

            chargeParameter.Add("UserID", salesOrderViewModel.UserLoginID);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetSalesOrderDetailsData", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<SalesOrderListViewModel>(ds.Tables[0]);
                TotalCount = Convert.ToInt32(ds.Tables[1].Rows[0][0]);                
                return Task.FromResult<IEnumerable<SalesOrderListViewModel>>(FilterResult<SalesOrderListViewModel>.GetFilteredResult(finalResult, salesOrderViewModel.FilterOn, salesOrderViewModel.PageSize));
            }

            return null;
        }


        public string GetFilterDataStr(SalesOrderListViewModel salesOrderViewModel)
        {
            var filterStr = "";

            if (salesOrderViewModel.InboundOutbound.Trim().ToLower() == "outbound")
            {
                if (salesOrderViewModel.OrderWorkbenchFilterModal != null)
                {
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo != null && salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo != "")
                    {
                        var orderNoStr = "";
                        var orderNoVersionStr = "";
                        string[] OrderNoList = salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo.Trim().Split(",");
                        foreach (string orderno in OrderNoList)
                        {
                            int count = 0;
                            string[] ordernoList = orderno.Split(".");
                            foreach (string order in ordernoList)
                            {
                                count = count + 1;
                                if (count == 1)
                                {
                                    orderNoStr = orderNoStr + "'" + order.Trim() + "',";
                                }
                                else
                                {
                                    orderNoVersionStr = orderNoVersionStr + "'" + order.Trim() + "',";
                                }
                            }
                        }
                        orderNoStr = orderNoStr.Remove(orderNoStr.Length - 1);
                        filterStr = filterStr + "OrderNumber in (" + orderNoStr + ") and ";

                        if (orderNoVersionStr.Length > 0)
                        {
                            orderNoVersionStr = orderNoVersionStr.Remove(orderNoVersionStr.Length - 1);
                            filterStr = filterStr + "OrderVersionNumber in (" + orderNoVersionStr + ") and ";
                        }
                    }
                    //if (salesOrderViewModel.OrderWorkbenchFilterModal.SourceN != null && salesOrderViewModel.OrderWorkbenchFilterModal.SourceN != "")
                    //{
                    //    filterStr = filterStr + "Code= " + salesOrderViewModel.OrderWorkbenchFilterModal.SourceN + " and ";//OSS.Code
                    //}
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.MinOrderAmount != null && salesOrderViewModel.OrderWorkbenchFilterModal.MinOrderAmount != 0)
                    {
                        filterStr = filterStr + " OrderAmount >= " + salesOrderViewModel.OrderWorkbenchFilterModal.MinOrderAmount + " and ";
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.MaxOrderAmount != null && salesOrderViewModel.OrderWorkbenchFilterModal.MaxOrderAmount != 0)
                    {
                        filterStr = filterStr + " OrderAmount <= " + salesOrderViewModel.OrderWorkbenchFilterModal.MaxOrderAmount + " and ";

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo != null && salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo != "")
                    {
                        var shipmentNoStr = "";
                        var shipmentNoVersionStr = "";
                        string[] ShipmentNoList = salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo.Trim().Split(",");
                        foreach (string shipmentno in ShipmentNoList)
                        {
                            int count = 0;
                            string[] shipmentnoList = shipmentno.Split(".");
                            foreach (string shipment in shipmentnoList)
                            {
                                count = count + 1;
                                if (count == 1)
                                {
                                    shipmentNoStr = shipmentNoStr + "'" + shipment.Trim() + "',";
                                }
                                else
                                {
                                    shipmentNoVersionStr = shipmentNoVersionStr + "'" + shipment.Trim() + "',";
                                }
                            }
                        }
                        shipmentNoStr = shipmentNoStr.Remove(shipmentNoStr.Length - 1);
                        filterStr = filterStr + "ShipmentNumber in (" + shipmentNoStr + ") and ";

                        if (shipmentNoVersionStr.Length > 0)
                        {
                            shipmentNoVersionStr = shipmentNoVersionStr.Remove(shipmentNoVersionStr.Length - 1);
                            filterStr = filterStr + "ShipmentVersion in (" + shipmentNoVersionStr + ") and ";
                        }

                        //var shipmentNoStr = "";
                        //string[] ShipmentNoList = salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo.Trim().Split(",");
                        //foreach (string shipmentno in ShipmentNoList)
                        //{
                        //    shipmentNoStr = shipmentNoStr + shipmentno.Trim() + ",";
                        //}
                        //shipmentNoStr = shipmentNoStr.Remove(shipmentNoStr.Length - 1);
                        //filterStr = filterStr + "ShipmentNumber in (" + shipmentNoStr + ") and ";

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.PONo != null && salesOrderViewModel.OrderWorkbenchFilterModal.PONo != "")
                    {
                        filterStr = filterStr + "PurchaseOrderNumber= " + salesOrderViewModel.OrderWorkbenchFilterModal.PONo + " and ";//SO.PurchaseOrderNumber
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderTypeItems.Count() > 0)
                    {
                        var orderTypeIdStr = "";
                        foreach (var ordertypeid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderTypeItems)
                        {
                            orderTypeIdStr = orderTypeIdStr + ordertypeid.Id + ",";
                        }
                        orderTypeIdStr = orderTypeIdStr.Remove(orderTypeIdStr.Length - 1);
                        filterStr = filterStr + "OrderTypeID in (" + orderTypeIdStr + ") and ";//SO.OrderTypeID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderStatusItems.Count() > 0)
                    {
                        var orderStatusIdStr = "";
                        foreach (var orderstatusid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderStatusItems)
                        {
                            orderStatusIdStr = orderStatusIdStr + orderstatusid.Id + ",";
                        }
                        orderStatusIdStr = orderStatusIdStr.Remove(orderStatusIdStr.Length - 1);
                        filterStr = filterStr + "OrderStatusID in (" + orderStatusIdStr + ") and ";//SO.OrderStatusID

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedAllVersionItems.Count() > 0)
                    {
                        var versionIdStr = "";
                        foreach (var versionId in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedAllVersionItems)
                        {
                            versionIdStr = versionIdStr + versionId.Id + ",";
                        }
                        versionIdStr = versionIdStr.Remove(versionIdStr.Length - 1);
                        filterStr = filterStr + "Version in (" + versionIdStr + ") and ";

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderConditionItems.Count() > 0)
                    {
                        var orderConditionIdStr = "";
                        foreach (var orderconditionid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderConditionItems)
                        {
                            orderConditionIdStr = orderConditionIdStr + orderconditionid.Id + ",";
                        }
                        orderConditionIdStr = orderConditionIdStr.Remove(orderConditionIdStr.Length - 1);
                        filterStr = filterStr + "OrderConditionID in (" + orderConditionIdStr + ") and ";//SO.OrderConditionID

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromItems.Count() > 0)
                    {
                        var shipFromLocationIdStr = "";
                        foreach (var shipfromlocationid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromItems)
                        {
                            shipFromLocationIdStr = shipFromLocationIdStr + shipfromlocationid.Id + ",";
                        }
                        shipFromLocationIdStr = shipFromLocationIdStr.Remove(shipFromLocationIdStr.Length - 1);
                        filterStr = filterStr + "FromLocationID in (" + shipFromLocationIdStr + ") and ";//SO.FromLocationID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToItems.Count() > 0)
                    {
                        var shipToLocationIdStr = "";
                        foreach (var shiptolocationid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToItems)
                        {
                            shipToLocationIdStr = shipToLocationIdStr + shiptolocationid.Id + ",";
                        }
                        shipToLocationIdStr = shipToLocationIdStr.Remove(shipToLocationIdStr.Length - 1);
                        filterStr = filterStr + "ToLocationID in (" + shipToLocationIdStr + ") and ";//SO.ToLocationID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromTypeItems.Count() > 0)
                    {
                        var shipFromTypeIdStr = "";
                        foreach (var shipfromtypeid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromTypeItems)
                        {
                            shipFromTypeIdStr = shipFromTypeIdStr + shipfromtypeid.Id + ",";
                        }
                        shipFromTypeIdStr = shipFromTypeIdStr.Remove(shipFromTypeIdStr.Length - 1);
                        filterStr = filterStr + "LocationTypeID in (" + shipFromTypeIdStr + ") and ";//TLocation.LocationTypeID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToTypeItems.Count() > 0)
                    {
                        var shipToTypeIdStr = "";
                        foreach (var shiptotypeid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToTypeItems)
                        {
                            shipToTypeIdStr = shipToTypeIdStr + shiptotypeid.Id + ",";
                        }
                        shipToTypeIdStr = shipToTypeIdStr.Remove(shipToTypeIdStr.Length - 1);
                        filterStr = filterStr + "LocationTypeID in (" + shipToTypeIdStr + ") and ";//TLocation.LocationTypeID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedMaterialItems.Count() > 0)
                    {
                        var materialIdStr = "";
                        foreach (var materialid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedMaterialItems)
                        {
                            materialIdStr = materialIdStr + materialid.Id + ",";
                        }
                        materialIdStr = materialIdStr.Remove(materialIdStr.Length - 1);
                        filterStr = filterStr + "MID in (" + materialIdStr + ") and ";//M.ID 
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedCarrierItems.Count() > 0)
                    {
                        var carrierIdStr = "";
                        foreach (var carrierid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedCarrierItems)
                        {
                            carrierIdStr = carrierIdStr + carrierid.Id + ",";
                        }
                        carrierIdStr = carrierIdStr.Remove(carrierIdStr.Length - 1);
                        filterStr = filterStr + "CID in (" + carrierIdStr + ") and ";//C.ID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSalesManagersItems.Count() > 0)
                    {
                        var salesManagerIdStr = "";
                        foreach (var salesmanager in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSalesManagersItems)
                        {
                            salesManagerIdStr = salesManagerIdStr + "'" + salesmanager.Name + "',"; // + salesmanager.Name + ", ";
                        }
                        salesManagerIdStr = salesManagerIdStr.Remove(salesManagerIdStr.Length - 1);
                        filterStr = filterStr + " SalesManager in (" + salesManagerIdStr + ") and ";
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSourceItems.Count() > 0)
                    {
                        var sourceNameStr = "";
                        foreach (var sourcename in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSourceItems)
                        {
                            sourceNameStr = sourceNameStr + "'" + sourcename.Name + "',";
                        }
                        sourceNameStr = sourceNameStr.Remove(sourceNameStr.Length - 1);
                        filterStr = filterStr + "Source in (" + sourceNameStr + ") and ";
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.ScheduledShipDateN != null && salesOrderViewModel.OrderWorkbenchFilterModal.ScheduledShipDateN.Count() > 0)
                    {
                        int count = 0;
                        string ScheduledShipDate1 = string.Empty;
                        string ScheduledShipDate2 = string.Empty;
                        foreach (var scheduledshipdate in salesOrderViewModel.OrderWorkbenchFilterModal.ScheduledShipDateN)
                        {
                            count += 1;
                            if (count == 1)
                            {
                                DateTime date1 = Convert.ToDateTime(scheduledshipdate);
                                ScheduledShipDate1 = String.Format("{0:u}", date1);
                            }
                            if (count == 2)
                            {
                                DateTime date2 = Convert.ToDateTime(scheduledshipdate);
                                ScheduledShipDate2 = String.Format("{0:u}", date2);
                            }
                            if (count > 1)
                            {
                                string[] s1 = ScheduledShipDate1.Split(' ');
                                string[] s2 = ScheduledShipDate2.Split(' ');
                                filterStr = filterStr + " ScheduledShipDate >= '" + s1[0] + "' and ScheduledShipDate <= '" + s2[0] + "' and ";

                            }
                        }
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.ReqDeliveryDateN != null && salesOrderViewModel.OrderWorkbenchFilterModal.ReqDeliveryDateN.Count() > 0)
                    {
                        int count = 0;
                        string ReqDeliveryDate1 = string.Empty;
                        string ReqDeliveryDate2 = string.Empty;
                        foreach (var reqdeliverydate in salesOrderViewModel.OrderWorkbenchFilterModal.ReqDeliveryDateN)
                        {
                            count += 1;
                            if (count == 1)
                            {
                                DateTime date1 = Convert.ToDateTime(reqdeliverydate);
                                ReqDeliveryDate1 = String.Format("{0:u}", date1);
                            }
                            if (count == 2)
                            {
                                DateTime date2 = Convert.ToDateTime(reqdeliverydate);
                                ReqDeliveryDate2 = String.Format("{0:u}", date2);
                            }
                            if (count > 1)
                            {
                                string[] s1 = ReqDeliveryDate1.Split(' ');
                                string[] s2 = ReqDeliveryDate2.Split(' ');
                                filterStr = filterStr + " RequestedDeliveryDate >= '" + s1[0] + "' and RequestedDeliveryDate <= '" + s2[0] + "' and ";

                            }
                        }
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.MustArriveByDateN != null && salesOrderViewModel.OrderWorkbenchFilterModal.MustArriveByDateN.Count() > 0)
                    {
                        int count = 0;
                        string MustArriveByDate1 = string.Empty;
                        string MustArriveByDate2 = string.Empty;
                        foreach (var mustarrivebydate in salesOrderViewModel.OrderWorkbenchFilterModal.MustArriveByDateN)
                        {
                            count += 1;

                            if (count == 1)
                            {
                                DateTime date1 = Convert.ToDateTime(mustarrivebydate);
                                MustArriveByDate1 = String.Format("{0:u}", date1);
                            }
                            if (count == 2)
                            {
                                DateTime date2 = Convert.ToDateTime(mustarrivebydate);
                                MustArriveByDate2 = String.Format("{0:u}", date2);
                            }
                            if (count > 1)
                            {
                                string[] s1 = MustArriveByDate1.Split(' ');
                                string[] s2 = MustArriveByDate2.Split(' ');

                                filterStr = filterStr + " MustArriveByDate >= '" + s1[0] + "' and MustArriveByDate <= '" + s2[0] + "' and ";

                            }
                        }
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.IsShipWith != null)
                    {
                        if (salesOrderViewModel.OrderWorkbenchFilterModal.IsShipWith == true)
                        {
                            filterStr = filterStr + " ShipWithOrderID IS NOT NULL and ";

                        }
                        else if (salesOrderViewModel.OrderWorkbenchFilterModal.IsShipWith == false)
                        {
                            //filterStr = filterStr + " ShipWithOrderID IS NULL or ShipWithOrderID = 0 or ShipWithOrderID = '' ";
                        }
                    }

                }
                if (filterStr.Length > 0)
                    filterStr = filterStr.Remove(filterStr.Length - 4);
            }
            else if (salesOrderViewModel.InboundOutbound.Trim().ToLower() == "inbound")
            {
                if (salesOrderViewModel.OrderWorkbenchFilterModal != null)
                {
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo != null && salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo != "")
                    {
                        var orderNoStr = "";
                        var orderNoVersionStr = "";
                        string[] OrderNoList = salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo.Trim().Split(",");
                        foreach (string orderno in OrderNoList)
                        {
                            int count = 0;
                            string[] ordernoList = orderno.Split(".");
                            foreach (string order in ordernoList)
                            {
                                count = count + 1;
                                if (count == 1)
                                {
                                    orderNoStr = orderNoStr + "'" + order.Trim() + "',";
                                }
                                else
                                {
                                    orderNoVersionStr = orderNoVersionStr + "'" + order.Trim() + "',";
                                }
                            }
                        }
                        orderNoStr = orderNoStr.Remove(orderNoStr.Length - 1);
                        filterStr = filterStr + "OrderNumber in (" + orderNoStr + ") and ";

                        if (orderNoVersionStr.Length > 0)
                        {
                            orderNoVersionStr = orderNoVersionStr.Remove(orderNoVersionStr.Length - 1);
                            filterStr = filterStr + "OrderVersionNumber in (" + orderNoVersionStr + ") and ";
                        }

                        //var orderNoStr = "";
                        //string[] OrderNoList = salesOrderViewModel.OrderWorkbenchFilterModal.OrderNo.Trim().Split(",");
                        //foreach (string orderno in OrderNoList)
                        //{
                        //    orderNoStr = orderNoStr + "'" + orderno.Trim() + "',";
                        //}
                        //orderNoStr = orderNoStr.Remove(orderNoStr.Length - 1);
                        //filterStr = filterStr + "OrderNumber in (" + orderNoStr + ") and ";//STO.OrderNumber
                    }

                    if (salesOrderViewModel.OrderWorkbenchFilterModal.MinOrderAmount != null && salesOrderViewModel.OrderWorkbenchFilterModal.MinOrderAmount != 0)
                    {
                        filterStr = filterStr + " OrderAmount >= " + salesOrderViewModel.OrderWorkbenchFilterModal.MinOrderAmount + " and ";
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.MaxOrderAmount != null && salesOrderViewModel.OrderWorkbenchFilterModal.MaxOrderAmount != 0)
                    {
                        filterStr = filterStr + " OrderAmount <= " + salesOrderViewModel.OrderWorkbenchFilterModal.MaxOrderAmount + " and ";

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo != null && salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo != "")
                    {
                        var shipmentNoStr = "";
                        var shipmentNoVersionStr = "";
                        string[] ShipmentNoList = salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo.Trim().Split(",");
                        foreach (string shipmentno in ShipmentNoList)
                        {
                            int count = 0;
                            string[] shipmentnoList = shipmentno.Split(".");
                            foreach (string shipment in shipmentnoList)
                            {
                                count = count + 1;
                                if (count == 1)
                                {
                                    shipmentNoStr = shipmentNoStr + "'" + shipment.Trim() + "',";
                                }
                                else
                                {
                                    shipmentNoVersionStr = shipmentNoVersionStr + "'" + shipment.Trim() + "',";
                                }
                            }
                        }
                        shipmentNoStr = shipmentNoStr.Remove(shipmentNoStr.Length - 1);
                        filterStr = filterStr + "ShipmentNumber in (" + shipmentNoStr + ") and ";

                        if (shipmentNoVersionStr.Length > 0)
                        {
                            shipmentNoVersionStr = shipmentNoVersionStr.Remove(shipmentNoVersionStr.Length - 1);
                            filterStr = filterStr + "ShipmentVersion in (" + shipmentNoVersionStr + ") and ";
                        }


                        //var shipmentNoStr = "";
                        //string[] ShipmentNoList = salesOrderViewModel.OrderWorkbenchFilterModal.ShipmentNo.Trim().Split(",");
                        //foreach (string shipmentno in ShipmentNoList)
                        //{
                        //    shipmentNoStr = shipmentNoStr + shipmentno.Trim() + ",";
                        //}
                        //shipmentNoStr = shipmentNoStr.Remove(shipmentNoStr.Length - 1);
                        //filterStr = filterStr + "ShipmentNumber in (" + shipmentNoStr + ") and ";

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.PONo != null && salesOrderViewModel.OrderWorkbenchFilterModal.PONo != "")
                    {
                        filterStr = filterStr + "PurchaseOrderNumber= " + salesOrderViewModel.OrderWorkbenchFilterModal.PONo + " and ";//STO.PurchaseOrderNumber
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderTypeItems.Count() > 0)
                    {
                        var orderTypeIdStr = "";
                        foreach (var ordertypeid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderTypeItems)
                        {
                            orderTypeIdStr = orderTypeIdStr + ordertypeid.Id + ",";
                        }
                        orderTypeIdStr = orderTypeIdStr.Remove(orderTypeIdStr.Length - 1);
                        filterStr = filterStr + "OrderTypeID in (" + orderTypeIdStr + ") and ";//STO.OrderTypeID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderStatusItems.Count() > 0)
                    {
                        var orderStatusIdStr = "";
                        foreach (var orderstatusid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderStatusItems)
                        {
                            orderStatusIdStr = orderStatusIdStr + orderstatusid.Id + ",";
                        }
                        orderStatusIdStr = orderStatusIdStr.Remove(orderStatusIdStr.Length - 1);
                        filterStr = filterStr + "OrderStatusID in (" + orderStatusIdStr + ") and ";//STO.OrderStatusID

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedAllVersionItems.Count() > 0)
                    {
                        var versionIdStr = "";
                        foreach (var versionId in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedAllVersionItems)
                        {
                            versionIdStr = versionIdStr + versionId.Id + ",";
                        }
                        versionIdStr = versionIdStr.Remove(versionIdStr.Length - 1);
                        filterStr = filterStr + "Version in (" + versionIdStr + ") and ";

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderConditionItems.Count() > 0)
                    {
                        var orderConditionIdStr = "";
                        foreach (var orderconditionid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedOrderConditionItems)
                        {
                            orderConditionIdStr = orderConditionIdStr + orderconditionid.Id + ",";
                        }
                        orderConditionIdStr = orderConditionIdStr.Remove(orderConditionIdStr.Length - 1);
                        filterStr = filterStr + "OrderConditionID in (" + orderConditionIdStr + ") and ";//STO.OrderConditionID

                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromItems.Count() > 0)
                    {
                        var shipFromLocationIdStr = "";
                        foreach (var shipfromlocationid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromItems)
                        {
                            shipFromLocationIdStr = shipFromLocationIdStr + shipfromlocationid.Id + ",";
                        }
                        shipFromLocationIdStr = shipFromLocationIdStr.Remove(shipFromLocationIdStr.Length - 1);
                        filterStr = filterStr + "FromLocationID in (" + shipFromLocationIdStr + ") and ";//STO.FromLocationID 
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToItems.Count() > 0)
                    {
                        var shipToLocationIdStr = "";
                        foreach (var shiptolocationid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToItems)
                        {
                            shipToLocationIdStr = shipToLocationIdStr + shiptolocationid.Id + ",";
                        }
                        shipToLocationIdStr = shipToLocationIdStr.Remove(shipToLocationIdStr.Length - 1);
                        filterStr = filterStr + "ToLocationID in (" + shipToLocationIdStr + ") and ";//STO.ToLocationID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromTypeItems.Count() > 0)
                    {
                        var shipFromTypeIdStr = "";
                        foreach (var shipfromtypeid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipFromTypeItems)
                        {
                            shipFromTypeIdStr = shipFromTypeIdStr + shipfromtypeid.Id + ",";
                        }
                        shipFromTypeIdStr = shipFromTypeIdStr.Remove(shipFromTypeIdStr.Length - 1);
                        filterStr = filterStr + "LocationTypeID in (" + shipFromTypeIdStr + ") and ";//TLocation.LocationTypeID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToTypeItems.Count() > 0)
                    {
                        var shipToTypeIdStr = "";
                        foreach (var shiptotypeid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedShipToTypeItems)
                        {
                            shipToTypeIdStr = shipToTypeIdStr + shiptotypeid.Id + ",";
                        }
                        shipToTypeIdStr = shipToTypeIdStr.Remove(shipToTypeIdStr.Length - 1);
                        filterStr = filterStr + "LocationTypeID in (" + shipToTypeIdStr + ") and ";//TLocation.LocationTypeID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedMaterialItems.Count() > 0)
                    {
                        var materialIdStr = "";
                        foreach (var materialid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedMaterialItems)
                        {
                            materialIdStr = materialIdStr + materialid.Id + ",";
                        }
                        materialIdStr = materialIdStr.Remove(materialIdStr.Length - 1);
                        filterStr = filterStr + "MID in (" + materialIdStr + ") and ";//M.ID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedCarrierItems.Count() > 0)
                    {
                        var carrierIdStr = "";
                        foreach (var carrierid in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedCarrierItems)
                        {
                            carrierIdStr = carrierIdStr + carrierid.Id + ",";
                        }
                        carrierIdStr = carrierIdStr.Remove(carrierIdStr.Length - 1);
                        filterStr = filterStr + "CID in (" + carrierIdStr + ") and ";//C.ID
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSalesManagersItems.Count() > 0)
                    {
                        var salesManagerIdStr = "";
                        foreach (var salesmanager in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSalesManagersItems)
                        {
                            salesManagerIdStr = salesManagerIdStr + "'" + salesmanager.Name + "',"; // + salesmanager.Name + ", ";
                        }
                        salesManagerIdStr = salesManagerIdStr.Remove(salesManagerIdStr.Length - 1);
                        filterStr = filterStr + " SalesManager in (" + salesManagerIdStr + ") and ";
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSourceItems.Count() > 0)
                    {
                        var sourceNameStr = "";
                        foreach (var sourcename in salesOrderViewModel.OrderWorkbenchFilterModal.SelectedSourceItems)
                        {
                            sourceNameStr = sourceNameStr + "'" + sourcename.Name + "',";
                        }
                        sourceNameStr = sourceNameStr.Remove(sourceNameStr.Length - 1);
                        filterStr = filterStr + "Source in (" + sourceNameStr + ") and ";
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.ScheduledShipDateN != null && salesOrderViewModel.OrderWorkbenchFilterModal.ScheduledShipDateN.Count() > 0)
                    {
                        int count = 0;
                        string ScheduledShipDate1 = string.Empty;
                        string ScheduledShipDate2 = string.Empty;
                        foreach (var scheduledshipdate in salesOrderViewModel.OrderWorkbenchFilterModal.ScheduledShipDateN)
                        {
                            count += 1;
                            if (count == 1)
                            {
                                DateTime date1 = Convert.ToDateTime(scheduledshipdate);
                                ScheduledShipDate1 = String.Format("{0:u}", date1);
                            }
                            if (count == 2)
                            {
                                DateTime date2 = Convert.ToDateTime(scheduledshipdate);
                                ScheduledShipDate2 = String.Format("{0:u}", date2);
                            }
                            if (count > 1)
                            {
                                string[] s1 = ScheduledShipDate1.Split(' ');
                                string[] s2 = ScheduledShipDate2.Split(' ');
                                filterStr = filterStr + " ScheduledShipDate >= '" + s1[0] + "' and ScheduledShipDate <= '" + s2[0] + "' and ";

                            }
                        }
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.ReqDeliveryDateN != null && salesOrderViewModel.OrderWorkbenchFilterModal.ReqDeliveryDateN.Count() > 0)
                    {
                        int count = 0;
                        string ReqDeliveryDate1 = string.Empty;
                        string ReqDeliveryDate2 = string.Empty;
                        foreach (var reqdeliverydate in salesOrderViewModel.OrderWorkbenchFilterModal.ReqDeliveryDateN)
                        {
                            count += 1;
                            if (count == 1)
                            {
                                DateTime date1 = Convert.ToDateTime(reqdeliverydate);
                                ReqDeliveryDate1 = String.Format("{0:u}", date1);
                            }
                            if (count == 2)
                            {
                                DateTime date2 = Convert.ToDateTime(reqdeliverydate);
                                ReqDeliveryDate2 = String.Format("{0:u}", date2);
                            }
                            if (count > 1)
                            {
                                string[] s1 = ReqDeliveryDate1.Split(' ');
                                string[] s2 = ReqDeliveryDate2.Split(' ');
                                filterStr = filterStr + " RequestedDeliveryDate >= '" + s1[0] + "' and RequestedDeliveryDate <= '" + s2[0] + "' and ";

                            }
                        }
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.MustArriveByDateN != null && salesOrderViewModel.OrderWorkbenchFilterModal.MustArriveByDateN.Count() > 0)
                    {
                        int count = 0;
                        string MustArriveByDate1 = string.Empty;
                        string MustArriveByDate2 = string.Empty;
                        foreach (var mustarrivebydate in salesOrderViewModel.OrderWorkbenchFilterModal.MustArriveByDateN)
                        {
                            count += 1;
                            if (count == 1)
                            {
                                DateTime date1 = Convert.ToDateTime(mustarrivebydate);
                                MustArriveByDate1 = String.Format("{0:u}", date1);
                            }
                            if (count == 2)
                            {
                                DateTime date2 = Convert.ToDateTime(mustarrivebydate);
                                MustArriveByDate2 = String.Format("{0:u}", date2);
                            }
                            if (count > 1)
                            {
                                string[] s1 = MustArriveByDate1.Split(' ');
                                string[] s2 = MustArriveByDate2.Split(' ');

                                filterStr = filterStr + " MustArriveByDate >= '" + s1[0] + "' and MustArriveByDate <= '" + s2[0] + "' and ";

                            }
                        }
                    }
                    if (salesOrderViewModel.OrderWorkbenchFilterModal.IsShipWith != null)
                    {
                        if (salesOrderViewModel.OrderWorkbenchFilterModal.IsShipWith == true)
                        {
                            filterStr = filterStr + " ShipWithOrderID IS NOT NULL and ";

                        }
                        else if (salesOrderViewModel.OrderWorkbenchFilterModal.IsShipWith == false)
                        {
                            // filterStr = filterStr + " ShipWithOrderID IS NULL or ShipWithOrderID = '' and ";
                        }
                    }
                }
                if (filterStr.Length > 0)
                    filterStr = filterStr.Remove(filterStr.Length - 4);
            }
            return filterStr;
        }

        /// <summary>
        ///  Retrieves All data from Charge Table along with the foriend key details
        /// </summary>
        /// <returns> Returns list of Charge Details</returns>
        public async Task<int> GetAllSalesOrderListDataCount(SalesOrderListViewModel salesOrderViewModel)
        {
            Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            if (salesOrderViewModel != null && string.IsNullOrWhiteSpace(salesOrderViewModel.FilterOn))
            {
                chargeParameter.Add("PageNumber", 0);
                chargeParameter.Add("PageSize", 0);
                chargeParameter.Add("ClientId", salesOrderViewModel.ClientID);
                chargeParameter.Add("LocationType", salesOrderViewModel.LocationType);
                chargeParameter.Add("RoleName", salesOrderViewModel.RoleName);
                chargeParameter.Add("InboundOutbound", salesOrderViewModel.InboundOutbound);
            }

            if (!string.IsNullOrWhiteSpace(salesOrderViewModel.SortColumn))
            {
                chargeParameter.Add("SortColumn", salesOrderViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(salesOrderViewModel.SortOrder))
            {
                chargeParameter.Add("SortOrder", salesOrderViewModel.SortOrder);
            }
            chargeParameter.Add("UserID", salesOrderViewModel.UserLoginID);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetSalesOrderDetailsData", chargeParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<SalesOrderViewModel>(ds.Tables[0]);
                return finalResult.Count();

                //return await Task.FromResult<IEnumerable<SalesOrderListViewModel>>(FilterResult<SalesOrderListViewModel>.GetFilteredResult(finalResult, salesOrderViewModel.FilterOn, salesOrderViewModel.PageSize));
            }

            return 0;
        }

        public async Task<bool> CancelSelectedOrdersAsync(long ClientId, string OrderIdList, string SelectedTab)
        {
            // string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CancelSalesOrder", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderIdList", OrderIdList);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }


        public async Task<bool> SaveSalesLinkOrder(long ClientId, string OrderIdList, string UserName, int ParentOrderId, string SelectedTab)
        {
            //string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_SaveLinkOrders", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderIdList", OrderIdList);
                    cmd.Parameters.AddWithValue("@UserName", UserName);
                    cmd.Parameters.AddWithValue("@ParentOrderId", ParentOrderId);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;



        }


        public async Task<IEnumerable<EditVerifyEquipmentMaterialProperty>> GetVerifyEquipmentMaterialPropertyOrder(EditVerifyEquipmentMaterialProperty viewModel)
        {

            using IDbConnection con = new SqlConnection(this.ConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@MaterialID", viewModel.materialID);
            parameter.Add("@EquipmentTypeID", viewModel.equipmentTypeID);
            var usersViewModels = con.Query<EditVerifyEquipmentMaterialProperty>("SPO_VerifyEquipmentMaterialProperty", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();
            return usersViewModels;

        }


        public async Task<List<MaterialPropertiesGrid>> GetVerifyEquipmentForMultipleMaterialPropertyOrder(RequestObjectMaterialProperties viewModel)
        {

            using IDbConnection con = new SqlConnection(this.ConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@MaterialID", viewModel.materialID);
            parameter.Add("@EquipmentTypeID", viewModel.equipmentTypeID);
            var usersViewModels = con.Query<EditVerifyEquipmentMaterialProperty>("SPO_VerifyEquipmentMultipleMaterialProperties", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();

            if (usersViewModels != null && usersViewModels.Count > 0)
            {
                var materialPropertiesData = usersViewModels.ToList();

                if (materialPropertiesData != null && materialPropertiesData.Count > 0)
                {
                    var materialPropertiesGrids = materialPropertiesData.GroupBy(x => x.materialID).Select(p => new MaterialPropertiesGrid
                    {
                        MaterialID = p.Key,
                        MaterialName = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key).materialName,
                        EquipmentID = viewModel.equipmentTypeID,
                        MaterialWeight = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key).materialWeight,
                        UnitInPallet = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Units on a Pallet").propertyValue,
                        UnitInEquipement = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Units in an Equipment").propertyValue,
                        PalletInEquipement = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Pallets in an Equipment").propertyValue,
                    }).ToList();

                    if (materialPropertiesGrids.Count > 0)
                    {
                        var filterMaterialWithNonZero = materialPropertiesGrids.Where(x => x.MaterialWeight == 0 || x.UnitInPallet == 0 || x.UnitInEquipement == 0 || x.PalletInEquipement == 0).ToList();

                        if (filterMaterialWithNonZero.Count > 0)
                            return filterMaterialWithNonZero;
                        else
                            return null;
                    }

                    return null;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

        }

        public async Task<bool> DeleteSelectedOrdersAsync(long ClientId, string OrderIdList, string SelectedTab)
        {
            // string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_DeleteSalesOrder", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderIdList", OrderIdList);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }

        public async Task<IEnumerable<SaveVerifyEquipmentMaterialProperty>> SaveUpdateVerifyEquipmentMaterial(SaveVerifyEquipmentMaterialProperty viewModel)
        {

            using IDbConnection con = new SqlConnection(this.ConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@MaterialID", viewModel.materialID);
            parameter.Add("@EquipmentTypeID", viewModel.equipmentTypeID);
            parameter.Add("@ClientID", viewModel.clientID);
            parameter.Add("@CreatedBy", viewModel.createdBy);
            parameter.Add("@propertyValueUP", viewModel.propertyValueUP);
            parameter.Add("@propertyValuePE", viewModel.propertyValuePE);
            parameter.Add("@propertyValueUE", viewModel.propertyValueUE);
            parameter.Add("@MaterialWeight", viewModel.materialWeight);
            parameter.Add("@propertiesUOMUP", viewModel.propertiesUOMUP);
            parameter.Add("@propertiesUOMPE", viewModel.propertiesUOMPE);
            parameter.Add("@propertiesUOMUE", viewModel.propertiesUOMUE);
            parameter.Add("@idUP", viewModel.idUP);
            parameter.Add("@idPE", viewModel.idPE);
            parameter.Add("@idUE", viewModel.idUE);

            var usersViewModels = con.Query<SaveVerifyEquipmentMaterialProperty>("SPO_InsertEquipmentMaterialProperty", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();
            return usersViewModels;

        }


        // Get Invoice no by shipment
        public async Task<object> GetInvoice(InviceParameterModel ViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientID", ViewModel.ClientID);
                parameter.Add("@ShipmentID", ViewModel.ShipmentID);
                var shipToDataViewModels = con.Query<ARInvoiceAgeDetailViewModel>("SPO_GetInvoiceNo", parameter, commandType: CommandType.StoredProcedure);

                con.Close();

                string InvoiceNumber = "";

                if (shipToDataViewModels != null)
                {
                    if (shipToDataViewModels.Count() > 0)
                    {
                        List<string> allInvoiceNumber = shipToDataViewModels.Select(x => x.InvoiceNumber).ToList();
                        InvoiceNumber = string.Join(",", allInvoiceNumber.ToArray());
                    }
                }
                return InvoiceNumber;
            }
        }

        public async Task<List<MaterialPropertiesGrid>> FindMissingMateriaOrder(RequestObjectMaterialProperties viewModel)
        {

            using IDbConnection con = new SqlConnection(this.ConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@MaterialID", viewModel.materialID);
            parameter.Add("@EquipmentTypeID", viewModel.equipmentTypeID);
            var usersViewModels = con.Query<EditVerifyEquipmentMaterialProperty>("SPO_VerifyEquipmentMultipleMaterialProperties", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();

            if (usersViewModels != null && usersViewModels.Count > 0)
            {
                var materialPropertiesData = usersViewModels.ToList();

                if (materialPropertiesData != null && materialPropertiesData.Count > 0)
                {
                    var materialPropertiesGrids = materialPropertiesData.GroupBy(x => x.materialID).Select(p => new MaterialPropertiesGrid
                    {
                        MaterialID = p.Key,
                        MaterialName = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key).materialName,
                        EquipmentID = viewModel.equipmentTypeID,
                        MaterialWeight = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key).materialWeight,
                        UnitInPallet = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Units on a Pallet").propertyValue,
                        UnitInEquipement = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Units in an Equipment").propertyValue,
                        PalletInEquipement = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Pallets in an Equipment").propertyValue,
                    }).ToList();

                    if (materialPropertiesGrids.Count > 0)
                    {
                        var filterMaterialWithNonZero = materialPropertiesGrids.Where(x => x.MaterialWeight == 0 || x.UnitInPallet == 0 || x.UnitInEquipement == 0 || x.PalletInEquipement == 0).ToList();

                        if (filterMaterialWithNonZero.Count > 0)
                            return filterMaterialWithNonZero;
                        else
                            return null;
                    }

                    return null;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

        }

        public async Task<bool> MoveUpDownLinkOrder(long ClientId, int OrderId, int SwapWithOrderId, int RouteSequence, int SwapWithRouteSequence, string UserName, long ShipWithOrderID, long SwapWithShipWithOrderID)
        {
            //string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_MoveUpDownLinkOrder", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@UserName", UserName);
                    cmd.Parameters.AddWithValue("@OrderId", OrderId);
                    cmd.Parameters.AddWithValue("@SwapWithOrderId", SwapWithOrderId);
                    cmd.Parameters.AddWithValue("@RouteSequence", RouteSequence);
                    cmd.Parameters.AddWithValue("@SwapWithRouteSequence", SwapWithRouteSequence);
                    cmd.Parameters.AddWithValue("@ShipWithOrderID", ShipWithOrderID);
                    cmd.Parameters.AddWithValue("@SwapWithShipWithOrderID", SwapWithShipWithOrderID);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }

        public async Task<bool> RemoveSelectedLinkOrderRecord(long ClientId, int OrderId, long ShipWithOrderID, string SelectedTab)
        {
            //string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_RemoveSelectedLinkOrderRecord", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderId", OrderId);
                    cmd.Parameters.AddWithValue("@ShipWithOrderID", ShipWithOrderID);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }


        public async Task<object> GetOrderDetailById(long OrderId, int ClientId, string OrderType)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientID", ClientId);
                parameter.Add("@OrderId", OrderId);
                parameter.Add("@OrdertypeCode", OrderType);
                var getOrderDetailById = con.Query<Object>("SPO_GetOrderDetailById", parameter, commandType: CommandType.StoredProcedure);

                con.Close();


                return getOrderDetailById;
            }
        }




        public async Task<IEnumerable<SalesOrderViewModel>> GetOrderDataByOrderIdForShipWith(int ClientId, int OrderId, string InboundOutbound)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", ClientId);
                parameter.Add("@OrderId", OrderId);
                parameter.Add("@InboundOutbound", InboundOutbound);
                var shipToDataViewModels = con.Query<SalesOrderViewModel>("SPO_SalesOrderWithLinkOrderByOrderId", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return shipToDataViewModels;
            }

            //Dictionary<string, object> chargeParameter = new Dictionary<string, object>();
            //if (salesOrderViewModel != null)
            //{
            //    chargeParameter.Add("@ClientId", salesOrderViewModel.ClientId);
            //    chargeParameter.Add("@OrderId", salesOrderViewModel.OrderId);
            //    chargeParameter.Add("@InboundOutbound", salesOrderViewModel.InboundOutbound);
            //}
            //DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_SalesOrderWithLinkOrderByOrderId", chargeParameter);
            //if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            //{
            //    var finalResult = ConvertDataTabe.CreateListFromTable<SalesOrderViewModel>(ds.Tables[0]);
            //    return await Task.FromResult<IEnumerable<SalesOrderViewModel>>(FilterResult<SalesOrderViewModel>.GetFilteredResult(finalResult, salesOrderViewModel.FilterOn, salesOrderViewModel.PageSize));
            //}
            //return null;
        }

        public async Task<bool> SetOverRideCreditLimit(SalesOrderViewModel viewModel)
        {

            var module = this._mapper.Map<SalesOrder>(viewModel);

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("OrderID", module.Id);
            this._unitOfWork.ExecuteProcedure("SP_CreatedHoldFlag", parameters);

            return await Task.FromResult<bool>(true);

            //var module = this._mapper.Map<SalesOrder>(viewModel);
            //var data = this._unitOfWork.SalesOrderRepository.SetOverRideCreditLimit(module);


            //this._unitOfWork.Save();
            //return await Task.FromResult<bool>(data.Result);
        }

        public async Task<bool> SaveCMComment(SalesOrderViewModel viewModel)
        {
            var module = this._mapper.Map<SalesOrder>(viewModel);
            var data = this._unitOfWork.SalesOrderRepository.SaveCMComment(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<object> SaveRegularOrder(AllSalesOrderViewModel viewModel)
        {

            string xmlChargeData = "<MaterialDetails>";
            bool isCharge = false;
            if (viewModel.locationMaterial != null && viewModel.locationMaterial.Count > 0)
            {
                foreach (var charegsData in viewModel.locationMaterial)
                {
                    isCharge = true;

                    if (charegsData.MaterialID.HasValue && charegsData.MaterialID > 0)
                    {
                        xmlChargeData = xmlChargeData + string.Format(
                          "<MaterialData MaterialID=\"{0}\" ChargeID=\"{1}\" Quantity=\"{2}\" RateTypeID=\"{3}\" Amount=\"{4}\" LineItem=\"{5}\" PriceMethodTypeID=\"{6}\" RateValue=\"{7}\" BOL=\"{8}\" CommodityID=\"{9}\"  OverrideRateTypeID=\"{10}\" OverridePriceMethodTypeID=\"{11}\" OverrideCommodityID=\"{12}\" OverrideBOL=\"{13}\" OverrideRateValue=\"{14}\" IsManual=\"{15}\" IsAutoAdded=\"{16}\" ></MaterialData>",
                          charegsData.MaterialID, charegsData.ChargeID, charegsData.ChargeUnit, charegsData.RateTypeID, charegsData.Amount, charegsData.overrideAmount, charegsData.PriceMethodID, charegsData.RateValue, charegsData.overrideShowOnBOL ? 1 : 0, charegsData.CommodityID, charegsData.overrideRateTypeID, charegsData.overridePriceMethodID, charegsData.overrideCommodityID, charegsData.overrideShowOnBOL ? 1 : 0, charegsData.overrideRateValue, charegsData.IsModified ? 1 : 0, charegsData.IsAutoAdded ? 1 : 0);
                    }
                    else
                    {
                        xmlChargeData = xmlChargeData + string.Format(
                           "<MaterialData  ChargeID=\"{0}\" Quantity=\"{1}\" RateTypeID=\"{2}\" Amount=\"{3}\" LineItem=\"{4}\" PriceMethodTypeID=\"{5}\" RateValue=\"{6}\" BOL=\"{7}\" CommodityID=\"{8}\"  OverrideRateTypeID=\"{9}\" OverridePriceMethodTypeID=\"{10}\" OverrideCommodityID=\"{11}\" OverrideBOL=\"{12}\" OverrideRateValue=\"{13}\" IsManual=\"{14}\" IsAutoAdded=\"{15}\" ></MaterialData>",
                            charegsData.ChargeID, charegsData.ChargeUnit, charegsData.RateTypeID, charegsData.Amount, charegsData.overrideAmount, charegsData.PriceMethodID, charegsData.RateValue, charegsData.overrideShowOnBOL ? 1 : 0, charegsData.CommodityID, charegsData.overrideRateTypeID, charegsData.overridePriceMethodID, charegsData.overrideCommodityID, charegsData.overrideShowOnBOL ? 1 : 0, charegsData.overrideRateValue, charegsData.IsModified ? 1 : 0, charegsData.IsAutoAdded ? 1 : 0);
                    }
                }
            }

            xmlChargeData = xmlChargeData + "</MaterialDetails>";


            string xmlDataInput = "<MaterialDetails>";
            foreach (var materialItems in viewModel.MaterialsList)
            {
                xmlDataInput = xmlDataInput + string.Format("<MaterialData MaterialID=\"{0}\"  Quantity=\"{1}\" ShippedQuantity=\"{2}\" EquivalentPallet=\"{3}\"/>", materialItems.MaterialID, materialItems.Quantity, materialItems.ShippedQuantity, materialItems.Pallets);
            }

            xmlDataInput = xmlDataInput + "</MaterialDetails>";




            if (viewModel.salesorder.Id > 0 && viewModel.salesorder.ToLocationId > 0 && (viewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Customer || viewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CPUOrder) && viewModel.salesorder.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.ShippedInventoryAndARChargesSentToMAS && viewModel.salesorder.ArchargesSentToAccounting.HasValue && viewModel.salesorder.ArchargesSentToAccounting.Value == 1 && viewModel.salesorder.OldToLocationID.Value != viewModel.salesorder.ToLocationId.Value)
            {
                Dictionary<string, object> divertParamters = new Dictionary<string, object>();
                divertParamters.Add("ClientID", viewModel.salesorder.ClientId);
                divertParamters.Add("OrderID", viewModel.salesorder.Id);
                divertParamters.Add("OrderTypeID", viewModel.salesorder.OrderTypeId);
                divertParamters.Add("TOLocation", viewModel.salesorder.ToLocationId);
                divertParamters.Add("PurchaseOrderNumber", viewModel.salesorder.PurchaseOrderNumber);
                if (viewModel.salesorder.PickupApplointment.HasValue)
                {
                    divertParamters.Add("PickAppointmentDate", viewModel.salesorder.PickupApplointmentString);
                }

                if (viewModel.salesorder.DeliveryAppointment.HasValue)
                {
                    divertParamters.Add("DeliveryAppointmentDate", viewModel.salesorder.DeliveryAppointmentString);
                }


                divertParamters.Add("MaterialDetails", xmlDataInput);

                if (isCharge)
                {
                    divertParamters.Add("ChargesDetails", xmlChargeData);
                }

                if (viewModel.salesorder.ToCustomerContractId.HasValue && viewModel.salesorder.ToCustomerContractId.Value > 0)
                {
                    divertParamters.Add("ToNewCustomerContractID", viewModel.salesorder.ToCustomerContractId.Value);
                }

                if (viewModel.salesorder.ToBusinessPartnerContractId.HasValue && viewModel.salesorder.ToBusinessPartnerContractId.Value > 0)
                {
                    divertParamters.Add("ToNewBussinessContractID", viewModel.salesorder.ToBusinessPartnerContractId.Value);
                }



                DataSet diversionResult = this._unitOfWork.ExecuteProcedure("SPO_CreateNewDiversionForRegularOrder", divertParamters);

                if (diversionResult != null && diversionResult.Tables != null && diversionResult.Tables.Count > 0)
                {
                    int finalTableIndex = diversionResult.Tables.Count - 1;
                    if (Convert.ToInt32(diversionResult.Tables[finalTableIndex].Rows[0]["StatusCode"]) == 1)
                    {
                        return new { id = Convert.ToInt32(diversionResult.Tables[finalTableIndex].Rows[0]["DivertedOrderID"]), OrderNumber = viewModel.salesorder.OrderNumber, OrderVersionNumber = Convert.ToInt32(diversionResult.Tables[finalTableIndex].Rows[0]["OrderVersionNumber"]), status = "NewDiversion" };
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return await this.SaveAll(viewModel);
                }

            }
            else if (viewModel.salesorder.Id > 0 && viewModel.salesorder.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.ShippedInventoryAndARChargesSentToMAS && viewModel.salesorder.ArchargesSentToAccounting.HasValue && viewModel.salesorder.ArchargesSentToAccounting.Value > 0)
            {
                Dictionary<string, object> versionParamters = new Dictionary<string, object>();
                versionParamters.Add("OrderID", viewModel.salesorder.Id);
                versionParamters.Add("OrderTypeID", viewModel.salesorder.OrderTypeId);
                versionParamters.Add("TOLocation", viewModel.salesorder.ToLocationId);
                versionParamters.Add("PurchaseOrderNumber", viewModel.salesorder.PurchaseOrderNumber);
                if (viewModel.salesorder.PickupApplointment.HasValue)
                {
                    versionParamters.Add("PickAppointmentDate", viewModel.salesorder.PickupApplointmentString);
                }
                if (viewModel.salesorder.DeliveryAppointment.HasValue)
                {
                    versionParamters.Add("DeliveryAppointmentDate", viewModel.salesorder.DeliveryAppointmentString);
                }
                versionParamters.Add("EquipmentNo", viewModel.salesorder.TrailerNumber);
                versionParamters.Add("SealNo", viewModel.salesorder.TrailerSealNumber);
                versionParamters.Add("Comments", viewModel.salesorder.Comments != null ? viewModel.salesorder.Comments : "");
                
                versionParamters.Add("MaterialDetails", xmlDataInput);

                if (isCharge)
                {
                    versionParamters.Add("ChargesDetails", xmlChargeData);
                }

                DataSet orderVersionResult = this._unitOfWork.ExecuteProcedure("SPO_CreateNewVersion", versionParamters);

                if (orderVersionResult != null && orderVersionResult.Tables != null && orderVersionResult.Tables.Count > 0)
                {
                    int finalTableIndex = orderVersionResult.Tables.Count - 1;
                    if (Convert.ToInt32(orderVersionResult.Tables[finalTableIndex].Rows[0]["Status"]) == 1)
                    {
                       


                        return new { id = Convert.ToInt32(orderVersionResult.Tables[finalTableIndex].Rows[0]["OrderID"]), OrderNumber = viewModel.salesorder.OrderNumber, OrderVersionNumber = Convert.ToInt32(orderVersionResult.Tables[finalTableIndex].Rows[0]["OrderVersionNumber"]), status = "NewVersion" };
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return await this.SaveAll(viewModel);
            }
        }
        public async Task<object> GetInvoiceNumberList(int ClientId)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("ClientId", ClientId);
                var getInvoiceObj = con.Query<object>("SPO_GetAllInvoiceNumber", parameter, commandType: CommandType.StoredProcedure);
                con.Close();

                return getInvoiceObj;
            }
        }
        public async Task<int> CopyOrdersAsync(long ClientId, string OrderIdList, string SelectedTab)
        {
            // string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CreateCopyOrder", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderIdList", OrderIdList);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        return result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return result;

        }
        public async Task<object> GetAllSource(int ClientId)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("ClientID", ClientId);
                var getSourceObj = con.Query<object>("SPO_GetAllSource", parameter, commandType: CommandType.StoredProcedure);
                con.Close();

                return getSourceObj;
            }
        }

        public async Task<int> GetCheckStatusForSendtoMass(long ClientId, string OrderIdList, string SelectedTab)
        {
            // string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CheckStatusForSendtoMassOrder", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderIdList", OrderIdList);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        return result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return result;

        }

        public async Task<int> GetCheckStatusReSendtoMass(long ClientId, string OrderIdList, string SelectedTab)
        {
            // string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CheckStatusForResendToMAS", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", ClientId);
                    cmd.Parameters.AddWithValue("@OrderIdList", OrderIdList);
                    cmd.Parameters.AddWithValue("@InboundOutbound", SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        return result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return result;

        }
        public async Task<bool> SendARChargesTOMAS(long ClientId, string OrderIdList, string SelectedTab)
        {
            if (SelectedTab.IndexOf("Stock Transfer") > -1 || SelectedTab.IndexOf("Collections") > -1)
            {
                this.hangfireOperation.ARChargeTOMASS(OrderIdList, 1);
            }
            else
            {
                this.hangfireOperation.ARChargeTOMASS(OrderIdList, 0);
            }

            return false;
        }

        public async Task<bool> ReSendARChargesTOMAS(long ClientId, string OrderIdList, string SelectedTab)
        {
            if (SelectedTab.IndexOf("Stock Transfer") > -1 || SelectedTab.IndexOf("Collections") > -1)
            {
                this.hangfireOperation.REARChargeTOMAS(OrderIdList, 1);
            }
            else
            {
                this.hangfireOperation.REARChargeTOMAS(OrderIdList, 0);
            }
            return false;
        }

        public async Task<bool> SaveCreateManageFilter(CreateFilter createFilter)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_CreateManageCustomFilter", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", createFilter.ClientID);
                    cmd.Parameters.AddWithValue("@FilterName", createFilter.FilterName);
                    cmd.Parameters.AddWithValue("@IsDefault", createFilter.IsDefault);
                    cmd.Parameters.AddWithValue("@FilterExpression", createFilter.FilterExpression);
                    cmd.Parameters.AddWithValue("@UserID", createFilter.UserID);
                    cmd.Parameters.AddWithValue("@InboundOutbound", createFilter.SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }

        public async Task<IEnumerable<CreateFilter>> GetAllCustomManageFiltersData(int clientId, int userId, string selectedTab)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientId", clientId);
                parameter.Add("@UserID", userId);
                parameter.Add("@InboundOutbound", selectedTab);
                var createFilterViewModels = con.Query<CreateFilter>("SPO_GetManageCustomFiltersData", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return createFilterViewModels;
            }
        }

        public async Task<bool> UpdateManageFilters(CreateFilter createFilter)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_UpdateManageCustomFilter", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", createFilter.ClientID);
                    cmd.Parameters.AddWithValue("@Id", createFilter.Id);
                    cmd.Parameters.AddWithValue("@FilterName", createFilter.FilterName);
                    cmd.Parameters.AddWithValue("@IsDefault", createFilter.IsDefault);
                    cmd.Parameters.AddWithValue("@FilterExpression", createFilter.FilterExpression);
                    cmd.Parameters.AddWithValue("@UserID", createFilter.UserID);
                    cmd.Parameters.AddWithValue("@InboundOutbound", createFilter.SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;

        }
        public async Task<bool> DeleteManageFilters(CreateFilter createFilter)
        {
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_DeleteManageCustomFilter", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientId", createFilter.ClientID);
                    cmd.Parameters.AddWithValue("@Id", createFilter.Id);
                    cmd.Parameters.AddWithValue("@UserID", createFilter.UserID);
                    cmd.Parameters.AddWithValue("@InboundOutbound", createFilter.SelectedTab);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;
                    try
                    {
                        con.Open();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);
                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);
                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            return false;
        }
        public async Task<string> ConvertTextEnglishToSpanish(string text)
        {
            return await this.convertEnglishToSpanish.ConvertTextEnglishToSpanish(text);
        }

        /// <summary>
        /// this method recalculate latest contact and shipping material and autoadded charges into existing order.
        /// </summary>
        /// <param name="orderId">order id</param>
        /// <param name="orderTypeId">order type id</param>
        /// <returns>validation response with status</returns>
        public async Task<ValidationResponse> RecalculateExistingOrders(long orderId, int orderTypeId)
        {
            ValidationResponse validationResponse = new ValidationResponse();

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("OrderID", orderId);
            parameters.Add("OrderTypeID", orderTypeId);

            var result = this._unitOfWork.ExecuteProcedure("SPO_ReCalculateFunctionalityForRegularOrder", parameters);

            if (result != null && result.Tables.Count > 0)
            {
                int response = Convert.ToInt32(result.Tables[0].Rows[0]["Status"]);

                if (response == 1)
                {
                    validationResponse.IsValid = true;
                    validationResponse.Message = "Updated.";
                }
                else if (response == 2)
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = "order already send to mas.";
                }
                else
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = "there is some issue contact to admin.";
                }
            }
            else
            {
                validationResponse.IsValid = false;
                validationResponse.Message = "there is some issue contact to admin.";
            }

            return validationResponse;
        }


        public async Task<IEnumerable<object>> GetShipmentNumberDetails(int ClientId, string shipdatefrom, string shipdateto)
        {
            string strConnectionString = _unitOfWork.ConnectionString;
            using IDbConnection con = new SqlConnection(strConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@ClientId", ClientId);
            parameter.Add("@shipdatefrom", shipdatefrom);
            parameter.Add("@shipdateto", shipdateto);
            var usersViewModels = con.Query<object>("SPO_GetFilterClaimOnShipmentNumber", parameter, commandType: CommandType.StoredProcedure);

            con.Close();
            return usersViewModels;

        }

        public async Task<IEnumerable<object>> GetOrderNumberDetails(int ClientId, string shipdatefrom, string shipdateto)
        {
            string strConnectionString = _unitOfWork.ConnectionString;
            using IDbConnection con = new SqlConnection(strConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@ClientId", ClientId);
            parameter.Add("@shipdatefrom", shipdatefrom);
            parameter.Add("@shipdateto", shipdateto);
            var usersViewModels = con.Query<object>("SPO_GetFilterClaimOnOrderNumber", parameter, commandType: CommandType.StoredProcedure);
            
            con.Close();
            return usersViewModels;

        }

        public async Task<IEnumerable<object>> GetShipmentNumberWithShippmentID(int ClientId, string shipdatefrom, string shipdateto, long ShipmentID)
        {
            string strConnectionString = _unitOfWork.ConnectionString;
            using IDbConnection con = new SqlConnection(strConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@ClientId", ClientId);
            parameter.Add("@shipdatefrom", shipdatefrom);
            parameter.Add("@shipdateto", shipdateto);
            parameter.Add("@shipmentID", ShipmentID);
            var usersViewModels = con.Query<object>("SPO_GetClaimWithShipmentIDShipmentNumber", parameter, commandType: CommandType.StoredProcedure);

            con.Close();
            return usersViewModels;

        }

        public async Task<IEnumerable<object>> GetOrderNumberWithShippmentID(int ClientId, string shipdatefrom, string shipdateto, long ShipmentID)
        {
            string strConnectionString = _unitOfWork.ConnectionString;
            using IDbConnection con = new SqlConnection(strConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@ClientId", ClientId);
            parameter.Add("@shipdatefrom", shipdatefrom);
            parameter.Add("@shipdateto", shipdateto);
            parameter.Add("@shipmentID", ShipmentID);
            var usersViewModels = con.Query<object>("SPO_GetClaimOnOrderNumberWithShipmentID", parameter, commandType: CommandType.StoredProcedure);

            con.Close();
            return usersViewModels;

        }

    }
}