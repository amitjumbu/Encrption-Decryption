﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class MedicationChartGridManager : BaseManager<MedicationChartGrid, MedicationChartGridViewModel>, IMedicationChartGridManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public MedicationChartGridManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        
        


        

        #region Save List of Medication  Chart records
        public async Task<bool> SaveAll(IEnumerable<MedicationChartGridViewModel> ViewModels)
        {
            if (ViewModels.Any())
            {
                foreach (MedicationChartGridViewModel ViewModel in ViewModels)
                {
                    var result = await this._unitOfWork.MedicationChartGridRepository.AddAsync(this._mapper.Map<MedicationChartGrid>(ViewModel)).ConfigureAwait(false);
                }

                var finalResult = this._unitOfWork.Save();

                return await Task.FromResult<bool>(finalResult).ConfigureAwait(false);

            }
            else
            {
                return await Task.FromResult<bool>(false).ConfigureAwait(false);
            }
        }
        #endregion

        public async override Task<int> CountAsync(MedicationChartGridViewModel viewModel)
        {
            Expression<Func<MedicationChartGrid, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
            {
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            }
            else
            {
                condition = condition.And(c => c.IsDeleted == false);
            }

            return await this._unitOfWork.MedicationChartGridRepository.CountAsync(condition);
        }

        public async override Task<bool> AddAsync(MedicationChartGridViewModel viewModel)
        {
            var module = this._mapper.Map<MedicationChartGridViewModel>(viewModel);
            //var data = this._unitOfWork.MedicationChartGridRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }
        public async override Task<IEnumerable<MedicationChartGridViewModel>> RangeAsync(int recordCount, MedicationChartGridViewModel viewModel)
        {
            Expression<Func<MedicationChartGrid, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.MedicationChartGridRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<MedicationChartGridViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<MedicationChartGridViewModel>> ListAsync(MedicationChartGridViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MedicationChartGrid, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.MedicationChartGridRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<MedicationChartGridViewModel>>(module);
        }



        #region Update record
        public async override Task<bool> UpdateAsync(MedicationChartGridViewModel viewModel)
        {
            var module = this._mapper.Map<MedicationChartGrid>(viewModel);
            var data = this._unitOfWork.MedicationChartGridRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
        #endregion

        
    }
}