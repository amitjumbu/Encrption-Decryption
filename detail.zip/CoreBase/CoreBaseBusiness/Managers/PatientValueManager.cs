﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Text;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Dapper;
    using Microsoft.AspNetCore.Hosting;
    using static CoreBaseBusiness.Helpers.Constants;

    public class PatientValueManager : BaseManager<Patient, PatientValueViewModel>, IPatientValueManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public PatientValueManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Patient table.
        /// </summary>
        public async override Task<PatientValueViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.Patientrepository.GetById(id);
            return this._mapper.Map<PatientValueViewModel>(module);
        }

        /// <summary>
        ///  Retrieves  All data from Patient.
        /// </summary>
        public async override Task<IEnumerable<PatientValueViewModel>> ListAsync(PatientValueViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Patient, bool>> condition = (c => !c.IsDeleted);
            var module = await this._unitOfWork.Patientrepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientValueViewModel>>(module);
        }

        /// <summary>
        /// Patient
        /// </summary>
        public async override Task<bool> AddAsync(PatientValueViewModel viewModel)
            {
            viewModel.CreateDateTimeServer = DateTime.UtcNow;
            viewModel.UpdateDateTimeServer = DateTime.UtcNow;
            viewModel.AdmissionDate = DateTime.UtcNow;
            viewModel.IsActive = true;
            var module = this._mapper.Map<Patient>(viewModel);
            var data = this._unitOfWork.Patientrepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.ID = module.Id;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for Patient Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(PatientValueViewModel viewModel)
        {
            var module = this._mapper.Map<Patient>(viewModel);
            var data = this._unitOfWork.Patientrepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Patient Details.
        /// </summary>
        public async override Task<int> CountAsync(PatientValueViewModel viewModel)
        {
            Expression<Func<Patient, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            if (viewModel.ID > 0)
                condition = condition.And(c => c.Id == viewModel.ID);
            else
                condition = condition.And(c => c.ClientId == viewModel.ClientID);

            return await this._unitOfWork.Patientrepository.CountAsync(condition);
        }

        public async Task<IEnumerable<object>> RangeAsync1(int recordCount, PatientValueViewModel viewModel)
        {
            //Expression<Func<Patient, bool>> condition = (c => c.Id == viewModel.ID);
            Expression<Func<Patient, bool>> condition = (c => c.ClientId == viewModel.ClientID && c.IsDeleted == false);
            var module = await this._unitOfWork.Patientrepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            return this._mapper.Map<IEnumerable<object>>(module);
        }
        /// <summary>
        ///  Retrieves  All data from  Patient Id wise.
        /// </summary>
        public async override Task<IEnumerable<PatientValueViewModel>> RangeAsync(int recordCount, PatientValueViewModel viewModel)
        {
            //Expression<Func<Patient, bool>> condition = (c => c.Id == viewModel.ID);
            Expression<Func<Patient, bool>> condition = (c => c.ClientId == viewModel.ClientID && c.IsDeleted == false);
            var module = await this._unitOfWork.Patientrepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            return this._mapper.Map<IEnumerable<PatientValueViewModel>>(module);
        }

        /// <summary>
        ///  Deletes record from Patient by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.Patientrepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<IEnumerable<object>> SearchPatient(PatientViewModel viewModel)
        {

            string strConnectionString = Authentication.ConnectionString;
            using (IDbConnection con = new SqlConnection(strConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@SearchMode", viewModel.SearchMode);
                parameter.Add("@SearchKey", viewModel.SearchKey);
                var usersViewModels = con.Query<object>("SPO_InsertPatientRegistartionInformation", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }

        }



        public async Task<IEnumerable<object>> GetContactAddressPhysicianInfo(PatientViewModel viewModel)
        {

            string strConnectionString = Authentication.ConnectionString;
            using (IDbConnection con = new SqlConnection(strConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@PatientId", viewModel.PatientId);
                parameter.Add("@Mode", viewModel.SearchMode);
                var usersViewModels = con.Query<object>("SPO_GetContactAddressPhysician_Info", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }

        }

        public async Task<IEnumerable<object>> GetPatientList(PatientViewModel viewModel)
        {

            string strConnectionString = Authentication.ConnectionString;
            using (IDbConnection con = new SqlConnection(strConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@PatientIds", viewModel.SearchKey);
                var usersViewModels = con.Query<object>("SPO_GetPatientList", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }

        }

        public List<PatientHeaderViewModel> GetPatientInfoByID(long PatientId)
        {
            List<PatientHeaderViewModel> usersList = new List<PatientHeaderViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("PatientId", PatientId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetPatientCommonInfo", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new PatientHeaderViewModel()
                    {
                        PatientId = Convert.ToInt64(dr["ID"]),
                        PatientName = dr["patientName"].ToString(),
                        CRNo = Convert.ToInt64(dr["CR_OutdoorNo"]),
                        MRDNo = Convert.ToInt64(dr["MRD_IndoorNo"]),
                        UnitNo= Convert.ToInt64(dr["UnitNo"]),
                        AdmissionDate =Convert.ToDateTime(dr["DateTimeOfAdmission"])
                    });
                }
            }

            return usersList;
        }

       

        public async Task<bool> UpdatePatientStatus(PatientTransactionViewModel pData)
        {

            string strConnectionString = Constants.Authentication.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_UpdatePatientStatus", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Mode", pData.Mode);
                    cmd.Parameters.AddWithValue("@PatientIds", pData.PatientId);
                    cmd.Parameters.AddWithValue("@UpdateBy", pData.UpdatedBy);
                    cmd.Parameters.AddWithValue("@UpdateDate", pData.UpdateDateTimeBrowser);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;

                    try
                    {
                        con.Open();

                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);

                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }


                }
            }

            return false;
        }
        public async Task<IEnumerable<PatientSetupListViewModel>> GetPatientSetupList(PatientSetupListViewModel patientSetupList)
        {
            Dictionary<string, object> patientParameter = new Dictionary<string, object>();
            //if (patientSetupList != null && string.IsNullOrWhiteSpace(patientSetupList.FilterOn))
            //{
            //    patientParameter.Add("PageNumber", patientSetupList.PageNo);
            //    patientParameter.Add("PageSize", patientSetupList.PageSize);
            //    patientParameter.Add("SortColumn", patientSetupList.SortColumn);
            //    patientParameter.Add("SortOrder", patientSetupList.SortOrder);

            //}
            if (patientSetupList != null && string.IsNullOrWhiteSpace(patientSetupList.FilterOn))
            {
                //patientParameter.Add("ClientID", patientSetupList.ClientID);
                patientParameter.Add("PageNumber", patientSetupList.PageNo);
                patientParameter.Add("PageSize", patientSetupList.PageSize);
            }
            if (!string.IsNullOrWhiteSpace(patientSetupList.SortColumn))
            {
                patientParameter.Add("SortColumn", patientSetupList.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(patientSetupList.SortOrder))
            {
                patientParameter.Add("SortOrder", patientSetupList.SortOrder);
            }
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetPatientSetupList", patientParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<PatientSetupListViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<PatientSetupListViewModel>>(FilterResult<PatientSetupListViewModel>.GetFilteredResult(finalResult, patientSetupList.FilterOn, patientSetupList.PageSize));
            }

            return null;
        }
        //public List<PatientSetupListViewModel> GetPatientSetupList()
        //{
        //    List<PatientSetupListViewModel> usersList = new List<PatientSetupListViewModel>();
        //    //Dictionary<string, object> parameters = new Dictionary<string, object>();

        //    DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetPatientSetupList");

        //    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in ds.Tables[0].Rows)
        //        {
        //            usersList.Add(new PatientSetupListViewModel()
        //            {
        //                Id = Convert.ToInt32(dr["ID"]),
        //                PatientName = dr["PatientName"].ToString(),
        //                RegistrationNo = dr["RegistrationNo"].ToString(),
        //                PhysicianName = dr["PhysicianName"].ToString(),
        //                HospitalName = dr["HospitalName"].ToString(),
        //                AdmissionDate = dr["AdmissionDate"].ToString(),
        //                PatientConditionID = Convert.ToInt32(dr["ConditionID"]),
        //                PatientConditionName = dr["Condition"].ToString(),
        //                PatientStatusID = Convert.ToInt32(dr["PatientStatusID"]),
        //                PatientStatusName = dr["PatientStatusName"].ToString(),
        //                Active = dr["Active"].ToString()
        //            });
        //        }
        //    }

        //    return usersList;
        //}

        #region Active/Inactive Patient Status as well as partograph
        public async Task<bool> ActivatePatientStatus(List<string> ids, bool isActive)
        {
            if (ids.Any())
            {
                List<Partograph> partographstatus = null;
                //List<int> PatientStatusID = ids.ConvertAll(int.Parse);
                List<long> PatientStatusID = ids.ConvertAll(long.Parse);

                List<Patient> patintstatus = this._unitOfWork.Patientrepository.ListAsync(p => PatientStatusID.Contains(p.Id)).Result.ToList();
                if (!isActive) {
                    partographstatus = this._unitOfWork.PartographRepository.ListAsync(p => PatientStatusID.Contains(p.PatientId)).Result.ToList();
                }


                foreach (Patient patientAlert in patintstatus)
                {
                    if (partographstatus != null && partographstatus.Count > 0) {
                        foreach (Partograph item in partographstatus)
                        {
                            item.IsActive = isActive;
                            patientAlert.IsActive = isActive;
                        }
                    }
                    else
                    {
                        patientAlert.IsActive = isActive;
                    }
                    
                }

                var result = this._unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }
        #endregion
        #region Delete patient from patient set up
        public async Task<string> DeleteAllAsync(List<string> ids)
        {
            string msg = "";
            if (ids.Any())
            {
                //List<int> PatientStatusID = ids.ConvertAll(int.Parse);
                List<long> PatientStatusID = ids.ConvertAll(long.Parse);

                List<Patient> patintstatus = this._unitOfWork.Patientrepository.ListAsync(p => PatientStatusID.Contains(p.Id)).Result.ToList();
                List<Partograph> partographstatus = this._unitOfWork.PartographRepository.ListAsync(p => PatientStatusID.Contains(p.PatientId) && p.IsActive == true).Result.ToList();
                List<Patient> Patientresult = patintstatus.Except(patintstatus.Where(o => partographstatus.Select(s => s.PatientId).ToList().Contains(o.Id))).ToList();
                //long[] sentMsgIDs = partographstatus.Select(v => v.PatientId).ToArray();
                //List<Patient> result1 = patintstatus.Where(o => !sentMsgIDs.Contains(o.Id)).ToList();
                foreach (Patient patientAlert in Patientresult)
                {
                    patientAlert.IsDeleted = true;
                }

                var result = this._unitOfWork.Save();
                if (result == true && PatientStatusID.Count > 1)
                {
                    msg = Constants.Identifire.DeleteMessageAll;
                }
                else
                {
                    msg = Constants.Identifire.DeleteMessageSingle;
                }
                return await Task.FromResult<string>(msg);
            }

            return await Task.FromResult<string>("");
        }


        #endregion
    }
}
