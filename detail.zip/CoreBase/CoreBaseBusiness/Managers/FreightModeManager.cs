﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.UnitOfWork;
using Dapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{
    public class FreightModeManager : BaseManager<FreightMode, FreightModeViewModel>, IFreightModeManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;

        private readonly IConfiguration configuration;
        

        private string ConnectionString { get { return this.BaseConnectionString; } }

        public FreightModeManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        public async override Task<bool> AddAsync(FreightModeViewModel viewModel)
        {

            var module = this._mapper.Map<FreightMode>(viewModel);
            var data = this._unitOfWork.freightmodeRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.ID = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }


        public async override Task<int> CountAsync(FreightModeViewModel viewModel)
        {
            Expression<Func<FreightMode, bool>> condition = (c => (!c.IsDeleted) && (viewModel.ClientID == null || c.ClientId == viewModel.ClientID));

            return await this._unitOfWork.freightmodeRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves  All data from  Package Id wise.
        /// </summary>


        public Task<OperatingLocationViewModel> GetAsync(long id)
        {
            throw new NotImplementedException();

        }

        public override Task<IEnumerable<FreightModeViewModel>> ListAsync(FreightModeViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async override Task<IEnumerable<FreightModeViewModel>> RangeAsync(int recordCount, FreightModeViewModel viewModel)
        {
            Expression<Func<FreightMode, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.freightmodeRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var Freightdata= this._mapper.Map<IEnumerable<FreightModeViewModel>>(module);
            //return this._mapper.Map<IEnumerable<FreightModeViewModel>>(module);
            return await Task.FromResult<IEnumerable<FreightModeViewModel>>(FilterResult<FreightModeViewModel>.GetFilteredResult(Freightdata, viewModel.FilterOn, viewModel.PageSize));
        }

        public async override Task<FreightModeViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.freightmodeRepository.GetById(id);
            return this._mapper.Map<FreightModeViewModel>(module);
        }

        public async override Task<bool> UpdateAsync(FreightModeViewModel viewModel)
        {
            var module = this._mapper.Map<FreightMode>(viewModel);
            var data = this._unitOfWork.freightmodeRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }


        /// <summary>
        ///  Deletes record from Comment by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.freightmodeRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<IEnumerable<FreightModeViewModel>> SaveAll(List<FreightModeViewModel> ViewModels)
        {
            var freightalls = new List<FreightModeViewModel>();
            
                foreach (FreightModeViewModel ViewModel in ViewModels)
                {
                var module = this._mapper.Map<FreightMode>(ViewModel);
                var result = await this._unitOfWork.freightmodeRepository.AddAsync(module).ConfigureAwait(false);
                //var result = await this._unitOfWork.freightmodeRepository.AddAsync(this._mapper.Map<FreightMode>(ViewModel)).ConfigureAwait(false);
                    if (result)
                    {
                        this._unitOfWork.Save();
                    ViewModel.ID = module.Id;
                    freightalls.Add(ViewModel);
                    }
                }
                return freightalls;
        }

        public async Task<bool> UpdateAll(IEnumerable<FreightModeViewModel> ViewModels)
        {
            if (ViewModels.Any())
            {
                foreach (FreightModeViewModel ViewModel in ViewModels)
                {
                    var result = await this._unitOfWork.freightmodeRepository.UpdateAsync(this._mapper.Map<FreightMode>(ViewModel)).ConfigureAwait(false);
                }

                var finalResult = this._unitOfWork.Save();

                return await Task.FromResult<bool>(finalResult).ConfigureAwait(false);

            }
            else
            {
                return await Task.FromResult<bool>(false).ConfigureAwait(false);
            }
        }

        //public async Task<bool> DeleteAllAsyncc(List<string> ids)
        //{
        //    if (ids.Any())
        //    {
        //        List<int> ID = ids.ConvertAll(int.Parse);

        //        List<FreightMode> freightmode = this._unitOfWork.freightmodeRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();

        //        foreach (FreightMode freight in freightmode)
        //        {
                    
        //            freight.IsDeleted = true;
        //        }

        //        var result = this._unitOfWork.Save();

        //        return await Task.FromResult<bool>(result);
        //    }

        //    return await Task.FromResult<bool>(false);
        //}

        public async Task<string> DeleteAllAsync(string id, string deleteby)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();
            Dictionary<string, object> storedProcedureOutParameter = new Dictionary<string, object>();
            storedProcedureOutParameter.Add("Status", 0);
            storedProcedureOutParameter.Add("Message", string.Empty);
            storedProcedureParameter.Add("IDs", id);
            storedProcedureParameter.Add("deletedBy", deleteby);
            var outputParameters = this._unitOfWork.ExecuteProcedureForResultValueWithDataType("SPO_DeleteFreightMode", storedProcedureParameter, storedProcedureOutParameter);

            if (outputParameters != null
                && outputParameters["Status"] != null)
            {
                return outputParameters["Message"].ToString();
            }

            return "Not valid";
        }
        public async Task<IEnumerable<FreightModeViewModel>> GetEditfmsAsync(string ids)
        {
            var authorsList = await this._unitOfWork.freightmodeRepository.GetByIds(ids).ConfigureAwait(false);
            var mappedData = this._mapper.Map<IEnumerable<FreightModeViewModel>>(authorsList);
            return mappedData;
        }

        public async Task<IEnumerable<FreightModeViewModel>> GetFreightMode(MaterialCommonModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@EquipmentTypeID", flagViewModel.EquipmentTypeID);
                parameter.Add("@ClientID", flagViewModel.ClientID);
                var usersViewModels = con.Query<FreightModeViewModel>("SPO_GetFreightModeByEquipment", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }

        public async Task<IEnumerable<FreightModeViewModel>> GetFreightModeList(FreightModeViewModel freightModeViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (freightModeViewModel != null && string.IsNullOrWhiteSpace(freightModeViewModel.FilterOn))
            {
                Parameter.Add("ClientID", freightModeViewModel.ClientID);
                Parameter.Add("PageNumber", freightModeViewModel.PageNo);
                Parameter.Add("PageSize", freightModeViewModel.PageSize);
                //Parameter.Add("SortColumn", freightModeViewModel.SortColumn);
                //Parameter.Add("SortOrder", freightModeViewModel.SortOrder);
            }
            if (!string.IsNullOrWhiteSpace(freightModeViewModel.SortColumn))
            {
                Parameter.Add("SortColumn", freightModeViewModel.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(freightModeViewModel.SortOrder)) {
                Parameter.Add("SortOrder", freightModeViewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFreightodeList", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FreightModeViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<FreightModeViewModel>>(FilterResult<FreightModeViewModel>.GetFilteredResult(finalResult, freightModeViewModel.FilterOn, freightModeViewModel.PageSize));
            }

            return null;
        }

    }
}
