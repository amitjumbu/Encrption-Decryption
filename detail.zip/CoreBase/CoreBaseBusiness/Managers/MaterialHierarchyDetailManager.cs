﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using NPOI.SS.Formula.Functions;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class MaterialHierarchyDetailManager : BaseManager<MaterialHierarchyDetail, MaterialHierarchyDetailViewModel>, IMaterialHierarchyDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        public MaterialHierarchyDetailManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(MaterialHierarchyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MaterialHierarchyDetailViewModel>> GetMaterialHierarchyDetailById(MaterialHierarchyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialHierarchyID", viewModel.MaterialHierarchyID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialHierarchyDetailById", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialHierarchyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialHierarchyDetailViewModel>>(FilterResult<MaterialHierarchyDetailViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        public async Task<int> GetMHDCount(MaterialHierarchyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialHierarchyID", viewModel.MaterialHierarchyID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialHierarchyDetailCountById", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialHierarchyDetailViewModel>(ds.Tables[0]);
                int number = Convert.ToInt32(ds.Tables[0].Rows[0].Field<int>("RecordCount"));
                return await Task.FromResult<int>(number);
            }

            return 0;
        }

        public override Task<IEnumerable<MaterialHierarchyDetailViewModel>> ListAsync(MaterialHierarchyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(MaterialHierarchyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}
