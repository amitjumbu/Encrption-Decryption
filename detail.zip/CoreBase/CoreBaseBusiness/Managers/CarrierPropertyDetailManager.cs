﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{

    public class CarrierPropertyDetailManager :
        BaseManager<CarrierPropertyDetail, CarrierPropertyDetailViewModel>, 
        ICarrierPropertyDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public CarrierPropertyDetailManager(IMapper mapper,
            IHostingEnvironment hostingEnvironment,
            ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;
        }

        public override Task<bool> AddAsync(CarrierPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(CarrierPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<CarrierPropertyDetailViewModel>> ListAsync(CarrierPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> MergeCarrierPropertyDetails(List<CarrierPropertyDetailViewModel> mergeModels)
        {
            foreach (CarrierPropertyDetailViewModel model in mergeModels)
            {
                Expression<Func<CarrierPropertyDetail, bool>> condition =
                        c => c.Id == model.ID
                        || (c.CarrierId == model.CarrierId && c.EntityPropertyId == model.EntityPropertyId);
                var recordExists = await this._unitOfWork.CarrierPropertyDetailRepository.GetList(condition);
                if (recordExists != null && recordExists.FirstOrDefault() != null)
                {
                    // update
                    CarrierPropertyDetail updateObj = recordExists.FirstOrDefault();
                    updateObj.PropertyValue = model.PropertyValue;
                    updateObj.PropertiesUom = model.PropertiesUom;
                    updateObj.UpdatedBy = model.UpdatedBy;
                    updateObj.UpdateDateTimeBrowser = model.UpdateDateTimeBrowser;
                    updateObj.UpdateDateTimeServer = DateTime.UtcNow;
                    updateObj.IsDeleted = model.IsDeleted;
                    var updateScuccessful = await this._unitOfWork.CarrierPropertyDetailRepository.UpdateAsync(updateObj);
                    if (!updateScuccessful)
                        return false;
                }
                else
                {
                    // insert
                    var insertObj = this._mapper.Map<CarrierPropertyDetail>(model);
                    insertObj.UpdateDateTimeServer = DateTime.Now;
                    insertObj.CreateDateTimeServer = DateTime.Now;
                    insertObj.Carrier = null;
                    var insertSuccessful = await this._unitOfWork.CarrierPropertyDetailRepository.AddAsync(insertObj);
                    if (!insertSuccessful)
                        return false;
                }
            }

            return this._unitOfWork.Save();
        }

        #region Get Existing Carrier characterstics
        public async Task<IEnumerable<CarrierPropertyDetailViewModel>> 
            GetExistingCarrierCharacteristics(CarrierPropertyDetailViewModel carrierPropertyDetailModel)
        {

            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("CarrierId", carrierPropertyDetailModel.CarrierId);
            parameter.Add("ClientId", carrierPropertyDetailModel.ClientID);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetExistingCarrierCharacteristics", parameter);
            if (ds != null && ds.Tables[0] != null)
            {
                List<CarrierPropertyDetailViewModel> entityPropertyViewModels = new List<CarrierPropertyDetailViewModel>();
                entityPropertyViewModels = ConvertDataTabe.CreateListFromTable<CarrierPropertyDetailViewModel>(ds.Tables[0]);
                return entityPropertyViewModels;
            }

            return null;
        }
        #endregion

        /// <summary>
        /// Delete  Existing Characterstics for a carrier.
        /// </summary>
        /// <param name="deleteModel">Contains details of items to be deleted.</param>
        /// <returns>A success/Failure.</returns>
        public async Task<bool> DeleteExistingCharacteristics(LocationPropertyDeleteModel deleteModel)
        {

            foreach (int id in deleteModel.Ids)
            {

                var setupDelete = await this._unitOfWork.CarrierPropertyDetailRepository
                    .DeleteAsync(id, deleteModel.DeletedBy);
                if (!setupDelete)
                {
                    // if fails during any items delete , then return failure
                    return false;
                }
            }


            // add more conditions and respective logic 
            var saveResponse = this._unitOfWork.Save();

            return await Task.FromResult<bool>(saveResponse);
        }
    }
}