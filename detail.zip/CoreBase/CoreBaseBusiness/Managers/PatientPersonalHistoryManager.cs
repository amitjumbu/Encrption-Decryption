﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientPersonalHistoryManager : BaseManager<PatientPersonalHistory, PatientPersonalHistoryViewModel>, IPatientPersonalHistoryManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientPersonalHistoryManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        

        public async override Task<int> CountAsync(PatientPersonalHistoryViewModel viewModel)
        {
            Expression<Func<PatientPersonalHistory, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientPersonalHistoryRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientPersonalHistoryViewModel>> RangeAsync(int recordCount, PatientPersonalHistoryViewModel viewModel)
        {
            Expression<Func<PatientPersonalHistory, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientPersonalHistoryRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientPersonalHistoryViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientPersonalHistoryViewModel>> ListAsync(PatientPersonalHistoryViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientPersonalHistory, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientPersonalHistoryRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientPersonalHistoryViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientPersonalHistoryViewModel viewModel)
        {
            var module = this._mapper.Map<PatientPersonalHistory>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientPersonalHistoryRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientPersonalHistoryViewModel viewModel)
        {
            var module = this._mapper.Map<PatientPersonalHistory>(viewModel);
            var data = this._unitOfWork.PatientPersonalHistoryRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
    }
}