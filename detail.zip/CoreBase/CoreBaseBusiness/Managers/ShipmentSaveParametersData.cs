﻿using CoreBaseBusiness.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace CoreBaseBusiness.Managers
{
    static class ShipmentSaveParametersData
    {
        public static DataTable CreateCpdata(ShipmentSaveData shipmentdetails)
        {
            DataTable dtcpdata = null;
            if (shipmentdetails.cpdata != null)
            {
                dtcpdata = new DataTable();
                dtcpdata.Columns.Add("ShipmentID");
                dtcpdata.Columns.Add("FromLocationId");
                dtcpdata.Columns.Add("FromCarrierInTime");
                dtcpdata.Columns.Add("FromCarrierOutTime");
                dtcpdata.Columns.Add("EntityCode");
                foreach (var location in shipmentdetails.cpdata)
                {
                    DataRow dr = dtcpdata.NewRow();
                    dr[0] = shipmentdetails.id;
                    dr[1] = location.locationID;
                    dr[2] = location.checkInTime;
                    dr[3] = location.checkOutTime;
                    dr[4] = "SalesOrder";
                    dtcpdata.Rows.Add(dr);
                }
            }
            return dtcpdata;
        }
        public static DataTable CreateCsddata(ShipmentSaveData shipmentdetails)
        {
            DataTable dtcsddata = null;
            if (shipmentdetails.csddata != null)
            {
                dtcsddata = new DataTable();
                dtcsddata.Columns.Add("ShipmentID");
                dtcsddata.Columns.Add("FromLocationId");
                dtcsddata.Columns.Add("FromCarrierInTime");
                dtcsddata.Columns.Add("FromCarrierOutTime");
                dtcsddata.Columns.Add("EntityCode");
                if (shipmentdetails.csddata != null)
                {
                    foreach (var location in shipmentdetails.csddata)
                    {
                        DataRow dr = dtcsddata.NewRow();
                        dr[0] = shipmentdetails.id;
                        dr[1] = location.locationID;
                        dr[2] = location.checkInTime;
                        dr[3] = location.checkOutTime;
                        dr[4] = "SalesOrder";
                        dtcsddata.Rows.Add(dr);
                    }
                }
            }
            return dtcsddata;

        }
        public static DataTable CreateOrdercomments(ShipmentSaveData shipmentdetails)
        {
            DataTable dtordercomments = new DataTable();
            dtordercomments.Columns.Add("ShipmentID");
            dtordercomments.Columns.Add("orderid");
            dtordercomments.Columns.Add("transportationComment");
            dtordercomments.Columns.Add("spanishTransportationComment");
            dtordercomments.Columns.Add("loadingComment");
            dtordercomments.Columns.Add("spanishLoadingComment");
            dtordercomments.Columns.Add("orderComment");
            dtordercomments.Columns.Add("ordercommentSpanish");
            dtordercomments.Columns.Add("transplaceOrderComment");
            dtordercomments.Columns.Add("transplaceDeliveryComment");
            foreach (var comment in shipmentdetails.ordercomments)
            {
                DataRow dr = dtordercomments.NewRow();
                dr[0] = shipmentdetails.id;
                dr[1] = comment.orderid;
                dr[2] = comment.transportationComment;
                dr[3] = comment.spanishTransportationComment;
                dr[4] = comment.loadingComment;
                dr[5] = comment.spanishLoadingComment;
                dr[6] = comment.orderComment;
                dr[7] = comment.ordercommentSpanish;
                dr[8] = comment.transplaceOrderComment;
                dr[9] = comment.transplaceDeliveryComment;
                dtordercomments.Rows.Add(dr);
            }
            return dtordercomments;
        }
        public static DataTable CreateApcharges(ShipmentSaveData shipmentdetails)
        {
            DataTable dtapcharges = new DataTable();
            dtapcharges.Columns.Add("shipmentID");
            dtapcharges.Columns.Add("BusinessParterneType");
            dtapcharges.Columns.Add("BusinessPartnerLocationID");
            dtapcharges.Columns.Add("BusinessPartnerContactID");
            dtapcharges.Columns.Add("CarrierID");
            dtapcharges.Columns.Add("ChargeID");
            dtapcharges.Columns.Add("ChargeUOMID");
            dtapcharges.Columns.Add("ChargeSequece");
            dtapcharges.Columns.Add("ChargeValue");
            dtapcharges.Columns.Add("ChargeModifiedValue");
            dtapcharges.Columns.Add("SalesTaxClassID");
            dtapcharges.Columns.Add("IsAutoAdded");
            dtapcharges.Columns.Add("IsManual");
            dtapcharges.Columns.Add("IsDefault");

            foreach (var apcharge in shipmentdetails.apcharges)
            {
                DataRow dr = dtapcharges.NewRow();
                dr[0] = shipmentdetails.id;
                dr[1] = apcharge.BusinessPartnerType;
                dr[2] = apcharge.BusinessPartnerLocationID;
                // dr[3] = apcharge.BusinessPartnerContactID;
                dr[3] = null;
                dr[4] = apcharge.CarrierID;
                dr[5] = apcharge.ChargeID;
                dr[6] = apcharge.ChargeUOMID;
                dr[7] = apcharge.ChargeSequece;
                dr[8] = apcharge.ChargeValue;
                dr[9] = apcharge.ChargeModifiedValue;
                dr[10] = apcharge.SalesTaxClassID;
                dr[11] = apcharge.IsAutoAdded;
                dr[12] = apcharge.IsManual;
                dr[13] = 0;

                dtapcharges.Rows.Add(dr);
            }
            return dtapcharges;
        }
        public static DataTable CreateSalesOrderDetail(ShipmentSaveData shipmentdetails)
        {
            DataTable dtsalesOrderDetail = new DataTable();
            dtsalesOrderDetail.Columns.Add("MaterialID");
            dtsalesOrderDetail.Columns.Add("OrderQuantity");
            dtsalesOrderDetail.Columns.Add("ShowOnBOL");
            dtsalesOrderDetail.Columns.Add("PriceMethodID");
            dtsalesOrderDetail.Columns.Add("OrderNumber");
            dtsalesOrderDetail.Columns.Add("ShippedQuantity");
            dtsalesOrderDetail.Columns.Add("CommodityID");
            dtsalesOrderDetail.Columns.Add("UOMCODE");
            dtsalesOrderDetail.Columns.Add("SalesOrderID");
            dtsalesOrderDetail.Columns.Add("ID");
            dtsalesOrderDetail.Columns.Add("NewMaterial");
            dtsalesOrderDetail.Columns.Add("ToLocationId");
            dtsalesOrderDetail.Columns.Add("EntityCode");
            dtsalesOrderDetail.Columns.Add("EquivalentPallets");
            
            if (shipmentdetails.salesOrderDetail != null)
            {
                foreach (var OrderDetail in shipmentdetails.salesOrderDetail)
                {
                    DataRow dr = dtsalesOrderDetail.NewRow();
                    dr[0] = OrderDetail.MaterialID;
                    dr[1] = OrderDetail.OrderQuantity;
                    dr[2] = OrderDetail.ShowOnBOL;
                    dr[3] = OrderDetail.PriceMethodID;
                    dr[4] = OrderDetail.OrderNumber;
                    dr[5] = OrderDetail.ShippedQuantity;
                    dr[6] = OrderDetail.CommodityID;
                    dr[7] = OrderDetail.UOMCODE;
                    dr[8] = OrderDetail.SalesOrderID;
                    dr[9] = OrderDetail.NewMaterial;
                    dr[10] = OrderDetail.ID;
                    dr[11] = OrderDetail.ToLocationId;
                    dr[12] = OrderDetail.EntityCode;
                    dr[13] = OrderDetail.EquivalentPallets;

                    dtsalesOrderDetail.Rows.Add(dr);
                }
            }
            return dtsalesOrderDetail;
        }
        public static DataTable CreateDeletesalesOrderDetail(ShipmentSaveData shipmentdetails)
        {
            DataTable dtDeletesalesOrderDetail = new DataTable();
            dtDeletesalesOrderDetail.Columns.Add("MaterialID");
            dtDeletesalesOrderDetail.Columns.Add("OrderQuantity");
            dtDeletesalesOrderDetail.Columns.Add("ShowOnBOL");
            dtDeletesalesOrderDetail.Columns.Add("PriceMethodID");
            dtDeletesalesOrderDetail.Columns.Add("OrderNumber");
            dtDeletesalesOrderDetail.Columns.Add("ShippedQuantity");
            dtDeletesalesOrderDetail.Columns.Add("CommodityID");
            dtDeletesalesOrderDetail.Columns.Add("UOMCODE");
            dtDeletesalesOrderDetail.Columns.Add("SalesOrderID");
            dtDeletesalesOrderDetail.Columns.Add("NewMaterial");
            dtDeletesalesOrderDetail.Columns.Add("EntityCode");
            if (shipmentdetails.deletesalesOrderDetail != null)
            {
                if (shipmentdetails.deletesalesOrderDetail.Length > 0)
                {
                    foreach (var DeleteOrderDetail in shipmentdetails.deletesalesOrderDetail)
                    {
                        DataRow dr = dtDeletesalesOrderDetail.NewRow();
                        dr[0] = DeleteOrderDetail.MaterialID;
                        dr[1] = DeleteOrderDetail.OrderQuantity;
                        dr[2] = DeleteOrderDetail.ShowOnBOL;
                        dr[3] = DeleteOrderDetail.PriceMethodID;
                        dr[4] = DeleteOrderDetail.OrderNumber;
                        dr[5] = DeleteOrderDetail.ShippedQuantity;
                        dr[6] = DeleteOrderDetail.CommodityID;
                        dr[7] = DeleteOrderDetail.UOMCODE;
                        dr[8] = DeleteOrderDetail.SalesOrderID;
                        dr[9] = DeleteOrderDetail.NewMaterial;
                        dr[10] = DeleteOrderDetail.EntityCode;
                        //dr[10] = 1;
                        //dr[10] = apcharge.SalesTaxClassID;
                        dtDeletesalesOrderDetail.Rows.Add(dr);
                    }
                }
            }
            return dtDeletesalesOrderDetail;
        }
        public static DataTable CreateSalesorderlocations(ShipmentSaveData shipmentdetails)
        {

            DataTable dtsalesorderlocations = new DataTable();
            dtsalesorderlocations.Columns.Add("ShipmentID");
            dtsalesorderlocations.Columns.Add("OrderID");
            dtsalesorderlocations.Columns.Add("FromLocationID");
            dtsalesorderlocations.Columns.Add("ToLocationID");
            dtsalesorderlocations.Columns.Add("OrderTypeID");
            dtsalesorderlocations.Columns.Add("PurchaseNumber");
            dtsalesorderlocations.Columns.Add("EntityCode");
            dtsalesorderlocations.Columns.Add("FromBusinessPartnerContractID");
            dtsalesorderlocations.Columns.Add("ToBusinessPartnerContractID");
            dtsalesorderlocations.Columns.Add("FromCustomerContractID");
            dtsalesorderlocations.Columns.Add("ToCustomerContractID");
           
           
            if (shipmentdetails.locations != null)
            {
                foreach (var location in shipmentdetails.locations)
                {
                    DataRow dr = dtsalesorderlocations.NewRow();
                    dr["ShipmentID"] = shipmentdetails.id;
                    dr["OrderID"] = location.OrderID;
                    dr["FromLocationID"] = location.FromLocationID == 0 ? null : location.FromLocationID;
                    dr["ToLocationID"] = location.ToLocationID == 0 ? null : location.ToLocationID;
                    dr["OrderTypeID"] = location.OrderTypeID;
                    dr["PurchaseNumber"] = location.PurchaseNumber;
                    dr["EntityCode"] = location.EntityCode;
                    dr["FromBusinessPartnerContractID"] = location.FromBusinessPartnerContractID > 0 ? location.FromBusinessPartnerContractID : 0;
                    dr["ToBusinessPartnerContractID"] = location.ToBusinessPartnerContractID > 0 ? location.ToBusinessPartnerContractID : 0;
                    dr["FromCustomerContractID"] = location.FromCustomerContractID > 0 ? location.FromCustomerContractID :0 ;
                    dr["ToCustomerContractID"] = location.ToCustomerContractID > 0 ? location.ToCustomerContractID : 0;
                   
                    dtsalesorderlocations.Rows.Add(dr);
                }
            }
            return dtsalesorderlocations;
        }
        public static DataTable CreateSalesorderappointments(ShipmentSaveData shipmentdetails)
        {
            DataTable dtsalesorderappointments = new DataTable();
            dtsalesorderappointments.Columns.Add("ShipmentID");
            dtsalesorderappointments.Columns.Add("OrderID");
            dtsalesorderappointments.Columns.Add("PickupAppointment");
            dtsalesorderappointments.Columns.Add("DeliveryAppointment");
            dtsalesorderappointments.Columns.Add("EntityCode");
            if (shipmentdetails.appointments != null)
            {
                foreach (var appointment in shipmentdetails.appointments)
                {
                    if (!(appointment.PickupAppointment == null && appointment.DeliveryAppointment == null))
                    {
                        DataRow dr = dtsalesorderappointments.NewRow();
                        dr[0] = shipmentdetails.id;
                        dr[1] = appointment.OrderID;
                        dr[2] = appointment.PickupAppointment;
                        dr[3] = appointment.DeliveryAppointment;
                        dr[4] = appointment.EntityCode;
                        dtsalesorderappointments.Rows.Add(dr);
                    }
                }
            }
            return dtsalesorderappointments;
        }

        public static DataTable CreateOrdApcData(ApchargeLocChangeModel apchargeLocChangeModel)
        {
            
           // ordDetailsApcLocChange 
            DataTable dtorderApcLocChange = null;
            if (apchargeLocChangeModel.orderApcLocChange != null)
            {
                dtorderApcLocChange = new DataTable();
                dtorderApcLocChange.Columns.Add("ShipmentID");
                dtorderApcLocChange.Columns.Add("OrderID");
                dtorderApcLocChange.Columns.Add("FromLocationID");
                dtorderApcLocChange.Columns.Add("ToLocationID");
                dtorderApcLocChange.Columns.Add("ReqDeliveryDate");
                dtorderApcLocChange.Columns.Add("OrderTypeID");
                dtorderApcLocChange.Columns.Add("PurchaseNumber");
                dtorderApcLocChange.Columns.Add("EntityCode");
                dtorderApcLocChange.Columns.Add("FromBusinessPartnerContractID");
                dtorderApcLocChange.Columns.Add("ToBusinessPartnerContractID");
                dtorderApcLocChange.Columns.Add("FromCustomerContractID");
                dtorderApcLocChange.Columns.Add("ToCustomerContractID");
                dtorderApcLocChange.Columns.Add("ClientID");

                foreach (var apcorder in apchargeLocChangeModel.orderApcLocChange)
                {
                    DataRow dr = dtorderApcLocChange.NewRow();
                    dr["ShipmentID"] = apchargeLocChangeModel.shipmentid;
                    dr["OrderID"] = apcorder.OrderID;
                    dr["FromLocationID"] = apcorder.FromLocationID;
                    dr["ToLocationID"] = apcorder.ToLocationID;
                    dr["ReqDeliveryDate"] = apcorder.ReqDeliveryDate ;
                    dr["OrderTypeID"] = apcorder.OrderTypeID;
                    dr["PurchaseNumber"] = apcorder.PurchaseNumber;
                    dr["EntityCode"] = apcorder.EntityCode;
                    dr["FromBusinessPartnerContractID"] = apcorder.FromBusinessPartnerContractID;
                    dr["ToBusinessPartnerContractID"] = apcorder.ToBusinessPartnerContractID;
                    dr["FromCustomerContractID"] = apcorder.FromCustomerContractID;
                    dr["ToCustomerContractID"] = apcorder.ToCustomerContractID;
                    dr["ClientID"] = apcorder.ClientID;
                    dtorderApcLocChange.Rows.Add(dr);
                }
            }
            return dtorderApcLocChange;
        }

        public static DataTable CreateOrdDetApcData(ApchargeLocChangeModel apchargeLocChangeModel)
        {

            // ordDetailsApcLocChange 
            DataTable dtorderdetApcLocChange = null;
            if (apchargeLocChangeModel.ordDetailsApcLocChange != null)
            {
                dtorderdetApcLocChange = new DataTable();
                dtorderdetApcLocChange.Columns.Add("ID");
                dtorderdetApcLocChange.Columns.Add("SalesOrderID");
                dtorderdetApcLocChange.Columns.Add("MaterialID");
                dtorderdetApcLocChange.Columns.Add("OrderQuantity");
                dtorderdetApcLocChange.Columns.Add("ShowOnBOL");
                dtorderdetApcLocChange.Columns.Add("PriceMethodID");
                dtorderdetApcLocChange.Columns.Add("OrderNumber");
                dtorderdetApcLocChange.Columns.Add("ShippedQuantity");
                dtorderdetApcLocChange.Columns.Add("CommodityID");
                dtorderdetApcLocChange.Columns.Add("UOMCODE");
                dtorderdetApcLocChange.Columns.Add("NewMaterial");
                dtorderdetApcLocChange.Columns.Add("EquivalentPallets");

                foreach (var apcorderdet in apchargeLocChangeModel.ordDetailsApcLocChange)
                {
                    DataRow dr = dtorderdetApcLocChange.NewRow();

                    dr["ID"] = apcorderdet.ID;
                    dr["SalesOrderID"] = apcorderdet.SalesOrderID;
                    dr["MaterialID"] = apcorderdet.MaterialID;
                    dr["OrderQuantity"] = apcorderdet.OrderQuantity;
                    dr["ShowOnBOL"] = apcorderdet.ShowOnBOL;
                    dr["PriceMethodID"] = apcorderdet.PriceMethodID;
                    dr["OrderNumber"] = apcorderdet.OrderNumber;
                    dr["ShippedQuantity"] = apcorderdet.ShippedQuantity;
                    dr["CommodityID"] = apcorderdet.CommodityID;
                    dr["UOMCODE"] = apcorderdet.UOMCODE;
                    dr["NewMaterial"] = apcorderdet.NewMaterial;
                    dr["EquivalentPallets"] = apcorderdet.EquivalentPallets;
                    dtorderdetApcLocChange.Rows.Add(dr);
                }
            }
            return dtorderdetApcLocChange;
        }



    }
}