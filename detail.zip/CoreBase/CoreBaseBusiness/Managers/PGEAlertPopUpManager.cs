﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class PGEAlertPopUpManager : BaseManager<PGEAlertPopUp, PGEAlertPopUpViewModel>, IPGEAlertPopUpManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public PGEAlertPopUpManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<PGEAlertPopUpViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.PGEAlertPopUpRepository.GetAsync(id);

            
            var viewModel = this._mapper.Map<PGEAlertPopUpViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from PGEAlertPopUp Details.
        /// </summary>
        public async override Task<IEnumerable<PGEAlertPopUpViewModel>> ListAsync(PGEAlertPopUpViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PGEAlertPopUp, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PGEAlertPopUpRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PGEAlertPopUpViewModel>>(module);
        }

        /// <summary>
        /// Add New PGEAlertPopUp Data into System
        /// </summary>
        public async override Task<bool> AddAsync(PGEAlertPopUpViewModel viewModel)
        {
            var module = this._mapper.Map<PGEAlertPopUp>(viewModel);
            var data = this._unitOfWork.PGEAlertPopUpRepository.AddAsync(module);

            

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.ID : 0;

            return await Task.FromResult<bool>(finalResult);
        } 

        /// <summary>
        ///  Updates existing record for PGEAlertPopUp Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(PGEAlertPopUpViewModel viewModel)
        {
            var module = this._mapper.Map<PGEAlertPopUp>(viewModel);
            var data = this._unitOfWork.PGEAlertPopUpRepository.UpdateAsync(module);

            

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from PGEAlertPopUp Details.
        /// </summary>
        public async override Task<int> CountAsync(PGEAlertPopUpViewModel viewModel)
        {
            Expression<Func<PGEAlertPopUp, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsActive == viewModel.IsActive);
            else
                condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.PGEAlertPopUpRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  PGEAlertPopUp details of Patient 
        /// </summary>
        public async override Task<IEnumerable<PGEAlertPopUpViewModel>> RangeAsync(int recordCount, PGEAlertPopUpViewModel viewModel)
        {
            Expression<Func<PGEAlertPopUp, bool>> condition = (c => c.IsActive == true && (c.ClientID == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientID == viewModel.PaientId || viewModel.PaientId == 0) && (c.StageId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.PGEAlertPopUpRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var PGEAlertPopUpModel = this._mapper.Map<IEnumerable<PGEAlertPopUpViewModel>>(module);
            

            return PGEAlertPopUpModel;
        }


        /// <summary>
        ///  Deletes record PGEAlertPopUp from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.PGEAlertPopUpRepository.DeleteAsync(id, deletedBy);

           

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


