﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class FuelSurchargeIndexManager : BaseManager<FuelChargeIndex, FuelSurchargeIndexViewModel>, IFuelSurchargeIndexManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        //private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public FuelSurchargeIndexManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
            _unitOfWork.ConnectionString = this.BaseConnectionString;
        }





        public async Task<IEnumerable<FuelPriceTypeViewModel>> GetFuelPriceTypes(FuelPriceTypeViewModel fuelpricetypeViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", fuelpricetypeViewModel.ClientId);

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuelPriceType", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                List<FuelPriceTypeViewModel> fuelpricetypes = ConvertDataTabe.CreateListFromTable<FuelPriceTypeViewModel>(ds.Tables[0]);
                //List<FuelPriceTypeViewModel> fuelpricetypes = ConvertDataTableToGenericList<FuelPriceTypeViewModel>(ds.Tables[0]);

                if (fuelpricetypes.Count > 0)
                {
                    return await Task.FromResult<IEnumerable<FuelPriceTypeViewModel>>(fuelpricetypes.AsEnumerable());
                }
                else
                {
                    return null;
                }
                return await Task.FromResult<IEnumerable<FuelPriceTypeViewModel>>(fuelpricetypes.AsEnumerable());
            }

            return null;
        }
        #region Get Fuel Price type
        public List<FuelPriceTypeViewModel> GetFuelPriceType(long ClientId)
        {
            List<FuelPriceTypeViewModel> usersList = new List<FuelPriceTypeViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", ClientId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuelPriceType", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new FuelPriceTypeViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        Name = dr["Name"].ToString()
                    });
                }
            }

            return usersList;
        }
        #endregion

        #region Get Charge Rate UOM
        public List<UOMViewModel> GetChargeRateUOM(long ClientId)
        {
            List<UOMViewModel> usersList = new List<UOMViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", ClientId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetChargeRateUOM", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new UOMViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        Name = dr["Name"].ToString()
                    });
                }
            }

            return usersList;
        }
        #endregion

        #region Save List of Fuel Surcharge records
        //public async Task<IEnumerable<FuelSurchargeIndexViewModel>> SaveAll(List<FuelSurchargeIndexViewModel> ViewModels)
        //{
        //    if (ViewModels.Any())
        //    {
        //        foreach (FuelSurchargeIndexViewModel ViewModel in ViewModels)
        //        {
        //            var result = await this._unitOfWork.FuelSurchargeIndexRepository.AddAsync(this._mapper.Map<FuelChargeIndex>(ViewModel)).ConfigureAwait(false);
        //        }

        //        var finalResult = this._unitOfWork.Save();

        //        return await Task.FromResult<bool>(finalResult).ConfigureAwait(false);

        //    }
        //    else
        //    {
        //        return await Task.FromResult<bool>(false).ConfigureAwait(false);
        //    }
        //}
        public async Task<IEnumerable<FuelSurchargeIndexViewModel>> SaveAll(List<FuelSurchargeIndexViewModel> ViewModels)
        {
            var freightalls = new List<FuelSurchargeIndexViewModel>();

            foreach (FuelSurchargeIndexViewModel ViewModel in ViewModels)
            {
                var module = this._mapper.Map<FuelChargeIndex>(ViewModel);
                var result = await this._unitOfWork.FuelSurchargeIndexRepository.AddAsync(module).ConfigureAwait(false);
                if (result)
                {
                    
                    this._unitOfWork.Save();
                    ViewModel.ID = module.Id;
                    freightalls.Add(ViewModel);
                }
            }
            return freightalls;
        }
        #endregion

        public async override Task<int> CountAsync(FuelSurchargeIndexViewModel viewModel)
        {
            Expression<Func<FuelChargeIndex, bool>> condition = (c => (!c.IsDeleted) && (viewModel.ClientID == null || c.ClientId == viewModel.ClientID));


            //if (viewModel.ID > 0)
            //    condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            //else
            //    condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.FuelSurchargeIndexRepository.CountAsync(condition);
        }

        //public async override Task<int> CountAsync(FreightModeViewModel viewModel)
        //{
        //    Expression<Func<FreightMode, bool>> condition = (c => (!c.IsDeleted) && (viewModel.ClientID == null || c.ClientId == viewModel.ClientID));

        //    return await this._unitOfWork.freightmodeRepository.CountAsync(condition);
        //}
        public async override Task<IEnumerable<FuelSurchargeIndexViewModel>> RangeAsync(int recordCount, FuelSurchargeIndexViewModel viewModel)
        {
            Expression<Func<FuelChargeIndex, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.FuelSurchargeIndexRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<FuelSurchargeIndexViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<FuelSurchargeIndexViewModel>> ListAsync(FuelSurchargeIndexViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<FuelChargeIndex, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.FuelSurchargeIndexRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<FuelSurchargeIndexViewModel>>(module);
        }
        public override async Task<FuelSurchargeIndexViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.FuelSurchargeIndexRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<FuelSurchargeIndexViewModel>((FuelChargeIndex)module);
        }
        public async Task<IEnumerable<FuelSurchargeIndexViewModel>> GetFuelSurchargeListByIDs(CollectFuelchargeIndexIDs collectHospialIDs)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            Parameter.Add("IDs", collectHospialIDs.IDs);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuleSurchargeindexListByIDs", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FuelSurchargeIndexViewModel>(ds.Tables[0]);
                return finalResult;
            }
            return null;
        }
        public async override Task<bool> AddAsync(FuelSurchargeIndexViewModel viewModel)
        {
            viewModel.IsDeleted = false;
            viewModel.UpdateDateTimeServer = DateTime.Now;
            viewModel.CreateDateTimeServer = DateTime.Now;
            var module = this._mapper.Map<FuelChargeIndex>(viewModel);
            var data = this._unitOfWork.FuelSurchargeIndexRepository.AddAsync(module);

            this._unitOfWork.Save();

           // viewModel.ID = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(data.Result);
        }
      
        #region Update record
        public async override Task<bool> UpdateAsync(FuelSurchargeIndexViewModel viewModel)
        {
            var module = this._mapper.Map<FuelChargeIndex>(viewModel);
            var data = this._unitOfWork.FuelSurchargeIndexRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
        #endregion

        #region Delete record
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.FuelSurchargeIndexRepository.DeleteAsync(id, deletedBy);
            var result = this._unitOfWork.Save();
            return await Task.FromResult<bool>(result);
        }
        #endregion

        #region Bind Fuel surCharge INdex list API
        public async Task<IEnumerable<FuelSurchargeIndexViewModel>> GetFuelSurChargeindexList(FuelSurchargeIndexViewModel fuelSurchargeIndexViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (fuelSurchargeIndexViewModel != null && string.IsNullOrWhiteSpace(fuelSurchargeIndexViewModel.FilterOn))
            {
                Parameter.Add("ClientID", fuelSurchargeIndexViewModel.ClientID);
                Parameter.Add("PageNumber", fuelSurchargeIndexViewModel.PageNo);
                Parameter.Add("PageSize", fuelSurchargeIndexViewModel.PageSize);
            }
            if (!string.IsNullOrWhiteSpace(fuelSurchargeIndexViewModel.SortColumn))
            {
                Parameter.Add("SortColumn", fuelSurchargeIndexViewModel.SortColumn);
            }
            if (!string.IsNullOrWhiteSpace(fuelSurchargeIndexViewModel.SortOrder))
            {
                Parameter.Add("SortOrder", fuelSurchargeIndexViewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuelSurChargeindexList", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FuelSurchargeIndexViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<FuelSurchargeIndexViewModel>>(FilterResult<FuelSurchargeIndexViewModel>.GetFilteredResult(finalResult, fuelSurchargeIndexViewModel.FilterOn, fuelSurchargeIndexViewModel.PageSize));
            }

            return null;
        }
        #endregion
        #region Get Hospitals by Multiple Id
        public async Task<IEnumerable<FuelSurchargeIndexViewModel>> GetFuelSurchargeIndexListByIDs(CollectFuelchargeIndexIDs collectFuelchargeIndexIDs)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            Parameter.Add("IDs", collectFuelchargeIndexIDs.IDs);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetFuelSurchargeIndexListByIDs", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FuelSurchargeIndexViewModel>(ds.Tables[0]);
                return finalResult;
            }
            return null;
        }
        #endregion
        #region Delete collection of ids
        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<int> ID = ids.ConvertAll(int.Parse);
                List<FuelChargeIndex> fuelsurcharge = this._unitOfWork.FuelSurchargeIndexRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();

                foreach (FuelChargeIndex fuels in fuelsurcharge)
                {
                    fuels.IsDeleted = true;
                }

                var result = this._unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }
        #endregion
    }
}