﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using NPOI.SS.Formula.Functions;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class MaterialHierarchyManager : BaseManager<MaterialHierarchy, MaterialHierarchyViewModel>, IMaterialHierarchyManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        public MaterialHierarchyManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(MaterialHierarchyViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<MaterialHierarchyViewModel>> ListAsync(MaterialHierarchyViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MaterialHierarchyViewModel>> ListMaterialHierarchyAsync(MaterialHierarchyViewModel viewModel)
        {
            //Expression<Func<MaterialHierarchy, bool>> condition = c => !c.IsDeleted && (c.ClientId == viewModel.ClientID || viewModel.ClientID == null || viewModel.ClientID == 0);
            //var module = await this._unitOfWork.MaterialHierarchyRepository.ListMaterialHierarchyAsync(condition).ConfigureAwait(false);
            //return this._mapper.Map<IEnumerable<MaterialHierarchyViewModel>>(module);

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialHierarchyList", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialHierarchyViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialHierarchyViewModel>>(FilterResult<MaterialHierarchyViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        #region Get Material Hierarchy Total records Count
        public async Task<int> RecordCountAsync(MaterialHierarchyViewModel viewModel)
        {
            var module = this._mapper.Map<MaterialHierarchy>(viewModel);
            var count = await this._unitOfWork.MaterialHierarchyRepository.MHRecordCountAsync(module).ConfigureAwait(false);
            return await Task.FromResult<int>(count);
        }

        #endregion
        public override Task<bool> UpdateAsync(MaterialHierarchyViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}
