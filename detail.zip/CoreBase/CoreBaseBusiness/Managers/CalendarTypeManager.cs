﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class CalendarTypeManager : BaseManager<CalendarType, CalendarTypeViewModel>, ICalendarTypeManager
    {
        private readonly IMapper mapper;
        private readonly IConfiguration configuration;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        private string ConnectionString { get { return this.BaseConnectionString; } }

        public CalendarTypeManager(
            IConfiguration configuration, 
            IMapper mapper,
            ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        public override Task<bool> AddAsync(CalendarTypeViewModel viewModel)
        {
            throw new System.NotImplementedException();
        }

        public override Task<bool> UpdateAsync(CalendarTypeViewModel viewModel)
        {
            throw new System.NotImplementedException();
        }

        public override Task<IEnumerable<CalendarTypeViewModel>> ListAsync(CalendarTypeViewModel viewModel)
        {
            throw new System.NotImplementedException();
        }


        public async Task<IEnumerable<CalendarTypeViewModel>> GetList()
        {
            var module = await this.unitOfWork.CalendarTypeRepository.GetAll();
            var viewModels = this.mapper.Map<List<CalendarTypeViewModel>>(module);
            return viewModels;
        }
    }
}
