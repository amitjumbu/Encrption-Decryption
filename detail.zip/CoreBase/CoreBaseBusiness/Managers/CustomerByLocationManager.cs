﻿namespace CoreBaseBusiness.Managers
{
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;

    public class CustomerByLocationManager : ICustomerByLocationManager
    {
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerByLocationManager"/> class.
        /// which is used to implement dependancy injection into manager.
        /// </summary>
        /// <param name="unitOfWork">database communication unit of work.</param>
        public CustomerByLocationManager(ADecTecCoreBaseDBContext eICDBContext)
        {
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }


        /// <summary>
        /// Get Customer By Location.
        /// </summary>
        /// <param name="customerByLocationViewModel">data model for pagination.</param>
        /// <returns> Returns a list of CustomerByLocation Details list</returns>
        public async Task<IEnumerable<CustomerByLocationViewModel>> GetCustomerByLocation(
                CustomerByLocationViewModel customerByLocationViewModel)
        {
            Dictionary<string, object> storedProcedureParameter = new Dictionary<string, object>();
            if (customerByLocationViewModel != null
                && string.IsNullOrWhiteSpace(customerByLocationViewModel.FilterOn))
            {
                storedProcedureParameter.Add("PageNumber", customerByLocationViewModel.PageNo);
                storedProcedureParameter.Add("PageSize", customerByLocationViewModel.PageSize);
            }

            storedProcedureParameter.Add("ClientId", customerByLocationViewModel.ClientID);

            if (!string.IsNullOrWhiteSpace(customerByLocationViewModel.SortColumn))
            {
                storedProcedureParameter.Add("SortColumn", customerByLocationViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(customerByLocationViewModel.SortOrder))
            {
                storedProcedureParameter.Add("SortOrder", customerByLocationViewModel.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetCustomerByLocationDetails", storedProcedureParameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CustomerByLocationViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CustomerByLocationViewModel>>(
                    FilterResult<CustomerByLocationViewModel>.GetFilteredResult(
                        finalResult,
                        customerByLocationViewModel.FilterOn,
                        customerByLocationViewModel.PageSize, customerByLocationViewModel));
            }

            return null;
        }

        public async Task<bool> UpdateCustomerByLocation(CustomerByLocationEditModel customerByLocationEditModel)
        {
            var location = new Location();
            // Update Location attributes
            {
                location.Id = customerByLocationEditModel.CustomerId;
                location.LoadingComment = customerByLocationEditModel.LoadingComment;
                location.TransportationComment = customerByLocationEditModel.TransportationComment;
                location.UpdateDateTimeBrowser = customerByLocationEditModel.UpdateDateTimeBrowser;
                location.DefaultCommodityID = customerByLocationEditModel.DefaultCommodityID;
                location.SetupComplete = customerByLocationEditModel.SetupDone;
                location.SetupCompleteDateTime = customerByLocationEditModel.SetupDoneDateTime;
                location.UpdatedBy = customerByLocationEditModel.UpdatedBy;
                var updateSuccsessful = await this.unitOfWork.LocationRepository.UpdateAsync(location);
                if (!updateSuccsessful)
                {
                    return false;
                }

            }

            // update sales broker
            {
                var salesBrokerEntityProperty = await this.unitOfWork.EntityPropertyRepository.GetByCode("SalesBroker");
                Expression<Func<CustomerPropertyDetail, bool>> condition =
                        c => c.IsDeleted == false
                            && c.EntityPropertyId == salesBrokerEntityProperty.Id
                            && c.LocationId == customerByLocationEditModel.CustomerId;
                var list = await this.unitOfWork.CustomerPropertyDetailRepository.GetList(condition);
                if (list != null)
                {
                    foreach (CustomerPropertyDetail dets in list)
                    {
                        await this.unitOfWork.CustomerPropertyDetailRepository.DeleteAsync(dets.Id, customerByLocationEditModel.UpdatedBy);
                    }
                }

                var addSalesBroker = await this.unitOfWork.CustomerPropertyDetailRepository.AddAsync(new CustomerPropertyDetail
                {
                    LocationId = customerByLocationEditModel.CustomerId,
                    EntityPropertyId = salesBrokerEntityProperty.Id,
                    IsDeleted = false,
                    ClientId = customerByLocationEditModel.ClientID,
                    PropertyValue = customerByLocationEditModel.SalesBrokerId.ToString(),
                    UpdatedBy = customerByLocationEditModel.UpdatedBy,
                    UpdateDateTimeBrowser = customerByLocationEditModel.UpdateDateTimeBrowser,
                    CreateDateTimeBrowser = customerByLocationEditModel.UpdateDateTimeBrowser
                });

                if (!addSalesBroker)
                {
                    return false;
                }
            }

            // update sales Manager
            {
                var salesManagerEntityProperty = await this.unitOfWork.EntityPropertyRepository.GetByCode("SalesManager");
                Expression<Func<CustomerPropertyDetail, bool>> condition =
                        c => c.IsDeleted == false && c.EntityPropertyId == salesManagerEntityProperty.Id && c.LocationId == customerByLocationEditModel.CustomerId;
                var list = await this.unitOfWork.CustomerPropertyDetailRepository.GetList(condition);
                if (list != null)
                {
                    foreach (CustomerPropertyDetail dets in list)
                    {
                        await this.unitOfWork.CustomerPropertyDetailRepository.DeleteAsync(dets.Id, customerByLocationEditModel.UpdatedBy);
                    }
                }

                var addSalesManager = await this.unitOfWork.CustomerPropertyDetailRepository.AddAsync(new CustomerPropertyDetail
                {
                    LocationId = customerByLocationEditModel.CustomerId,
                    EntityPropertyId = salesManagerEntityProperty.Id,
                    IsDeleted = false,
                    ClientId = customerByLocationEditModel.ClientID,
                    PropertyValue = customerByLocationEditModel.SalesManagerId.ToString(),
                    UpdatedBy = customerByLocationEditModel.UpdatedBy,
                    UpdateDateTimeBrowser = customerByLocationEditModel.UpdateDateTimeBrowser,
                    CreateDateTimeBrowser = customerByLocationEditModel.UpdateDateTimeBrowser
                });

                if (!addSalesManager)
                {
                    return false;
                }
            }

            var saveAll = this.unitOfWork.Save();

            if (saveAll)
            {
                return true;
            }

            return false;

        }
        #region Active/Inactive location Businesspartner
        public async Task<bool> ActivateCustomerByLocation(List<string> ids, bool isActive)
        {
            if (ids.Any())
            {
                List<long> CustomerbyLocationID = ids.ConvertAll(long.Parse);

                List<Location> CustomerbyLocationStatus = this.unitOfWork.LocationRepository.ListAsync(p => CustomerbyLocationID.Contains(p.Id)).Result.ToList();
                if (CustomerbyLocationStatus.Count != 0)
                {
                    foreach (Location customerbylocation in CustomerbyLocationStatus)
                    {
                        customerbylocation.IsActive = isActive;
                    }

                    var result = this.unitOfWork.Save();

                    return await Task.FromResult<bool>(result);
                }
                return await Task.FromResult<bool>(false);
            }

            return await Task.FromResult<bool>(false);
        }
        #endregion
    }
}
