﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{

    public class ProteinManager : BaseManager<MeasurementUrineProtienMeasurementValue, ProteinViewModel>, IProteinManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public ProteinManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<ProteinViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.ProteinRepository.GetAsync(id);

           
            var viewModel = this._mapper.Map<ProteinViewModel>(module);

           
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_UrineProtienMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<ProteinViewModel>> ListAsync(ProteinViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementUrineProtienMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }

            var module = await this._unitOfWork.ProteinRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<ProteinViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_UrineProtienMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(ProteinViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementUrineProtienMeasurementValue>(viewModel);
            var data = this._unitOfWork.ProteinRepository.AddAsync(module);

           
            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_UrineProtienMeasurementValue Details. 
        /// </summary>
        public async override Task<bool> UpdateAsync(ProteinViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementUrineProtienMeasurementValue>(viewModel);
            var data = this._unitOfWork.ProteinRepository.UpdateAsync(module);

            
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_UrineProtienMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(ProteinViewModel viewModel)
        {
            Expression<Func<MeasurementUrineProtienMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.ProteinRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_UrineProtienMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<ProteinViewModel>> RangeAsync(int recordCount, ProteinViewModel viewModel)
        {
            Expression<Func<MeasurementUrineProtienMeasurementValue, bool>> condition = (c => c.IsDeleted == false);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            var module = await this._unitOfWork.ProteinRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var ProteinModel = this._mapper.Map<IEnumerable<ProteinViewModel>>(module);
            

            return ProteinModel;
        }


        /// <summary>
        ///  Deletes record Measurement_UrineProtienMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.ProteinRepository.DeleteAsync(id, deletedBy);

            
            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


