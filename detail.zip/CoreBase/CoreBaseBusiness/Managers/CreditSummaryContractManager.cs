﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class CreditSummaryContractManager : BaseManager<ArinvoiceAgeDetail, CreditSummaryViewModel>, ICreditSummaryContractManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        private string ConnectionString { get { return this.BaseConnectionString; } }

        public CreditSummaryContractManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(CreditSummaryViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<CreditSummaryViewModel>> GetCreditSummaryListCount(CreditSummaryViewModel aRInvoiceAgeDetailViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
               // parameter.Add("@OrganizationID", aRInvoiceAgeDetailViewModel.OrganizationID);
               // parameter.Add("@SystemTypeCode", aRInvoiceAgeDetailViewModel.SystemTypeCode);
                var usersViewModels = con.Query<CreditSummaryViewModel>("SPO_CreditSummary", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }


        public async Task<IEnumerable<CreditSummaryViewModel>> GetCreditSummaryList(CreditSummaryViewModel aRInvoiceAgeDetailViewModel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            if (aRInvoiceAgeDetailViewModel != null && string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.FilterOn))
            {
                parameter.Add("PageNumber", aRInvoiceAgeDetailViewModel.PageNo);
                parameter.Add("PageSize", aRInvoiceAgeDetailViewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.SortColumn))
            {
                parameter.Add("SortColumn", aRInvoiceAgeDetailViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(aRInvoiceAgeDetailViewModel.SortOrder))
            {
                parameter.Add("SortOrder", aRInvoiceAgeDetailViewModel.SortOrder);
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_CreditSummary", parameter);

            DataTable dtCloned = ds.Tables[0].Clone();
            dtCloned.Columns[3].DataType = typeof(string);
            dtCloned.Columns[4].DataType = typeof(string);
            dtCloned.Columns[5].DataType = typeof(string);
            dtCloned.Columns[6].DataType = typeof(string);
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                dtCloned.ImportRow(row);
            }
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CreditSummaryViewModel>(dtCloned);
                return await Task.FromResult<IEnumerable<CreditSummaryViewModel>>(FilterResult<CreditSummaryViewModel>.GetFilteredResult(finalResult, aRInvoiceAgeDetailViewModel.FilterOn, aRInvoiceAgeDetailViewModel.PageSize));
            }

            return null;
        }

        public override Task<IEnumerable<CreditSummaryViewModel>> ListAsync(CreditSummaryViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(CreditSummaryViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}
