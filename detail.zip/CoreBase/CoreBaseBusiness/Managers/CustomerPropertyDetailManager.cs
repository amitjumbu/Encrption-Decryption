﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.Helpers;
using System.Data.SqlClient;
using System.Data;
using System.Linq;

namespace CoreBaseBusiness.Managers
{

    public class CustomerPropertyDetailManager :
        BaseManager<CustomerPropertyDetail, CustomerPropertyDetailViewModel>, 
        ICustomerPropertyDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public CustomerPropertyDetailManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            _unitOfWork.ConnectionString = this.BaseConnectionString;
        }

        /// <summary>
        ///User can get Retrieves data from LocationContact by id.
        /// </summary>
        //public override async Task<LocationPreferredMaterialViewModel> GetAsync(int id)
        //{
        //    var module = await _unitOfWork.LocationPreferredMaterialRepository.GetById(id).ConfigureAwait(false);
        //    return this._mapper.Map<LocationPreferredMaterialViewModel>((LocationPreferredMaterial)module);
        //}


        ///// <summary>
        ///// Commodity Add Data.
        ///// </summary>
        //public async override Task<bool> AddAsync(LocationContactViewModel viewModel)
        //{
        //    var module = this._mapper.Map<LocationContact>(viewModel);
        //    var data = this._unitOfWork.LocationContactRepository.AddAsync(module);

        //    var finalResult = this._unitOfWork.Save();

        //    viewModel.Id = finalResult ? module.Id : 0;

        //    return await Task.FromResult<bool>(finalResult);
        //}


        /// <summary>
        ///  Retrieves  All data from LocationContact.
        /// </summary>
        public async override Task<IEnumerable<CustomerPropertyDetailViewModel>> ListAsync(CustomerPropertyDetailViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<CustomerPropertyDetail, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.CustomerPropertyDetailRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CustomerPropertyDetailViewModel>>(module);
        }

        /// <summary>
        /// LocationContact Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(CustomerPropertyDetailViewModel viewModel)
        {
            var module = this._mapper.Map<CustomerPropertyDetail>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            
            var data = this._unitOfWork.CustomerPropertyDetailRepository.AddAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<bool> InsertCustomerPropertyDetails(CustomerPropertyDetailViewModel viewModel)
        {
            string strConnectionString = this.ConnectionString;
            SqlDataAdapter sqla = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int result = 0;

            using (SqlConnection con = new SqlConnection(strConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SPO_InsertCustomerPropertyDetail", con))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@PropertyValue", viewModel.PropertyValue);
                    cmd.Parameters.AddWithValue("@PropertiesUOM", viewModel.PropertiesUom);
                    cmd.Parameters.AddWithValue("@EntityPropertyCode", viewModel.EntityPropertyCode);
                    cmd.Parameters.AddWithValue("@SourceSystemId", viewModel.SourceSystemID);
                    cmd.Parameters.AddWithValue("@UpdatedBy", viewModel.UpdatedBy);
                    cmd.Parameters.AddWithValue("@LocationId", viewModel.LocationId);
                    cmd.Parameters.AddWithValue("@ClientId", viewModel.ClientID);
                    cmd.Parameters.Add("@IntResult", (SqlDbType)Convert.ToInt32("0"));
                    cmd.Parameters["@IntResult"].Direction = ParameterDirection.Output;

                    try
                    {
                        con.Open();

                        // int i = cmd.ExecuteNonQuery();
                        sqla = new SqlDataAdapter(cmd);
                        sqla.Fill(ds);

                        result = Convert.ToInt32(cmd.Parameters["@IntResult"].Value);

                        if (result > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                    catch (Exception ex)
                    {
                        // throw the exception
                    }
                    finally
                    {
                        con.Close();
                    }


                }
            }

            return false;
        }

        /// <summary>
        ///  Updates existing record for LocationContact Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(CustomerPropertyDetailViewModel viewModel)
        {
            if (viewModel.PageAction == Constants.PageActionType.Location)
            {
                var module = this._mapper.Map<CustomerPropertyDetail>(viewModel);
                module.IsDeleted = false;
                module.UpdateDateTimeServer = DateTime.Now;
                module.CreateDateTimeServer = DateTime.Now;
                
                var data = this._unitOfWork.CustomerPropertyDetailRepository.UpdateAsync(module);
                this._unitOfWork.Save();
                return await Task.FromResult<bool>(data.Result);
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        ///  Retrieves Count Of All data from LocationContact.
        /// </summary>
        public async override Task<int> CountAsync(CustomerPropertyDetailViewModel viewModel)
        {
            Expression<Func<CustomerPropertyDetail, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.ID > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.CustomerPropertyDetailRepository.CountAsync(condition);
        }

        /// <summary>
        /// Get All List for LocationContact Data List
        /// </summary>
        public async override Task<IEnumerable<CustomerPropertyDetailViewModel>> RangeAsync(int recordCount, CustomerPropertyDetailViewModel viewModel)
        {
            Expression<Func<CustomerPropertyDetail, bool>> condition = c => c.IsDeleted == false && c.LocationId == viewModel.LocationId;
            var module = await this._unitOfWork.CustomerPropertyDetailRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<CustomerPropertyDetailViewModel>>(module);
            return mappedData;
        }


        /// <summary>
        /// Get All List for LocationContact Data List
        /// </summary>
        public async Task<IEnumerable<CustomerPropertyDetailViewModel>> RangeAsyncList(CustomerPropertyDetailViewModel viewModel)
        {
            //Expression<Func<CustomerPropertyDetail, bool>> condition = c => c.IsDeleted == false && c.LocationId == viewModel.LocationId;
            //var module = await this._unitOfWork.CustomerPropertyDetailRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            //var mappedData = this._mapper.Map<IEnumerable<CustomerPropertyDetailViewModel>>(module);
            //return mappedData;

            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (viewModel != null)
            {
                parameters.Add("LocationId", viewModel.LocationId);
                parameters.Add("EntityPropertyCode", viewModel.EntityPropertyCode);

            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetCustomerPropertyDetail", parameters);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CustomerPropertyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CustomerPropertyDetailViewModel>>(finalResult);
            }

            return null;
        }

        /// <summary>
        /// User can get list by locatinId.
        /// </summary>
        public async Task<IEnumerable<CustomerPropertyDetailViewModel>> GetList(int id)
        {
            Expression<Func<CustomerPropertyDetail, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.CustomerPropertyDetailRepository.GetList(condition);
            var mappedData = this._mapper.Map<IEnumerable<CustomerPropertyDetailViewModel>>(module);
            return mappedData;
        }

       


        /// <summary>
        ///  Deletes record from LocationContact id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.CustomerPropertyDetailRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        //public async Task<IEnumerable<LocationViewModel>> LocationList(LocationViewModel viewModel)
        //{
        //    long locationTypeId = await this.GetLocationTypedId(viewModel.LocationTypeCode);

        //    Expression<Func<Location, bool>> condition = c => c.IsDeleted == false && c.LocationTypeId == locationTypeId && c.ClientId == viewModel.ClientId && c.IsActive == true;
        //    var module = await this._unitOfWork.LocationRepository.GetList(condition);
        //    var mappedData = this._mapper.Map<IEnumerable<LocationViewModel>>(module);
        //    return mappedData;

        //}

        /// <summary>
        ///  Deletes record Caput from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {

            var data = this._unitOfWork.CustomerPropertyDetailRepository.DeleteAsync(id, deletedBy);            

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }


        /// <summary>
        /// Softly remove default Equipment from the system.
        /// </summary>
        /// <param name="id">Existing UserAddress ID</param>
        /// <param name="deletedBy">Name of user who wants to remove UserAddress from the system.</param>
        /// <returns>on sucees return true and return false on fail</returns>
        public async Task<bool> DeleteAllAsync(CustomerPropertyDetailViewModel viewModel)
        {
            int flag = 1;
            //if (viewModel.MaterialIds.Length > 0)
            //{
            if (viewModel.PageAction == Constants.PageActionType.Location)
            {
                //var values = await this._unitOfWork.LocationAddressRepository.GetByIds(ids).ConfigureAwait(false);
                var values = await this._unitOfWork.CustomerPropertyDetailRepository.GetById(viewModel.Ids);
                foreach (var item in values)
                {
                    //item.UpdatedBy = viewModel.DeletedBy;
                    //item.IsDeleted = true;
                    //item.IsActive = false;
                    var data = this._unitOfWork.CustomerPropertyDetailRepository.DeleteAsync(item.Id, viewModel.UpdatedBy);
                    flag++;
                }
            }
            var finalResult = this._unitOfWork.Save();
            return await Task.FromResult(finalResult).ConfigureAwait(false);
            //}
            //else
            //{
            //    return await Task.FromResult(false).ConfigureAwait(false);
            //}
        }

        public async Task<IEnumerable<ForecastCustomerLocationViewModel>> GetMapForecastCustomerLocation(ForecastCustomerLocationViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialID", viewModel.MaterialID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMapForecastCustomerLocation", parameters);
            if (ds != null && ds.Tables != null)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ForecastCustomerLocationViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<ForecastCustomerLocationViewModel>>(FilterResult<ForecastCustomerLocationViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        public async Task<int> GetTotalCount(ForecastCustomerLocationViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialID", viewModel.MaterialID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetCountMapForecastCustomerLocation", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<ForecastCustomerLocationViewModel>(ds.Tables[0]);
                int number = Convert.ToInt32(ds.Tables[0].Rows[0].Field<int>("RecordCount"));
                return await Task.FromResult<int>(number);
            }

            return 0;
        }

        public async Task<IEnumerable<CustomerLocationDropdownViewModel>> GetCustomerLocationDropDownList(CustomerLocationDropdownViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetCustomerLocation", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CustomerLocationDropdownViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CustomerLocationDropdownViewModel>>(finalResult);
            }

            return null;
        }

        public async Task<bool> MergeCustomerPropertyDetails(List<CustomerPropertyDetailViewModel> mergeModels)
        {
            foreach (CustomerPropertyDetailViewModel model in mergeModels)
            {
                Expression<Func<CustomerPropertyDetail, bool>> condition =
                        c => c.Id == model.ID
                        || (c.LocationId == model.LocationId && c.EntityPropertyId == model.EntityPropertyId);
                var recordExists = await this._unitOfWork.CustomerPropertyDetailRepository.GetList(condition);
                if (recordExists != null && recordExists.FirstOrDefault() != null)
                {
                    // update
                    CustomerPropertyDetail updateObj = recordExists.FirstOrDefault();
                    updateObj.PropertyValue = model.PropertyValue;
                    updateObj.PropertiesUom = model.PropertiesUom;
                    updateObj.UpdatedBy = model.UpdatedBy;
                    updateObj.UpdateDateTimeBrowser = model.UpdateDateTimeBrowser;
                    updateObj.UpdateDateTimeServer = DateTime.UtcNow;
                    updateObj.IsDeleted = model.IsDeleted;
                    var updateScuccessful = await this._unitOfWork.CustomerPropertyDetailRepository.UpdateAsync(updateObj);
                    if (!updateScuccessful)
                        return false;
                }
                else
                {
                    // insert
                    var insertObj = this._mapper.Map<CustomerPropertyDetail>(model);
                    insertObj.UpdateDateTimeServer = DateTime.Now;
                    insertObj.CreateDateTimeServer = DateTime.Now;
                    insertObj.EntityProperty = null;

                    var insertSuccessful = await this._unitOfWork.CustomerPropertyDetailRepository.AddAsync(insertObj);
                    if (!insertSuccessful)
                        return false;
                }
            }

            return this._unitOfWork.Save();
        }

    }
}