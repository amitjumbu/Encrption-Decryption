﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class ChargeTypeManager : BaseManager<ChargeType, ChargeTypeViewModel>, IChargeTypeManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public ChargeTypeManager(IMapper mapper,  ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> AddAsync(ChargeTypeViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        ///  List all the Charge Type 
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async override Task<IEnumerable<ChargeTypeViewModel>> ListAsync(ChargeTypeViewModel viewModel)
        {
            var module = await this.unitOfWork.ChargeTypeRepository.ListAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<ChargeTypeViewModel>>(module);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> UpdateAsync(ChargeTypeViewModel viewModel)
        {
            throw new NotImplementedException();
        }
    }
}