﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;

namespace CoreBaseBusiness.Managers
{

    public class CaputManager : BaseManager<MeasurementCaputMeasurementValue, CaputViewModel>, ICaputManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public CaputManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<CaputViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.CaputRepository.GetAsync(id);

          //  var comments = await this._unitOfWork.MeasurementCaputMeasurementValue.ListAsync(x => x.IsDeleted == false && x.ClientID == module.ClientID && x.Measurement_CaputMeasurementValueID == module.ID);

            var viewModel = this._mapper.Map<CaputViewModel>(module);

            //if (comments != null && comments.Any())
            //{
            //    viewModel.Comments = this._mapper.Map<ICollection<CaputCommentViewModel>>(comments);
            //}
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Caput Details.
        /// </summary>
        public async override Task<IEnumerable<CaputViewModel>> ListAsync(CaputViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementCaputMeasurementValue, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.CaputRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CaputViewModel>>(module);
        }

        /// <summary>
        /// Add New Caput Data into System
        /// </summary>
        public async override Task<bool> AddAsync(CaputViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementCaputMeasurementValue>(viewModel);
            var data = this._unitOfWork.CaputRepository.AddAsync(module);

            //if (data.Result)
            //{
            //    foreach (var commnetData in viewModel.Comments)
            //    {
            //        var commentObj = new MeasurementCaputMeasurementValue()
            //        {
            //            //Caput = module,
            //            ClientId = module.ClientId,
            //            CreateDateTimeBrowser = module.CreateDateTimeBrowser,
            //            CreateDateTimeServer = DateTime.UtcNow,
            //            CreatedBy = module.CreatedBy,
            //            //Description = commnetData.Description,
            //            IsDeleted = false,
            //            //IsUrgent = commnetData.IsUrgent,
            //            SourceSystemId = module.SourceSystemId
            //        };

            //        var commentResult = this._unitOfWork.MeasurementCaputMeasurementValue.AddAsync(commentObj);
            //    }
            //}


            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary> 
        ///  Updates existing record for Caput Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(CaputViewModel viewModel)
        {
            var module = this._mapper.Map<MeasurementCaputMeasurementValue>(viewModel);
            var data = this._unitOfWork.CaputRepository.UpdateAsync(module);

            if (data.Result)
            {
                foreach (var commnetData in viewModel.Comments)
                {
                    var commentObj = new MeasurementCaputMeasurementValue()
                    {
                        //Measurement_CaputMeasurementValueID = module.ID,
                        ClientId = module.ClientId,
                        CreateDateTimeBrowser = module.CreateDateTimeBrowser,
                        CreateDateTimeServer = DateTime.UtcNow,
                        CreatedBy = module.CreatedBy,
                        //Description = commnetData.Description,
                        //Isd = true,
                        IsDeleted = false,
                        //IsUrgent = commnetData.IsUrgent,
                        SourceSystemId = module.SourceSystemId
                    };

                    //if (commnetData.Id == 0)
                    //{
                    //    var commentResult = this._unitOfWork.MeasurementCaputMeasurementValue.AddAsync(commentObj);
                    //}
                    //else
                    //{
                    //    commentObj.Id = commnetData.Id;

                    //    this._unitOfWork.MeasurementCaputMeasurementValue.UpdateAsync(commentObj);
                    //}
                }
            }



            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Caput Details.
        /// </summary>
        public async override Task<int> CountAsync(CaputViewModel viewModel)
        {
            Expression<Func<MeasurementCaputMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.CaputRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Caput details of Patient 
        /// </summary>
        public async override Task<IEnumerable<CaputViewModel>> RangeAsync(int recordCount, CaputViewModel viewModel)
        {
            Expression<Func<MeasurementCaputMeasurementValue, bool>> condition = (c => c.IsDeleted == false && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.PatientId == viewModel.PatientId || viewModel.PatientId == 0) && (c.StagesId == viewModel.StagesId || viewModel.StagesId == 0) && (c.PartographId == viewModel.PartographId || viewModel.PartographId == 0));
            var module = await this._unitOfWork.CaputRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var CaputModel = this._mapper.Map<IEnumerable<CaputViewModel>>(module);
            ////foreach (var CaputData in CaputModel.ToList())
            ////{
            ////    var comments = await this._unitOfWork.MeasurementCaputMeasurementValue.ListAsync(x => x.IsDeleted == false && x.ClientID == CaputData.ClientId && x.Measurement_CaputMeasurementValueID == CaputData.Id);
            ////    if (comments != null && comments.Any())
            ////    {
            ////        CaputData.Comments = this._mapper.Map<ICollection<CaputCommentViewModel>>(comments);
            ////    }
            ////}

            return CaputModel;
        }


        /// <summary>
        ///  Deletes record Caput from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
        //    var data = this._unitOfWork.CaputRepository.DeleteAsync(id, deletedBy);

        //    var allCommnets = this._unitOfWork.MeasurementCaputMeasurementValue.ListAsync(x => x.Measurement_CaputMeasurementValueID == id);

        //    foreach (var comments in allCommnets.Result)
        //    {
        //        var resultData = this._unitOfWork.MeasurementCaputMeasurementValue.DeleteAsync(comments.ID, deletedBy);
        //    }

            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


