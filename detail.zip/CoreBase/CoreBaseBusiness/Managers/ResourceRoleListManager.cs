﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{

    public class ResourceRoleListManager : BaseManager<ResourceRoleList, ResourceRoleListViewModel>, IResourceRoleListManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public ResourceRoleListManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary> 
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<ResourceRoleListViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.ResourceRoleListRepository.GetAsync(id);

            var comments = await this._unitOfWork.ResourceRoleListRepository.ListAsync(x => x.IsDeleted == false && x.ClientId == module.ClientId && x.Id == module.Id);


            var viewModel = this._mapper.Map<ResourceRoleListViewModel>(module);

            
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from ResourceRolesList Details.
        /// </summary>
        public async override Task<IEnumerable<ResourceRoleListViewModel>> ListAsync(ResourceRoleListViewModel viewModel)
        {
            // TODO: This can be used for contains 
            throw new NotImplementedException();
        }

        /// <summary>
        /// Add New ResourceRolesList Data into System
        /// </summary>
        public async override Task<bool> AddAsync(ResourceRoleListViewModel viewModel)
        {
            var module = this._mapper.Map<ResourceRoleList>(viewModel);
            var data = this._unitOfWork.ResourceRoleListRepository.AddAsync(module);
            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for ResourceRolesList Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(ResourceRoleListViewModel viewModel)
        {
            var module = this._mapper.Map<ResourceRoleList>(viewModel);
            var data = this._unitOfWork.ResourceRoleListRepository.UpdateAsync(module);         

            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from ResourceRolesList Details.
        /// </summary>
        public async override Task<int> CountAsync(ResourceRoleListViewModel viewModel)
        {
            Expression<Func<ResourceRoleList, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);
            return await this._unitOfWork.ResourceRoleListRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  ResourceRolesList details of Patient 
        /// </summary>
        public async override Task<IEnumerable<ResourceRoleListViewModel>> RangeAsync(int recordCount, ResourceRoleListViewModel viewModel)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        ///  Deletes record ResourceRolesList from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.ResourceRoleListRepository.DeleteAsync(id, deletedBy);
            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


