﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;
    using NPOI.OpenXmlFormats.Dml;

    public class BusinessPartnerContractManager : BaseManager<BusinessPartnerContract, BusinessPartnerContractViewModel>, IBusinessPartnerContractManager
    {
        private readonly IMapper mapper;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;
        private readonly IConfiguration configuration;

        public BusinessPartnerContractManager(IMapper mapper, IWebHostEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext, IConfiguration configuration)
            : base()
        {
            this.mapper = mapper;
            this.hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        /// <summary>
        /// this method sends the BusinessPartnerContract on ID Basis.
        /// </summary>
        /// <param name="id">Id of BusinessPartnerContract</param>
        /// <returns>BusinessPartnerContract Entity View Model.</returns>
        public async override Task<BusinessPartnerContractViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWork.BusinessPartnerContractRepository.GetAsync(id);
            var viewModel = this.mapper.Map<BusinessPartnerContractViewModel>(module);
            return viewModel;
        }

        /// <summary>
        /// this method get all list of system alert filter according to AlertType, clientid and systemevent.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which contains filter details.</param>
        /// <returns>list of system alerts.</returns>
        public async override Task<IEnumerable<BusinessPartnerContractViewModel>> ListAsync(BusinessPartnerContractViewModel viewModel)
        {
            Expression<Func<BusinessPartnerContract, bool>> condition = c => !c.IsDeleted && (c.ContractTypeId == viewModel.ContractTypeId || viewModel.ContractTypeId == 0 || viewModel.ContractTypeId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0 || viewModel.ClientId == null) && (c.LocationId == viewModel.LocationId || viewModel.LocationId == 0 || viewModel.LocationId == null) && (c.IsActive == viewModel.IsActive || viewModel.IsActive == 0 || viewModel.IsActive == null);
            var module = await this.unitOfWork.BusinessPartnerContractRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<BusinessPartnerContractViewModel>>(module);
        }

        /// <summary>
        /// this method use to add System Alerts into table.
        /// </summary>
        /// <param name="viewModel">System Alerts Data to save into db.</param>
        /// <returns>true for sucess/false on fail</returns>
        public async override Task<bool> AddAsync(BusinessPartnerContractViewModel viewModel)
        {
            var module = this.mapper.Map<BusinessPartnerContract>(viewModel);
            module.Code = module.ContractNumber.Replace(" ", string.Empty);
            var result = await this.unitOfWork.BusinessPartnerContractRepository.AddAsync(module);
            return await Task.FromResult<bool>(result);
        }

        /// <summary>
        /// this method update the System Alert.
        /// </summary>
        /// <param name="viewModel">System Alert View Model which will be Update into DB.</param>
        /// <returns>true on success/false on fail.</returns>
        public async override Task<bool> UpdateAsync(BusinessPartnerContractViewModel viewModel)
        {
            var module = this.mapper.Map<BusinessPartnerContract>(viewModel);
            var result = await this.unitOfWork.BusinessPartnerContractRepository.UpdateAsync(module);
            return await Task.FromResult<bool>(result);
        }

        /// <summary>
        /// The the total Active System Alerts.
        /// </summary>
        /// <param name="viewModel">System Alert View Model for data filter.</param>
        /// <returns>Total no of active system alerts.</returns>
        public async override Task<int> CountAsync(BusinessPartnerContractViewModel viewModel)
        {
            Expression<Func<BusinessPartnerContract, bool>> condition = c => !c.IsDeleted;

            return await this.unitOfWork.BusinessPartnerContractRepository.CountAsync(condition);
        }

        /// <summary>
        /// This method get all the list of System Alerts.
        /// </summary>
        /// <param name="recordCount">No of total records count </param>
        /// <param name="viewModel">this view model filter the records from table.</param>
        /// <returns>return list of system alert other wiser return null</returns>
        public async override Task<IEnumerable<BusinessPartnerContractViewModel>> RangeAsync(int recordCount, BusinessPartnerContractViewModel viewModel)
        {
            Expression<Func<BusinessPartnerContract, bool>> condition = c =>  !c.IsDeleted && (c.ContractTypeId == viewModel.ContractTypeId || viewModel.ContractTypeId == 0 || viewModel.ContractTypeId == null) && (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0 || viewModel.ClientId == null) && (c.LocationId == viewModel.LocationId || viewModel.LocationId == 0 || viewModel.LocationId == null) && (c.IsActive == viewModel.IsActive || viewModel.IsActive == 0 || viewModel.IsActive == null);
            var module = await this.unitOfWork.BusinessPartnerContractRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            if (module.Any())
            {
                var BusinessPartnerContractModel = this.mapper.Map<IEnumerable<BusinessPartnerContractViewModel>>(module);
                return BusinessPartnerContractModel;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// this method softly remove records from db.
        /// this method just set isDeleted Column true into DB.
        /// </summary>
        /// <param name="id">ID of system alert.</param>
        /// <param name="deletedBy">who will be detele this records.</param>
        /// <returns>return true on success or false on fail.</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.BusinessPartnerContractRepository.DeleteAsync(id, deletedBy);

            if (data.Result)
            {
                var finalResult = this.unitOfWork.Save();
                return await Task.FromResult<bool>(finalResult);
            }
            else
            {
                return await Task.FromResult<bool>(data.Result);
            }
        }

     
    }
}