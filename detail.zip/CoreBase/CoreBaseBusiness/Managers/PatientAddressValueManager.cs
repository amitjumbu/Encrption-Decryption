﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
   public class PatientAddressValueManager : BaseManager<PatientAddress, PatientAddressValueViewModel>, IPatientAddressValueManager
    {
        private readonly IMapper _mapper; 
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;

        public PatientAddressValueManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext)
    : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }




        /// <summary>
        /// Retrieves data id wise from Patient Contact.
        /// </summary>
        public async override Task<PatientAddressValueViewModel> GetAsync(int id)
        {
            var module = await this._unitOfWork.PatientAddressrepository.GetById(id);
            return this._mapper.Map<PatientAddressValueViewModel>(module);
        }

        /// <summary>
        ///  Retrieves  All data from Patient Contact.
        /// </summary>
        public async override Task<IEnumerable<PatientAddressValueViewModel>> ListAsync(PatientAddressValueViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientAddress, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientAddressrepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientAddressValueViewModel>>(module);
        }

        /// <summary>
        /// PatientContact Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(PatientAddressValueViewModel viewModel)
        {
            var module = this._mapper.Map<PatientAddress>(viewModel);
            var data = this._unitOfWork.PatientAddressrepository.AddAsync(module);
            this._unitOfWork.Save();
            viewModel.ID = module.ID;
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for PatientContact.
        /// </summary>
        public async override Task<bool> UpdateAsync(PatientAddressValueViewModel viewModel)
        {
            var module = this._mapper.Map<PatientAddress>(viewModel);
            var data = this._unitOfWork.PatientAddressrepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Patient Contact 
        /// </summary>
        public async override Task<int> CountAsync(PatientAddressValueViewModel viewModel)
        {
            Expression<Func<PatientAddress, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            if (viewModel.ID > 0)
                condition = condition.And(c => c.IsActive == viewModel.IsActive);
            else
                condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.PatientAddressrepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves  All data from  PatientContact Id wise.
        /// </summary>
        public async override Task<IEnumerable<PatientAddressValueViewModel>> RangeAsync(int recordCount, PatientAddressValueViewModel viewModel)
        {
            Expression<Func<PatientAddress, bool>> condition = (c => c.PatientID == viewModel.PatientID);
            var module = await this._unitOfWork.PatientAddressrepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            return this._mapper.Map<IEnumerable<PatientAddressValueViewModel>>(module);
        }


        /// <summary>
        ///  Deletes record from PatientContact by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.PatientAddressrepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }


    }
}
