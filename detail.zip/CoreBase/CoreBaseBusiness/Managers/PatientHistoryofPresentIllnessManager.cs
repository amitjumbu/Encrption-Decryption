﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class PatientHistoryofPresentIllnessManager : BaseManager<PatientHistoryofPresentIllness, PatientHistoryofPresentIllnessViewModel>, IPatientHistoryofPresentIllnessManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }


        public PatientHistoryofPresentIllnessManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }


        

        public async override Task<int> CountAsync(PatientHistoryofPresentIllnessViewModel viewModel)
        {
            Expression<Func<PatientHistoryofPresentIllness, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.Id > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.PatientHistoryofPresentIllnessRepository.CountAsync(condition);
        }
        public async override Task<IEnumerable<PatientHistoryofPresentIllnessViewModel>> RangeAsync(int recordCount, PatientHistoryofPresentIllnessViewModel viewModel)
        {
            Expression<Func<PatientHistoryofPresentIllness, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.PatientHistoryofPresentIllnessRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<PatientHistoryofPresentIllnessViewModel>>(module);
            return mappedData;
        }
        public async override Task<IEnumerable<PatientHistoryofPresentIllnessViewModel>> ListAsync(PatientHistoryofPresentIllnessViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<PatientHistoryofPresentIllness, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.PatientHistoryofPresentIllnessRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<PatientHistoryofPresentIllnessViewModel>>(module);
        }

        public async override Task<bool> AddAsync(PatientHistoryofPresentIllnessViewModel viewModel)
        {
            var module = this._mapper.Map<PatientHistoryofPresentIllness>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.UpdateDateTimeBrowser = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;
            module.CreateDateTimeBrowser = DateTime.Now;
            var data = this._unitOfWork.PatientHistoryofPresentIllnessRepository.AddAsync(module);

            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        public async override Task<bool> UpdateAsync(PatientHistoryofPresentIllnessViewModel viewModel)
        {
            var module = this._mapper.Map<PatientHistoryofPresentIllness>(viewModel);
            var data = this._unitOfWork.PatientHistoryofPresentIllnessRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }
        public List<PatientCovidStatusViewModel> GetCovidStatus()
        {
            List<PatientCovidStatusViewModel> usersList = new List<PatientCovidStatusViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            //parameters.Add("ClientID", ClientId);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetPatientCovidStatus");

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new PatientCovidStatusViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        Name = dr["Name"].ToString()
                    });
                }
            }

            return usersList;
        }
        public override async Task<PatientHistoryofPresentIllnessViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.PatientHistoryofPresentIllnessRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<PatientHistoryofPresentIllnessViewModel>((PatientHistoryofPresentIllness)module);
        }
    }
}