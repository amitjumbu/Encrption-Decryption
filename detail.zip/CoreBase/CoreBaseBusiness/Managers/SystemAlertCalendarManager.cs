﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Helpers;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.Repository.Interface;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Extensions.Configuration;
    using Newtonsoft.Json;

    public class SystemAlertCalendarManager : BaseManager<SystemAlertCalendar, SystemAlertCalendarViewModel>, ISystemAlertCalendarManager
    {
        private readonly IMapper mapper;
        private readonly ADecTecCoreBaseUnitOfWork unitOfWorkCoreBase;

        public SystemAlertCalendarManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWorkCoreBase = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Get SystemAlertCalendar detail on the basis of passing id of oragnization.
        /// </summary>
        /// <param name="id">SystemAlertCalendar id which must be available.</param>
        /// <returns>return the SystemAlertCalendar details.</returns>
        public async override Task<SystemAlertCalendarViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWorkCoreBase.SystemAlertCalendarRepository.GetById(id).ConfigureAwait(false);
            return this.mapper.Map<SystemAlertCalendarViewModel>(module);
        }

        /// <summary>
        /// Get All list of active records from system.
        /// </summary>
        /// <param name="viewModel">SystemAlertCalendar View model as input.</param>
        /// <returns>return list of all active SystemAlertCalendar records.</returns>
        public async override Task<IEnumerable<SystemAlertCalendarViewModel>> ListAsync(SystemAlertCalendarViewModel viewModel)
        {
            Expression<Func<SystemAlertCalendar, bool>> condition = c => (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.EntityId == viewModel.EntityId || viewModel.EntityId == 0) && (c.UserAlertId == viewModel.UserAlertId || viewModel.UserAlertId == 0);
            var module = await this.unitOfWorkCoreBase.SystemAlertCalendarRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<SystemAlertCalendarViewModel>>(module);
        }

        /// <summary>
        /// Add new SystemAlertCalendar to system.
        /// </summary>
        /// <param name="viewModel">SystemAlertCalendar view model as input to save the SystemAlertCalendar into system.</param>
        /// <returns>return either true for success or false for fail</returns>
        public async override Task<bool> AddAsync(SystemAlertCalendarViewModel viewModel)
        {
            var module = this.mapper.Map<SystemAlertCalendar>(viewModel);

            module.UserAlert = null;

            var data = this.unitOfWorkCoreBase.SystemAlertCalendarRepository.AddAsync(module);
            if (data.Result)
            {
                var savedResult = this.unitOfWorkCoreBase.Save();
                return await Task.FromResult(savedResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(false).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Update SystemAlertCalendar Data into System
        /// </summary>
        /// <param name="viewModel">Ogranization View Model data which will update the existing SystemAlertCalendar details</param>
        /// <returns>return true on succes and false on fail</returns>
        public async override Task<bool> UpdateAsync(SystemAlertCalendarViewModel viewModel)
        {
            var module = this.mapper.Map<SystemAlertCalendar>(viewModel);
            var data = this.unitOfWorkCoreBase.SystemAlertCalendarRepository.UpdateAsync(module);
            if (data.Result)
            {
                var finalResult = this.unitOfWorkCoreBase.Save();
                return await Task.FromResult(finalResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(data.Result).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Get total all count records into system
        /// </summary>
        /// <param name="viewModel">SystemAlertCalendar View Model which filter the total records</param>
        /// <returns>return total count records</returns>
        public async override Task<int> CountAsync(SystemAlertCalendarViewModel viewModel)
        {
            Expression<Func<SystemAlertCalendar, bool>> condition = c => (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.EntityId == viewModel.EntityId || viewModel.EntityId == 0) && (c.UserAlertId == viewModel.UserAlertId || viewModel.UserAlertId == 0);

            return await unitOfWorkCoreBase.SystemAlertCalendarRepository.CountAsync(condition).ConfigureAwait(false);
        }

        /// <summary>
        /// Get all SystemAlertCalendar by filtering the data on basis of perticular condition.
        /// </summary>
        /// <param name="recordCount">Total No of records count.</param>
        /// <param name="viewModel">SystemAlertCalendar view model, with the help of model we will filter data accordingly</param>
        /// <returns>List of all active SystemAlertCalendar on filter basis</returns>
        public async override Task<IEnumerable<SystemAlertCalendarViewModel>> RangeAsync(int recordCount, SystemAlertCalendarViewModel viewModel)
        {
            Expression<Func<SystemAlertCalendar, bool>> condition = c => (c.ClientId == viewModel.ClientId || viewModel.ClientId == 0) && (c.EntityId == viewModel.EntityId || viewModel.EntityId == 0) && (c.UserAlertId == viewModel.UserAlertId || viewModel.UserAlertId == 0);
            var module = await unitOfWorkCoreBase.SystemAlertCalendarRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition).ConfigureAwait(false);
            var mappedData = this.mapper.Map<IEnumerable<SystemAlertCalendarViewModel>>(module);
            return mappedData;
        }

        /// <summary>
        /// Softly remove SystemAlertCalendar from the system.
        /// </summary>
        /// <param name="id">Existing SystemAlertCalendar ID</param>
        /// <param name="deletedBy">Name of user who wants to remove SystemAlertCalendar from the system.</param>
        /// <returns>on sucees return true and return false on fail</returns>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWorkCoreBase.SystemAlertCalendarRepository.DeleteAsync(id, deletedBy);
            if (data.Result)
            {
                var finalResult = this.unitOfWorkCoreBase.Save();
                return await Task.FromResult(finalResult).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(data.Result).ConfigureAwait(false);
            }
        }

    }
}
