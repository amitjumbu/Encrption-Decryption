﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
using CoreBaseData.Helpers;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using System.Security.Cryptography.X509Certificates;
using NPOI.SS.Formula.Functions;
using System.Data;
using CoreBaseBusiness.Helpers;

namespace CoreBaseBusiness.Managers
{

    public class EquipmentTypeMaterialPropertyDetailManager : BaseManager<EquipmentTypeMaterialPropertyDetail, EquipmentTypeMaterialPropertyDetailViewModel>, IEquipmentTypeMaterialPropertyDetailManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        public EquipmentTypeMaterialPropertyDetailManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            this._unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public async Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetEquipmentTypeMaterialPropertyDetailByCode(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialCode", viewModel.MaterialCode);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetDefineEquipmentMaterialCharacteristics", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentTypeMaterialPropertyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>>(FilterResult<EquipmentTypeMaterialPropertyDetailViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        public async Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetMaterialPropertyByEquipmentTypeCode(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("EquipmentTypeCode", viewModel.EquipmentTypeCode);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetDefineEquipmentMaterialCharacteristicsByEquipmentID", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentTypeMaterialPropertyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>>(FilterResult<EquipmentTypeMaterialPropertyDetailViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        public async Task<int> GetCount(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("EquipmentTypeCode", viewModel.EquipmentTypeCode);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_CountMaterialsByEquipmentID", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentTypeMaterialPropertyDetailViewModel>(ds.Tables[0]);
                int number = Convert.ToInt32(ds.Tables[0].Rows[0].Field<int>("RecordCount"));
                return await Task.FromResult<int>(number);
            }

            return 0;
        }

        public async Task<int> GetmatTotalCountCount(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialCode", viewModel.MaterialCode);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_CountEquipmentsByMaterialID", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentTypeMaterialPropertyDetailViewModel>(ds.Tables[0]);
                int number = Convert.ToInt32(ds.Tables[0].Rows[0].Field<int>("RecordCount"));
                return await Task.FromResult<int>(number);
            }

            return 0;
        }

        public async Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> SaveAll(List<EquipmentTypeMaterialPropertyDetailViewModel> viewModels)
        {
            var materialPropDetailall = new List<EquipmentTypeMaterialPropertyDetailViewModel>();

            foreach (EquipmentTypeMaterialPropertyDetailViewModel viewModel in viewModels)
            {
                var model = this._mapper.Map<EquipmentTypeMaterialPropertyDetail>(viewModel);
                model.Material = null;
                var result = await this._unitOfWork.EquipmentTypeMaterialPropertyDetailRepository.AddEquipmentMaterialAsync(model).ConfigureAwait(false);
                if (result)
                {
                    this._unitOfWork.Save();
                    materialPropDetailall.Add(viewModel);
                }
            }

            return materialPropDetailall;
        }

        public override Task<bool> AddAsync(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> ListAsync(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<EquipmentMatPropDetailFromSelectedMatModel>> GetEquipmentMatPropDetailFromSelectedMaterial(EquipmentMatPropDetailFromSelectedMatModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("MaterialCodeGlobal", viewModel.MaterialCodeGlobal);
                parameters.Add("MaterialCodeDropDown", viewModel.MaterialCodeDropDown);
                parameters.Add("ClientID", viewModel.ClientID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_CopyEquipmentTypeMaterialPropertyDetail", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentMatPropDetailFromSelectedMatModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<EquipmentMatPropDetailFromSelectedMatModel>>(finalResult);
            }

            return null;
        }

        public async Task<IEnumerable<EquipmentPropDetailFromSelectedEquipmentModel>> GetCopiedPropFromSelectedEquipment(EquipmentPropDetailFromSelectedEquipmentModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("EquipmentCodeGlobal", viewModel.EquipmentCodeGlobal);
                parameters.Add("EquipmentCodeDropDown", viewModel.EquipmentCodeDropDown);
                parameters.Add("ClientID", viewModel.ClientID);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_CopyMaterialPropertyFromOneEquipmentTypeToOther", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentPropDetailFromSelectedEquipmentModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<EquipmentPropDetailFromSelectedEquipmentModel>>(finalResult);
            }

            return null;
        }

        public async Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetTotalCountEquipmentTypeMaterialPropertyForPopUp(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("MaterialCode", viewModel.MaterialCode);
                parameters.Add("EquipmentTypeIDs", viewModel.EquipmentTypeIDs);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetEquipmentMaterialCharacteristicsForPopUp", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentTypeMaterialPropertyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>>(finalResult);
            }

            return null;
        }

        public async Task<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>> GetEquipmentTypeMaterialPropertyForPopUp(EquipmentTypeMaterialPropertyDetailViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            parameters.Add("ClientID", viewModel.ClientID);
            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("MaterialCode", viewModel.MaterialCode);
                parameters.Add("EquipmentTypeIDs", viewModel.EquipmentTypeIDs);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetEquipmentMaterialCharacteristicsForPopUp", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<EquipmentTypeMaterialPropertyDetailViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>>(FilterResult<EquipmentTypeMaterialPropertyDetailViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));
            }

            return null;
        }

        public async Task<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>> GetTotalCountMaterialPropertyByEquipmentForPopUp(MaterialPropertyDetailByEquipmentViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null)
            {
                parameters.Add("ClientID", viewModel.ClientID);
                parameters.Add("EquipmentTypeCode", viewModel.EquipmentTypeCode);
                parameters.Add("MaterialIDs", viewModel.MaterialIDs);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialCharacteristicsEquipmentForPopUp", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialPropertyDetailByEquipmentViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>>(finalResult);
            }

            return null;
        }

        public async Task<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>> GetMaterialPropertyByEquipmentForPopUp(MaterialPropertyDetailByEquipmentViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            parameters.Add("ClientID", viewModel.ClientID);
            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            if (viewModel != null)
            {
                parameters.Add("EquipmentTypeCode", viewModel.EquipmentTypeCode);
                parameters.Add("MaterialIDs", viewModel.MaterialIDs);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialCharacteristicsEquipmentForPopUp", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialPropertyDetailByEquipmentViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>>(FilterResult<MaterialPropertyDetailByEquipmentViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize));                
            }

            return null;
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> iD = ids.ConvertAll(long.Parse);

                List<EquipmentTypeMaterialPropertyDetail> equipMaterialProps = this._unitOfWork.EquipmentTypeMaterialPropertyDetailRepository.ListAsync(p => iD.Contains(p.Id)).Result.ToList();

                foreach (EquipmentTypeMaterialPropertyDetail equipMaterialProp in equipMaterialProps)
                {
                    await this._unitOfWork.EquipmentTypeMaterialPropertyDetailRepository.DeleteEquipmentMaterialAsync(equipMaterialProp.Id);
                    var result = this._unitOfWork.Save();
                }

                return await Task.FromResult<bool>(true);
            }

            return await Task.FromResult<bool>(false);
        }

    }
}
