﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{

    public class CountryOfOriginOfMaterialManager : BaseManager<CountryOfOriginOfMaterial, CountryOfOriginOfMaterialViewModel>, ICountryOfOriginOfMaterialManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork unitOfWork;


        public CountryOfOriginOfMaterialManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<CountryOfOriginOfMaterialViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWork.CountryOfOriginOfMaterialRepository.GetById(id);
            return this._mapper.Map<CountryOfOriginOfMaterialViewModel>(module);
        }

        /// <summary>
        ///  Retrieves  All data from Package Details.
        /// </summary>
        public async override Task<IEnumerable<CountryOfOriginOfMaterialViewModel>> ListAsync(CountryOfOriginOfMaterialViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<CountryOfOriginOfMaterial, bool>> condition = (c => !c.IsDeleted);

            var module = await this.unitOfWork.CountryOfOriginOfMaterialRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<CountryOfOriginOfMaterialViewModel>>(module);
        }

        /// <summary>
        /// Address varification Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(CountryOfOriginOfMaterialViewModel viewModel)
        {


            //CountryOfOriginOfMaterialViewModel entity = new CountryOfOriginOfMaterialViewModel();
            // viewModel.CountryId = viewModel.CountryId;

            viewModel.IsDeleted = false;
            viewModel.UpdateDateTimeServer = DateTime.Now;
            viewModel.CreateDateTimeServer = DateTime.Now;

            // var module = this._mapper.Map<NamePrefix>(entity);
            var module = this._mapper.Map<CountryOfOriginOfMaterial>(viewModel);
            var data = this.unitOfWork.CountryOfOriginOfMaterialRepository.AddAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for Package Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(CountryOfOriginOfMaterialViewModel viewModel)
        {
            viewModel.UpdateDateTimeServer = DateTime.Now;
            var module = this._mapper.Map<CountryOfOriginOfMaterial>(viewModel);
            var data = this.unitOfWork.CountryOfOriginOfMaterialRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from package Details.
        /// </summary>
        //public async override Task<int> CountAsync(CountryOfOriginOfMaterialViewModel viewModel)
        //{
        //    Expression<Func<CountryOfOriginOfMaterial, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

        //    if (viewModel.Id > 0)
        //        condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
        //    else
        //        condition = condition.And(c => c.IsDeleted == true);

        //    return await this.unitOfWork.CountryOfOriginOfMaterialRepository.CountAsync(condition);
        //}

        /// <summary>
        ///  Retrieves  All data from  Package Id wise.
        /// </summary>
        //public async override Task<IEnumerable<CountryOfOriginOfMaterialViewModel>> RangeAsync(int recordCount, CountryOfOriginOfMaterialViewModel viewModel)
        //{
        //    Expression<Func<CountryOfOriginOfMaterial, bool>> condition = (c => c.ClientId == viewModel.ClientId);
        //    var module = await this.unitOfWork.CountryOfOriginOfMaterialRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
        //    return this._mapper.Map<IEnumerable<CountryOfOriginOfMaterialViewModel>>(module);
        //}


        /// <summary>
        ///  Deletes record from Testte by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.CountryOfOriginOfMaterialRepository.DeleteAsync(id, deletedBy);
            this.unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }
        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<int> ID = ids.ConvertAll(int.Parse);

                List<CountryOfOriginOfMaterial> countryOfOriginOfGoods = this.unitOfWork.CountryOfOriginOfMaterialRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();

                foreach (CountryOfOriginOfMaterial Origin in countryOfOriginOfGoods)
                {
                    Origin.IsDeleted = true;
                }

                var result = this.unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }
        public async Task<IEnumerable<CountryOfOriginOfMaterialViewModel>> GetAllOriginOfGoodsDetails(CountryOfOriginOfMaterialViewModel ViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (ViewModel != null && string.IsNullOrWhiteSpace(ViewModel.FilterOn))
            {
                Parameter.Add("PageNumber", ViewModel.PageNo);
                Parameter.Add("PageSize", ViewModel.PageSize);
            }
            if (!string.IsNullOrWhiteSpace(ViewModel.SortColumn))
            {
                Parameter.Add("SortColumn", ViewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(ViewModel.SortOrder))
            {
                Parameter.Add("SortOrder", ViewModel.SortOrder);
            }
            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetAllCountryOfOriginOfMaterialDetails", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<CountryOfOriginOfMaterialViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<CountryOfOriginOfMaterialViewModel>>(FilterResult<CountryOfOriginOfMaterialViewModel>.GetFilteredResult(finalResult, ViewModel.FilterOn, ViewModel.PageSize));
            }

            return null;
        }
    }
}


