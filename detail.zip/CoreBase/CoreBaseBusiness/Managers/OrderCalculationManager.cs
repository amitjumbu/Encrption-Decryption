﻿/// <summary>
/// this Manager has been implemented by Kapil Pandey.
/// On 17-Sep-2020 for Order Management Module.
/// </summary>
namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Helpers;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Dapper;
    using Helpers;
    using Microsoft.EntityFrameworkCore.Internal;
    using Microsoft.Extensions.Configuration;
    using Newtonsoft.Json;
    using NPOI.OpenXmlFormats.Dml;

    public class OrderCalculationManager : IOrderCalculationManager
    {
        private readonly ADecTecCoreBaseUnitOfWork unitOfWork;
        private readonly ADecTecCoreBaseDBContext aDecTecCoreBaseDBContext;

        private string ConnectionString { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderCalculationManager"/> class.
        /// which user to implemente dependanceinjection into manager.
        /// </summary>
        /// <param name="unitOfWork">database communication unit of work.</param>
        public OrderCalculationManager(ADecTecCoreBaseDBContext eICDBContext)
        {
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);

            var configurationBuild = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json")
           .Build();
            this.unitOfWork.ConnectionString = configurationBuild["ConnectionString:CoreBaseDB"];
            this.aDecTecCoreBaseDBContext = eICDBContext;

            this.ConnectionString = configurationBuild["ConnectionString:CoreBaseDB"];
        }

        public OrderDetailViewModel GetOrderDetails(long orderID, long orderTypeID)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("OrderID", orderID);
            parameters.Add("OrderTypeID", orderTypeID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetOrderData", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                List<OrderDetailViewModel> orders = ConvertDataTabe.CreateListFromTable<OrderDetailViewModel>(ds.Tables[0]);

                if (orders.Count > 0)
                {
                    return orders.FirstOrDefault();
                }
                else
                {
                    return null;
                }
            }

            return null;
        }

        /// <summary>
        /// this method return all the salesmanagers list to ordermanagement page on location basis.
        /// </summary>
        /// <param name="locationID">shipping location id.</param>
        /// <param name="roleName">Name Of UserRoles.</param>
        /// <param name="userLocationType">Locatin Type Of User like : Customer,Ban.</param>
        /// <returns>List of managers.</returns>
        public List<RoleUsersViewModel> GetUsersList(long locationID, string roleName, string userLocationType)
        {

            List<RoleUsersViewModel> usersList = new List<RoleUsersViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("LocationType", userLocationType);
            parameters.Add("LocationID", locationID);
            parameters.Add("RoleName", roleName);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SP_GetUsersByRoleOfLocation", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    usersList.Add(new RoleUsersViewModel()
                    {
                        ID = Convert.ToInt64(dr["ID"]),
                        Name = dr["FullName"].ToString()
                    });
                }
            }

            return usersList;
        }

        public List<ComputationMethodViewModel> GetComputationMethodDataOnElementAndChargeID(RequestDataPriceMethodAndComputationMethod requestDataPriceMethodAndComputationMethod)
        {
            DataSet dsResult = this.GetComputationMethodAndPriceMethodOnElementAndChargeIDData(requestDataPriceMethodAndComputationMethod);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<ComputationMethodViewModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public List<PriceMethodViewModel> GetPriceMethodDataOnElementAndChargeID(RequestDataPriceMethodAndComputationMethod requestDataPriceMethodAndComputationMethod)
        {
            DataSet dsResult = this.GetComputationMethodAndPriceMethodOnElementAndChargeIDData(requestDataPriceMethodAndComputationMethod);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<PriceMethodViewModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        private DataSet GetComputationMethodAndPriceMethodOnElementAndChargeIDData(RequestDataPriceMethodAndComputationMethod requestDataPriceMethodAndComputationMethod)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("MaterialID", requestDataPriceMethodAndComputationMethod.MaterialID);
            parameters.Add("ChargeID", requestDataPriceMethodAndComputationMethod.ChargeID);
            parameters.Add("LocationID", requestDataPriceMethodAndComputationMethod.ShipTOLocationID);
            parameters.Add("ContractID", requestDataPriceMethodAndComputationMethod.ContractID);
            parameters.Add("Type", requestDataPriceMethodAndComputationMethod.Type);

            return this.unitOfWork.ExecuteProcedure("SPO_GetChargeComputationMethodAndRatePrice", parameters);
        }

        public List<PriceMethodViewModel> GetPriceMethodList(RequestCommonViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ChargeID", requestCommonViewModel.ChargeID);
            parameters.Add("ContractID", requestCommonViewModel.ContractID);
            parameters.Add("ContractType", requestCommonViewModel.ContractType);
            parameters.Add("ClientID", requestCommonViewModel.ClientID);


            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetPriceMethodByCharge", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<PriceMethodViewModel>(dsResult.Tables[0]);
            }
            else
            {
                return null;
            }
        }

        public ResponseAdjustChargesWithDefaultData GetDefaultAjustCharges(RequestCommonViewModel requestCommonViewModel)
        {
            string materiallist = "";

            if (requestCommonViewModel.Materials != null)
            {
                if (requestCommonViewModel.Materials.Count > 0)
                {
                    List<long> allMaterialID = requestCommonViewModel.Materials.Select(x => x.MaterialID).ToList();
                    materiallist = string.Join(",", allMaterialID.ToArray());
                }
            }

            ResponseAdjustChargesWithDefaultData responseAdjustChargesWithDefaultData = new ResponseAdjustChargesWithDefaultData();

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ContractID", requestCommonViewModel.ContractID);
            parameters.Add("LocationID", requestCommonViewModel.ShipToLocationID);
            parameters.Add("FromLocationID", requestCommonViewModel.ShipFromLocationID);
            parameters.Add("ClientID", requestCommonViewModel.ClientID);
            parameters.Add("MaterialID", materiallist);
            parameters.Add("OrderTypeID", requestCommonViewModel.OrderTypeID.Value);

            parameters.Add("ValidDate", requestCommonViewModel.ValidDate);

            if (requestCommonViewModel.OrderID.HasValue && requestCommonViewModel.OrderID.Value > 0)
            {
                parameters.Add("OrderID", requestCommonViewModel.OrderID.Value);
            }

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_GetDefaultAdjustChargesList", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables.Count > 0)
            {
                // get the default RateValue for contract Detail basis.
                responseAdjustChargesWithDefaultData.allContractDetailValue = ConvertDataTabe.CreateListFromTable<ResponseAdjustCharges>(dsResult.Tables[0]);

                if (responseAdjustChargesWithDefaultData.allContractDetailValue.Count > 0)
                {
                    responseAdjustChargesWithDefaultData.allContractDetailValue = responseAdjustChargesWithDefaultData.allContractDetailValue.Select(x =>
                    {
                        x.overrideShowOnBOL = x.ShowOnBOL;
                        return x;
                    }).ToList();
                }

                // this Property hold all autoAdded Contract Data.
                responseAdjustChargesWithDefaultData.ResponseContractDefaultRateValue = JsonConvert.DeserializeObject<List<ResponseAdjustCharges>>(JsonConvert.SerializeObject(responseAdjustChargesWithDefaultData.allContractDetailValue.Where(x => x.IsRequired == 1).ToList()));

                List<ResponseAdjustCharges> materialChargesData = new List<ResponseAdjustCharges>();

                if (dsResult.Tables.Count > 1 && dsResult.Tables[1].Rows.Count > 0 && requestCommonViewModel.OrderID.HasValue && requestCommonViewModel.OrderTypeID.HasValue && requestCommonViewModel.OrderID.Value > 0 && requestCommonViewModel.OrderTypeID.Value > 0)
                {
                    // this section execute for those orders which has orderid
                    var existingResult = ConvertDataTabe.CreateListFromTable<ResponseAdjustCharges>(dsResult.Tables[1]);

                    if (existingResult.Count > 0)
                    {
                        materialChargesData.AddRange(existingResult);
                    }

                }
                else
                {
                    var contractItemsDefaultValues = JsonConvert.DeserializeObject<List<ResponseAdjustCharges>>(JsonConvert.SerializeObject(responseAdjustChargesWithDefaultData.ResponseContractDefaultRateValue));
                    var defaultCharges = contractItemsDefaultValues.Where(x => x.MaterialID == null).ToList();


                    // this section execute for fresh order 
                    if (requestCommonViewModel.Materials != null)
                    {
                        if (requestCommonViewModel.Materials.Count > 0)
                        {
                            // now get all default values for calcuation purspose.


                            foreach (var material in requestCommonViewModel.Materials)
                            {
                                var allmaterialExist = contractItemsDefaultValues.Where(x => x.MaterialID == material.MaterialID);

                                if (allmaterialExist != null && allmaterialExist.Count() > 0)
                                {
                                    foreach (var materialExist in allmaterialExist.ToList())
                                    {
                                        materialExist.type = material.Type;
                                        materialExist.ChargeUnit = Convert.ToInt64(materialExist.QuantityPerUOM);
                                        //materialExist.IsAutoAdded = true;
                                        materialChargesData.Add(materialExist);
                                    }
                                }
                            }
                        }
                    }

                    foreach (var defaultCharegsData in defaultCharges)
                    {
                        defaultCharegsData.MaterialName = " ";
                        defaultCharegsData.MaterialID = -1;
                        defaultCharegsData.OrderQuantity = Convert.ToInt64(defaultCharegsData.QuantityPerUOM);
                        defaultCharegsData.ChargeUnit = Convert.ToInt64(defaultCharegsData.ChargeUnit);
                        //defaultCharegsData.IsAutoAdded = true;
                        materialChargesData.Add(defaultCharegsData);
                    }

                }


                responseAdjustChargesWithDefaultData.ResponseAdjustCharges = materialChargesData;


                return responseAdjustChargesWithDefaultData;
            }
            else
            {
                return null;
            }
        }

        private decimal CalculateRateValue(long quantity, long RateTypeID, decimal RateValue)
        {
            return quantity * RateValue;
        }


        public decimal GetAvailableCredit(AvailableCreaditViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("LocationID", requestCommonViewModel.LocationID);
            parameters.Add("DeliveryDate", requestCommonViewModel.RequestedOrderDate);

            var dsResult = this.unitOfWork.ExecuteProcedure("SPO_CalculateAvailableCredit", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                if (!(dsResult.Tables[0].Rows[0][0] is System.DBNull) && dsResult.Tables[0].Rows[0][0] != null)
                {
                    return Convert.ToDecimal(dsResult.Tables[0].Rows[0][0].ToString());
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }


        public FuelChargesViewModel GetFuelCharges(AvailableCreaditViewModel requestCommonViewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("LocationID", requestCommonViewModel.LocationID);

            var dsResult = this.unitOfWork.ExecuteProcedure("Spo_GetFuelPriceComponent", parameters);

            if (dsResult != null && dsResult.Tables != null && dsResult.Tables[0].Rows.Count > 0)
            {
                return ConvertDataTabe.CreateListFromTable<FuelChargesViewModel>(dsResult.Tables[0]).FirstOrDefault();
            }
            else
            {
                return null;
            }
        }

        public ValidationResponse ValidateMaterialWithEquipment(MaterialEquipmentValidation materialEquipmentValidation)
        {

            var materials = materialEquipmentValidation.MaterialList.Select(x => x.MaterialID).ToList();


            var allMaterialWithPropertyDetails = this.unitOfWork.EquipmentTypeMaterialPropertyDetailRepository.ListAsync(x => x.IsDeleted == false && materials.Contains(x.MaterialId) && x.EquipmentTypeId == materialEquipmentValidation.EquipmentID);

            Dictionary<string, object> paramtersentity = new Dictionary<string, object>();
            paramtersentity.Add("Code", "Number of Units on a Pallet");
            paramtersentity.Add("ClientID", materialEquipmentValidation.ClientID);

            int EntityPropertyID = 0;
            DataSet ResultEntity = this.unitOfWork.ExecuteProcedure("SPO_GetEntityPropertyDetailOnProeprtyCode", paramtersentity);

            //var entityProeprty = this.unitOfWork.EntityPropertyRepository.GetByCode("Number of Units on a Pallet").Result;


            if (ResultEntity != null && ResultEntity.Tables.Count > 0)
            {
                EntityPropertyID = Convert.ToInt32(ResultEntity.Tables[0].Rows[0]["ID"].ToString());
            }

            bool inValid = true;
            string Msg = string.Empty;

            long totalPallets = 0;
            long truckSize = 0;

            truckSize = this.TotalEquipmentLoadSize(materialEquipmentValidation.EquipmentID, materialEquipmentValidation.ClientID, materialEquipmentValidation.MaterialList);


            foreach (var materialData in materialEquipmentValidation.MaterialList)
            {
                if (allMaterialWithPropertyDetails.Result != null)
                {
                    var existingMaterialEquipmentdetails = allMaterialWithPropertyDetails.Result.FirstOrDefault(x => x.MaterialId == materialData.MaterialID && x.EntityPropertyId == EntityPropertyID);
                    long materialPallets = 0;
                    if (existingMaterialEquipmentdetails != null)
                    {
                        materialPallets = this.ConvertMaterialToPallet(existingMaterialEquipmentdetails, materialData.Quantity, materialData.MaterialHiraryCode);
                        totalPallets = totalPallets + materialPallets;
                    }

                    //if (existingMaterialEquipmentdetails != null && Convert.ToDouble(existingMaterialEquipmentdetails.PropertyValue) < materialPallets)
                    //{
                    //    inValid = false;
                    //    //Msg = string.Format(Constants.OrderManagementValidationMessage.MaterialSizeOver, materialData.MaterialName, existingMaterialEquipmentdetails.PropertyValue);
                    //    break;
                    //}
                }
            }

            if (inValid)
            {
                if (truckSize < totalPallets)
                {
                    inValid = false;
                    Msg = Constants.OrderManagementValidationMessage.TruckOverloaded;
                }
            }

            return new ValidationResponse()
            {
                IsValid = inValid,
                Message = Msg
            };
        }

        private long ConvertMaterialToPallet(EquipmentTypeMaterialPropertyDetail existingMaterialEquipmentdetails, long currentQuanity, string materialHirarchyCode)
        {
            long totalPallets = 0;
            if (Convert.ToInt32(existingMaterialEquipmentdetails.PropertyValue) > 0 && currentQuanity > 0)
            {
                /*** Convert inputed quanity and convert them to Pallet **/

                var pallets = Math.Ceiling(Convert.ToDouble(currentQuanity) / Convert.ToDouble(existingMaterialEquipmentdetails.PropertyValue));

                if (materialHirarchyCode == "F23")
                {
                    pallets = Math.Ceiling((Convert.ToDouble(currentQuanity) * 2) / Convert.ToDouble(existingMaterialEquipmentdetails.PropertyValue));
                }

                totalPallets = Convert.ToInt64(pallets);
            }

            return totalPallets;
        }


        private int TotalEquipmentLoadSize(long equipmentID, int clientID, List<OrderMaterials> materialList)
        {
            string materils = string.Join(',', materialList.Select(x => x.MaterialID).ToList().ToArray());
            int totalTruckLoad = 0;
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("EquipmentTypeID", equipmentID);
            parameters.Add("ClientID", clientID);
            parameters.Add("Materials", materils);

            DataSet equipementResult = this.unitOfWork.ExecuteProcedure("SPO_GetEquipemntLoadSizeWithMaterialHirarchy", parameters);

            if (equipementResult != null && equipementResult.Tables.Count > 1)
            {
                totalTruckLoad = Convert.ToInt32(equipementResult.Tables[0].Rows[0][0].ToString());

                foreach (DataRow dr in equipementResult.Tables[1].Rows)
                {
                    var material = materialList.FirstOrDefault(x => x.MaterialID == Convert.ToInt32(dr["ID"]));
                    material.MaterialHiraryCode = dr["Code"].ToString();
                }
            }

            return totalTruckLoad;
        }

        /// <summary>
        /// this method only calculate those amount which amount is not override by user.
        /// before sending any filter out those records which are updated by user.
        /// this method re-calculate the amount of contract on basis of latest contract.
        /// </summary>
        /// <param name="calculateOrderCharges">view model for calculate the amount again.</param>
        /// <returns>Update viewmodel with amount.</returns>
        public async System.Threading.Tasks.Task<CalculateOrderCharges> CalculateOrderChargesOnLatestContractAsync(CalculateOrderCharges calculateOrderCharges)
        {

            var latestContractds = this.GetLatestContract(calculateOrderCharges.LocationID, calculateOrderCharges.RequestedDelieveryDate);

            if (latestContractds != null && latestContractds.Count > 0)
            {
                await this.GetLatestDefaultRateValues(latestContractds, calculateOrderCharges);

            }

            return calculateOrderCharges;
        }

        public decimal CalculateCoreChargesByRateID(long quantity, int rateTypeID, decimal ratevalue)
        {
            string ratetypecode = string.Empty;

            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("RateTypeID", rateTypeID);

            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetRateValueCode", parameter);

            if (ds != null && ds.Tables.Count > 0)
            {
                ratetypecode = ds.Tables[0].Rows[0][0].ToString();

                if (!string.IsNullOrEmpty(ratetypecode))
                {
                    return this.CalculateCoreCharges(quantity, ratetypecode, ratevalue);
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 0;
            }
        }

        public decimal CalculateCoreCharges(long quantity, string ratetypecode, decimal ratevalue)
        {
            if (quantity == 0 && ratevalue == 0)
            {
                return 0;
            }

            decimal amount = 0;
            switch (ratetypecode.ToLower())
            {
                case "perea":
                case "perpallet":

                    amount = quantity * ratevalue;

                    break;
            }

            return amount;
        }

        public ValidationResponse ValidateOrderCoreInputs(AllSalesOrderViewModel flagViewModel)
        {
            ValidationResponse validationResponse = new ValidationResponse()
            {
                IsValid = true,
                Message = string.Empty
            };
            var salesOrderViewModel = flagViewModel.salesorder;

            if (salesOrderViewModel.OrderTypeId.HasValue && salesOrderViewModel.OrderTypeId.Value > 0)
            {
                if (validationResponse.IsValid && !salesOrderViewModel.ClientId.HasValue)
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.Errors.InvalidClient;
                }

                if (validationResponse.IsValid && !salesOrderViewModel.RequestedDeliveryDate.HasValue && (salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderType.CPUOrder || salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderType.Customer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerReturn || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerToCustomer))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.InvalidDate;
                }

                if (validationResponse.IsValid && !salesOrderViewModel.ScheduledShipDate.HasValue && (salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Collections || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.StockTransfer))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.InvalidScheduleDate;
                }
                if (validationResponse.IsValid && string.IsNullOrEmpty(salesOrderViewModel.PurchaseOrderNumber))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.InvalidPO;
                }
                if (validationResponse.IsValid && (salesOrderViewModel.EquipmentTypeId == null || salesOrderViewModel.EquipmentTypeId == 0))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.EquipmentMaterialEmpty;
                }
                if (validationResponse.IsValid && salesOrderViewModel.ShipToTypeId <= 0 && (salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CPUOrder || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Customer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerToCustomer))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.ValidShipToType;
                }

                if (validationResponse.IsValid && (salesOrderViewModel.ToLocationId == null || salesOrderViewModel.ToLocationId == 0) && (salesOrderViewModel.OrderTypeCode != Constants.ModelEntityCodeValue.OrderType.CustomerReturn || salesOrderViewModel.OrderTypeCode != Constants.ModelEntityCodeValue.OrderType.StockTransfer || salesOrderViewModel.OrderTypeCode != Constants.ModelEntityCodeValue.OrderType.Collections))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.ValidShipToLocation;
                }

                if (validationResponse.IsValid && (salesOrderViewModel.FromLocationId == null || salesOrderViewModel.FromLocationId == 0) && (salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerReturn || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerToCustomer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.StockTransfer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Collections))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.ValidShipToLocation;
                }

                if (validationResponse.IsValid && salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.SendforShipping && flagViewModel.MaterialsList.Count == 0)
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.OneMaterialNeed;
                }
                if (validationResponse.IsValid && (salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.StockTransfer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Collections) && (!salesOrderViewModel.CarrierId.HasValue || salesOrderViewModel.CarrierId.Value <= 0))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.InvalidCarrier;
                }

                if (validationResponse.IsValid && salesOrderViewModel.ToLocationId > 0)
                {
                    if (!this.VerifyLocationIsBusinessParternMASWearHouse(salesOrderViewModel.ToLocationId.Value))
                    {
                        validationResponse.IsValid = false;
                        validationResponse.Message = Constants.OrderManagementValidationMessage.BusinessPartnerMustBeMASWearHOuse;
                    }
                }
                if (validationResponse.IsValid && salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.SendforShipping && (salesOrderViewModel.FromLocationId == null || salesOrderViewModel.FromLocationId == 0))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.FromLocationMissing;
                }

                if (validationResponse.IsValid && salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.SendforShipping && (salesOrderViewModel.ToLocationId == null || salesOrderViewModel.ToLocationId == 0))
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.FromLocationMissing;
                }

                if (validationResponse.IsValid && flagViewModel.MaterialsList.Count > 0 && flagViewModel.MaterialsList.Any(x => x.Quantity < 0) && salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.SendforShipping)
                {
                    validationResponse.IsValid = false;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.MaterialQuantityPositive;

                }
                if (validationResponse.IsValid && (flagViewModel.locationMaterial != null || flagViewModel.locationMaterial.Count > 0) && (salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CPUOrder || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Customer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.StockTransfer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Collections || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerToCustomer))
                {
                    decimal totalAmount = 0;

                    foreach (var chargesData in flagViewModel.locationMaterial)
                    {
                        totalAmount = totalAmount + chargesData.FullAmount;
                    }

                    if (totalAmount < 0)
                    {
                        validationResponse.IsValid = false;
                        validationResponse.Message = Constants.OrderManagementValidationMessage.ChargeShouldbeNonNegative;
                    }

                }

                if (validationResponse.IsValid && (salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.StockTransfer || salesOrderViewModel.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Collections))
                {

                    if (flagViewModel.salesorder.ScheduledShipDate.HasValue && flagViewModel.salesorder.MustArriveByDate.HasValue && flagViewModel.salesorder.ScheduledShipDate.Value >= flagViewModel.salesorder.MustArriveByDate.Value)
                    {
                        validationResponse.IsValid = false;
                        validationResponse.Message = Constants.OrderManagementValidationMessage.mustarrivegraterthanScheduleshipdate;
                    }
                }



            }



            if (validationResponse.IsValid && flagViewModel.MaterialsList != null && flagViewModel.MaterialsList.Count > 0)
            {
                MaterialEquipmentValidation materialEquipmentValidation = new MaterialEquipmentValidation()
                {
                    ClientID = flagViewModel.salesorder.ClientId.Value,
                    EquipmentID = flagViewModel.salesorder.EquipmentTypeId.Value
                };

                if (materialEquipmentValidation.MaterialList == null)
                {
                    materialEquipmentValidation.MaterialList = new List<OrderMaterials>();
                }
                else
                {
                    materialEquipmentValidation.MaterialList.Clear();
                }

                materialEquipmentValidation.MaterialList.AddRange(flagViewModel.MaterialsList.Where(x => x.IsPackage == false));

                if (materialEquipmentValidation.MaterialList.Count > 0)
                {
                    validationResponse = this.ValidateMaterialWithEquipment(materialEquipmentValidation);
                }
            }

            // this section holds the warning message.
            if (validationResponse.IsValid && salesOrderViewModel.OrderStatusCode == Constants.ModelEntityCodeValue.OrderStatus.SendforShipping && (flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CPUOrder || flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Customer))
            {
                if (!this.VerifyLinkedOrderSize(salesOrderViewModel.OrderId, salesOrderViewModel.EquipmentTypeId.Value))
                {
                    // validationResponse.IsValid = false;
                    validationResponse.IsConfirmation = true;
                    validationResponse.Message = Constants.OrderManagementValidationMessage.linkedOrderTruckOverload;
                }
                else
                {
                    validationResponse.IsConfirmation = false;
                }

            }

            if (validationResponse.IsValid == false || validationResponse.IsConfirmation == true)
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("MessageCode", validationResponse.Message);
                parameters.Add("ApplicationCode", "Ord");
                parameters.Add("ClientID", flagViewModel.salesorder.ClientId.Value);

                var resultMessage = this.unitOfWork.ExecuteProcedure("SPO_GetMessageByCode", parameters);

                if (resultMessage != null && resultMessage.Tables != null && resultMessage.Tables.Count > 0 && resultMessage.Tables[0].Rows.Count > 0)
                {
                    validationResponse.Message = resultMessage.Tables[0].Rows[0][0].ToString();
                }


            }

            return validationResponse;
        }


        public List<ContractDropdownViewModel> GetLatestContract(long locationID, DateTime requestedDelieveryDate)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("LocationID", locationID);
            parameter.Add("RequestDate", requestedDelieveryDate);
            var latestContractds = this.unitOfWork.ExecuteProcedure("SPO_ShipToGetContractData", parameter);

            if (latestContractds != null && latestContractds.Tables.Count > 0)
            {
                var contractList = ConvertDataTabe.CreateListFromTable<ContractDropdownViewModel>(latestContractds.Tables[0]);
                return contractList;
            }

            return null;

        }

        public async Task<CalculateOrderCharges> GetLatestDefaultRateValues(List<ContractDropdownViewModel> contractList, CalculateOrderCharges calculateOrderCharges)
        {
            var latestContract = contractList.FirstOrDefault(x => !string.IsNullOrEmpty(x.Code) && !string.IsNullOrEmpty(calculateOrderCharges.ContractCode) && x.Code.ToLower() == calculateOrderCharges.ContractCode.ToLower());

            if (latestContract != null && latestContract.Code.ToLower().Equals("customer"))
            {
                var autoadded = await this.unitOfWork.CustomerContractDetailRepository.ListAsync(x => x.CustomerContractId == latestContract.Id && x.IsRequired.HasValue && x.IsRequired.Value == 1 && x.TermStartDate.Value <= calculateOrderCharges.RequestedDelieveryDate && x.TermEndDate.Value > calculateOrderCharges.RequestedDelieveryDate && x.MaterialId == calculateOrderCharges.MaterialID && x.ChargeId == calculateOrderCharges.ChargeID && x.ChargeComputationMethodId == calculateOrderCharges.RateTypeID);

                if (autoadded != null && autoadded.Count() > 0)
                {
                    var defaultAutoAdded = autoadded.FirstOrDefault();
                    if (defaultAutoAdded != null)
                    {
                        calculateOrderCharges.RateValue = defaultAutoAdded.RateValue;
                        calculateOrderCharges.Amount = this.CalculateCoreCharges(calculateOrderCharges.Qunatity, calculateOrderCharges.RateTypeName, defaultAutoAdded.RateValue);
                    }
                }
            }
            else if (latestContract != null && latestContract.Code.ToLower().Equals("bp"))
            {
                var autoadded = await this.unitOfWork.CustomerContractDetailRepository.ListAsync(x => x.CustomerContractId == latestContract.Id && x.IsRequired.HasValue && x.IsRequired.Value == 1 && x.TermStartDate.Value <= calculateOrderCharges.RequestedDelieveryDate && x.TermEndDate.Value > calculateOrderCharges.RequestedDelieveryDate && x.MaterialId == calculateOrderCharges.MaterialID && x.ChargeId == calculateOrderCharges.ChargeID && x.ChargeComputationMethodId == calculateOrderCharges.RateTypeID);

                if (autoadded != null && autoadded.Count() > 0)
                {
                    var defaultAutoAdded = autoadded.FirstOrDefault();
                    if (defaultAutoAdded != null)
                    {
                        calculateOrderCharges.RateValue = defaultAutoAdded.RateValue;
                        calculateOrderCharges.Amount = this.CalculateCoreCharges(calculateOrderCharges.Qunatity, calculateOrderCharges.RateTypeName, defaultAutoAdded.RateValue);
                    }
                }
            }

            return await Task.FromResult(calculateOrderCharges);
        }



        private bool VerifyLocationIsBusinessParternMASWearHouse(long locationid)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("LocationID", locationid);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_ValidateBusinessPartnerLocationIsMASWeareHouse", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                if (Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString()) == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }

            return false;
        }

        private bool VerifyLinkedOrderSize(long orderID, long EquipmentTypeID)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("OrderID", orderID);
            parameters.Add("EquipmentTypeID", EquipmentTypeID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetstatusexceedsTruckLoad", parameters);
            if (ds != null && ds.Tables.Count > 0)
            {
                if (Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString()) == 1)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }

            return false;
        }


        public async Task<bool> ModifyEquipmentMaterialPropertyDetails(List<MaterialPropertiesGrid> materialPropertiesGrid, int ClientID, string CreatedBy)
        {
            if (materialPropertiesGrid != null && materialPropertiesGrid.Count > 0)
            {

                string xmlDataInput = "<EquipmentMaterialDetails>";
                foreach (var materialItems in materialPropertiesGrid)
                {
                    xmlDataInput = xmlDataInput + "<Data>";
                    xmlDataInput = xmlDataInput + string.Format("<MaterialData EquipmentTypeID=\"{0}\" ID=\"{1}\" PropertyValueUnitInPallet=\"{2}\" PropertyValueUnitInEquipment=\"{3}\" PropertyValuePalletInEquipment=\"{4}\" Weight=\"{5}\"></MaterialData>", materialItems.EquipmentID, materialItems.MaterialID, materialItems.UnitInPallet, materialItems.UnitInEquipement, materialItems.PalletInEquipement, materialItems.MaterialWeight);
                    xmlDataInput = xmlDataInput + "</Data>";
                }
                xmlDataInput = xmlDataInput + "</EquipmentMaterialDetails>";

                Dictionary<string, object> parameters = new Dictionary<string, object>();
                parameters.Add("EquipmentMaterialPropertyMapped", xmlDataInput);
                parameters.Add("ClientID", ClientID);
                parameters.Add("CreatedBy", CreatedBy);
                this.unitOfWork.ExecuteProcedure("SPO_ModifyEquipmentMultipleMaterialProperty", parameters);
            }

            return true;
        }

        public double CalculateChargesForRegularScreen(RequestObjectChargeFormulaeCalculation viewModel)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("Quantity", viewModel.Quantity);
            parameter.Add("RateTypeID", viewModel.RateTypeID);
            parameter.Add("ChargeUnit", viewModel.ChargeUnit);
            parameter.Add("EquipmentTypeID", viewModel.EquipmentTypeID);
            parameter.Add("LocationID", viewModel.LocationID);
            parameter.Add("OrderID", viewModel.OrderID);
            parameter.Add("Percentage", viewModel.Percentage);
            parameter.Add("PricemethodID", viewModel.PricemethodID);
            parameter.Add("RateValue", viewModel.RateValue);
            parameter.Add("TotalAmount", viewModel.TotalAmount);
            parameter.Add("TotalPallets", viewModel.TotalPallets);
            parameter.Add("TotalQuantity", viewModel.TotalQuantity);

            var calculatedChargeResult = this.unitOfWork.ExecuteProcedure("SPO_CalculateChargesDataForRegularOrder", parameter);

            if (calculatedChargeResult != null && calculatedChargeResult.Tables.Count > 0)
            {
                var contractList = Convert.ToDouble(calculatedChargeResult.Tables[0].Rows[0][0].ToString());
                return contractList;
            }

            return 0;

        }

        public async Task<List<MaterialPropertiesGrid>> GetVerifyEquipmentForMultipleMaterialPropertyOrder(RequestObjectMaterialProperties viewModel)
        {

            using IDbConnection con = new SqlConnection(this.ConnectionString);
            if (con.State == ConnectionState.Closed)
                con.Open();

            DynamicParameters parameter = new DynamicParameters();
            parameter.Add("@MaterialID", viewModel.materialID);
            parameter.Add("@EquipmentTypeID", viewModel.equipmentTypeID);
            var usersViewModels = con.Query<EditVerifyEquipmentMaterialProperty>("SPO_VerifyEquipmentMultipleMaterialProperties", parameter, commandType: CommandType.StoredProcedure).ToList();

            con.Close();

            if (usersViewModels != null && usersViewModels.Count > 0)
            {
                var materialPropertiesData = usersViewModels.ToList();

                if (materialPropertiesData != null && materialPropertiesData.Count > 0)
                {
                    var materialPropertiesGrids = materialPropertiesData.GroupBy(x => x.materialID).Select(p => new MaterialPropertiesGrid
                    {
                        MaterialID = p.Key,
                        MaterialName = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key).materialName,
                        EquipmentID = viewModel.equipmentTypeID,
                        MaterialWeight = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key).materialWeight,
                        UnitInPallet = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Units on a Pallet").propertyValue,
                        UnitInEquipement = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Units in an Equipment").propertyValue,
                        PalletInEquipement = materialPropertiesData.FirstOrDefault(x => x.materialID == p.Key && x.code == "Number of Pallets in an Equipment").propertyValue,
                    }).ToList();

                    if (materialPropertiesGrids.Count > 0)
                    {
                        var filterMaterialWithNonZero = materialPropertiesGrids.Where(x => x.MaterialWeight == 0 || x.UnitInPallet == 0 || x.UnitInEquipement == 0 || x.PalletInEquipement == 0).ToList();

                        if (filterMaterialWithNonZero.Count > 0)
                            return filterMaterialWithNonZero;
                        else
                            return null;
                    }

                    return null;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }

        }

    }
}
