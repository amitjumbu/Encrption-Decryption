﻿namespace CoreBaseBusiness.Managers
{
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq.Expressions;
    using System.Threading.Tasks;

    public class OrganizationPropertyDetailManager : BaseManager<OrganizationPropertyDetail, OrganizationPropertyDetailViewModel>, IOrganizationPropertyDetailManager
    {
        private readonly IMapper mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public OrganizationPropertyDetailManager(IMapper mapper,  ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public override Task<bool> AddAsync(OrganizationPropertyDetailViewModel viewModel)
        {
            var module = this.mapper.Map<OrganizationPropertyDetail>(viewModel);
            var data = this.unitOfWork.OrganizationPropertyDetailRepository.AddAsync(module);

            var finalResult = this.unitOfWork.Save();

            viewModel.ID = finalResult ? module.Id : 0;

            return Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  List all the Charge Type 
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async override Task<IEnumerable<OrganizationPropertyDetailViewModel>> ListAsync(OrganizationPropertyDetailViewModel viewModel)
        {
            var module = await this.unitOfWork.OrganizationPropertyDetailRepository.ListAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<OrganizationPropertyDetailViewModel>>(module);
        }

        /// <summary>
        ///  
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async override Task<IEnumerable<OrganizationPropertyDetailViewModel>> RangeAsync(int recordCount, OrganizationPropertyDetailViewModel viewModel)
        {
            Expression<Func<OrganizationPropertyDetail, bool>> condition = (c => c.IsDeleted == false);
            var module = await this.unitOfWork.OrganizationPropertyDetailRepository.GetAllAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var Freightdata = this.mapper.Map<IEnumerable<OrganizationPropertyDetailViewModel>>(module);
            //return this._mapper.Map<IEnumerable<FreightModeViewModel>>(module);
            return await Task.FromResult<IEnumerable<OrganizationPropertyDetailViewModel>>(FilterResult<OrganizationPropertyDetailViewModel>.GetFilteredResult(Freightdata, viewModel.FilterOn, viewModel.PageSize));
        }

        public async override Task<OrganizationPropertyDetailViewModel> GetAsync(int id)
        {
            var module = await this.unitOfWork.OrganizationPropertyDetailRepository.GetById(id);
            return this.mapper.Map<OrganizationPropertyDetailViewModel>(module);
        }

        public async override Task<bool> UpdateAsync(OrganizationPropertyDetailViewModel viewModel)
        {
            var module = this.mapper.Map<OrganizationPropertyDetail>(viewModel);
            var data = this.unitOfWork.OrganizationPropertyDetailRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        public async override Task<int> CountAsync(OrganizationPropertyDetailViewModel viewModel)
        {
            Expression<Func<OrganizationPropertyDetail, bool>> condition = (c => (!c.IsDeleted || c.IsDeleted) && (viewModel.ClientID == null || c.ClientId == viewModel.ClientID));

            return await this.unitOfWork.OrganizationPropertyDetailRepository.CountAsync(condition);
        }
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.OrganizationPropertyDetailRepository.DeleteAsync(id, deletedBy);
            this.unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }
        public Task<OrganizationPropertyDetailViewModel> GetAsync(long id)
        {
            var operatingLocationData = this.unitOfWork.OrganizationPropertyDetailRepository.GetAsync(id);

            var operatingLocationViewModelData = this.mapper.Map<OrganizationPropertyDetailViewModel>(operatingLocationData.Result);
            return Task.FromResult<OrganizationPropertyDetailViewModel>(operatingLocationViewModelData);

        }
        public async Task<IEnumerable<OrganizationPropertyDetailViewModel>> GetOrganizationPropertyDetailsList(OrganizationPropertyDetailViewModel organizationPropertyDetailViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            //if (organizationPropertyDetailViewModel != null && string.IsNullOrWhiteSpace(organizationPropertyDetailViewModel.FilterOn))
            //{
            //    Parameter.Add("ClientID", organizationPropertyDetailViewModel.ClientID);
            //    Parameter.Add("OrganizationID", organizationPropertyDetailViewModel.OrganizationId);
            //    Parameter.Add("PageNumber", organizationPropertyDetailViewModel.PageNo);
            //    Parameter.Add("PageSize", organizationPropertyDetailViewModel.PageSize);
            //    //Parameter.Add("SortColumn", freightModeViewModel.SortColumn);
            //    //Parameter.Add("SortOrder", freightModeViewModel.SortOrder);
            //}
            //if (!string.IsNullOrWhiteSpace(organizationPropertyDetailViewModel.SortColumn))
            //{
            //    Parameter.Add("SortColumn", organizationPropertyDetailViewModel.SortColumn);
            //}
            //if (!string.IsNullOrWhiteSpace(organizationPropertyDetailViewModel.SortOrder))
            //{
            //    Parameter.Add("SortOrder", organizationPropertyDetailViewModel.SortOrder);
            //}
            Parameter.Add("OrganizationID", organizationPropertyDetailViewModel.OrganizationId);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetOrganizationPropertyDetailsList", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<OrganizationPropertyDetailViewModel>(ds.Tables[0]);
                return finalResult; //await Task.FromResult<IEnumerable<OrganizationPropertyDetailViewModel>>(FilterResult<OrganizationPropertyDetailViewModel>.GetFilteredResult(finalResult, organizationPropertyDetailViewModel.FilterOn, organizationPropertyDetailViewModel.PageSize));
            }

            return null;
        }
        #region Get Operating Location Characteristics
        public async Task<IEnumerable<EntityPropertyViewModel>> GetOrganizationCharacteristics(EntityPropertyViewModel ModeViewModel)
        {
            List<EntityPropertyViewModel> entityPropertyViewModels = new List<EntityPropertyViewModel>();

            EntityPropertyViewModel entityProperty = new EntityPropertyViewModel();
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            Parameter.Add("OrganizationID", ModeViewModel.OrganizationID);
            Parameter.Add("ClientId", ModeViewModel.ClientId);
            //Parameter.Add("EntityCode", ModeViewModel.EntityCode); //SPO_GetOranizationCharacteristics
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetOranizationCharacteristics", Parameter);
            entityPropertyViewModels = ConvertDataTabe.CreateListFromTable<EntityPropertyViewModel>(ds.Tables[0]);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {

                foreach (var item in entityPropertyViewModels)
                {
                    Dictionary<string, object> EntityClientPropertyControlValueParameter = new Dictionary<string, object>();
                    //@EntityClientPropertyID
                    EntityClientPropertyControlValueParameter.Add("EntityClientPropertyID", item.EntityClientPropertyId);
                    DataSet PropertyControlValueds = this.unitOfWork.ExecuteProcedure("SPO_GetClientPropertyControlValueonEntityClientPropertyID", EntityClientPropertyControlValueParameter);
                    List<EntityClientPropertyControlValueViewModel> entityClientPropertyControlValue =
                        ConvertDataTabe.CreateListFromTable<EntityClientPropertyControlValueViewModel>(PropertyControlValueds.Tables[0]);
                    if (entityClientPropertyControlValue != null)
                    {
                        item.entityclientPropertyControlValueViewModel = entityClientPropertyControlValue;
                    }
                }
                return entityPropertyViewModels;
            }

            return null;
            //throw new NotImplementedException();
        }
        #endregion
        public async Task<bool> DeleteByIdsAsync(OrganizationPropertyDetailViewModel organizationPropertyDetailViewModel)
        {
            //foreach (int id in ids)
            //{
            //    var setupDelete = await this.unitOfWork.LocationRepository.DeleteAsync(id, deletedBy);
            //    if (!setupDelete)
            //    {
            //        // if fails during any items delete , then return failure
            //        return false;
            //    }
            //}
            var setupDelete = await this.unitOfWork.OrganizationPropertyDetailRepository.DeleteAsync(organizationPropertyDetailViewModel.ID, organizationPropertyDetailViewModel.UpdatedBy);
            if (!setupDelete)
            {
                // if fails during any items delete , then return failure
                return false;
            }
            var saveResponse = this.unitOfWork.Save();

            return await Task.FromResult<bool>(saveResponse);
        }
        public async Task<IEnumerable<OrganizationPropertyDetailViewModel>> SaveAll(List<OrganizationPropertyDetailViewModel> ViewModels)
        {
            var Organizationalls = new List<OrganizationPropertyDetailViewModel>();

            foreach (OrganizationPropertyDetailViewModel ViewModel in ViewModels)
            {
                if(ViewModel.PropertyValue != null) {
                    var result = await this.unitOfWork.OrganizationPropertyDetailRepository.AddAsync(this.mapper.Map<OrganizationPropertyDetail>(ViewModel)).ConfigureAwait(false);
                    if (result)
                    {
                        this.unitOfWork.Save();
                        Organizationalls.Add(ViewModel);
                    }
                }
                
            }
            return Organizationalls;
        }
    }
}