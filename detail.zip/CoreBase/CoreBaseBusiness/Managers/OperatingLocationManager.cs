﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity;
using CoreBaseData.UnitOfWork;
using Dapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{
    public class OperatingLocationManager : BaseManager<OperatingLocation, OperatingLocationViewModel>, IOperatingLocationManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private UnitOfWork _unitOfWork;


        public OperatingLocationManager(IMapper mapper, IHostingEnvironment hostingEnvironment, CoreDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new UnitOfWork(eICDBContext);
        }

        public override Task<bool> AddAsync(OperatingLocationViewModel viewModel)
        {
            bool result = false;
            if (viewModel != null)
            {
                var operatinglocationData = this._mapper.Map<OperatingLocation>(viewModel);
                operatinglocationData.UpdateDateTimeServer = DateTime.UtcNow;
                operatinglocationData.CreateDateTimeServer = DateTime.UtcNow;

                var addParto = this._unitOfWork.OperatingLocationRepository.AddAsync(operatinglocationData);
                this._unitOfWork.Save();
                viewModel.ID = operatinglocationData.ID;
                if (operatinglocationData.ID > 0)
                {

                    if (addParto.Result && viewModel.OperatingLocationAddresses != null && viewModel.OperatingLocationAddresses.Count > 0)
                    {
                        foreach (OperatingLocationAddressViewModel operatingAddressViewModel in viewModel.OperatingLocationAddresses)
                        {
                            operatingAddressViewModel.OperatingLocationID = viewModel.ID;
                            var operatingLocationAddressData = this._mapper.Map<OperatingLocationAddress>(operatingAddressViewModel);
                            // operatingLocationAddressData.OperatingLocation = operatinglocationData;
                            this._unitOfWork.OperatingLocationAddressRepository.AddAsync(operatingLocationAddressData);
                            this._unitOfWork.Save();
                        }
                    }

                    if (addParto.Result && viewModel.OperatingLocationContacts != null && viewModel.OperatingLocationContacts.Count > 0)
                    {
                        foreach (OperatingLocationContactViewModel operatingLocationContact in viewModel.OperatingLocationContacts)
                        {
                            operatingLocationContact.OperatingLocationID = viewModel.ID;
                            var operatingLocationContactData = this._mapper.Map<OperatingLocationContact>(operatingLocationContact);
                            //operatingLocationContactData.OperatingLocation = operatinglocationData;
                            this._unitOfWork.OperatingLocationContactRepository.AddAsync(operatingLocationContactData);
                            this._unitOfWork.Save();
                        }
                    }
                }

            }

            return Task.FromResult<bool>(result);

        }

        public Task<bool> Delete(EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket)
        {
            var contactList = this._unitOfWork.OperatingLocationContactRepository.GetAllAsync(2000, 1, 2000, x => x.OperatingLocationID == entityRecordRemoveRequestPacket.ID).Result;
            var addressList = this._unitOfWork.OperatingLocationAddressRepository.GetAllAsync(2000, 1, 2000, x => x.OperatingLocationID == entityRecordRemoveRequestPacket.ID).Result;


            foreach (var contact in contactList)
            {
                this._unitOfWork.OperatingLocationContactRepository.DeleteAsync(contact.ID, entityRecordRemoveRequestPacket.UserName);
            }

            foreach (var address in addressList)
            {
                this._unitOfWork.OperatingLocationAddressRepository.DeleteAsync(address.ID, entityRecordRemoveRequestPacket.UserName);
            }

            var result = this._unitOfWork.OperatingLocationRepository.DeleteAsync(entityRecordRemoveRequestPacket.ID, entityRecordRemoveRequestPacket.UserName);

            var transresult = this._unitOfWork.Save();

            return Task.FromResult<bool>(transresult);
        }

        /// <summary>
        ///  Retrieves  All data from  Package Id wise.
        /// </summary>
        public async override Task<IEnumerable<OperatingLocationViewModel>> RangeAsync(int recordCount, OperatingLocationViewModel viewModel)
        {
            Expression<Func<OperatingLocation, bool>> condition = c => c.ClientID == viewModel.ClientID && c.IsDeleted == false;
            var module = await this._unitOfWork.OperatingLocationRepository.GetAllAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);

            var finalResult = module.ToList().ConvertAll(p => new OperatingLocationViewModel()
            {

                ID = p.ID,
                ClientID = p.ClientID,
                Code = p.Code,
                CreateDateTimeBrowser = p.CreateDateTimeBrowser,
                CreateDateTimeServer = p.CreateDateTimeServer,
                CreatedBy = p.CreatedBy,
                Description = p.Description,
                ExternalSourceLocationKey = p.ExternalSourceLocationKey,
                IsActive = p.IsActive,
                IsDeleted = p.IsDeleted,
                IsPrimary = p.IsPrimary,
                Name = p.Name,
                OperatingLocationTypeID = p.OperatingLocationTypeID,
                OrganizationID = p.OrganizationID,
                ReferenceNo = p.ReferenceNo,
                SetupComplete = p.SetupComplete,
                SetupCompleteDateTime = p.SetupCompleteDateTime,
                SourceSystemID = p.SourceSystemID,
                TimeZoneID = p.TimeZoneID,
                UpdateDateTimeBrowser = p.UpdateDateTimeBrowser,
                UpdateDateTimeServer = p.UpdateDateTimeServer,
                UpdatedBy = p.UpdatedBy

            }).AsEnumerable();

            return finalResult;

            //return this._mapper.Map<IEnumerable<OperatingLocationViewModel>>(module);
        }

        public Task<OperatingLocationViewModel> GetAsync(long id)
        {
            var operatingLocationData = this._unitOfWork.OperatingLocationRepository.GetAsync(id);

            var operatingLocationContact = this._unitOfWork.OperatingLocationContactRepository.GetAllAsync(2000, 1, 2000, x => x.OperatingLocationID == id);

            var operatingLocationAddress = this._unitOfWork.OperatingLocationAddressRepository.GetAllAsync(2000, 1, 2000, x => x.OperatingLocationID == id);

            var operatingLocationViewModelData = this._mapper.Map<OperatingLocationViewModel>(operatingLocationData.Result);

            if (operatingLocationContact.Result.Any())
            {
                operatingLocationViewModelData.OperatingLocationContacts = this._mapper.Map<ICollection<OperatingLocationContactViewModel>>(operatingLocationContact.Result);
            }

            if (operatingLocationAddress.Result.Any())
            {
                operatingLocationViewModelData.OperatingLocationAddresses = this._mapper.Map<ICollection<OperatingLocationAddressViewModel>>(operatingLocationAddress.Result);
            }

            return Task.FromResult<OperatingLocationViewModel>(operatingLocationViewModelData);

        }

        public override Task<OperatingLocationViewModel> GetAsync(int id)
        {
            throw new NotImplementedException();
        }

        public override Task<IEnumerable<OperatingLocationViewModel>> ListAsync(OperatingLocationViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override Task<bool> UpdateAsync(OperatingLocationViewModel viewModel)
        {
            bool result = false;
            if (viewModel != null)
            {
                var OperatingLocationData = this._mapper.Map<OperatingLocation>(viewModel);

                var modifiedParto = this._unitOfWork.OperatingLocationRepository.UpdateAsync(OperatingLocationData);

                if (modifiedParto.Result && viewModel.OperatingLocationContacts != null && viewModel.OperatingLocationContacts.Count > 0)
                {
                    foreach (OperatingLocationContactViewModel contact in viewModel.OperatingLocationContacts)
                    {
                        var OperatingLocationContact = this._mapper.Map<OperatingLocationContact>(contact);

                        //OperatingLocationContact.OperatingLocation = OperatingLocationData;

                        if (contact.ID == 0)
                        {
                            this._unitOfWork.OperatingLocationContactRepository.AddAsync(OperatingLocationContact);
                        }
                        else
                        {
                            this._unitOfWork.OperatingLocationContactRepository.UpdateAsync(OperatingLocationContact);
                        }
                    }
                }

                if (modifiedParto.Result && viewModel.OperatingLocationAddresses != null && viewModel.OperatingLocationAddresses.Count > 0)
                {
                    foreach (OperatingLocationAddressViewModel operatingLocationAddress in viewModel.OperatingLocationAddresses)
                    {
                        var OperatingLocationaddress = this._mapper.Map<OperatingLocationAddress>(operatingLocationAddress);

                        //OperatingLocationaddress.OperatingLocation = OperatingLocationData;

                        if (operatingLocationAddress.ID == 0)
                        {
                            this._unitOfWork.OperatingLocationAddressRepository.AddAsync(OperatingLocationaddress);
                        }
                        else
                        {
                            this._unitOfWork.OperatingLocationAddressRepository.UpdateAsync(OperatingLocationaddress);
                        }
                    }
                }

                result = this._unitOfWork.Save();
            }

            return Task.FromResult<bool>(result);

        }


        public Task<IEnumerable<OperatingLocation>> RangeAsync(int recordCount, OperatingLocation viewModel)
        {
            throw new NotImplementedException();
        }

        public async override Task<int> CountAsync(OperatingLocationViewModel viewModel)
        {
            Expression<Func<OperatingLocation, bool>> condition = (c => !c.IsDeleted);

            //if (viewModel.ID > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this._unitOfWork.OperatingLocationRepository.CountAsync(condition);
        }

        
       public IEnumerable<object> GetOrganizationHierarchyGroupAsync(int recordCount, OperatingLocationViewModel viewModel)
        {
            string strConnectionString = Constants.Authentication.ConnectionString;

            using (IDbConnection con = new SqlConnection(strConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@OrganizationId", viewModel.OrganizationID);
                parameter.Add("@ClientId", viewModel.ClientID);
                IEnumerable<object> usersViewModels = con.Query<object>("SPO_GetOrganizationHierarchyGroup", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }

        public IEnumerable<object> GetOrganizationHierarchyEnterprisesAsync(int recordCount, OperatingLocationViewModel viewModel)
        {
            string strConnectionString = Constants.Authentication.ConnectionString;

            using (IDbConnection con = new SqlConnection(strConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@OrganizationId", viewModel.OrganizationID);
                parameter.Add("@ClientId", viewModel.ClientID);
                IEnumerable<object> usersViewModels = con.Query<object>("SPO_GetOrganizationHierarchy", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }

        #region Get Hospitals by Multiple Id
        public async Task<IEnumerable<OperatingLocationListViewModel>> GetLocationsListByIDs(CollectHospialIDs collectHospialIDs)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            Parameter.Add("IDs", collectHospialIDs.IDs);
            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetOperatingLocaationSetupListByIDs", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<OperatingLocationListViewModel>(ds.Tables[0]);
                return finalResult;
            }
            return null;
        }
        #endregion
    }
}
