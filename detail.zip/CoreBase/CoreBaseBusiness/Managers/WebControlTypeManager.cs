﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity2;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
using CoreBaseData;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;

namespace CoreBaseBusiness.Managers
{

    public class WebControlTypeManager : BaseManager<WebControlType, WebControlTypeViewModel>, IWebControlTypeManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;


        public WebControlTypeManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<WebControlTypeViewModel> GetAsync(long id)
        {
            var module = await this._unitOfWork.WebControlTypeRepository.GetAsync(id);
            var viewModel = this._mapper.Map<WebControlTypeViewModel>(module);
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<WebControlTypeViewModel>> ListAsync(WebControlTypeViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<WebControlType, bool>> condition = (c => !c.IsDeleted);
            //if (viewModel.IsAll)
            //{
            //    condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            //}
            //else
            //{
            //    condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            //}
            var module = await this._unitOfWork.WebControlTypeRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<WebControlTypeViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_ContractionsMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(WebControlTypeViewModel viewModel)
        {
            var module = this._mapper.Map<WebControlType>(viewModel);
            var data = this._unitOfWork.WebControlTypeRepository.AddAsync(module);



            var finalResult = this._unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }

        /// <summary>
        ///  Updates existing record for Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(WebControlTypeViewModel viewModel)
        {
            var module = this._mapper.Map<WebControlType>(viewModel);
            var data = this._unitOfWork.WebControlTypeRepository.UpdateAsync(module);



            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_ContractionsMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(WebControlTypeViewModel viewModel)
        {
            Expression<Func<WebControlType, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

           
            return await this._unitOfWork.WebControlTypeRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_ContractionsMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<WebControlTypeViewModel>> RangeAsync(int recordCount, WebControlTypeViewModel viewModel)
        {
            Expression<Func<WebControlType, bool>> condition = c => !c.IsDeleted;

            var module = await this._unitOfWork.WebControlTypeRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var webcontrolTypeviewmodel = this._mapper.Map<IEnumerable<WebControlTypeViewModel>>(module);

            return webcontrolTypeviewmodel;
        }


        /// <summary>
        ///  Deletes record Measurement_ContractionsMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this._unitOfWork.ContractionsPer10MinRepository.DeleteAsync(id, deletedBy);


            var result = this._unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


