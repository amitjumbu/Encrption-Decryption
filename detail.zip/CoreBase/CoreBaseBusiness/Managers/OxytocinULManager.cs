﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using CoreBaseData.Models.Entity2;
using CoreBaseData.UnitOfWork;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Managers
{

    public class OxytocinULManager : BaseManager<MeasurementOxytocinMeasurementValue, OxytocinULViewModel>, IOxytocinULManager
    {
        private readonly IMapper mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork unitOfWork;


        public OxytocinULManager(IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this.mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        /// <summary>
        /// Retrieves data id wise from Package Details.
        /// </summary>
        public async override Task<OxytocinULViewModel> GetAsync(long id)
        {
            var module = await this.unitOfWork.OxytocinULRepository.GetAsync(id);

          
            var viewModel = this.mapper.Map<OxytocinULViewModel>(module);

           
            return viewModel;
        }

        /// <summary>
        ///  Retrieves  All data from Measurement_OxytocinMeasurementValue Details.
        /// </summary>
        public async override Task<IEnumerable<OxytocinULViewModel>> ListAsync(OxytocinULViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<MeasurementOxytocinMeasurementValue, bool>> condition = (c => !c.IsDeleted);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.PartographId == viewModel.PartographId);
            }
            var module = await this.unitOfWork.OxytocinULRepository.ListAsync(condition).ConfigureAwait(false);
            return this.mapper.Map<IEnumerable<OxytocinULViewModel>>(module);
        }

        /// <summary>
        /// Add New Measurement_OxytocinMeasurementValue Data into System
        /// </summary>
        public async override Task<bool> AddAsync(OxytocinULViewModel viewModel)
        {
            var module = this.mapper.Map<MeasurementOxytocinMeasurementValue>(viewModel);
            var data = this.unitOfWork.OxytocinULRepository.AddAsync(module);

            var finalResult = this.unitOfWork.Save();

            viewModel.Id = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        } 

        /// <summary>
        ///  Updates existing record for Measurement_OxytocinMeasurementValue Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(OxytocinULViewModel viewModel)
        {
            var module = this.mapper.Map<MeasurementOxytocinMeasurementValue>(viewModel);
            var data = this.unitOfWork.OxytocinULRepository.UpdateAsync(module);

            

            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Measurement_OxytocinMeasurementValue Details.
        /// </summary>
        public async override Task<int> CountAsync(OxytocinULViewModel viewModel)
        {
            Expression<Func<MeasurementOxytocinMeasurementValue, bool>> condition = (c => !c.IsDeleted || c.IsDeleted);

            //if (viewModel.Id > 0)
            //    condition = condition.And(c => c.IsActive == viewModel.IsActive);
            //else
            //    condition = condition.And(c => c.IsActive == true);

            return await this.unitOfWork.OxytocinULRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves ALL  Measurement_OxytocinMeasurementValue details of Patient 
        /// </summary>
        public async override Task<IEnumerable<OxytocinULViewModel>> RangeAsync(int recordCount, OxytocinULViewModel viewModel)
        {
            Expression<Func<MeasurementOxytocinMeasurementValue, bool>> condition = (c => c.IsDeleted == false);
            if (viewModel.IsAll)
            {
                condition = condition.And(c => c.IsDeleted == false && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }
            else
            {
                condition = condition.And(c => (c.IsDeleted == false && c.IsVisible == true) && c.ClientId == viewModel.ClientId && c.PatientId == viewModel.PatientId && c.StagesId == viewModel.StagesId && c.PartographId == viewModel.PartographId);
            }

            var module = await this.unitOfWork.OxytocinULRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var OxytocinULModel = this.mapper.Map<IEnumerable<OxytocinULViewModel>>(module);
           

            return OxytocinULModel;
        }


        /// <summary>
        ///  Deletes record Measurement_OxytocinMeasurementValue from system id wise.
        /// </summary>
        public async Task<bool> DeleteAsync(long id, string deletedBy)
        {
            var data = this.unitOfWork.OxytocinULRepository.DeleteAsync(id, deletedBy);

            

            var result = this.unitOfWork.Save();

            return await Task.FromResult<bool>(result);
        }
    }
}


