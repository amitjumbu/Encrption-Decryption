﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;

using CoreBaseData.UnitOfWork;
using Dapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using CoreBaseBusiness.Helpers;
using CoreBaseData.Models.Entity2;

namespace CoreBaseBusiness.Managers
{
    public class FreightLaneManager : BaseManager<FreightLane, FreightLaneViewModel>, IFreightLaneManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        private readonly IConfiguration configuration;



        private string ConnectionString { get { return this.BaseConnectionString; } }

        public FreightLaneManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext) : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            this.unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
        }

        public async override Task<bool> AddAsync(FreightLaneViewModel viewModel)
        {

            var module = this._mapper.Map<FreightLane>(viewModel);
            var data = this.unitOfWork.FreightLaneRepository.AddAsync(module);

            var finalResult = this.unitOfWork.Save();

            viewModel.ID = finalResult ? module.Id : 0;

            return await Task.FromResult<bool>(finalResult);
        }


        public async override Task<int> CountAsync(FreightLaneViewModel viewModel)
        {
            Expression<Func<FreightLane, bool>> condition = (c => (!c.IsDeleted) && (viewModel.ClientID == null || c.ClientId == viewModel.ClientID));

            return await this.unitOfWork.FreightLaneRepository.CountAsync(condition);
        }

        /// <summary>
        ///  Retrieves  All data from  Package Id wise.
        /// </summary>


        public Task<OperatingLocationViewModel> GetAsync(long id)
        {
            throw new NotImplementedException();

        }

        public override Task<IEnumerable<FreightLaneViewModel>> ListAsync(FreightLaneViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public async override Task<IEnumerable<FreightLaneViewModel>> RangeAsync(int recordCount, FreightLaneViewModel viewModel)
        {
            Expression<Func<FreightLane, bool>> condition = (c => c.IsDeleted == false);
            var module = await this.unitOfWork.FreightLaneRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var Freightdata = this._mapper.Map<IEnumerable<FreightLaneViewModel>>(module);
            //return this._mapper.Map<IEnumerable<FreightModeViewModel>>(module);
            return await Task.FromResult<IEnumerable<FreightLaneViewModel>>(FilterResult<FreightLaneViewModel>.GetFilteredResult(Freightdata, viewModel.FilterOn, viewModel.PageSize));
        }

        //public async override Task<FreightLaneViewModel> GetAsync(int id)
        //{
        //    var module = await this.unitOfWork.FreightLaneRepository.GetById(id);
        //    return this._mapper.Map<FreightLaneViewModel>(module);
        //}

        public async override Task<bool> UpdateAsync(FreightLaneViewModel viewModel)
        {
            var module = this._mapper.Map<FreightLane>(viewModel);
            var data = this.unitOfWork.FreightLaneRepository.UpdateAsync(module);
            this.unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }


        /// <summary>
        ///  Deletes record from Comment by id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this.unitOfWork.FreightLaneRepository.DeleteAsync(id, deletedBy);
            this.unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }


        public async Task<IEnumerable<FreightLaneViewModel>> SaveAll(List<FreightLaneViewModel> ViewModels)
        {
            var FreightLaneId = 0;
            Dictionary<string, object> Parameter = new Dictionary<string, object>();

            //Parameter.Add("FromCountry", ViewModels[0].FromCountry);
            //Parameter.Add("FromState", ViewModels[0].FromState);
            //Parameter.Add("FromCity", ViewModels[0].FromCity);
            //Parameter.Add("FromZipcode", ViewModels[0].FromZipcode);
            //Parameter.Add("ToCountry", ViewModels[0].ToCountry);
            //Parameter.Add("ToState", ViewModels[0].ToState);
            //Parameter.Add("ToCity", ViewModels[0].ToCity);
            //Parameter.Add("ToZipcode", ViewModels[0].ToZipcode);
            //DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetGeoLocationId", Parameter);
            //if (ds.Tables[0].Rows.Count == 2)
            //{
            //    var FromGeoLocationId = ds.Tables[0].Rows[0]["GeoLocationId"];
            //    var ToGeoLocationId = ds.Tables[0].Rows[1]["GeoLocationId"];
                //ViewModels[0].FromGeoLocationId = Convert.ToInt32(FromGeoLocationId);
                //ViewModels[0].ToGeoLocationId = Convert.ToInt32(ToGeoLocationId);
                ////ViewModels[0].Distance = 4;
                var module = this._mapper.Map<FreightLane>(ViewModels[0]);
                var result = await this.unitOfWork.FreightLaneRepository.AddAsync(module).ConfigureAwait(false);
                if (result)
                {
                    this.unitOfWork.Save();
                    FreightLaneId = (int)module.Id;

                }
            //}
            var freightalls = new List<FreightLaneViewModel>();

            foreach (FreightLaneViewModel ViewModel in ViewModels)
            {
                ViewModel.FreightLaneId = FreightLaneId;
                //ViewModel.CostPerUnit = 5;
                ViewModel.MaterialId = null;
                ViewModel.QuantityUomid = null;
                ViewModel.CostPerUnit = ViewModel.RatePerLoad;
                // var module = this._mapper.Map<FreightLane>(ViewModel);
                var moduledet = this._mapper.Map<FreightLaneDetail>(ViewModel);
                // var result = await this.unitOfWork.FreightLaneRepository.AddAsync(module).ConfigureAwait(false);
                var result1 = await this.unitOfWork.FreightLaneRepository.AddAsyncDet(moduledet).ConfigureAwait(false);
                // var result = await this._unitOfWork.freightmodeRepository.AddAsync(this._mapper.Map<FreightMode>(ViewModel)).ConfigureAwait(false);
                if (result1)
                {
                    this.unitOfWork.Save();
                    ViewModel.ID = moduledet.Id;
                    freightalls.Add(ViewModel);
                }
            }
            return freightalls;
        }




        public async Task<IEnumerable<FreightLaneViewModel>> UpdateAll(List<FreightLaneViewModel> ViewModels)
        {
            var module = this._mapper.Map<FreightLane>(ViewModels[0]);
            var result = await this.unitOfWork.FreightLaneRepository.UpdateAsync(this._mapper.Map<FreightLane>(module)).ConfigureAwait(false);
            var FreightLaneId = (int)module.Id;
            
            this.unitOfWork.Save();
            //var FreightLaneId = 0;
            var freightalls = new List<FreightLaneViewModel>();
            if (ViewModels.Any())
            {
                foreach (FreightLaneViewModel ViewModel in ViewModels)
                {

                    //var module = this._mapper.Map<FreightLane>(ViewModel);
                    //var result = await this.unitOfWork.FreightLaneRepository.UpdateAsync(this._mapper.Map<FreightLane>(module)).ConfigureAwait(false);
                    //FreightLaneId = (int)module.Id;
                    //this.unitOfWork.Save();
                    var FreightDetId = ViewModel.FreightLaneDetId;
                    var moduledet = this._mapper.Map<FreightLaneDetail>(ViewModel);
                    moduledet.FreightLaneId = FreightLaneId;
                    if (FreightDetId != null)
                    {
                        moduledet.Id = (int)FreightDetId;
                    }
                
                    if (ViewModel.FreightLaneDetId != null)
                    {
                        var result1 = await this.unitOfWork.FreightLaneRepository.UpdateAsyncDet(this._mapper.Map<FreightLaneDetail>(moduledet)).ConfigureAwait(false);
                        //this.unitOfWork.Save();
                    }
                    else
                    {
                        //moduledet.MaterialId = null;
                        //moduledet.QuantityUomid = 30;
                        var result1 = await this.unitOfWork.FreightLaneRepository.AddAsyncDet(moduledet).ConfigureAwait(false);
                        
                    }
                    this.unitOfWork.Save();
                    freightalls.Add(ViewModel);
                }

                //  var finalResult = this.unitOfWork.Save();

               

            }
            return freightalls;
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> ID = ids.ConvertAll(long.Parse);
              //  List<int> FDID = ids.ConvertAll(int.Parse);

                List<FreightLane> freightlane = this.unitOfWork.FreightLaneRepository.ListAsync(p => ID.Contains(p.Id)).Result.ToList();
                //var name = FreightLane.UpdatedBy;
                List<FreightLaneDetail> freightlaneDet = this.unitOfWork.FreightLaneDetailRepository.ListAsync(p => ID.Contains(p.FreightLaneId)).Result.ToList();
                foreach (FreightLane freight in freightlane)
                {
                    freight.IsDeleted = true;
                }

                var result = this.unitOfWork.Save();
                foreach (FreightLaneDetail freightDet in freightlaneDet)
                {
                    freightDet.IsDeleted = true;
                }
                var result1 = this.unitOfWork.Save();
                //var result1 = this.unitOfWork.FreightLaneRepository.DeleteAsync(ID, deletedBy);
                // var result1 = await this.unitOfWork.FreightLaneRepository.DeleteAsync(ID, null);
                return await Task.FromResult<bool>(result1);
            }

            return await Task.FromResult<bool>(false);
        }

        public async Task<IEnumerable<FreightLaneViewModel>> GetEditfmsAsync(string ids)
        {
            var authorsList = await this.unitOfWork.FreightLaneRepository.GetByIds(ids).ConfigureAwait(false);
            var mappedData = this._mapper.Map<IEnumerable<FreightLaneViewModel>>(authorsList);
            return mappedData;
        }

        //public async Task<IEnumerable<FreightLaneViewModel>> GetFreightMode(MaterialCommonModel flagViewModel)
        //{
        //    using (SqlConnection con = new SqlConnection(this.ConnectionString))
        //    {
        //        if (con.State == ConnectionState.Closed)
        //        {
        //            con.Open();
        //        }

        //        DynamicParameters parameter = new DynamicParameters();
        //        parameter.Add("@EquipmentTypeID", flagViewModel.EquipmentTypeID);
        //        parameter.Add("@ClientID", flagViewModel.ClientID);
        //        var usersViewModels = con.Query<FreightModeViewModel>("SPO_GetFreightModeByEquipment", parameter, commandType: CommandType.StoredProcedure);

        //        con.Close();
        //        return usersViewModels;
        //    }
        //}

        public async Task<IEnumerable<FreightLaneViewModel>> GetFreightLaneList(FreightLaneViewModel freightLaneViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (freightLaneViewModel != null)
            {
                if (freightLaneViewModel != null && string.IsNullOrWhiteSpace(freightLaneViewModel.FilterOn))
                {
                    //Parameter.Add("ClientID", freightLaneViewModel.ClientID);
                    Parameter.Add("PageNumber", freightLaneViewModel.PageNo);
                    Parameter.Add("PageSize", freightLaneViewModel.PageSize);
                    //Parameter.Add("SortColumn", freightModeViewModel.SortColumn);
                    //Parameter.Add("SortOrder", freightModeViewModel.SortOrder);
                }
                if (!string.IsNullOrWhiteSpace(freightLaneViewModel.SortColumn))
                {
                    Parameter.Add("SortColumn", freightLaneViewModel.SortColumn);
                }
                if (!string.IsNullOrWhiteSpace(freightLaneViewModel.SortOrder))
                {
                    Parameter.Add("SortOrder", freightLaneViewModel.SortOrder);
                }
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetAllFreightLaneDetails", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FreightLaneViewModel>(ds.Tables[0]);
                if (freightLaneViewModel != null)
                {
                    return await Task.FromResult<IEnumerable<FreightLaneViewModel>>(FilterResult<FreightLaneViewModel>.GetFilteredResult(finalResult, freightLaneViewModel.FilterOn, freightLaneViewModel.PageSize));
                }
                else
                {
                    return finalResult;
                }
            }

            return null;
        }

        public async Task<IEnumerable<FreightLaneViewModel>> GetFreightLaneExcelErrorList(FreightLaneViewModel freightLaneViewModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            if (freightLaneViewModel != null)
            {
                if (freightLaneViewModel != null && string.IsNullOrWhiteSpace(freightLaneViewModel.FilterOn))
                {
                    //Parameter.Add("ClientID", freightLaneViewModel.ClientID);
                    Parameter.Add("PageNumber", freightLaneViewModel.PageNo);
                    Parameter.Add("PageSize", freightLaneViewModel.PageSize);
                    //Parameter.Add("SortColumn", freightModeViewModel.SortColumn);
                    //Parameter.Add("SortOrder", freightModeViewModel.SortOrder);
                }
                if (!string.IsNullOrWhiteSpace(freightLaneViewModel.SortColumn))
                {
                    Parameter.Add("SortColumn", freightLaneViewModel.SortColumn);
                }
                if (!string.IsNullOrWhiteSpace(freightLaneViewModel.SortOrder))
                {
                    Parameter.Add("SortOrder", freightLaneViewModel.SortOrder);
                }
            }

            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetFreightLaneErrorReportDetails", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FreightLaneViewModel>(ds.Tables[0]);
                if (freightLaneViewModel != null)
                {
                    return await Task.FromResult<IEnumerable<FreightLaneViewModel>>(FilterResult<FreightLaneViewModel>.GetFilteredResult(finalResult, freightLaneViewModel.FilterOn, freightLaneViewModel.PageSize));
                }
                else
                {
                    return finalResult;
                }
            }

            return null;
        }

        public async Task<IEnumerable<FreightLaneViewModel>> GetFreightLaneFilterData(FreightLaneViewModel ViewModel)
        {

            Dictionary<string, object> Parameter = new Dictionary<string, object>();

            Parameter.Add("FromCountry", ViewModel.FromCountry);
            Parameter.Add("FromState", ViewModel.FromState);
            Parameter.Add("FromCity", ViewModel.FromCity);
            Parameter.Add("FromZipcode", ViewModel.FromZipcode);

            Parameter.Add("ToCountry", ViewModel.ToCountry);
            Parameter.Add("ToState", ViewModel.ToState);
            Parameter.Add("ToCity", ViewModel.ToCity);
            Parameter.Add("ToZipcode", ViewModel.ToZipcode);

            Parameter.Add("FreightMode", ViewModel.FreightMode);
            Parameter.Add("Carrier", ViewModel.Carrier);
            Parameter.Add("EquipmentType", ViewModel.EquipmentType);

            DataSet ds = this.unitOfWork.ExecuteProcedure("Sp_GetFreightLaneFilterData", Parameter);

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<FreightLaneViewModel>(ds.Tables[0]);
                if (ViewModel != null)
                {
                    return await Task.FromResult<IEnumerable<FreightLaneViewModel>>(FilterResult<FreightLaneViewModel>.GetFilteredResult(finalResult, ViewModel.FilterOn, ViewModel.PageSize));
                }
                else
                {
                    return finalResult;
                }
            }

            return null;
        }
        public async Task<IEnumerable<FreightLaneViewModel>> InsertFreightLaneExcelData(List<FreightLaneViewModel> ViewModels)
        {
            using (IDbConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                var usersViewModels = con.Query<object>("SPO_DeleteFromFreightLaneExcelUpload", null, commandType: CommandType.StoredProcedure).ToList();

                con.Close();
                //return true;
            }

            foreach (FreightLaneViewModel ViewModel in ViewModels)
            {
                
                var moduledet = this._mapper.Map<FreightLaneExcelUpload>(ViewModel);
                //moduledet.Distance = ViewModel.Distances;
                var result = await this.unitOfWork.FreightLaneExcelUploadRepository.AddAsyncDet(moduledet).ConfigureAwait(false);
            }
            var result1 = this.unitOfWork.Save();
            using (IDbConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                var usersViewModels = con.Query<object>("SPO_InsertExcelDataInToFreightLaneTables", null, commandType: CommandType.StoredProcedure).ToList();

                con.Close();
                //return true;
            }
           // var ds = this.unitOfWork.ExecuteProcedure("SPO_InsertExcelDataInToFreightLaneTables", null);

           

            return null;
        }
       
    }
}
