﻿using System;
using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Contracts;
using CoreBaseData.UnitOfWork;
//using CoreBaseData.Helpers.PredicateExtension;
using CoreBaseBusiness.Helpers.PredicateExtension;
using CoreBaseData.Models.Entity2;
using System.Data.SqlClient;
using System.Data;
using CoreBaseBusiness.Helpers;
using Microsoft.Extensions.Configuration;
using System.Linq;
using Dapper;

namespace CoreBaseBusiness.Managers
{

    public class MaterialManager : BaseManager<Material, MaterialViewModel>, IMaterialManager
    {
        private readonly IMapper _mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private ADecTecCoreBaseUnitOfWork _unitOfWork;

        /// <summary>
        /// this variables holds the information of configuration like connectionstring etc.
        /// </summary>
        private readonly IConfiguration configuration;

        /// <summary>
        /// this property sends connection strings.
        /// </summary>
        //private string ConnectionString { get { return this.configuration["ConnectionString:CoreBaseDB"]; } }
        private string ConnectionString { get { return this.BaseConnectionString; } }

        public MaterialManager(IConfiguration configuration, IMapper mapper, IHostingEnvironment hostingEnvironment, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            this._hostingEnvironment = hostingEnvironment;
            _unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
            this.configuration = configuration;
            _unitOfWork.ConnectionString = this.BaseConnectionString;
        }

        /// <summary>
        ///User can get Retrieves data from Material by id.
        /// </summary>
        public override async Task<MaterialViewModel> GetAsync(int id)
        {
            var module = await _unitOfWork.MaterialRepository.GetById(id).ConfigureAwait(false);
            return this._mapper.Map<MaterialViewModel>((Material)module);
        }

        /// <summary>
        ///  Retrieves  All data from location.
        /// </summary>
        public async override Task<IEnumerable<MaterialViewModel>> ListAsync(MaterialViewModel viewModel)
        {
            // TODO: This can be used for contains 
            Expression<Func<Material, bool>> condition = (c => !c.IsDeleted);

            var module = await this._unitOfWork.MaterialRepository.ListAsync(condition).ConfigureAwait(false);
            return this._mapper.Map<IEnumerable<MaterialViewModel>>(module);
        }


        public async Task<int> ListmaterialAsync(MaterialCommodityMapViewModel viewModel = null)
        {
            var module = await this._unitOfWork.MaterialRepository.ListmaterialAsync(c => viewModel != null ? viewModel.IsDeleted : !c.IsDeleted).ConfigureAwait(false);
            return module.Count();
        }

        public async Task<IEnumerable<MaterialCommodityMapViewModel>> GetAllMaterialCommodityMapData(MaterialCommodityMapViewModel viewModel)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel != null && string.IsNullOrWhiteSpace(viewModel.FilterOn))
            {
                parameters.Add("PageNumber", viewModel.PageNo);
                parameters.Add("PageSize", viewModel.PageSize);
            }

            parameters.Add("ClientID", viewModel.ClientID);
            if (!string.IsNullOrWhiteSpace(viewModel.SortColumn))
            {
                parameters.Add("SortColumn", viewModel.SortColumn);
            }

            if (!string.IsNullOrWhiteSpace(viewModel.SortOrder))
            {
                parameters.Add("SortOrder", viewModel.SortOrder);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("Sp_GetAllMaterialCommodityMapData", parameters);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialCommodityMapViewModel>(ds.Tables[0]);
                return await Task.FromResult<IEnumerable<MaterialCommodityMapViewModel>>(FilterResult<MaterialCommodityMapViewModel>.GetFilteredResult(finalResult, viewModel.FilterOn, viewModel.PageSize, viewModel));
            }

            return null;
        }

        /// <summary>
        /// Material Add Data.
        /// </summary>
        public async override Task<bool> AddAsync(MaterialViewModel viewModel)
        {
            var module = this._mapper.Map<Material>(viewModel);
            module.IsDeleted = false;
            module.UpdateDateTimeServer = DateTime.Now;
            module.CreateDateTimeServer = DateTime.Now;

            var data = this._unitOfWork.MaterialRepository.AddAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Updates existing record for Material Details.
        /// </summary>
        public async override Task<bool> UpdateAsync(MaterialViewModel viewModel)
        {
            var module = this._mapper.Map<Material>(viewModel);
            var data = this._unitOfWork.MaterialRepository.UpdateAsync(module);
            this._unitOfWork.Save();
            return await Task.FromResult<bool>(data.Result);
        }

        /// <summary>
        ///  Retrieves Count Of All data from Material.
        /// </summary>
        public async override Task<int> CountAsync(MaterialViewModel viewModel)
        {
            Expression<Func<Material, bool>> condition = (c => !c.IsDeleted);


            if (viewModel.ID > 0)
                condition = condition.And(c => c.IsDeleted == viewModel.IsDeleted);
            else
                condition = condition.And(c => c.IsDeleted == false);

            return await this._unitOfWork.MaterialRepository.CountAsync(condition);
        }

        /// <summary>
        ///Get All List for Material Data List
        /// </summary>
        public async override Task<IEnumerable<MaterialViewModel>> RangeAsync(int recordCount, MaterialViewModel viewModel)
        {
            Expression<Func<Material, bool>> condition = (c => c.IsDeleted == false);
            var module = await this._unitOfWork.MaterialRepository.RangeAsync(recordCount, viewModel.PageNo, viewModel.PageSize, condition);
            var mappedData = this._mapper.Map<IEnumerable<MaterialViewModel>>(module);
            return mappedData;
        }
        /// <summary>
        ///  Deletes record from location id.
        /// </summary>
        public async Task<bool> DeleteAsync(int id, string deletedBy)
        {
            var data = this._unitOfWork.MaterialRepository.DeleteAsync(id, deletedBy);
            this._unitOfWork.Save();

            return await Task.FromResult<bool>(data.Result);
        }

        public async Task<IEnumerable<MaterialViewModel>> GetOrderMaterial(OrderRequestedMaterialsViewModel orderRequestedMaterialsViewModel)
        {

            Dictionary<string, object> parameters = new Dictionary<string, object>();

            parameters.Add("SectionID", orderRequestedMaterialsViewModel.SectionID);
            parameters.Add("ClientID", orderRequestedMaterialsViewModel.ClientID);

            if (orderRequestedMaterialsViewModel.OrderTypeID.HasValue && orderRequestedMaterialsViewModel.OrderTypeID.Value > 0)
            {
                parameters.Add("OrderTypID", orderRequestedMaterialsViewModel.OrderTypeID.Value);
            }

            DataSet ds = this._unitOfWork.ExecuteProcedure("SPO_GetMaterialList", parameters);

            if (ds != null && ds.Tables.Count > 0)
            {
                List<MaterialViewModel> orders = ConvertDataTabe.CreateListFromTable<MaterialViewModel>(ds.Tables[0]);

                if (orders.Count > 0)
                {
                    return await Task.FromResult<IEnumerable<MaterialViewModel>>(orders.AsEnumerable());
                }
                else
                {
                    return null;
                }
            }

            return null;
        }

        public async Task<LocationMaterialModel> Materialquantity(MaterialQuantityRequestModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@EquipmentTypeId", flagViewModel.EquipmentTypeID);
                parameter.Add("@MaterialId", flagViewModel.MaterialId);
                parameter.Add("@ClientID", flagViewModel.ClientID);
                parameter.Add("@EntityPropertyCode", flagViewModel.EntityPropertyCode);
                var usersViewModels = con.Query<LocationMaterialModel>("Sp_GetMaterialQuantity", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels.FirstOrDefault();
            }
        }

        public async Task<IEnumerable<LocationMaterialModel>> LocationMaterial(MaterialCommonModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@LocationID", flagViewModel.LocationID);
                parameter.Add("@ClientID", flagViewModel.ClientID);
                parameter.Add("@EntityPropertyCode", flagViewModel.EntityPropertyCode);
                parameter.Add("@EquipmentTypeID", flagViewModel.EquipmentTypeID);

                if (flagViewModel.OrderTypeID.HasValue && flagViewModel.OrderID.HasValue && flagViewModel.OrderTypeID.Value > 0 && flagViewModel.OrderID.Value > 0)
                {
                    parameter.Add("@OrderID", flagViewModel.OrderID.Value);
                    parameter.Add("@OrdertTypeID", flagViewModel.OrderTypeID.Value);
                }

                var usersViewModels = con.Query<LocationMaterialModel>("SPO_GetMaterialByLoacation", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }

        public async Task<IEnumerable<LocationMaterialModel>> LocationShippingMaterial(MaterialCommonModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@LocationID", flagViewModel.LocationID);
                parameter.Add("@ClientID", flagViewModel.ClientID);

                if (flagViewModel.OrderID.HasValue && flagViewModel.OrderID.Value > 0 && flagViewModel.OrderTypeID.HasValue && flagViewModel.OrderTypeID.Value > 0)
                {
                    parameter.Add("@OrderID", flagViewModel.OrderID.Value);
                    parameter.Add("@OrderTypeID", flagViewModel.OrderTypeID.Value);
                }
                var usersViewModels = con.Query<LocationMaterialModel>("SPO_GetShippingMaterialByLoacation", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }



        public async Task<IEnumerable<LocationMaterialModel>> DefaultPallet(MaterialCommonModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientID", flagViewModel.ClientID);
                parameter.Add("@UserID", flagViewModel.UserID);
                var usersViewModels = con.Query<LocationMaterialModel>("SPO_GetDefaultPalletMaterial", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }


        public async Task<IEnumerable<ShippmentMaterialModel>> AllMaterialquantity(AllMaterialQuantityRequestModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                string materiallist = "";

                if (flagViewModel.Materials != null)
                {
                    if (flagViewModel.Materials.Count > 0)
                    {
                        List<long> allMaterialID = flagViewModel.Materials.Select(x => x.MaterialID).ToList();
                        materiallist = string.Join(",", allMaterialID.ToArray());
                    }
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@EquipmentTypeId", flagViewModel.MaterialQuantityRequestModel.EquipmentTypeID);
                parameter.Add("@MaterialID", materiallist);
                parameter.Add("@ClientID", flagViewModel.MaterialQuantityRequestModel.ClientID);
                parameter.Add("@EntityPropertyCode", flagViewModel.MaterialQuantityRequestModel.EntityPropertyCode);
                var usersViewModels = con.Query<ShippmentMaterialModel>("SPO_GetAllMaterialQuantity", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return usersViewModels;
            }
        }

        public async Task<IEnumerable<MaterialPalletsCalculation>> GetMaterialPalletsCalculation(MaterialPalletsCalculation flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
               
                DynamicParameters parameter = new DynamicParameters();               
                parameter.Add("@SalesOrderID", flagViewModel.SalesOrderID);
                parameter.Add("@ClientID", flagViewModel.ClientID);                
                var usersViewModels = con.Query<MaterialPalletsCalculation>("SPO_GetMaterialPalletsCalculation", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return usersViewModels;
            }
        }
        public async Task<IEnumerable<MaterialViewModel>> GetDefaultMaterialCommodity(MaterialCommodityRequestModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                string materiallist = "";

                if (flagViewModel.Materials != null)
                {
                    if (flagViewModel.Materials.Count > 0)
                    {
                        List<long> allMaterialID = flagViewModel.Materials.Select(x => x.ID).ToList();
                        materiallist = string.Join(",", allMaterialID.ToArray());
                    }
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@MaterialID", materiallist);
                parameter.Add("@LocationID", flagViewModel.MaterialQuantityRequestModel.LocationID);
                parameter.Add("@ClientID", flagViewModel.MaterialQuantityRequestModel.ClientID);

                var usersViewModels = con.Query<MaterialViewModel>("SPO_GetMaterialCommodity", parameter, commandType: CommandType.StoredProcedure);
                con.Close();
                return usersViewModels;
            }
        }



        public async Task<DefaultMaterialProperty> DefaultMaterialProperty(MaterialQuantityRequestModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientID", flagViewModel.ClientID);
                var usersViewModels = con.Query<DefaultMaterialProperty>("SPO_GetMaterialDefaultProperty", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels.FirstOrDefault();
            }
        }

        public async Task<object> getMaterial(string code)
        {
            var comdata = await this._unitOfWork.MaterialRepository.GetByCode(code);
            if (comdata != null)
            {
                return await Task.FromResult<object>(comdata);
            }
            else
            {
                return await Task.FromResult<object>(null);
            }
        }

        public async Task<IEnumerable<MaterialCommodityMapViewModel>> UpdateMaterialCommodityAsync(List<MaterialCommodityMapViewModel> viewModels)
        {
            var updatedViewModel = new List<MaterialCommodityMapViewModel>();
            foreach (MaterialCommodityMapViewModel viewModel in viewModels)
            {
                var material = this._mapper.Map<Material>(viewModel);
                material.MaterialHierarchy = null;
                material.LocationPreferredMaterial = null;
                material.MaterialPropertyDetail = null;
                var response = await this._unitOfWork.MaterialRepository.UpdateMaterialCommodityAsync(material).ConfigureAwait(false);
                if (response)
                {
                    this._unitOfWork.Save();
                    updatedViewModel.Add(viewModel);
                }
            }

            return updatedViewModel;
        }

        public async Task<bool> DeleteAllAsync(List<string> ids)
        {
            if (ids.Any())
            {
                List<long> iD = ids.ConvertAll(long.Parse);

                List<Material> materials = this._unitOfWork.MaterialRepository.ListmaterialAsync(p => iD.Contains(p.Id)).Result.ToList();

                foreach (Material material in materials)
                {
                    material.IsDeleted = true;
                }

                var result = this._unitOfWork.Save();

                return await Task.FromResult<bool>(result);
            }

            return await Task.FromResult<bool>(false);
        }
        public async Task<IEnumerable<MaterialCommodityMapViewModel>> GetAllMaterialWithHMaterialHierarchy(MaterialCommodityDeleteModel materialCommodityDeleteModel)
        {
            Dictionary<string, object> Parameter = new Dictionary<string, object>();
            Parameter.Add("IDs", materialCommodityDeleteModel.IDs);
            DataSet ds = this._unitOfWork.ExecuteProcedure("Sp_GetAllMaterialwithMaterialHierarchy", Parameter);
            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                var finalResult = ConvertDataTabe.CreateListFromTable<MaterialCommodityMapViewModel>(ds.Tables[0]);
                return finalResult;
            }
            return null;
        }

        public async Task<object> ContractMaterial(ContractMaterialModel flagViewModel)
        {
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }

                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@ClientID", flagViewModel.ClientID);
                parameter.Add("@ContractID", flagViewModel.ContractID);
                parameter.Add("@LocationID", flagViewModel.LocationID);
              

               
                var usersViewModels = con.Query<Object>("SPO_GetContractMaterial", parameter, commandType: CommandType.StoredProcedure);

                con.Close();
                return usersViewModels;
            }
        }

    }
}