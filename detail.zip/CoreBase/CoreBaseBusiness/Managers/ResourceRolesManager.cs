﻿namespace CoreBaseBusiness.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.PredicateExtension;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.UnitOfWork;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.Extensions.Configuration;

    public class ResourceRolesManager : BaseManager<ResourceRoles, ResourceRolesViewModel>, IResourceRolesManager
    {
        private readonly IMapper _mapper;
        private ADecTecCoreBaseUnitOfWork unitOfWork;

        public ResourceRolesManager(IMapper mapper, ADecTecCoreBaseDBContext eICDBContext)
            : base()
        {
            this._mapper = mapper;
            unitOfWork = new ADecTecCoreBaseUnitOfWork(eICDBContext);
        }

        public async override Task<bool> AddAsync(ResourceRolesViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override async Task<IEnumerable<ResourceRolesViewModel>> ListAsync(ResourceRolesViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public override async Task<bool> UpdateAsync(ResourceRolesViewModel viewModel)
        {
            throw new NotImplementedException();
        }
        public List<ResourceRolesViewModel> GetResourceRole(long ClientId)
        {
            List<ResourceRolesViewModel> ResourceroleList = new List<ResourceRolesViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", ClientId);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetResourceRoleList", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ResourceroleList.Add(new ResourceRolesViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        Name = dr["Name"].ToString()
                    });
                }
            }

            return ResourceroleList;
        }

        #region Bind Physician Name in Patient page
        public List<ResourceOnResourceRoleViewModel> GetResourceNameOnResourceRole(ResourceOnResourceRoleViewModel resourceOnResourceRoleViewModel)
        {
            List<ResourceOnResourceRoleViewModel> ResourceName = new List<ResourceOnResourceRoleViewModel>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("ClientID", resourceOnResourceRoleViewModel.ClientId);
            parameters.Add("ResourceRoleID", resourceOnResourceRoleViewModel.ResourceRoleID);
            parameters.Add("LocationId", resourceOnResourceRoleViewModel.LocationID);
            DataSet ds = this.unitOfWork.ExecuteProcedure("SPO_GetResourceNameOnResourceRole", parameters);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    ResourceName.Add(new ResourceOnResourceRoleViewModel()
                    {
                        Id = Convert.ToInt32(dr["ID"]),
                        Code = dr["Code"].ToString(),
                        PhysicianName = dr["PhysicianName"].ToString(),
                        IsActive =Convert.ToBoolean(dr["IsActive"]),
                        IsDeleted = Convert.ToBoolean(dr["IsDeleted"]),
                        LocationID =Convert.ToInt64(dr["LocationID"]),
                        ResourceTypeID = Convert.ToInt64(dr["ResourceTypeID"]),
                        ClientId = Convert.ToInt64(dr["ClientId"]),
                        ResourceRoleID = Convert.ToInt64(dr["ClientId"]),
                        ResourceRoleCode = dr["ClientId"].ToString(),
                        ResourceRoleName = dr["ClientId"].ToString(),
                    });
                }
            }

            return ResourceName;
        }
        #endregion
    }
}