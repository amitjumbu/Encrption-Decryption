﻿namespace CoreBaseBusiness.Services
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.ViewModel;

    /// <summary>
    /// Interface which send your process in background job.
    /// </summary>
    public interface IHangfireOperation
    {
        void SendEmailAsyn(string messageBody, string subject, string recipeint, string cc, string bcc, List<string> attachement);

        void SendForShippingOrder(long orderID, int OrderTypeID);

        string CreateOrderNumberAndSave(long orderID,int OrderTypeID, bool isAsynchronous = true);

        void ARChargesTOMAS(long orderID);

        IEnumerable<object> SendShipmentTOMAS(long shipmentID);

        void CalculateARChargesAgain(long orderid);

        void SendAppointmentDetails(string pickup, string delivery, long orderid, int orderTypeID);

        void CalculateAPChargesAgain(long orderid, int ordertypeid);
        void UpdateOrderFileFlag(AllSalesOrderViewModel viewModel);

        void ARChargeTOMAS(long orderID, int ordertypeid);

        void ARChargeTOMASS(string orderID,int isStockTransfer);

        void REARChargeTOMAS(string orderID, int isStockTransfer);

        void UpdateEnglishToSpanishComment(long orderID, int OrderTypeId, string SpanishTransportationComment, string SpanishLoadingComment, string SpanishTransplaceOrderComment, string SpanishTransplaceDeliveryComment);

        void SaveOrderConvertLanguage(List<BulkOrderViewModel> result);

    }
}
