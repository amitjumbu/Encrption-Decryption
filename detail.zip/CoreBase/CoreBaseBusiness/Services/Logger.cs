using CoreBaseBusiness.Services;
using System;
using ApplicationLogLevel = CoreBaseBusiness.Helpers.Enums;
namespace CoreSecurityBusiness.Services
{
    public class Logger
    {
        //private readonly ILogger _logger;
        // public Logger(ILogger logger)
        // {
        //     this._logger = logger;
        // }

        public void Log(Exception ex, string message, ApplicationLogLevel.LogLevel logLevel)
        {
            switch (logLevel)
            {
                case ApplicationLogLevel.LogLevel.Error:
                    NLogService.CurrentInstance.Error(ex, message);
                    break;
                case ApplicationLogLevel.LogLevel.Information:
                    NLogService.CurrentInstance.Info(message);
                    break;
            }
        }
    }
}