namespace CoreBaseBusiness.Services
{
    public class ConfigurationKeys
    {
        public bool EnforceApiEncryption { get; set; }
        public bool EnforceApiDecryption { get; set; }
    }
}