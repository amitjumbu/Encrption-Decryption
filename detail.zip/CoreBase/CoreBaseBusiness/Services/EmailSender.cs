﻿namespace CoreBaseBusiness.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;
    using ViewModel;
    using Microsoft.EntityFrameworkCore.Internal;
    using MimeKit;
    using MimeKit.Cryptography;

    public interface IEmailSender
    {
        Task<bool> SendEmailAsync(string messageBody, string messageSubject, string recipeints, string cc, string bcc, List<string> attachments);
    }

    /// <summary>
    /// this class implemented by Kapil Pandey.
    /// On 03-Sep-2020.
    /// this class send email.
    /// </summary>
    public class EmailSender : IEmailSender
    {
        private readonly EmailConfigurationViewModel emailConfigurationViewModel;
        private readonly char seprator = ';';

        public EmailSender(EmailConfigurationViewModel emailConfigurationViewModel)
        {
            this.emailConfigurationViewModel = emailConfigurationViewModel;
        }

        /// <summary>
        /// this method sends email.
        /// </summary>
        /// <param name="messageBody">Body Of Message.</param>
        /// <param name="messageSubject">Subject of message.</param>
        /// <param name="recipeints">Recivers List.</param>
        /// <param name="cc">CC List.</param>
        /// <param name="bcc">BCC list.</param>
        /// <param name="attachments">List Of Attachmets.</param>
        /// <returns>return true after success.</returns>
        public async Task<bool> SendEmailAsync(string messageBody, string messageSubject, string recipeints, string cc, string bcc, List<string> attachments)
        {
            MimeMessage mimeMessage = new MimeMessage();

            mimeMessage.From.Add(new MailboxAddress(this.emailConfigurationViewModel.Sender));

            mimeMessage.To.AddRange(this.FactorEmailAddress(recipeints, this.seprator));

            if (!string.IsNullOrEmpty(bcc))
            {
                mimeMessage.Bcc.AddRange(this.FactorEmailAddress(bcc, this.seprator));
            }

            if (!string.IsNullOrEmpty(cc))
            {
                mimeMessage.Cc.AddRange(this.FactorEmailAddress(cc, this.seprator));
            }

            mimeMessage.Subject = messageSubject;


            var multipart = new Multipart("mixed");

            var body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = messageBody,
                IsAttachment = attachments == null ? false : attachments.Any(),
            };

            multipart.Add(body);

            if (attachments != null && attachments.Count > 0)
            {
                var attachentsList = this.GetAttachments(attachments);

                if (attachentsList.Any())
                {
                    foreach (var attachment in attachentsList)
                    {
                        multipart.Add(attachment);
                    }
                }
            }

            mimeMessage.Body = multipart;

            using (MailKit.Net.Smtp.SmtpClient smtpClient = new MailKit.Net.Smtp.SmtpClient())
            {
                smtpClient.Connect(
                    this.emailConfigurationViewModel.SmtpServer,
                    this.emailConfigurationViewModel.Port,
                    this.emailConfigurationViewModel.isSSL);

                smtpClient.Authenticate(
                    this.emailConfigurationViewModel.UserName,
                    this.emailConfigurationViewModel.Password);

                await smtpClient.SendAsync(mimeMessage);

                smtpClient.Disconnect(true);
            }

            return true;
        }

        /// <summary>
        /// this method get the emails which is comma seprated and create mailbox list.
        /// </summary>
        /// <param name="emails">list of emails which is seprated by seprator.</param>
        /// <param name="serpator">it could be either comma, semicolon.</param>
        /// <returns>list of mail boxes.</returns>
        private List<MailboxAddress> FactorEmailAddress(string emails, char serpator)
        {
            List<MailboxAddress> emailList = new List<MailboxAddress>();
            var emailsData = emails.Split(serpator, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < emailsData.Length; i++)
            {
                emailList.Add(new MailboxAddress(emailsData[i].Trim()));
            }

            return emailList;
        }

        /// <summary>
        /// Get All Attachments list.
        /// </summary>
        /// <param name="attachments">all attachments.</param>
        /// <returns>list of attachmnets.</returns>
        private List<MimePart> GetAttachments(List<string> attachments)
        {
            List<MimePart> allAttchmnets = new List<MimePart>();

            for (int i = 0; i < attachments.Count; i++)
            {
                if (File.Exists(attachments[i]))
                {
                    var attachment = new MimePart("image", Path.GetExtension(attachments[i]))
                    {
                        Content = new MimeContent(File.OpenRead(attachments[i]), ContentEncoding.Default),
                        ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                        ContentTransferEncoding = ContentEncoding.Base64,
                        FileName = Path.GetFileName(attachments[i]),
                    };

                    allAttchmnets.Add(attachment);
                }
            }

            return allAttchmnets;
        }
    }
}
