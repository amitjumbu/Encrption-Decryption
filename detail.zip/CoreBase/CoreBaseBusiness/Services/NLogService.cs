using NLog;
namespace CoreBaseBusiness.Services
{
    public static class NLogService
    {
        public static NLog.Logger CurrentInstance { get { return NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger(); } }
        public static void Shutdown()
        {
            NLog.LogManager.Shutdown();
        }
    }
}