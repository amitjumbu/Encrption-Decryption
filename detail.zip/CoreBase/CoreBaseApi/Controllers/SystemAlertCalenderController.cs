﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Models.Entity2;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class SystemAlertCalenderController : ControllerBase
    {
        private readonly ISystemAlertCalendarManager manager;

        public SystemAlertCalenderController(ISystemAlertCalendarManager alertManager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = alertManager;
        }

        /// <summary>
        /// this end point use to activate the alert scanning and sending notification to users.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] SystemAlertCalendarViewModel systemAlertCalenderView)
        {
            if (systemAlertCalenderView.ClientId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }
            else if (systemAlertCalenderView.CreateDateTimeBrowser == null || systemAlertCalenderView.CreateDateTimeBrowser < DateTime.Now.AddDays(-7))
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidCreatedDate, Constants.Errors.InvalidCreatedDate);
            }
            else if (systemAlertCalenderView.UserAlertId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidAlertID, Constants.Errors.InvalidAlertID);
            }
            else if (systemAlertCalenderView.EntityId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidEntityID, Constants.Errors.InvalidEntityID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            //string role = string.Empty;
            //if (role != string.Empty)
            //{
            //    throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            //}

            //systemAlertCalenderView.CreatedBy = base.CurrentUserEmail;
            var data = await this.manager.AddAsync(systemAlertCalenderView);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<SystemAlertCalendarViewModel>.SendResponse(systemAlertCalenderView)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
    }
}
