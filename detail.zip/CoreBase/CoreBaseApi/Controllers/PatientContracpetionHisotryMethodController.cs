﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class PatientContracpetionHisotryMethodController : ControllerBase
    {
        private readonly IPatientContracpetionHisotryMethodManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public PatientContracpetionHisotryMethodController(IPatientContracpetionHisotryMethodManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion
        
        #region List of records displayed
        // List of records displayed
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] PatientContracpetionHisotryMethodViewModel patientContracpetionHisotryMethodViewModel)
        {
            var Count = await this._Manager.CountAsync(patientContracpetionHisotryMethodViewModel);
            if (Count > 0)
            {
                IEnumerable<PatientContracpetionHisotryMethodViewModel> Data = await this._Manager.RangeAsync(Count, patientContracpetionHisotryMethodViewModel);
                return await Task.FromResult(Ok(UserResponse<PatientContracpetionHisotryMethodViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }
        #endregion

        #region Update the Record
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] PatientContracpetionHisotryMethodViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientContracpetionHisotryMethodViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }
        #endregion
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] PatientContracpetionHisotryMethodViewModel patientContracpetionHisotryMethodViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this._Manager.AddAsync(patientContracpetionHisotryMethodViewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<PatientContracpetionHisotryMethodViewModel>.SendResponse(patientContracpetionHisotryMethodViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }
    }
}