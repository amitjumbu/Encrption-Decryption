﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class LocationAverageShipFromMileMappingController : ControllerBase
    {
        private readonly ILocationAverageShipFromMileMappingManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public LocationAverageShipFromMileMappingController(ILocationAverageShipFromMileMappingManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        ///User can get Retrieves data from Candidate page wise.hi
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] LocationAverageShipFromMileMappingViewModel flagViewModel)
        {
            //var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<LocationAverageShipFromMileMappingViewModel> Data = await this._Manager.RangeAsyncMilesList(flagViewModel);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationAverageShipFromMileMappingViewModel>.SendResponse(Data.Count(), Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }


        /// <summary>
        ///User can get Retrieves data from Candidate page wise.hi
        /// </summary>
        [HttpPost("getDistance")]
        public async Task<ActionResult> GetDistance([FromBody] LocationAverageShipFromMileMappingViewModel flagViewModel)
        {
            //var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<LocationAverageShipFromMileMappingViewModel> Data = await this._Manager.GetDistanceAsync(flagViewModel);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationAverageShipFromMileMappingViewModel>.SendResponse(Data.Count(), Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }


        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] LocationAverageShipFromMileMappingViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            

            //viewModel.UpdatedBy = base.CurrentUserEmail;
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<LocationAverageShipFromMileMappingViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        /// <summary>
        ///User can get list by locatinId.
        /// </summary>
        [HttpGet(Constants.Identifire.GetByID + "/{id}")]
        public async Task<IActionResult> GetByID(int id)
        {
            IEnumerable<LocationAverageShipFromMileMappingViewModel> Data = await this._Manager.GetList(id);
            //this.instanceLogger.AddInstanseLogger("Get Preferred Material List By Id", Data);
            return await Task.FromResult(Ok(UserResponse<LocationAverageShipFromMileMappingViewModel>.SendResponse(1, Data)));
        }


        /// <summary>
        /// update candidate data flag wise.
        /// </summary>
        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] LocationAverageShipFromMileMappingViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //viewModel.UpdatedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<LocationAverageShipFromMileMappingViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }


        [HttpPost(Constants.Identifire.DeleteByID)]
        public async Task<ActionResult> DeleteAllAsync([FromBody] LocationAverageShipFromMileMappingViewModel viewModel)
        {
            var data = await this._Manager.DeleteAllAsync(viewModel).ConfigureAwait(false);
            //this.instanceLogger.AddInstanseLogger("Delete Preferred Material List", data);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        ///// <summary>
        /////delete candidate record behalf of id
        ///// </summary>
        //[HttpDelete(Constants.Identifire.Id)]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
        //    //var CurrentUserEmail = base.CurrentUserEmail;
        //    await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
        //    return await Task.FromResult(Ok(UserResponse<CommentViewModel>.SendResponse(Data))).ConfigureAwait(false);
        //}
    }
}