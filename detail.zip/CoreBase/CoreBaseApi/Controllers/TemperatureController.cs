﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class TemperatureController : ControllerBase
    {
        private readonly ITemperatureManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public TemperatureController(ITemperatureManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        ///User can get Retrieves data from Candidate page wise.hi
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] TemperatureViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<TemperatureViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<TemperatureViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
            
        }

        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] TemperatureViewModel viewModel)
        {
            if (viewModel is null)
            {
                throw new ArgumentNullException(nameof(viewModel));
            }

            if (viewModel.ClientId == 0 || viewModel.ClientId == null)
            {
                this.ModelState.AddModelError("ClientError", "Please send client id");
            }

            if (viewModel.PatientId == 0 || viewModel.PatientId == null)
            {
                this.ModelState.AddModelError("PatientError", "Please send patient id");
            }

            if (viewModel.PartographId == 0 || viewModel.PartographId == null)
            {
                this.ModelState.AddModelError("PartographError", "Please send Partograph id");
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            string role = string.Empty;
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            // viewModel.UpdatedBy = base.CurrentUserEmail;
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<TemperatureViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        /// update candidate data flag wise.
        /// </summary>
        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody]TemperatureViewModel viewModel)
        { 
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //viewModel.UpdatedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<TemperatureViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        ///delete candidate record behalf of id
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            //var CurrentUserEmail = base.CurrentUserEmail;
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<TemperatureViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }
    }
}