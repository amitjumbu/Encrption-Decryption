﻿namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;


    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class LocationController : ControllerBase
    {
        private readonly ILocationManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public LocationController(ILocationManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        /// <summary>
        ///User can get Retrieves data from Location by id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///Get All List for Location Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] LocationViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<LocationViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }


        [HttpPost("GetLocation")]
        public async Task<ActionResult> GetLocation([FromBody] LocationViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<LocationViewModel> Data = await this._Manager.LocationList(flagViewModel);
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }

        [HttpPost("GetLocationByLocationfunction")]
        public async Task<ActionResult> GetLocationByLocationfunction([FromBody] LocationViewModel flagViewModel)
        {
            IEnumerable<LocationViewModel> data = await this._Manager.GetLocationByLocationFunctionID(flagViewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<LocationViewModel>.SendResponse(0, data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetToFromLocation")]
        public async Task<ActionResult> GetToFromLocation([FromBody] LocationViewModel flagViewModel)
        {
            IEnumerable<LocationViewModel> Data = await this._Manager.GetToFromLocation(flagViewModel);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(Data.Count(), Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }



        [HttpPost(Constants.Identifire.ManufacturerList)]
        public async Task<ActionResult> GetManufacturerList([FromBody] LocationViewModel flagViewModel)
        {
            IEnumerable<LocationViewModel> data = await this._Manager.ManufacturerList(flagViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        ///User can get list by locatinId.
        /// </summary>
        [HttpGet(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID(int id)
        {
            IEnumerable<LocationViewModel> Data = await this._Manager.GetList(id);
            return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(1, Data)));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="flagViewModel"></param>
        /// <returns></returns>
        [HttpPost("locationlist")]
        public async Task<ActionResult> GetLocationList([FromBody] LocationViewModel[] flagViewModel)
        {
            IEnumerable<LocationViewModel> Data = await this._Manager.LocationList(flagViewModel);
            return await Task.FromResult(Ok(UserResponse<IEnumerable<LocationViewModel>>.SendResponse(Data)));
        }
        #region Post Hospital Records
        [HttpPost("PostHospital")]
        public async Task<ActionResult> Post([FromBody] LocationViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }
        #endregion

        #region Update Location data without setupComplete
        [HttpPost(Constants.Identifire.UpdateHospital)]
        public async Task<ActionResult> UpdateHospitalSetupWithoutSetupComplete([FromBody] LocationViewModel viewModel)
        {
            await this._Manager.UpdateLocationWithoutSetupCompleteAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(viewModel)));
        }
        #endregion


        #region Save All Hospital API
        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<LocationViewModel> viewModel)
        {
            IEnumerable<LocationViewModel> data = await this._Manager.SaveAll(viewModel);
            return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(data.Count(), data)));
        }
        #endregion
        #region Bind Hospital List for Hospital Setup
        [HttpPost(Constants.Identifire.GetAllHospital)]
        public async Task<ActionResult> GetHospitalList(LocationViewModel locationViewModel)
        {
            IEnumerable<LocationViewModel> data = await this._Manager.GetHospitalList(locationViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion
        #region Get All  Operating Location List
        [HttpPost(Constants.Identifire.GetAllOperatingLocationList)]
        public async Task<ActionResult> GetOperatingLocationList(OperatingLocationListViewModel locationViewModel)
        {
            IEnumerable<OperatingLocationListViewModel> data = await this._Manager.GetOperatingLocationList(locationViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<OperatingLocationListViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion
        #region Change Hospital Active/ Inactive Status
        [HttpPost(Constants.Identifire.ActiveAll)]
        public async Task<ActionResult> ActiveAll([FromBody] CollectHospialIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.ActivateHospitalStatus(allIds, collectHospialIDs.isActive);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion
        #region Get Records by sending multiple IDs
        [HttpPost("GetAllByID")]
        public async Task<IActionResult> GetAll([FromBody] CollectHospialIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            IEnumerable<LocationViewModel> data = await this._Manager.GetHospitalListByIDs(collectHospialIDs);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion
        #region delete Multiple Hospital from Hospital setup
        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] CollectHospialIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion


        /// <summary>
        /// Set Status for a list of Location.
        /// </summary>
        /// <param name="viewModels"> Evey Model should contain isActive , updatedBy, browserUpdatedTime </param>
        [HttpPost(Constants.Identifire.Status)]
        public async Task<ActionResult> UpdateStatus([FromBody] List<LocationViewModel> viewModels)
        {
            foreach (LocationViewModel item in viewModels)
            {
                if (item.ID < 1)
                {
                    this.ModelState.AddModelError(
                        Constants.Errors.InvalidID,
                        Constants.Errors.InvalidID);
                    break;
                }

                if (string.IsNullOrWhiteSpace(item.UpdatedBy))
                {
                    this.ModelState.AddModelError(
                        Constants.Errors.InvalidUpdatedBy,
                        Constants.Errors.InvalidUpdatedBy);
                    break;
                }

                if (item.UpdateDateTimeBrowser == null)
                {
                    this.ModelState.AddModelError(
                        Constants.Errors.GraterDate,
                        Constants.Errors.GraterDate);
                    break;
                }
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            bool data =
                await this._Manager.UpdateLocationStatus(viewModels);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
        }

        /// <summary>
        /// Get Sales Broker from Location table.
        /// </summary>
        /// <param name="viewModels"> For Paginated result model should  contain Pagination info like Pagezise, page number and all.</param>
        [HttpPost("SalesBroker")]
        public async Task<ActionResult> GetSalesBroker([FromBody] LocationViewModel viewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data =
                await this._Manager.GetSalesBroker(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<LocationViewModel>.SendResponse(0, null)));
            }

        }

        [HttpPost(Constants.Identifire.DeleteByID)]
        public async Task<ActionResult> DeleteLocations([FromBody] LocationDeleteModel deleteModel)
        {

            var response = await this._Manager.DeleteByIdsAsync(deleteModel.ids, deleteModel.deletedBy).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(response))).ConfigureAwait(false);
        }
        #region Get Location Characteristics
        [HttpPost("GetLocationCharacteristics")]
        public async Task<IActionResult> GetLocationCharacteristics([FromBody] EntityPropertyViewModel entityPropertyViewModel)
        {

            IEnumerable<EntityPropertyViewModel> data = await this._Manager.GetLocationCharacteristics(entityPropertyViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<EntityPropertyViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        #region Get Existing Characterstics From OperatingLocationPropertyDetail
        [HttpPost("GetExistingCharacteristics")]
        public async Task<IActionResult> GetExistingCharacteristics([FromBody] OperatingLocationPropertyDetailViewModel operatingLocationPropertyDetailView)
        {

            IEnumerable<OperatingLocationPropertyDetailViewModel> data = await this._Manager.GetExistingLocationCharacteristics(operatingLocationPropertyDetailView);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<OperatingLocationPropertyDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion

        #region Delete  Existing Characterstics for a location
        /// <summary>
        /// Delete  Existing Characterstics for a location.
        /// </summary>
        /// <param name="locationDeleteModel">Contains details of items to be deleted.</param>
        /// <returns>A success/Failure.</returns>
        [HttpPost("DeleteExistingCharacteristics")]
        public async Task<IActionResult> DeleteExistingCharacteristics([FromBody] LocationPropertyDeleteModel locationDeleteModel)
        {

            var data = await this._Manager.DeleteExistingCharacteristics(locationDeleteModel);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
        }
        #endregion


        [HttpPost("VerifyOrderLocationStatus")]
        public async Task<ActionResult> VerifyOrderLocationStatus([FromBody] VerifyOrderLocationViewModel verifyOrderLocationViewModel)
        {

            verifyOrderLocationViewModel = await this._Manager.VerifyOrderLocationStatus(verifyOrderLocationViewModel);
            return await Task.FromResult(Ok(UserResponse<VerifyOrderLocationViewModel>.SendResponse(verifyOrderLocationViewModel))).ConfigureAwait(false);
        }

        [HttpPost("GetBillingEntityForBP")]
        public async Task<ActionResult> GetBillingEntityForBP([FromBody] LocationViewModel flagViewModel)
        {
           
                IEnumerable<LocationForClaim> Data = await this._Manager.BillingEntityForBPlist(flagViewModel);
                return await Task.FromResult(Ok(UserResponse<LocationForClaim>.SendResponse(0, Data)));
            
        }

        [HttpPost("GetBillingEntityForCustomer")]
        public async Task<ActionResult> GetBillingEntityForCustomer([FromBody] LocationViewModel flagViewModel)
        {
              IEnumerable<LocationForClaim> Data = await this._Manager.BillingEntityForCustomerlist(flagViewModel);
                return await Task.FromResult(Ok(UserResponse<LocationForClaim>.SendResponse(0, Data)));
            
        }

    }
}