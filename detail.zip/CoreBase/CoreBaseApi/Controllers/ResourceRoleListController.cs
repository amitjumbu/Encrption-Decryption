﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData.Repository.Implementation;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ResourceRoleListController : ControllerBase
    {
        private readonly IResourceRoleListManager manager;


        public ResourceRoleListController(IResourceRoleListManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }
               

        
        /// <summary>
        /// Post Resource Role List
        /// </summary>
        /// <param name="resourceRoleListViewModel"></param>
        /// <returns></returns>
        [HttpPost("SaveResourceList")]
        public async Task<ActionResult> PostResourceList([FromBody] ResourceRoleListViewModel resourceRoleListViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.AddAsync(resourceRoleListViewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<ResourceRoleListViewModel>.SendResponse(resourceRoleListViewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }
    }
}
