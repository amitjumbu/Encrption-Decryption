﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft;
using Newtonsoft.Json.Linq;
using CoreBaseBusiness.ViewModel;
using CoreBaseBusiness.Helpers;
using CoreBaseData.Models.Entity;
using Newtonsoft.Json;




// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PateintDetailController : ControllerBase
    {

        private readonly IPatientValueManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IHostingEnvironment _hostingEnvironmentAdd;
        private readonly IHostingEnvironment _hostingEnvironmentCont;

        private readonly IPatientAddressValueManager _ManagerAdd;
        private readonly IPatientContactValueManager _ManagerCont;

        private readonly IMapper mapper;

        public ICollection<PatientAddress> PatientAddressList { get; set; }
        public ICollection<PatientContact> PatientContactList { get; set; }

        public PateintDetailController(  
                                         IPatientValueManager DIManager, IHostingEnvironment hostingEnvironment,
                                         IPatientAddressValueManager DIManagerAdd, IHostingEnvironment hostingEnvironmentAdd,
                                         IPatientContactValueManager DIManagerCont, IHostingEnvironment hostingEnvironmentCont
                                      )
        {
            this._Manager = DIManager;          _hostingEnvironment = hostingEnvironment;
            this._ManagerAdd = DIManagerAdd;    _hostingEnvironmentAdd = hostingEnvironment;
            this._ManagerCont = DIManagerCont;  _hostingEnvironmentCont = hostingEnvironment;
        }

        // GET: api/<PateintDetailController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            JObject jobj = new JObject();
            return new string[] { "value1", "value2" };
        }

        /// <summary>
        ///add data data into Patient PatientAddress & PatientContact.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> patientDetailPost([FromBody] PatientDetailModelValueViewModel viewModel)
        {
            JObject inputModelAddress = new JObject();
            JObject inputModelContact = new JObject();
            PatientValueViewModel objPatient = new PatientValueViewModel();
            objPatient = viewModel.PatientsDM;
            var data = await this._Manager.AddAsync(objPatient);
            if (objPatient.ID > 0)
            {
                //Insert Patient Address
                foreach (var PAddModel in viewModel.PatientsAddressDM)
                {
                    PatientAddressValueViewModel objPatientAddress = new PatientAddressValueViewModel();
                    dynamic Padrs = PAddModel;
                    objPatientAddress = Padrs;
                    objPatientAddress.PatientID = objPatient.ID;
                    objPatientAddress.UpdateDateTimeServer = DateTime.UtcNow;
                    objPatientAddress.CreateDateTimeServer = DateTime.UtcNow;
                    var addData = await this._ManagerAdd.AddAsync(objPatientAddress);
                }
                //Insert Patient Contact
                foreach (var PContModel in viewModel.PatientsContactDM)
                {
                    PatientContactValueViewModel objPatientContact = new PatientContactValueViewModel();
                    dynamic Pcontact = PContModel;
                    objPatientContact = Pcontact;
                    objPatientContact.PatientID = objPatient.ID;
                    objPatientContact.CreateDateTimeServer = DateTime.UtcNow;
                    objPatientContact.UpdateDateTimeServer = DateTime.UtcNow;
                    var ContData = await this._ManagerCont.AddAsync(objPatientContact);
                }
            }
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
        }

        /// <summary>
        /// Update add data .
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> patientDetailPut([FromBody] PatientDetailModelValueViewModel viewModel)
        {
            JObject inputModelAddress = new JObject();
            JObject inputModelContact = new JObject();
            PatientValueViewModel objPatient = new PatientValueViewModel();
            objPatient = viewModel.PatientsDM;
            if (objPatient.ID > 0)
            {
                await this._Manager.UpdateAsync(objPatient).ConfigureAwait(false);

                //Update Patient Address
                foreach (var PAddModel in viewModel.PatientsAddressDM)
                {
                    PatientAddressValueViewModel objPatientAddress = new PatientAddressValueViewModel();
                    dynamic Padrs = PAddModel;
                    objPatientAddress = Padrs;
                    objPatientAddress.PatientID = objPatient.ID;
                    objPatientAddress.UpdateDateTimeServer = DateTime.UtcNow;
                    objPatientAddress.CreateDateTimeServer = DateTime.UtcNow;
                    await this._ManagerAdd.UpdateAsync(objPatientAddress);
                }
                //Update Patient Contact
                foreach (var PContModel in viewModel.PatientsContactDM)
                {
                    PatientContactValueViewModel objPatientContact = new PatientContactValueViewModel();
                    dynamic Pcontact = PContModel;
                    objPatientContact = Pcontact;
                    objPatientContact.PatientID = objPatient.ID;
                    objPatientContact.CreateDateTimeServer = DateTime.UtcNow;
                    objPatientContact.UpdateDateTimeServer = DateTime.UtcNow;
                    await this._ManagerCont.UpdateAsync(objPatientContact);
                }
            }
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
        }



    }
}
