﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Managers;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore.Query;
    using Microsoft.Extensions.Options;
    using NPOI.SS.Formula.Functions;
    using Org.BouncyCastle.Math.EC.Rfc7748;

    /// <summary>
    /// Order Calculation Controller Developed By Kapil Pandey.
    /// On : 17-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class OrderCalculationController : ControllerBase
    {
        private readonly IOrderCalculationManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrderCalculationController"/> class.
        /// </summary>
        /// <param name="manager">OrderCalculation Manager with the help of DI.</param>
        /// <param name="salesOrderManager">SalesOrder Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public OrderCalculationController(IOrderCalculationManager manager)
        {
            this.manager = manager;

        }

        /// <summary>
        /// this end point return all the list of sales manager, which are belonging to perticular location.
        /// </summary>
        /// <param name="locationwiseUsers">view model contains locationid.</param>
        /// <returns>return the list of salesmanager.</returns>
        [HttpPost(Constants.Identifire.GetSalesManager)]
        public async Task<ActionResult> GetSalesManager([FromBody] LocationwiseUsersViewModel locationwiseUsers)
        {
            if (locationwiseUsers.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (locationwiseUsers.LocationID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidShippingTo);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.GetUsersList(locationwiseUsers.LocationID, Constants.ModelEntityCodeValue.Roles.SalesManager, Constants.ModelEntityCodeValue.LocationType.Customer);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<RoleUsersViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        /// <summary>
        /// this end point get order details of on perticular id basis.
        /// </summary>
        /// <param name="orderRequestViewModel">view model contain order id and ordertypeid.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetDetail)]
        public async Task<ActionResult> GetDetail([FromBody] OrderRequestViewModel orderRequestViewModel)
        {
            if (orderRequestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (orderRequestViewModel.OrderID == 0)
            {
                OrderDetailViewModel orderRequestViewModel1 = new OrderDetailViewModel();
                return await Task.FromResult(this.Ok(UserResponse<OrderDetailViewModel>.SendResponse(orderRequestViewModel1)));

            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.GetOrderDetails(orderRequestViewModel.OrderID, orderRequestViewModel.OrderTypeID);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<OrderDetailViewModel>.SendResponse(data)));
            }
            else
            {
                var emptyOrderDetailViewModel = new OrderDetailViewModel();
                return await Task.FromResult(this.Ok(UserResponse<OrderDetailViewModel>.SendResponse(emptyOrderDetailViewModel)));
            }
        }

        /// <summary>
        /// this end point get order details of on perticular id basis.
        /// </summary>
        /// <param name="requestViewModel">view model contain order id and ordertypeid.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetPriceMethodByMaterialAndCharge)]
        public async Task<ActionResult> GetPriceMethodByMaterialAndCharge([FromBody] RequestDataPriceMethodAndComputationMethod requestViewModel)
        {
            if (requestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (requestViewModel.MaterialID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidMaterial, Constants.Errors.InvalidMaterial);
            }

            if (requestViewModel.ChargeID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidCharge, Constants.Errors.InvalidCharge);
            }

            if (requestViewModel.ShipTOLocationID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidShippingTo);
            }

            if (requestViewModel.ContractID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidContract, Constants.Errors.InvalidContract);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            requestViewModel.Type = 1;

            var data = this.manager.GetPriceMethodDataOnElementAndChargeID(requestViewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<List<PriceMethodViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        /// <summary>
        /// this end point get order details of on perticular id basis.
        /// </summary>
        /// <param name="requestViewModel">view model contain order id and ordertypeid.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetComputationMehtodByMaterialAndCharge)]
        public async Task<ActionResult> GetComputationMehtodByMaterialAndCharge([FromBody] RequestDataPriceMethodAndComputationMethod requestViewModel)
        {
            if (requestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (requestViewModel.MaterialID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidMaterial, Constants.Errors.InvalidMaterial);
            }

            if (requestViewModel.ChargeID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidCharge, Constants.Errors.InvalidCharge);
            }

            if (requestViewModel.ShipTOLocationID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidShippingTo);
            }

            if (requestViewModel.ContractID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidContract, Constants.Errors.InvalidContract);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            requestViewModel.Type = 0;

            var data = this.manager.GetComputationMethodDataOnElementAndChargeID(requestViewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<List<ComputationMethodViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        /// <summary>
        /// this end point implement for according document Tosca Order Requirement V2 point 83 - PriceMethod create get API.
        /// </summary>
        /// <param name="requestViewModel">view model contain order id and ordertypeid.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetPriceMethodResult)]
        public async Task<ActionResult> GetPriceMethodResult([FromBody] RequestCommonViewModel requestViewModel)
        {
            if (requestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (requestViewModel.ChargeID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidCharge, Constants.Errors.InvalidCharge);
            }

            if (requestViewModel.ShipToLocationID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidShippingTo);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.GetPriceMethodList(requestViewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<List<PriceMethodViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }



        /// <summary>
        /// this service end point will return the tabls of Charges list for adjust charges table.
        /// </summary>
        /// <param name="requestViewModel">view model contain order id and ordertypeid.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetAdjustChargesDefaultData)]
        public async Task<ActionResult> GetAdjustChargesDefaultData([FromBody] RequestCommonViewModel requestViewModel)
        {
            if (requestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.GetDefaultAjustCharges(requestViewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<ResponseAdjustChargesWithDefaultData>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        /// <summary>
        /// this service end point return the avaiable credit of selected location.
        /// </summary>
        /// <param name="requestViewModel">view model contain Requested date and Location ID.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetAvailableCredit)]
        public async Task<ActionResult> GetAvailableCredit([FromBody] AvailableCreaditViewModel requestViewModel)
        {
            if (requestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.GetAvailableCredit(requestViewModel);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));

        }

        /// <summary>
        /// this service end point return the fuel charges of perticular location.
        /// </summary>
        /// <param name="requestViewModel">view model contain Requested date and Location ID.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.GetFuelCharges)]
        public async Task<ActionResult> GetFuelCharges([FromBody] AvailableCreaditViewModel requestViewModel)
        {
            if (requestViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.GetFuelCharges(requestViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<FuelChargesViewModel>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<FuelChargesViewModel>.SendResponse(new FuelChargesViewModel())));
            }

        }

        /// <summary>
        /// this service end point return the fuel charges of perticular location.
        /// </summary>
        /// <param name="requestViewModel">view model contain Requested date and Location ID.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.ValidateMaterialInOrder)]
        public async Task<ActionResult> ValidateMaterialInOrder([FromBody] MaterialEquipmentValidation requestViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this.manager.ValidateMaterialWithEquipment(requestViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<ValidationResponse>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<FuelChargesViewModel>.SendResponse(new FuelChargesViewModel())));
            }

        }


        /// <summary>
        /// this service end point return the fuel charges of perticular location.
        /// </summary>
        /// <param name="requestViewModel">view model contain Requested date and Location ID.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.CalculateCharges)]
        public async Task<ActionResult> CalculateCharges([FromBody] CalculateOrderCharges requestViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            requestViewModel = await this.manager.CalculateOrderChargesOnLatestContractAsync(requestViewModel);

            if (requestViewModel != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<CalculateOrderCharges>.SendResponse(requestViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }

        }


        /// <summary>
        /// this service end point return the fuel charges of perticular location.
        /// </summary>
        /// <param name="requestViewModel">view model contain Requested date and Location ID.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.AmountCalculator)]
        public async Task<ActionResult> AmountCalculator([FromBody] RateValueCalculator requestViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            requestViewModel.Amount = this.manager.CalculateCoreCharges(requestViewModel.Quantity, requestViewModel.RateType, requestViewModel.RateValue);

            if (requestViewModel != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<RateValueCalculator>.SendResponse(requestViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }

        }

        /// <summary>
        /// this end point validate order core data.
        /// </summary>
        /// <param name="flagViewModel">view model contain Requested date and Location ID.</param>
        /// <returns>Detail of order.</returns>
        [HttpPost(Constants.Identifire.ValidateOrderCoreInputs)]
        public async Task<ActionResult> ValidateOrderCoreInputs([FromBody] AllSalesOrderViewModel flagViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            RegularOrderValidationResponse regularOrderValidationResponse = new RegularOrderValidationResponse();
            regularOrderValidationResponse.validationResponse = new ValidationResponse() { IsValid = true, Message = string.Empty , IsConfirmation = false };

            if (flagViewModel.salesorder.EquipmentTypeId.HasValue && flagViewModel.salesorder.EquipmentTypeId > 0 && flagViewModel.MaterialsList != null && flagViewModel.MaterialsList.Count > 0)
            {
                // this section check weather all matreials are having valid properties or not
                var materialsList = flagViewModel.MaterialsList.Select(p => p.MaterialID.ToString()).ToList();
                var allMaterials = string.Join(',', materialsList.ToArray());
                RequestObjectMaterialProperties requestObjectMaterialProperties = new RequestObjectMaterialProperties()
                {
                    materialID = allMaterials,
                    equipmentTypeID = flagViewModel.salesorder.EquipmentTypeId.Value,
                };

                var result = await this.manager.GetVerifyEquipmentForMultipleMaterialPropertyOrder(requestObjectMaterialProperties);
                if (result != null && result.Count > 0)
                {
                    regularOrderValidationResponse.editVerifyEquipmentMaterialProperties = result;
                    regularOrderValidationResponse.validationResponse.IsValid = false;
                    regularOrderValidationResponse.validationResponse.Message = Constants.OrderManagementValidationMessage.Materialpropertymissing;
                }
            }

            if (regularOrderValidationResponse.validationResponse.IsValid)
            {// this section validate the inputed data
                var validationResult = this.manager.ValidateOrderCoreInputs(flagViewModel);


                regularOrderValidationResponse.validationResponse = validationResult;
            }

            if (regularOrderValidationResponse.validationResponse != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<RegularOrderValidationResponse>.SendResponse(regularOrderValidationResponse)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        [HttpPost(Constants.Identifire.SaveBulkMaterialProperties)]
        public async Task<ActionResult> SaveBulkMaterialProperties([FromBody] RequestObjectMaterialPropertiesGrid flagViewModel)
        {
            if (flagViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (string.IsNullOrEmpty(flagViewModel.UserName))
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidName, Constants.Errors.InvalidName);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.ModifyEquipmentMaterialPropertyDetails(flagViewModel.materialPropertiesGrids, flagViewModel.ClientID, flagViewModel.UserName);


            if (finalResult)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        [HttpPost(Constants.Identifire.CalculateChargesForAdjustmnetGrid)]
        public async Task<ActionResult> CalculateChargesForAdjustmnetGrid([FromBody] RequestObjectChargeFormulaeCalculation flagViewModel)
        {
            var finalResult = this.manager.CalculateChargesForRegularScreen(flagViewModel);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));

        }

        [HttpPost(Constants.Identifire.ValidateMaterialsInputs)]
        public async Task<ActionResult> ValidateMaterialsInputs([FromBody] ShipmentMaterialViewModel flagViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            RegularOrderValidationResponse regularOrderValidationResponse = new RegularOrderValidationResponse();
            regularOrderValidationResponse.validationResponse = new ValidationResponse() { IsValid = true, Message = string.Empty };

            if (flagViewModel.EquipmentTypeId != 0 && flagViewModel.MaterialsList.Count > 0)
            {
                // this section check weather all matreials are having valid properties or not
                var materialsList = flagViewModel.MaterialsList.Select(p => p.Id.ToString()).ToList();
                var allMaterials = string.Join(',', materialsList.ToArray());
                RequestObjectMaterialProperties requestObjectMaterialProperties = new RequestObjectMaterialProperties()
                {
                    materialID = allMaterials,
                    equipmentTypeID = flagViewModel.EquipmentTypeId,
                };

                var result = await this.manager.GetVerifyEquipmentForMultipleMaterialPropertyOrder(requestObjectMaterialProperties);
                if (result != null && result.Count > 0)
                {
                    regularOrderValidationResponse.editVerifyEquipmentMaterialProperties = result;
                    regularOrderValidationResponse.validationResponse.IsValid = false;
                    regularOrderValidationResponse.validationResponse.Message = Constants.OrderManagementValidationMessage.Materialpropertymissing;

                }
            }
            if (regularOrderValidationResponse.validationResponse != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<RegularOrderValidationResponse>.SendResponse(regularOrderValidationResponse)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

    }
}
