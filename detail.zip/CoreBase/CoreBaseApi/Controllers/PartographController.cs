﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Managers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft;
using Newtonsoft.Json.Linq;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class PartographController : ControllerBase
    {
        
        private readonly IPartographManager PartographManager;
       
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public PartographController(IPartographManager partographManager, IHostingEnvironment hostingEnvironment)
        {
            this.PartographManager = partographManager;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] PartographViewModel partographViewModel)
        {
            //if (!this.ModelState.IsValid)
            //{
            //    return this.BadRequest(this.ModelState);
            //}
            var data = await this.PartographManager.AddAsync(partographViewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<PartographViewModel>.SendResponse(partographViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        [HttpPost("PartographList")]
        public async Task<ActionResult> PartographList([FromBody] PartographViewModel partographViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            IEnumerable<object> goldenMaster = await this.PartographManager.GetAllPatientList(0, partographViewModel);

            if (goldenMaster != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<object>>.SendResponse(goldenMaster)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] PartographViewModel partographViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            IEnumerable<PartographViewModel> goldenMaster = await this.PartographManager.RangeAsync(0,partographViewModel);
         
            if (goldenMaster!=null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<PartographViewModel>>.SendResponse(goldenMaster)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        //[HttpPost]
        //public async Task<IActionResult> Update([FromBody] PartographViewModel partographViewModel)
        //{

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }
        //    var result = await this.PartographManager.UpdateAsync(partographViewModel);
        //    if (result)
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<PartographViewModel>.SendResponse(partographViewModel)));
        //    }
        //    else
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
        //    }
        //}


        //[HttpPost]
        //public async Task<IActionResult> GetAll([FromBody] PartographViewModel partographViewModel)
        //{

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }

        //    var totalRecordCount = await this.PartographManager.CountAsync(partographViewModel);
        //    var result = await this.PartographManager.RangeAsync(totalRecordCount, partographViewModel);

        //    return await Task.FromResult(this.Ok(UserResponse<PartographViewModel>.SendResponse(totalRecordCount,result)));

        //}


        //[HttpPost]
        //public async Task<IActionResult> GetByID([FromBody] EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket)
        //{

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }
        //    var result = await this.PartographManager.GetAsync(entityRecordRemoveRequestPacket.ID);

        //    return await Task.FromResult(this.Ok(UserResponse<PartographViewModel>.SendResponse(result)));

        //}


        //[HttpPost]
        //public async Task<IActionResult> Delete([FromBody] EntityRecordRemoveRequestPacketForSmallID entityRecordRemoveRequestPacket)
        //{

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }
        //    var result = await this.PartographManager.Delete(entityRecordRemoveRequestPacket);
        //    if (result)
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));
        //    }
        //    else
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        //    }
        //}



    }
}