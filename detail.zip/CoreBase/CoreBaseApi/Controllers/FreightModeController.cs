﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FreightModeController : ControllerBase
    {
        private readonly IFreightModeManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public FreightModeController(IFreightModeManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }
        /// <summary>
        /// Count number of Records 
        /// </summary>
        /// <param name="flagViewModel"></param>
        /// <returns></returns>

        [HttpPost("Count")]
        public async Task<ActionResult> Count([FromBody] FreightModeViewModel flagViewModel)
        {
            var count = await this._Manager.CountAsync(flagViewModel);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count)));
        }

        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] FreightModeViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<FreightModeViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
            return await Task.FromResult(Ok(UserResponse<FreightModeViewModel>.SendResponse(Data.Count(), Data)));
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] FreightModeViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<FreightModeViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<FreightModeViewModel> viewModel)
        {
            
            IEnumerable<FreightModeViewModel> data = await this._Manager.SaveAll(viewModel);
            return await Task.FromResult(Ok(UserResponse<FreightModeViewModel>.SendResponse(data.Count(), data)));
        }

        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FreightModeViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.UpdateAll)]
        public async Task<IActionResult> UpdateAll(IEnumerable<FreightModeViewModel> viewModel)
        {
            var data = await this._Manager.UpdateAll(viewModel).ConfigureAwait(false);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] FreightModeViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FreightModeViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] FreightModeDelete freightdelete)
        {
            var allIds = freightdelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(freightdelete.IDs, freightdelete.DeletedBy);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        [HttpPut(Constants.Identifire.EditFreigtmodes)]
        public async Task<IActionResult> EditfmsByIDs(string ids)
        {
            var data = await this._Manager.GetEditfmsAsync(ids).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<IEnumerable<FreightModeViewModel>>.SendResponse(data))).ConfigureAwait(false);
        }


        /// <summary>
        ///User can  Retrieves data from FreightMode by equipment.
        /// </summary>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<ActionResult> GetFreightMode([FromBody] MaterialCommonModel flagViewModel)
        {
            IEnumerable<FreightModeViewModel> Data = await this._Manager.GetFreightMode(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FreightModeViewModel>.SendResponse(0, Data))).ConfigureAwait(false);
        }

        #region Get Freight mode list with sorting,filtering and paggination
        [HttpPost("GetAllRecords")]
        public async Task<IActionResult> GetAllRecords([FromBody] FreightModeViewModel requestCommonViewModel)
        {
            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<FreightModeViewModel> data = await this._Manager.GetFreightModeList(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<FreightModeViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
    }
}
