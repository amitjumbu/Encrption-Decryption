﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class FreightModeEquipTypeMapController : ControllerBase
    {
        private readonly IFreightModeEquipTypeMapManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommodityController"/> class.
        /// </summary>
        /// <param name="manager">Commodity Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public FreightModeEquipTypeMapController(IFreightModeEquipTypeMapManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }


        //[HttpPost]
        //public async Task<ActionResult> Post([FromBody] FreightModeEquipMapViewModel viewModel)
        //{

        //    if (viewModel.FreightModeID == null || viewModel.EquipmentTypeID == null)
        //    {
        //        this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
        //    }
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }


        //    var data = await this.manager.AddAsync(viewModel);
        //    if (data == true)
        //    {
        //        return await Task.FromResult(Ok(UserResponse<FreightModeEquipMapViewModel>.SendResponse(viewModel)));
        //    }
        //    else
        //    {
        //        return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
        //    }
        //}

        //[HttpPost(Constants.Identifire.SaveAll)]
        //public async Task<IActionResult> SaveAll(IEnumerable<FreightModeEquipMapViewModel> viewModel)
        //{
        //    var data = await this.manager.SaveAll(viewModel).ConfigureAwait(false);

        //    return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        //}
        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<FreightModeEquipMapViewModel> viewModel)
        {

            IEnumerable<FreightModeEquipMapViewModel> data = await this.manager.SaveAll(viewModel);
            return await Task.FromResult(Ok(UserResponse<FreightModeEquipMapViewModel>.SendResponse(data.Count(), data)));
        }
        //[HttpPost(Constants.Identifire.UpdateAll)]
        //public async Task<IActionResult> UpdateAll(IEnumerable<FreightModeEquipMapViewModel> viewModel)
        //{
        //    var data = await this.manager.UpdateAll(viewModel).ConfigureAwait(false);

        //    return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        //}

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] FreightModeEquipMapDelete freightModeEquipMapdelete)
        {
            var allIds = freightModeEquipMapdelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        //[HttpPost(Constants.Identifire.List)]
        //public async Task<ActionResult> List([FromBody] FreightModeEquipMapViewModel freightModeEquipMapViewModel)
        //{
        //    var Count = await this.manager.CountAsync(freightModeEquipMapViewModel);
        //    if (Count > 0)
        //    {
        //        IEnumerable<FreightModeEquipMapViewModel> Data = await this.manager.RangeAsync(Count, freightModeEquipMapViewModel);
        //        return await Task.FromResult(Ok(UserResponse<FreightModeEquipMapViewModel>.SendResponse(Count, Data)));
        //    }

        //    else
        //    {
        //        return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
        //    }
        //}
        [HttpPost(Constants.Identifire.GetFreightModeEquipMapList)]
        public async Task<ActionResult> GetFreightModeEquipMapList(long FreightModeID)
        {

            if (FreightModeID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }


            var data = this.manager.GetFreightModeEquipMapList(FreightModeID);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<FreightModeEquipMapViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        [HttpPost(Constants.Identifire.GetFreightModeEquipmentMapingList)]
        public async Task<ActionResult> GetFreightModeEquipmentMapingList([FromBody] FreightModeEquipmentMapViewModel freightModeEquipMapViewModel)
        {

            if (freightModeEquipMapViewModel.FreightModeID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            IEnumerable<FreightModeEquipmentMapViewModel> data = await this.manager.GetFreightModeEquipmentMapingList(freightModeEquipMapViewModel);
            if (data != null && data.Any())
            {
                return await Task.FromResult(Ok(UserResponse<FreightModeEquipmentMapViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
        #region Count Total records
        [HttpPost("GetCountFreightModeEquipmentMap")]
        public async Task<IActionResult> GetCountFreightModeEquipmentMap([FromBody] FreightModeEquipMapViewModel freightModeEquipMapViewModel)
        {
            if (freightModeEquipMapViewModel.ClientId == null || freightModeEquipMapViewModel.ClientId <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetCount(freightModeEquipMapViewModel);

            if (finalResult != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }
        #endregion

    }
}
