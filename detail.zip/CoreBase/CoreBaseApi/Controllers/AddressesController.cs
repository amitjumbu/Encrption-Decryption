﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AddressesController : ControllerBase
    {
        private readonly IPatientAddressValueManager _ManagerPAdd;
        private readonly IOperatingLocationAddressManager _ManagerAddLoc;

        public AddressesController(
                                     IHostingEnvironment hostingEnvironment, IPatientAddressValueManager DIManagerPAdd,
                                     IOperatingLocationAddressManager DIManagerLAdd
                                  )
        {
            this._ManagerPAdd = DIManagerPAdd;
            this._ManagerAddLoc = DIManagerLAdd;
        }

        /// <summary>
        ///add data data in Address.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> AddAddress([FromBody] PatientDetailModelValueViewModel viewModel)
        {
            dynamic resultData = null;
            if (viewModel.PatientsAddressDM != null)
            {
                //Insert Patient Address
                foreach (var PAddModel in viewModel.PatientsAddressDM)
                {
                    PatientAddressValueViewModel objPatientAddress = new PatientAddressValueViewModel();
                    dynamic Padrs = PAddModel;
                    objPatientAddress = Padrs;
                    objPatientAddress.UpdateDateTimeServer = DateTime.UtcNow;
                    objPatientAddress.CreateDateTimeServer = DateTime.UtcNow;
                    var addData = await this._ManagerPAdd.AddAsync(objPatientAddress);
                    resultData = addData;
                }
            }
            else if (viewModel.LocationAddressDM != null)
            {
                //Insert Location Address
                foreach (var LAddModel in viewModel.LocationAddressDM)
                {
                    OperatingLocationAddressViewModel objLocationAddress = new OperatingLocationAddressViewModel();
                    dynamic Padrs = LAddModel;
                    objLocationAddress = Padrs;
                    objLocationAddress.UpdateDateTimeServer = DateTime.UtcNow;
                    objLocationAddress.CreateDateTimeServer = DateTime.UtcNow;
                    var addData = await this._ManagerAddLoc.AddAsync(objLocationAddress);
                    resultData = addData;
                }
            }
            if (resultData == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientDetailModelValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }


        /// <summary>
        ///add data data into Patient PatientAddress & PatientContact.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> updateAddress([FromBody] PatientDetailModelValueViewModel viewModel)
        {
            dynamic resultData = null;
            if (viewModel.PatientsAddressDM != null)
            {
                //Update Patient Address
                foreach (var PAddModel in viewModel.PatientsAddressDM)
                {
                    PatientAddressValueViewModel objPatientAddress = new PatientAddressValueViewModel();
                    dynamic Padrs = PAddModel;
                    objPatientAddress = Padrs;
                    objPatientAddress.UpdateDateTimeServer = DateTime.UtcNow;
                    objPatientAddress.CreateDateTimeServer = DateTime.UtcNow;
                    var addData = await this._ManagerPAdd.UpdateAsync(objPatientAddress);
                    resultData = addData;
                }
            }
            else if (viewModel.LocationAddressDM != null)
            {
                //Update Location Address
                foreach (var LAddModel in viewModel.LocationAddressDM)
                {
                    OperatingLocationAddressViewModel objLocationAddress = new OperatingLocationAddressViewModel();
                    dynamic Padrs = LAddModel;
                    objLocationAddress = Padrs;
                    objLocationAddress.UpdateDateTimeServer = DateTime.UtcNow;
                    objLocationAddress.CreateDateTimeServer = DateTime.UtcNow;
                    var addData = await this._ManagerAddLoc.UpdateAsync(objLocationAddress);
                    resultData = addData;
                }
            }
            if (resultData == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientDetailModelValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }

    }

}
