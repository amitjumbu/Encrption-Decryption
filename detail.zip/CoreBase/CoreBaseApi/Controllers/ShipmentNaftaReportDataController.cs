﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShipmentNaftaReportDataController : ControllerBase
    {
        private readonly IShipmentNaftaReportDataManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;
       
        public ShipmentNaftaReportDataController(IShipmentNaftaReportDataManager DIManager, IHostingEnvironment hostingEnvironment)
        
        {
            this._Manager = DIManager;

            this._hostingEnvironment = hostingEnvironment;

        }

        /// <summary>
        ///User can get Retrieves data from Candidate page wise.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<ShipmentNaftaReportDataViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }

        
        [HttpPost(Constants.Identifire.GetShipmentNaftaReportData)]
        public async Task<ActionResult> GetShipmentNAFTAReportdata([FromBody] ShipmentNaftaReportDataViewModel ViewModel)
        {

            IEnumerable<ShipmentNaftaReportDataViewModel> data = await this._Manager.GetAllShipmentNaftaReportData(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ShipmentNaftaReportDataViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #region Get NetCost Value
        [HttpPost(Constants.Identifire.GetNetCostData)]
        public async Task<ActionResult> GetNetCostData([FromBody] NetCostViewModel ViewModel)
        {

            IEnumerable<NetCostViewModel> data = await this._Manager.GeAllNetCostData(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<NetCostViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
      
        #endregion
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<ShipmentNaftaReportDataViewModel> data = await this._Manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ShipmentNaftaReportDataViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
       

            [HttpPost]
        public async Task<ActionResult> Post([FromBody] ShipmentNaftaReportDataViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            // var data = await this._Manager.AddData(viewModel);
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<ShipmentNaftaReportDataViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        /// update candidate data flag wise.
        /// </summary>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] ShipmentNaftaReportDataViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //viewModel.ModifiedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<ShipmentNaftaReportDataViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] ShipmentNaftaReportDataDelete viewModelDelete)
        {
            var allIds = viewModelDelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        [HttpPost(Constants.Identifire.AutherizedSignature), DisableRequestSizeLimit]
       
        public ObjectResult UploadFile()
        {
            try
            {
                var file = Request.Form.Files[0];
                string folderName = "Upload";
                string webRootPath = _hostingEnvironment.WebRootPath;
                string newPath = Path.Combine(webRootPath, folderName);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                string fileName = "";
                if (file.Length > 0)
                {
                    fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    string fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }

                return Ok(fileName);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        /// <summary>
        /// Get Nafta Report By Shipping Id
        /// </summary>
        [HttpGet("GetNaftaReportById/{shipmentId}")]
        public async Task<IActionResult> GetNaftaReportById(long shipmentId)
        {
            if (shipmentId == 0)
            {
                return BadRequest("Invalid shipping id.");
            }
            var data = await this._Manager.GetNaftaReportById(shipmentId).ConfigureAwait(false);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, data))).ConfigureAwait(false);
            }
            
        }
    }
    //[HttpPost(Constants.Identifire.AutherizedSignature)]
    //public async Task<ActionResult> Upload([FromBody] IFormFile file)
    //{
    //    var uploads = Path.Combine("D://Source//ADecTec2015//Lamps//DEV//Source//MicroServicesWebAPI//CoreBase//CoreBaseApi//Models", "uploads");
    //    if (!Directory.Exists(uploads))
    //    {
    //        Directory.CreateDirectory(uploads);
    //    }
    //    if (file.Length > 0)
    //    {
    //        var filePath = Path.Combine(uploads, file.FileName);
    //        using (var fileStream = new FileStream(filePath, FileMode.Create))
    //        {
    //            await file.CopyToAsync(fileStream);
    //        }
    //    }
    //    return Ok();
    //}
    //public async Task<ActionResult> UploadFiles([FromBody] ShipmentNaftaReportDataViewModel ViewModel)
    //{
    //    var data = await this._Manager.UploadFilesAsync(ViewModel);
    //    return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
    //    //return await _Manager.UploadFilesAsync(files);
    //}

   
}
