﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ForecastController : ControllerBase
    {
        private readonly IForecastManager manager;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public ForecastController(
            IForecastManager DIManager, 
            IHostingEnvironment hostingEnvironment, 
            IInstanseLogger instanceLogger)
        {
            this.manager = DIManager;
            this.instanceLogger = instanceLogger;
        }

        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> GetForecastDetailList([FromBody] ForecastViewModel viewModel)
        {
            if (viewModel == null)
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidRequest,
                       Constants.Errors.InvalidRequest);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.ListAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data != null ? data.Count() : 0, data))).ConfigureAwait(false);
        }
        [HttpPost]
        public async Task<ActionResult> AddForecast([FromBody] ForecastViewModel viewModel)
        {
            if (viewModel == null
                || string.IsNullOrEmpty(viewModel.Name)
                || string.IsNullOrEmpty(viewModel.Description))
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidRequest,
                       Constants.Errors.InvalidRequest);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var duplicateExists = await this.manager.DuplicateExists(viewModel);
            if (duplicateExists)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(
                            "A forecast with this name already exists. Please provide another name.",
                            HttpStatusCode.BadRequest)))
                    .ConfigureAwait(false);
            }
            var data = await this.manager.AddForecast(viewModel).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Added Forecast : ", viewModel);
            if (data)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(
                                "Forecast creation failed. Please contact Tech Support.",
                                HttpStatusCode.BadRequest)))
                    .ConfigureAwait(false);

            }
        }

        [HttpGet("GetDynamicColumnById")]
        public async Task<ActionResult> GetDynamicColumnById(long id)
        {
            if (id == 0)
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidID,
                       Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetDynamicColumnById(id).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data != null ? data.Count : 0, data))).ConfigureAwait(false);
        }


        [HttpPost("GetForecastDetailById")]
        public async Task<ActionResult> GetForecastDetailById([FromBody] ForecastViewModel viewModel)
        {
            if (viewModel == null || viewModel.ID == 0)
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidID,
                       Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetForecastDetailById(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data != null ? data.Count() : 0, data))).ConfigureAwait(false);
        }

        [HttpPost("GetChildForecastDetailById")]
        public async Task<ActionResult> GetChildForecastDetailById([FromBody] ForecastViewModel viewModel)
        {
            if (viewModel == null || viewModel.ID == 0)
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidID,
                       Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetChildForecastDetailById(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data != null ? data.Count() : 0, data))).ConfigureAwait(false);
        }

        [HttpPost("GetForecastTemplateById")]
        public async Task<ActionResult> GetForecastTemplateById([FromBody] ForecastViewModel viewModel)
        {
            if (viewModel == null || viewModel.ID == 0)
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidID,
                       Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetForecastTemplateById(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data != null ? data.Count() : 0, data))).ConfigureAwait(false);
        }

        [HttpPost("GetStatusAggregateForecastDetailById")]
        public async Task<ActionResult> GetStatusAggregateForecastDetailById([FromBody] ForecastViewModel viewModel)
        {
            if (viewModel == null || viewModel.ID == 0)
            {
                this.ModelState.AddModelError(
                       Constants.Errors.InvalidID,
                       Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetStatusAggregateForecastDetailById(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>
                    .SendResponse(data != null ? data.Count() : 0, data))).ConfigureAwait(false);
        }

        [HttpGet("GetLastUpdatedForecast")]
        public async Task<ActionResult> GetLastUpdatedForecast()
        {
            var data = await this.manager.GetLastUpdatedForecast().ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<ForecastViewModel>
                    .SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost("UploadForecast")]
        public async Task<ActionResult> UploadForecast()
        {
            try
            {
                var file = Request.Form.Files[0];
                var forecastUploadViewModel = new ForecastUploadViewModel();
                forecastUploadViewModel.ForecastName = Request.Form["ForecastName"];
                forecastUploadViewModel.ForecastDesc = Request.Form["ForecastDesc"];
                forecastUploadViewModel.ParentForecastId = long.Parse(Request.Form["ForecastId"]);
                forecastUploadViewModel.IsOverride = bool.Parse(Request.Form["Override"]);
                forecastUploadViewModel.CreatedBy = Request.Form["CreatedBy"];
                if (file == null || !file.FileName.EndsWith(".xlsx") 
                    || string.IsNullOrEmpty(forecastUploadViewModel.ForecastName) 
                    || string.IsNullOrEmpty(forecastUploadViewModel.ForecastDesc)
                    || forecastUploadViewModel.ParentForecastId < 1)
                {
                    return await Task.FromResult(this.Ok(UserResponse<object>
                        .SendResponse(
                                    "Forecast upload failed. Wrong format of file.",
                                    HttpStatusCode.BadRequest)))
                        .ConfigureAwait(false);
                }

                var duplicateExists = await this.manager.DuplicateExists(new ForecastViewModel() { Name = forecastUploadViewModel.ForecastName});
                if (duplicateExists)
                {
                    return await Task.FromResult(this.Ok(UserResponse<object>
                        .SendResponse(
                                "A forecast with this name already exists. Please provide another name.",
                                HttpStatusCode.BadRequest)))
                        .ConfigureAwait(false);
                }

                var data = await this.manager.UploadForecast(file, forecastUploadViewModel).ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<object>
                        .SendResponse(data))).ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>
                   .SendResponse(
                               "Forecast upload failed. Please contact tech support.",
                               HttpStatusCode.BadRequest)))
                   .ConfigureAwait(false);
            }
        }
    }
}