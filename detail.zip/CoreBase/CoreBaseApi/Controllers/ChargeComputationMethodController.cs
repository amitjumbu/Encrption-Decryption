﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    ///  Operates on ChargeType.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ChargeComputationMethodController : ControllerBase
    {
        private readonly IChargeComputationMethodManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeComputationMethodController"/> class.
        /// </summary>
        /// <param name="manager">Charge Computation Method Manager with the help of DI.</param>
        public ChargeComputationMethodController(IChargeComputationMethodManager manager)
        {
            this.manager = manager;
        }

        /// <summary>
        /// Get List of all ChargeTypes.
        /// </summary>
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<ChargeComputationMethodViewModel> data = await this.manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeComputationMethodViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
    }
}
