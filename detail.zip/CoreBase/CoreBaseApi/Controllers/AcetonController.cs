﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class AcetonController : ControllerBase
    {
        private readonly IAcetonManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public AcetonController(IAcetonManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        ///Get All List for Measurement_UrineAcetoneMeasurementValue Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] AcetonViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<AcetonViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<AcetonViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                 return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
            
        }

        /// <summary>
        ///Save Measurement_UrineAcetoneMeasurementValue data with comment and media into system
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] AcetonViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            //viewModel.UpdatedBy = base.CurrentUserEmail;
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<AcetonViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        ///Update the Measurement_UrineAcetoneMeasurementValue data with comment and media also update the existing comment
        ///and media as well
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody]AcetonViewModel viewModel)
        { 
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //viewModel.UpdatedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<AcetonViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }


        /// <summary>
        ///Delete (soft removal) existing Measurement_UrineAcetoneMeasurementValue data from system 
        ///
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(long id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            //var CurrentUserEmail = base.CurrentUserEmail;

            if (Data != null)
            {
                await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(Ok(UserResponse<AcetonViewModel>.SendResponse(Data))).ConfigureAwait(false);
            }
            return await Task.FromResult(Ok(UserResponse<string>.SendResponse("No records found"))).ConfigureAwait(false);
        }



        /// <summary>
        ///Get the Measurement_UrineAcetoneMeasurementValue Records from Existing System By Measurement_UrineAcetoneMeasurementValue ID
        ///if any comments and media exist then it records also avaialble 
        /// </summary>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID([FromBody] AcetonViewModel viewModel)
        {
            
            AcetonViewModel Data = await this._Manager.GetAsync(viewModel.Id);
            return await Task.FromResult(Ok(UserResponse<AcetonViewModel>.SendResponse(Data)));
        }
    }
}