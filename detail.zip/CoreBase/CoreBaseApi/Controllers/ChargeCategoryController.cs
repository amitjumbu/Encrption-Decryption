﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    ///  Operates on ChargeType.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ChargeCategoryController : ControllerBase
    {
        private readonly IChargeCategoryManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeCategoryController"/> class.
        /// </summary>
        /// <param name="manager">Charge Catagory Manager with the help of DI.</param>
        public ChargeCategoryController(IChargeCategoryManager manager)
        {
            this.manager = manager;
        }

        /// <summary>
        /// Get List of all ChargeCategory.
        /// </summary>
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<ChargeCategoryViewModel> data = await this.manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeCategoryViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
    }
}
