﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ClaimController : ControllerBase
    {
        private readonly IClaimManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public ClaimController(IClaimManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this._Manager = manager;
        }


        [HttpPost(Constants.Identifire.GetClaimList)]
        public async Task<ActionResult> GetClaimList([FromBody] ClaimViewModel claimViewModel)
        {
            //int TotalData = await this._Manager.GetAllClaimDataCount(claimViewModel);
            int TotalData = 0;
            IEnumerable<ClaimViewModel> data = await this._Manager.GetAllClaimData(claimViewModel, ref TotalData);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ClaimViewModel>.SendResponse(TotalData, data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetFilterClaimData)]
        public async Task<IActionResult> GetFilterClaimData(ClaimFilterParameter ViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this._Manager.GetFilterClaimData(ViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetClaimByClaimId)]
        public async Task<IActionResult> GetClaimByClaimId(int ClaimId, int ClientId)
        {
            var data = await this._Manager.GetClaimDetailsByClaimId(ClaimId, ClientId).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.SetCompleteSetupAndNotify)]
        public async Task<ActionResult> SetCompleteSetupAndNotify(int clientId, int claimId, bool isCompleteSetupAndNotify, int claimStatusId, int userId)
        {
            // To Insert Data in SystemAlertCalendar table for send Notification
            var alert = await this._Manager.CompleteSetupAndNotifyAlert(clientId, claimId, isCompleteSetupAndNotify).ConfigureAwait(false);

            var data = await this._Manager.CompleteSetupAndNotify(clientId, claimId, isCompleteSetupAndNotify, claimStatusId, userId).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.ClaimApproved)]
        public async Task<ActionResult> ClaimApproved(int clientId, int claimId, bool isApproved, int claimStatusId, int userId)
        {
            // To Insert Data in SystemAlertCalendar table for send Notification
            var alert = await this._Manager.SetClaimApprovedAlert(clientId, claimId, isApproved).ConfigureAwait(false);

            var data = await this._Manager.SetClaimApproved(clientId, claimId, isApproved, claimStatusId, userId).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }


        [HttpPost(Constants.Identifire.SaveClaimDetail)]
        public async Task<IActionResult> SaveClaimDetail(ClaimDetailModel ViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            ViewModel.CreateDateTimeBrowser = DateTime.UtcNow;
            var data = await this._Manager.SaveClaimDetail(ViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost("SaveClaim")]
        public async Task<IActionResult> SaveClaim(ClaimModel ViewModel)
        {
            object outPutdata = new object();
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            if (ViewModel.ClaimID == 0)
            {
                outPutdata = await this._Manager.SaveClaim(ViewModel).ConfigureAwait(false);

            }
            else
            {
                outPutdata = await this._Manager.UpdateClaim(ViewModel).ConfigureAwait(false);
                //return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(outPutdata))).ConfigureAwait(false);
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(outPutdata))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.SaveMultiClaimDetail)]
        public async Task<IActionResult> SaveMultiClaimDetail(MultiClaimModel multiClaimModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            multiClaimModel.CreateDateTimeBrowser = DateTime.UtcNow.ToString();


            var data = await this._Manager.SaveMultiClaimDetail(multiClaimModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }



        [HttpPost(Constants.Identifire.DeleteClaimDetail)]
        public async Task<IActionResult> DeleteClaimDetail(MultiClaimModel multiClaimModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            multiClaimModel.CreateDateTimeBrowser = DateTime.UtcNow.ToString();


            var data = await this._Manager.DeleteClaimDetail(multiClaimModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.DeleteClaimSelectedRecords)]
        public async Task<ActionResult> DeleteClaimSelectedRecords(int userId, int clientID, string selectedRecords)
        {
            if (clientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.ClaimSelectedRecordsDelete(userId, clientID, selectedRecords);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

    }
}
