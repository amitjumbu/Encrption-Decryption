﻿//using System.Web.Http;
//using ExcelUploadAPI.Models;
namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    //using ExcelDataReader;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;
    using System.Web;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.ViewModel;
    //using ExcelDataReader;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/[controller]")]
    [ApiController]
    public class FreightLaneController : ControllerBase
    {
        private readonly IFreightLaneManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public FreightLaneController(IFreightLaneManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }
        /// <summary>
        /// Count number of Records 
        /// </summary>
        /// <param name="flagViewModel"></param>
        /// <returns></returns>

        [HttpPost("Count")]
        public async Task<ActionResult> Count([FromBody] FreightLaneViewModel flagViewModel)
        {
            var count = await this._Manager.CountAsync(flagViewModel);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count)));
        }
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<FreightLaneViewModel> data = await this._Manager.GetFreightLaneList(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        //[HttpPost(Constants.Identifire.List)]
        //public async Task<ActionResult> List([FromBody] FreightLaneViewModel flagViewModel)
        //{
        //    var Count = await this._Manager.CountAsync(flagViewModel);
        //    IEnumerable<FreightLaneViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
        //    return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(Data.Count(), Data)));
        //}

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] FreightLaneViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<FreightLaneViewModel> viewModel)
        {

            IEnumerable<FreightLaneViewModel> data = await this._Manager.SaveAll(viewModel);
            return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(data.Count(), data)));
        }

        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.UpdateAll)]
        public async Task<IActionResult> UpdateAll(List<FreightLaneViewModel> viewModel)
        {
            var data = await this._Manager.UpdateAll(viewModel).ConfigureAwait(false);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] FreightLaneViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] FreightLaneDelete freightdelete)
        {
            var allIds = freightdelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }


        [HttpPut(Constants.Identifire.EditFreigtmodes)]
        public async Task<IActionResult> EditfmsByIDs(string ids)
        {
            var data = await this._Manager.GetEditfmsAsync(ids).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<IEnumerable<FreightLaneViewModel>>.SendResponse(data))).ConfigureAwait(false);
        }


        /// <summary>
        ///User can  Retrieves data from FreightMode by equipment.
        /// </summary>
        //[HttpPost(Constants.Identifire.GetByID)]
        //public async Task<ActionResult> GetFreightMode([FromBody] MaterialCommonModel flagViewModel)
        //{
        //    IEnumerable<FreightModeViewModel> Data = await this._Manager.GetFreightMode(flagViewModel).ConfigureAwait(false);
        //    return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(0, Data))).ConfigureAwait(false);
        //}

        #region Get Freight Lane list with sorting,filtering and paggination
        [HttpPost("GetAllRecords")]
        public async Task<IActionResult> GetAllRecords([FromBody] FreightLaneViewModel requestCommonViewModel)
        {
            //if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            //{
            //    this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            //}

            //if (!this.ModelState.IsValid)
            //{
            //    return this.BadRequest(this.ModelState);
            //}

            IEnumerable<FreightLaneViewModel> data = await this._Manager.GetFreightLaneList(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<FreightLaneViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        #region Get Freight mode list with sorting,filtering and paggination
        [HttpPost("GetFilterRecords")]
        public async Task<IActionResult> GetFilterRecords([FromBody] FreightLaneViewModel requestCommonViewModel)
        {
            //if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            //{
            //    this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            //}

            //if (!this.ModelState.IsValid)
            //{
            //    return this.BadRequest(this.ModelState);
            //}

            IEnumerable<FreightLaneViewModel> data = await this._Manager.GetFreightLaneFilterData(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<FreightLaneViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion

        #region Get Freight Lane Excel Error Report
        [HttpPost("GetErrorReport")]
        public async Task<IActionResult> GetErrorReport([FromBody] FreightLaneViewModel requestCommonViewModel)
        {
            //if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            //{
            //    this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            //}

            //if (!this.ModelState.IsValid)
            //{
            //    return this.BadRequest(this.ModelState);
            //}

            IEnumerable<FreightLaneViewModel> data = await this._Manager.GetFreightLaneExcelErrorList(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<FreightLaneViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        [HttpPost("UploadExcel")]
        public async Task<ActionResult> uploadExcel(List<object[]> data)
        {
            
            List<FreightLaneViewModel> objFreightList = new List<FreightLaneViewModel>();
            
            for (int i = 1; i < data.Count; i++)
            {
                var objFreight = new FreightLaneViewModel();
                for (int j = 1; j < data[i].Length; j++)
                {
                    if (data[i][j] != null)
                    {
                       
                        if (j == 0)
                            objFreight.RateType = data[i][0].ToString();
                        if (j == 1)
                            objFreight.CarrierSCAC = data[i][1].ToString();
                        if (j == 2)
                            objFreight.OriginCountry = data[i][2].ToString();
                        if (j == 3)
                            objFreight.OriginCity = data[i][3].ToString();
                        if (j == 4)
                            objFreight.OriginState = data[i][4].ToString();
                        if (j == 5)
                            objFreight.DestinationCountry = data[i][5].ToString();
                        if (j == 6)
                            objFreight.DestinationCity = data[i][6].ToString();
                        if (j == 7)
                            objFreight.DestinationState = data[i][7].ToString();
                        if (j == 8)
                            objFreight.TransitDays = data[i][8].ToString();
                        if (j == 9)
                            objFreight.RateUOM = data[i][9].ToString();
                        if (j == 10)
                            objFreight.Rate = data[i][10].ToString();
                        if (j == 11)
                            objFreight.MinCharge = data[i][11].ToString();
                        if (j == 12)
                            objFreight.MaxCharge = data[i][12].ToString();
                        if (j == 13)
                            objFreight.EquipmentType = data[i][13].ToString();
                        if (j == 14)
                            objFreight.RateEffBeginDate = data[i][14].ToString();
                        if (j == 15)
                            objFreight.RateEffEndDate = data[i][15].ToString();
                        if (j == 16)
                            objFreight.Funds = data[i][16].ToString();
                        if (j == 17)
                            objFreight.ModeType = data[i][17].ToString();
                        if (j == 18)
                            objFreight.DistanceUOM = data[i][18].ToString();
                        if (j == 19)
                            objFreight.Distances = data[i][19].ToString();

                      
                    }
                    
                }
                objFreightList.Add(objFreight);
            }
            await this._Manager.InsertFreightLaneExcelData(objFreightList);
          
            return await Task.FromResult(Ok(UserResponse<FreightLaneViewModel>.SendResponse(1, null)));
        }
       // [HttpPost("UploadExcel")]
        public ObjectResult ExcelUpload()
        {
            try
            {
                var file = Request.Form.Files[0];
                string folderName = "Upload";
                string webRootPath = _hostingEnvironment.WebRootPath;
                string newPath = Path.Combine(webRootPath, folderName);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                string fileName = "";
                if (file.Length > 0)
                {
                    fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    string fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }

                return Ok(fileName);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        //[Route("UploadExcel")]
        [HttpPost("UploadExcel1")]
        public string ExcelUpload1()
        {
            string message = "";
            //HttpResponseMessage result = null;
            HttpContext httpContext = HttpContext;
            //  var httpRequest = httpContext.Current.Request;
            // using (AngularDBEntities objEntity = new AngularDBEntities())
            // {
            var i = 0;
            if (i == 0)
            {
                //         HttpPostedFile file = httpRequest.Files[0];
                //         Stream stream = file.InputStream;

                //         IExcelDataReader reader = null;

                //         if (file.FileName.EndsWith(".xls"))
                //         {
                //             reader = ExcelReaderFactory.CreateBinaryReader(stream);
                //         }
                //         else if (file.FileName.EndsWith(".xlsx"))
                //         {
                //             reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                //         }
                //         else
                //         {
                //             message = "This file format is not supported";
                //         }

                //         DataSet excelRecords = reader.AsDataSet();
                //         reader.Close();

                //         var finalRecords = excelRecords.Tables[0];
                //         for (int i = 0; i < finalRecords.Rows.Count; i++)
                //         {
                //             UserDetail objUser = new UserDetail();
                //             objUser.UserName = finalRecords.Rows[i][0].ToString();
                //             objUser.EmailId = finalRecords.Rows[i][1].ToString();
                //             objUser.Gender = finalRecords.Rows[i][2].ToString();
                //             objUser.Address = finalRecords.Rows[i][3].ToString();
                //             objUser.MobileNo = finalRecords.Rows[i][4].ToString();
                //             objUser.PinCode = finalRecords.Rows[i][5].ToString();

                //             objEntity.UserDetails.Add(objUser);

                //         }

                //         int output = objEntity.SaveChanges();
                //         if (output > 0)
                //         {
                //             message = "Excel file has been successfully uploaded";
                //         }
                //         else
                //         {
                //             message = "Excel file uploaded has fiald";
                //         }

                //     }

                //     else
                //     {
                //         result = Request.CreateResponse(HttpStatusCode.BadRequest);
                //     }
            }
            return message;
            //}
        }
    }
}
