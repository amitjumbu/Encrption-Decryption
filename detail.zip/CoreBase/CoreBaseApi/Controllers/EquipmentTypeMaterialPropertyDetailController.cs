﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class EquipmentTypeMaterialPropertyDetailController : ControllerBase
    {
        private readonly IEquipmentTypeMaterialPropertyDetailManager manager;

        public EquipmentTypeMaterialPropertyDetailController(IEquipmentTypeMaterialPropertyDetailManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost("GetEquipmentTypeMaterialPropertyDetailByCode")]
        public async Task<IActionResult> GetEquipmentTypeMaterialPropertyDetailByCode([FromBody] EquipmentTypeMaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel> data = await this.manager.GetEquipmentTypeMaterialPropertyDetailByCode(commonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<EquipmentTypeMaterialPropertyDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetMaterialPropertyByEquipmentTypeCode")]
        public async Task<IActionResult> GetMaterialPropertyByEquipmentTypeCode([FromBody] EquipmentTypeMaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetMaterialPropertyByEquipmentTypeCode(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetCountMaterialsByEquipmentTypeCode")]
        public async Task<IActionResult> GetCountMaterialsByEquipmentTypeCode([FromBody] EquipmentTypeMaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetCount(commonViewModel);

            if (finalResult != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }

        [HttpPost("GetCountEquipmentsByMaterialCode")]
        public async Task<IActionResult> GetCountEquipmentsByMaterialCode([FromBody] EquipmentTypeMaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetmatTotalCountCount(commonViewModel);

            if (finalResult != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }

        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<EquipmentTypeMaterialPropertyDetailViewModel> viewModel)
        {
            IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel> data = await this.manager.SaveAll(viewModel);
            return await Task.FromResult(this.Ok(UserResponse<EquipmentTypeMaterialPropertyDetailViewModel>.SendResponse(data.Count(), data)));
        }

        [HttpPost("GetEquipmentTypeMaterialPropertyForPopUp")]
        public async Task<IActionResult> GetEquipmentTypeMaterialPropertyForPopUp([FromBody] EquipmentTypeMaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<EquipmentTypeMaterialPropertyDetailViewModel> data = await this.manager.GetEquipmentTypeMaterialPropertyForPopUp(commonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<EquipmentTypeMaterialPropertyDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetMaterialPropertyByEquipmentForPopUp")]
        public async Task<IActionResult> GetMaterialPropertyByEquipmentForPopUp([FromBody] MaterialPropertyDetailByEquipmentViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetMaterialPropertyByEquipmentForPopUp(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialPropertyDetailByEquipmentViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetTotalCountMaterialPropertyByEquipmentForPopUp")]
        public async Task<IActionResult> GetTotalCountMaterialPropertyByEquipmentForPopUp([FromBody] MaterialPropertyDetailByEquipmentViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetTotalCountMaterialPropertyByEquipmentForPopUp(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult.Count())));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetTotalCountEquipmentTypeMaterialPropertyForPopUp")]
        public async Task<IActionResult> GetTotalCountEquipmentTypeMaterialPropertyForPopUp([FromBody] EquipmentTypeMaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetTotalCountEquipmentTypeMaterialPropertyForPopUp(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult.Count())));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] EquipmentTypeMaterialPropertyDetailDeleteModel equipmentMatPropDetailDeleteModel)
        {
            var allIds = equipmentMatPropDetailDeleteModel.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        [HttpPost("CopyEquipmentMatPropDetailFromSelectedMaterial")]
        public async Task<IActionResult> GetEquipmentMatPropDetailFromSelectedMaterial([FromBody] EquipmentMatPropDetailFromSelectedMatModel commonViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetEquipmentMatPropDetailFromSelectedMaterial(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<EquipmentMatPropDetailFromSelectedMatModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("CopyEquipmentPropDetailFromSelectedEquipment")]
        public async Task<IActionResult> CopyEquipmentPropDetailFromSelectedEquipment([FromBody] EquipmentPropDetailFromSelectedEquipmentModel commonViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetCopiedPropFromSelectedEquipment(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<EquipmentPropDetailFromSelectedEquipmentModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }
    }
}
