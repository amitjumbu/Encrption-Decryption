﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Contract Controller Developed By Jamil Akhtar.
    /// On : 05-November-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ContractController : ControllerBase
    {
        private readonly IContractManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContractController"/> class.
        /// </summary>
        /// <param name="manager">Contract Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public ContractController(IContractManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }


        [HttpPost("CheckExist")]
        public async Task<ActionResult> CheckExist([FromBody] CustomerContractViewModel ContractModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this.manager.CheckExist(ContractModel);
            //if (data == true)
            //{
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            //}
            //else
            //{
            //    return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            //}

        }
        /// <summary>
        /// this end point get all list of Contract.
        /// Point No 82. In Tosca Order Requirement V2 Doccument.
        /// </summary>
        /// <param name="requestCommonViewModel">Contract View Model for filter purpose.</param>
        /// <returns>list of Contract.</returns>
        /// 
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CustomerContractViewModel ContractModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this.manager.AddAsyncData(ContractModel);
            //if (data == true)
            //{
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            //}
            //else
            //{
            //    return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            //}

        }

        [HttpPost(Constants.Identifire.Update)]
        public async Task<IActionResult> UpdateContract([FromBody] CustomerContractViewModel ContractModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this.manager.UpdateContractAsync(ContractModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpGet("GetCharacteristic")]
        public async Task<ActionResult> GetCharacteristic()
        {
            var data = await this.manager.GetCharacteristic();
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }


        [HttpPost("AllContractCount")]
        public async Task<IActionResult> AllContractCount([FromBody] ContractViewModel requestCommonViewModel)
        {


            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<ContractViewModel> data = await this.manager.GetAllContract(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data.Count())));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0)));
            }
        }

        [HttpPost("GetContractDetailsByIds")]

        public async Task<IActionResult> GetContractDetailsByIds([FromBody] CustomerContractViewModel requestCommonViewModel)
        {

            if (requestCommonViewModel.ClientId == null || requestCommonViewModel.ClientId <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<ContractDetailViewModel> data = await this.manager.GetContractDetailsByIds(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<ContractDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetContractDetails")]
        public async Task<IActionResult> GetContractDetails([FromBody] CustomerContractViewModel requestCommonViewModel)
        {

            if (requestCommonViewModel.ClientId == null || requestCommonViewModel.ClientId <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetContractDetails(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("SaveContractDetails")]
        public async Task<IActionResult> SaveContractDetails([FromBody] List<ContractDetailViewModel> viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.AddContractAsync(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost("DeleteContractDetails")]
        public async Task<IActionResult> DeleteContractDetails([FromBody] ContractDetailViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.DeleteContractDetails(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost("ContractApprove")]
        public async Task<IActionResult> ContractApprove([FromBody] ContractViewModel requestCommonViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.ContractApprove(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }


        [HttpPost("GetContractById")]
        public async Task<IActionResult> GetContractById([FromBody] ContractViewModel requestCommonViewModel)
        {


            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetByIdContract(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetAllContract")]
        public async Task<IActionResult> GetAllContract([FromBody] ContractViewModel requestCommonViewModel)
        {


            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<ContractViewModel> data = await this.manager.GetAllContract(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }



        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] CommodityDelete commoditydelete)
        {
            var allIds = commoditydelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        /// <summary>
        ///User can get Retrieves data from Candidate page wise.hi
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] CustomerContractViewModel flagViewModel)
        {
            var Count = await this.manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<CustomerContractViewModel> Data = await this.manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<CustomerContractViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }

        [HttpPost("SaveDefiningCharacteristics")]
        public async Task<IActionResult> SaveDefiningCharacteristics([FromBody] List<DefiningCharacteristicsViewModel> viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.AddCharacteristicsAsyncData(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetCharacteristicById")]
        public async Task<IActionResult> GetCharacteristicById([FromBody] ContractViewModel requestCommonViewModel)
        {


            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetCharacteristicsData(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("DeleteDefiningCharacteristics")]
        public async Task<IActionResult> DeleteDefiningCharacteristics([FromBody] List<DefiningCharacteristicsViewModel> viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.DeleteDefiningCharacteristics(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost("DeleteContracts")]
        public async Task<IActionResult> DeleteContracts([FromBody] List<ContractViewModel> viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.DeleteContracts(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost("InactiveContracts")]
        public async Task<IActionResult> InactiveContracts([FromBody] List<ContractViewModel> viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.InactiveContracts(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost("ActiveContracts")]
        public async Task<IActionResult> ActiveContracts([FromBody] List<ContractViewModel> viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.ActivateContracts(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("SendApprovalNotification")]
        public async Task<IActionResult> SendApprovalNotification([FromBody] CustomerContractViewModel ContractModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var data = await this.manager.SendApprovalNotification(ContractModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost("GetLocationsIds")]
        public async Task<IActionResult> GetLocationsIds([FromBody] CustomerContractViewModel requestCommonViewModel)
        {
            if (requestCommonViewModel.ClientId == null || requestCommonViewModel.ClientId <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.manager.GetLocationsIds(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #region Get Customer Code by Contract Type
        [HttpPost("GetCustomerByContractType")]
        public async Task<IActionResult> GetCustomerByContractType([FromBody] CustomerContractViewModel requestCommonViewModel)
        {
            
            var data = await this.manager.GetCustomerByContactType(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        #region Get Business Partner by Contract Type
        [HttpPost("GetBusinessPartnerOnContractType")]
        public async Task<IActionResult> GetBusinessPartnerOnContractType([FromBody] BusinessPartnerContractViewModel requestCommonViewModel)
        {

            var data = await this.manager.GetBusinessPartnerOnContactType(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        [HttpPost("GetChargesAndCharacteristicsFrom")]
        public async Task<IActionResult> GetChargesAndCharacteristicsFrom([FromBody] CustomerContractViewModel requestCommonViewModel)
        {
            var data = await this.manager.GetChargesAndCharacteristicsFrom(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("SaveAndUpdateContractDetail")]
        public async Task<IActionResult> SaveAndUpdateContractDetail([FromBody] ContractRequestObject requestCommonViewModel)
        {
            var data = await this.manager.SaveAndUpdateContract(requestCommonViewModel.InitialContract,requestCommonViewModel.UpdatedContract);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }



    }
}
