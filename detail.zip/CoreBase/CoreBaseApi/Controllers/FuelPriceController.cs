﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class FuelPriceController : ControllerBase
    {
        private readonly IFuelPriceManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public FuelPriceController(IFuelPriceManager DIManager, IHostingEnvironment hostingEnvironment, IInstanseLogger instanceLogger)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
            this.instanceLogger = instanceLogger;
        }


        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Get Fuel Price Data", Data);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion


        /// <summary>
        ///Get All List for Location Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] FuelPriceViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<FuelPriceViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                this.instanceLogger.AddInstanseLogger("Get Fuel Price Data List", Data);
                return await Task.FromResult(Ok(UserResponse<FuelPriceViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }


        /// <summary>
        /// Get List for all Customer By location.
        /// </summary>
        /// <param name="viewModel"> Model should contain pageNo, pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetFuelList)]
        public async Task<ActionResult> GetFuelPriceList([FromBody] FuelPriceViewModel viewModel)
        {
            IEnumerable<FuelPriceViewModel> data =
                await this._Manager.GetFuelPriceList(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<FuelPriceViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        ///User can get list by locatinId.
        /// </summary>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetFuelPriceListById([FromBody] FuelPriceViewModel viewModel)
        {
            IEnumerable<FuelPriceViewModel> Data = await this._Manager.GetFuelPriceListById(viewModel);
            this.instanceLogger.AddInstanseLogger("Get Preferred Material Data By Id", Data);
            return await Task.FromResult(Ok(UserResponse<FuelPriceViewModel>.SendResponse(1, Data)));
        }


        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<ActionResult> Update([FromBody] FuelPriceViewModel viewModel)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.UpdateAsync(viewModel);
            this.instanceLogger.AddInstanseLogger("Update Preferred Material Data", data);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<FuelPriceViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationContactModel"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] FuelPriceViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.AddAsync(viewModel);
            this.instanceLogger.AddInstanseLogger("Save Fuel Price Data", data);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<FuelPriceViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationContactModel"></param>
        /// <returns></returns>
        [HttpPost("CheckDuplicate")]
        public async Task<ActionResult> CheckDuplicate([FromBody] FuelPriceViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.GetFuelPriceListByDateAndRate(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<FuelPriceViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }

        [HttpPost(Constants.Identifire.DeleteByID)]
        public async Task<ActionResult> DeletePreferredMaterialAsync([FromBody] FuelPriceViewModel viewModel)
        {
            var data = await this._Manager.DeleteAllAsync(viewModel).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Delete Preferred Material List", data);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

    }
}