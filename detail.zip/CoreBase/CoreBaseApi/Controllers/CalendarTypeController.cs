﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalendarTypeController : ControllerBase
    {
        private readonly ICalendarTypeManager manager;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public CalendarTypeController(
            ICalendarTypeManager DIManager, 
            IHostingEnvironment hostingEnvironment, 
            IInstanseLogger instanceLogger)
        {
            this.manager = DIManager;
            this.instanceLogger = instanceLogger;
        }

        [HttpGet(Constants.Identifire.GetAll)]
        public async Task<ActionResult> GetAll()
        {
            var data = await this.manager.GetList().ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

    }
}