﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking.Internal;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IPatientValueManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;




        public PatientController(IPatientValueManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }
          

        /// <summary>
        ///User can get Retrieves data from Candidate page wise.hi
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] PatientValueViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<object> goldenMaster = await this._Manager.RangeAsync1(Count, flagViewModel);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, goldenMaster)));
        }
        #region Get patient info by patient Id
        [HttpPost(Constants.Identifire.GetPatientInfoByID)]
        public async Task<ActionResult> GetPatientHeaderInfoByID(long PatientId)
        {
            if (Convert.ToInt32(PatientId) == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }


            var data = this._Manager.GetPatientInfoByID(PatientId);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<PatientHeaderViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        #endregion

        [HttpPost("SerachPatient")]
        public async Task<ActionResult> SerachPatient([FromBody] PatientViewModel flagViewModel)
        {
           
            IEnumerable<object> goldenMaster = await this._Manager.SearchPatient(flagViewModel);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(goldenMaster)));
        }

        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] PatientValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = string.Empty;
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        /// update candidate data flag wise.
        /// </summary>
        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] PatientValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientValueViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        [HttpPost("PatientUpdate")]
        public async Task<IActionResult> PatientUpdate([FromBody] PatientValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientValueViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        ///delete candidate record behalf of id
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientValueViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }


        [HttpPost("UpdatePatientStatus")]
        public async Task<IActionResult> UpdatePatientStatus(PatientTransactionViewModel viewmodel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(viewmodel);
            }
            await this._Manager.UpdatePatientStatus(viewmodel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(viewmodel))).ConfigureAwait(false);
        }

        #region Bind Patient List for Patient Setup
        [HttpPost(Constants.Identifire.GetAddedPatientList)]
        public async Task<ActionResult> GetAddedPatientList(PatientViewModel patientSetupList)
        {
            IEnumerable<object> data = await this._Manager.GetPatientList(patientSetupList);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion

        #region Bind Patient List for Patient Setup
        [HttpPost(Constants.Identifire.GetPatientList)]
        public async Task<ActionResult> GetPatientList(PatientSetupListViewModel patientSetupList)
        {
            IEnumerable<PatientSetupListViewModel> data = await this._Manager.GetPatientSetupList(patientSetupList);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<PatientSetupListViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion

        #region Bind Patient Information 
        [HttpPost("PatientContactAddressPhysicianList")]
        public async Task<ActionResult> PatientContactAddressPhysicianList(PatientViewModel patientSetupList)
        {
            IEnumerable<object> data = await this._Manager.GetContactAddressPhysicianInfo(patientSetupList);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion


        #region Change patient Active/ Inactive Status as well as partograph
        [HttpPost(Constants.Identifire.ActiveAll)]
        public async Task<ActionResult> ActiveAll([FromBody] CollectPatientIDs collectPatientIDs)
        {
            var allIds = collectPatientIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.ActivatePatientStatus(allIds, collectPatientIDs.isActive);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion

        #region delete patient from patient setup
        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] CollectPatientIDs collectPatientIDs)
        {
            var allIds = collectPatientIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion
    }
}
