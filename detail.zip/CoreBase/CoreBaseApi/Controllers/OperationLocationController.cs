﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Managers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft;
using Newtonsoft.Json.Linq;
using System.Linq;
using System;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class OperatingLocationController : ControllerBase
    {
        
        private readonly IOperatingLocationManager OperatingLocationManager;
       
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public OperatingLocationController(IOperatingLocationManager opratingManager, IHostingEnvironment hostingEnvironment)
        {
            this.OperatingLocationManager = opratingManager;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpPost]
        public async Task<ActionResult> Save([FromBody] OperatingLocationViewModel operatingViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.OperatingLocationManager.AddAsync(operatingViewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<OperatingLocationViewModel>.SendResponse(operatingViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        [HttpPost]
        public async Task<IActionResult> Update([FromBody] OperatingLocationViewModel OperatingLocationViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.OperatingLocationManager.UpdateAsync(OperatingLocationViewModel);
            if (result)
            {
                return await Task.FromResult(this.Ok(UserResponse<OperatingLocationViewModel>.SendResponse(OperatingLocationViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        [HttpPost]
        public async Task<IActionResult> GetAll([FromBody] OperatingLocationViewModel OperatingLocationViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var totalRecordCount = await this.OperatingLocationManager.CountAsync(OperatingLocationViewModel);
            var result = await this.OperatingLocationManager.RangeAsync(totalRecordCount, OperatingLocationViewModel);
         

            return await Task.FromResult(this.Ok(UserResponse<OperatingLocationViewModel>.SendResponse(totalRecordCount,result)));
            
        }


        [HttpPost]
        public async Task<IActionResult> GetOrganizationHierarchyGroup([FromBody] OperatingLocationViewModel OperatingLocationViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            // var totalRecordCount = await this.OperatingLocationManager.CountAsync(OperatingLocationViewModel);
            var result = this.OperatingLocationManager.GetOrganizationHierarchyGroupAsync(0, OperatingLocationViewModel);


            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0,  result)));

        }

        [HttpPost]
        public async Task<IActionResult> GetOrganizationHierarchyEnterprises([FromBody] OperatingLocationViewModel OperatingLocationViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            // var totalRecordCount = await this.OperatingLocationManager.CountAsync(OperatingLocationViewModel);
            var result = this.OperatingLocationManager.GetOrganizationHierarchyEnterprisesAsync(0, OperatingLocationViewModel);


            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, result)));

        }



        [HttpPost]
        public async Task<IActionResult> GetByID([FromBody] EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.OperatingLocationManager.GetAsync(entityRecordRemoveRequestPacket.ID);

            return await Task.FromResult(this.Ok(UserResponse<OperatingLocationViewModel>.SendResponse(result)));

        }


        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.OperatingLocationManager.Delete(entityRecordRemoveRequestPacket);
            if (result)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
        #region Get Records by sending multiple IDs
        [HttpPost]
        public async Task<IActionResult> GetAllByID([FromBody] CollectHospialIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            IEnumerable<OperatingLocationListViewModel> data = await this.OperatingLocationManager.GetLocationsListByIDs(collectHospialIDs);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<OperatingLocationListViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion

    }
}