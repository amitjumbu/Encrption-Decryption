﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class BusinessPartnerPropertyDetailController : ControllerBase
    {
        private readonly IBusinessPartnerPropertyDetailManager _Manager;
        //private readonly ILocationManager Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public BusinessPartnerPropertyDetailController(IBusinessPartnerPropertyDetailManager DIManager, IHostingEnvironment hostingEnvironment, IInstanseLogger instanceLogger)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
            this.instanceLogger = instanceLogger;
        }


        
        [HttpPost(Constants.Identifire.UpdateAll)]
        public async Task<ActionResult> UpdateAll([FromBody] List<BusinessPartnerPropertyDetailViewModel> viewModels)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.MergeBusinessPartnerPropertyDetails(viewModels);
            this.instanceLogger.AddInstanseLogger("MergeBusinessPartnerPropertyDetails  Data", data);
            if (data)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }
    }
}