﻿namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;


    [Route("api/[controller]")]
    [ApiController]


    public class CreditSummaryController : ControllerBase
    {
        private readonly ICreditSummaryContractManager manager;

        public CreditSummaryController(ICreditSummaryContractManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost("GetCreditSummaryList")]
        public async Task<ActionResult> GetCreditSummaryList([FromBody] CreditSummaryViewModel csViewModel)
        {

            IEnumerable<CreditSummaryViewModel> data = await this.manager.GetCreditSummaryList(csViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CreditSummaryViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetCreditSummaryListCount")]
        public async Task<ActionResult> GetCreditSummaryListCount([FromBody] CreditSummaryViewModel csViewModel)
        {

            IEnumerable<CreditSummaryViewModel> data = await this.manager.GetCreditSummaryListCount(csViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CreditSummaryViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

    }
}
