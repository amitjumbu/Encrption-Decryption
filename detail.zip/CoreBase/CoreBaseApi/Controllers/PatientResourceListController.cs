﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class PatientResourceListController : ControllerBase
    {
        private readonly IPatientResourceListManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public PatientResourceListController(IPatientResourceListManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion
        
        #region List of records displayed
        // List of records displayed
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] PatientResourceListViewModel patientResourceListViewModel)
        {
            var Count = await this._Manager.CountAsync(patientResourceListViewModel);
            if (Count > 0)
            {
                IEnumerable<PatientResourceListViewModel> Data = await this._Manager.RangeAsync(Count, patientResourceListViewModel);
                return await Task.FromResult(Ok(UserResponse<PatientResourceListViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }
        #endregion

        #region Update the Record
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] PatientResourceListViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientResourceListViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }
        #endregion
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] PatientResourceListViewModel patientResourceListView)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this._Manager.AddAsync(patientResourceListView);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<PatientResourceListViewModel>.SendResponse(patientResourceListView)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }
        [HttpPost(Constants.Identifire.GetAllPhysiciansByPatientId)]
        public async Task<ActionResult> GetPhysiciansByPatientId(PatientResourceListViewModel ViewModel)
        {
            IEnumerable<PatientResourceListViewModel> data = await this._Manager.GetPhysiciansByPatientId(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<PatientResourceListViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }

        [HttpPost(Constants.Identifire.CheckPhysicianMappedWithPatient)]
        public async Task<ActionResult> CheckPhysicianMappedWithPatient(PatientResourceMapppingViewModel ViewModel)
        {
            var data = await this._Manager.CheckPhysicianMappedWithPatient(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [HttpPost("Delete")]
        public async Task<IActionResult> Delete(PatientResourceListViewModel viewModel)
        {
            var data = await this._Manager.DeleteAllAsync(viewModel.ids, viewModel.UpdatedBy).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }


    }
}