﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryOfOriginOfMaterialController : ControllerBase
    {
        private readonly ICountryOfOriginOfMaterialManager _Manager;
        private readonly IMapper mapper;

        public CountryOfOriginOfMaterialController(ICountryOfOriginOfMaterialManager DIManager)
        {
            this._Manager = DIManager;
        }

        /// <summary>
        ///User can get Retrieves data from Candidate page wise.
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<CountryOfOriginOfMaterialViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }

        
        [HttpPost(Constants.Identifire.GetOriginOfGoodsDetails)]
        public async Task<ActionResult> GetOriginOfGoodsDetails([FromBody] CountryOfOriginOfMaterialViewModel ViewModel)
        {

            IEnumerable<CountryOfOriginOfMaterialViewModel> data = await this._Manager.GetAllOriginOfGoodsDetails(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CountryOfOriginOfMaterialViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
    
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<CountryOfOriginOfMaterialViewModel> data = await this._Manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CountryOfOriginOfMaterialViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }


        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CountryOfOriginOfMaterialViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            // var data = await this._Manager.AddData(viewModel);
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<CountryOfOriginOfMaterialViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        /// update candidate data flag wise.
        /// </summary>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] CountryOfOriginOfMaterialViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //viewModel.ModifiedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<CountryOfOriginOfMaterialViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] OriginOfGoodsDelete viewModelDelete)
        {
            var allIds = viewModelDelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
    }
}
