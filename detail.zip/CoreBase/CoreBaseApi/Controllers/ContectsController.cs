﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ContectsController : ControllerBase
    {
       // private readonly IHostingEnvironment _hostingEnvironmentPCont;
       // private readonly IHostingEnvironment _hostingEnvironmentLCont;
        private readonly IPatientContactValueManager _ManagerPCont;
        private readonly IOperatingLocationContactManager _ManagerLCont;

        public ContectsController(IHostingEnvironment hostingEnvironment,
                         IPatientContactValueManager DIManagerPCont,
                         IOperatingLocationContactManager DIManagerLCont //,  IHostingEnvironment hostingEnvironmentPCont
                      )
        {
            this._ManagerPCont = DIManagerPCont; //_hostingEnvironmentPCont = hostingEnvironment;
            this._ManagerLCont = DIManagerLCont;
        }

        /// <summary>
        ///Add Address Data.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> addContect([FromBody] PatientDetailModelValueViewModel viewModel)
        {
            dynamic resultData = null;
            if (viewModel.PatientsContactDM != null)
            {
                foreach (var PContModel in viewModel.PatientsContactDM)
                {
                    PatientContactValueViewModel objPatientContact = new PatientContactValueViewModel();
                    dynamic Pcontact = PContModel;
                    objPatientContact = Pcontact;
                    objPatientContact.CreateDateTimeServer = DateTime.UtcNow;
                    objPatientContact.UpdateDateTimeServer = DateTime.UtcNow;
                    var ContData = await this._ManagerPCont.AddAsync(objPatientContact);
                    resultData = ContData;
                }
            }
            else if (viewModel.LocationContactDM != null)
            {
                foreach (var LContModel in viewModel.LocationContactDM)
                {
                    OperatingLocationContactViewModel objLocationContact = new OperatingLocationContactViewModel();
                    dynamic Pcontact = LContModel;
                    objLocationContact = Pcontact;
                    objLocationContact.CreateDateTimeServer = DateTime.UtcNow;
                    objLocationContact.UpdateDateTimeServer = DateTime.UtcNow;
                    var ContData = await this._ManagerLCont.AddAsync(objLocationContact);
                    resultData = ContData;
                }
            }
            if (resultData == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientDetailModelValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }


        }

        /// <summary>
        ///Update Current Address Datea.
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> updateContect([FromBody] PatientDetailModelValueViewModel viewModel)
        {
            if (viewModel.PatientsContactDM != null)
            {
                foreach (var PContModel in viewModel.PatientsContactDM)
                {
                    PatientContactValueViewModel objPatientContact = new PatientContactValueViewModel();
                    dynamic Pcontact = PContModel;
                    objPatientContact = Pcontact;
                    objPatientContact.CreateDateTimeServer = DateTime.UtcNow;
                    objPatientContact.UpdateDateTimeServer = DateTime.UtcNow;
                    await this._ManagerPCont.UpdateAsync(objPatientContact);
                }
            }
            else if (viewModel.LocationContactDM != null)
            {
                foreach (var LContModel in viewModel.LocationContactDM)
                {
                    OperatingLocationContactViewModel objLocationContact = new OperatingLocationContactViewModel();
                    dynamic Pcontact = LContModel;
                    objLocationContact = Pcontact;
                    objLocationContact.CreateDateTimeServer = DateTime.UtcNow;
                    objLocationContact.UpdateDateTimeServer = DateTime.UtcNow;
                    await this._ManagerLCont.UpdateAsync(objLocationContact);
                }
            }


            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
        }






    }
}
