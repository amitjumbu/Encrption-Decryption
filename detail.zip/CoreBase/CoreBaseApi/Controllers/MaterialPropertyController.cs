﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialPropertyController : ControllerBase
    {
        private readonly IMaterialPropertyManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="MaterialPropertyController"/> class.
        /// </summary>
        /// <param name="manager">MaterialProperty Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public MaterialPropertyController(IMaterialPropertyManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<IActionResult> ListMaterialPropertyAsync([FromBody] MaterialPropertyViewModel commonViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<MaterialPropertyViewModel> data = await this.manager.ListMaterialPropertyAsync(commonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<MaterialPropertyViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetMaterialPropertyControlValue")]
        public async Task<IActionResult> GetMaterialPropertyControlValue([FromBody] MaterialPropertyControlValueViewModel commonViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetMaterialPropertyControlValue(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialPropertyControlValueViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }
    }
}
