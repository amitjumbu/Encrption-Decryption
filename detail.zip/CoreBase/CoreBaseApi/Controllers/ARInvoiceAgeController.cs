﻿namespace CoreBaseApi.Controllers
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;


    [Route("api/[controller]")]
    [ApiController]


    public class ARInvoiceAgeController : ControllerBase
    {
        private readonly IARInvoiceManager manager;

        public ARInvoiceAgeController(IARInvoiceManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost("GetInvoiceDetails")]
        public async Task<ActionResult> GetInvoiceDetails([FromBody] ARInvoiceAgeDetailViewModel invoiceViewModel)
        {

            IEnumerable<ARInvoiceAgeDetailViewModel> data = await this.manager.GetInvoiceList(invoiceViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ARInvoiceAgeDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("GetInvoiceList")]
        public async Task<ActionResult> GetInvoiceList([FromBody] ARInvoiceAgeDetailViewModel invoiceViewModel)
        {

            IEnumerable<ARInvoiceAgeDetailViewModel> data = await this.manager.GetInvoiceCount(invoiceViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ARInvoiceAgeDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }




    }
}
