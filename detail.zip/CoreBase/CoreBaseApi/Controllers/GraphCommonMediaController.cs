﻿namespace CoreBaseApi.Controllers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;

    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class GraphCommonMediaController : ControllerBase
    {
        private readonly IGraphCommonMediaManager manager;

        public GraphCommonMediaController(IGraphCommonMediaManager dIManager)
        {
            this.manager = dIManager;
        }

        /// <summary>
        /// Get the list of Medias according to graph type.
        /// </summary>
        /// <param name="flagViewModel">Pass GraphCommonMediaViewModel as json format.</param>
        /// <returns>Return List of Medias according to graph.</returns>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] GraphCommonMediaViewModel flagViewModel)
        {
            flagViewModel.MediaModule = flagViewModel.MediaModule.ToLower();
            var count = 2000;
            IEnumerable<GraphCommonMediaViewModel> data = await this.manager.GetAllAsync(count, flagViewModel);
            return await Task.FromResult(this.Ok(UserResponse<GraphCommonMediaViewModel>.SendResponse(count, data)));
        }

        /// <summary>
        /// Save the Graph Medias into System according to Graph Name.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonMediaViewModel as json format.</param>
        /// <returns>Return either inserted Media GraphCommonMediaViewModel view or false (on insertion failed).</returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] GraphCommonMediaViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            string role = string.Empty;
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            viewModel.MediaModule = viewModel.MediaModule.ToLower();
            var data = await this.manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<GraphCommonMediaViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        /// <summary>
        /// Update the existing Medias of graph according to graph and Media id.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonMediaViewModel as json format.</param>
        /// <returns>return updated GraphCommonMediaViewModel of selected Media which need to modify.</returns>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody]GraphCommonMediaViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this.manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<GraphCommonMediaViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        /// Soft removal of existing Medias from system.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonMediaViewModel as json format.</param>
        /// <returns>Return either success or fail message to UI.</returns>
        [HttpPost(Constants.Identifire.Delete)]
        public async Task<IActionResult> Delete([FromBody] GraphCommonMediaViewModel viewModel)
        {
            var data = await this.manager.GetByIDAsync(viewModel).ConfigureAwait(false);
            if (data != null)
            {
                var result = await this.manager.DeleteAsync(viewModel, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<string>.SendResponse("Record not found"))).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Get Medias by its ID.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonMediaViewModel as json format.</param>
        /// <returns>Return GraphCommonMediaViewModel to UI on Id basis.</returns>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID([FromBody] GraphCommonMediaViewModel viewModel)
        {
            GraphCommonMediaViewModel data = await this.manager.GetByIDAsync(viewModel);
            return await Task.FromResult(this.Ok(UserResponse<GraphCommonMediaViewModel>.SendResponse(data)));
        }
    }
}