﻿namespace CoreBaseApi.Controllers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class GraphCommonCommentController : ControllerBase
    {
        private readonly IGraphCommonCommentManager manager;

        public GraphCommonCommentController(IGraphCommonCommentManager dIManager)
        {
            this.manager = dIManager;
        }

        /// <summary>
        /// Get the list of comments according to graph type.
        /// </summary>
        /// <param name="flagViewModel">Pass GraphCommonCommentViewModel as json format.</param>
        /// <returns>Return List of Comments according to graph.</returns>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] GraphCommonCommentViewModel flagViewModel)
        {
            flagViewModel.CommentModule = flagViewModel.CommentModule.ToLower();
            var count = 2000;
            IEnumerable<GraphCommonCommentViewModel> data = await this.manager.GetAllAsync(count, flagViewModel);
            return await Task.FromResult(this.Ok(UserResponse<GraphCommonCommentViewModel>.SendResponse(count, data)));
        }

        /// <summary>
        /// Save the Graph Comments into System according to Graph Name.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonCommentViewModel as json format.</param>
        /// <returns>Return either inserted comment GraphCommonCommentViewModel view or false (on insertion failed).</returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] GraphCommonCommentViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            string role = string.Empty;
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            viewModel.CommentModule = viewModel.CommentModule.ToUpper();
            var data = await this.manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<GraphCommonCommentViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        /// <summary>
        /// Update the existing comments of graph according to graph and comment id.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonCommentViewModel as json format.</param>
        /// <returns>return updated GraphCommonCommentViewModel of selected comment which need to modify.</returns>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody]GraphCommonCommentViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this.manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<GraphCommonCommentViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        /// Soft removal of existing comments from system.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonCommentViewModel as json format.</param>
        /// <returns>Return either success or fail message to UI.</returns>
        [HttpPost(Constants.Identifire.Delete)]
        public async Task<IActionResult> Delete([FromBody] GraphCommonCommentViewModel viewModel)
        {
            var data = await this.manager.GetByIDAsync(viewModel).ConfigureAwait(false);
            if (data != null)
            {
                var result = await this.manager.DeleteAsync(viewModel, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<string>.SendResponse("Record not found"))).ConfigureAwait(false);
            }
        }

        /// <summary>
        /// Get Comments by its ID.
        /// </summary>
        /// <param name="viewModel">Pass GraphCommonCommentViewModel as json format.</param>
        /// <returns>Return GraphCommonCommentViewModel to UI on Id basis.</returns>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID([FromBody] GraphCommonCommentViewModel viewModel)
        {
            GraphCommonCommentViewModel data = await this.manager.GetByIDAsync(viewModel);
            return await Task.FromResult(this.Ok(UserResponse<GraphCommonCommentViewModel>.SendResponse(data)));
        }
    }
}