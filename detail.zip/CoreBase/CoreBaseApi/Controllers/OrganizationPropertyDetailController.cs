﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationPropertyDetailController : ControllerBase
    {
        private readonly IOrganizationPropertyDetailManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public OrganizationPropertyDetailController(IOrganizationPropertyDetailManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpPost("Count")]
        public async Task<ActionResult> Count([FromBody] OrganizationPropertyDetailViewModel flagViewModel)
        {
            var count = await this._Manager.CountAsync(flagViewModel);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count)));
        }

        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] OrganizationPropertyDetailViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<OrganizationPropertyDetailViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
            return await Task.FromResult(Ok(UserResponse<OrganizationPropertyDetailViewModel>.SendResponse(Data.Count(), Data)));
        }
        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<OrganizationPropertyDetailViewModel> viewModel)
        {

            IEnumerable<OrganizationPropertyDetailViewModel> data = await this._Manager.SaveAll(viewModel);
            return await Task.FromResult(Ok(UserResponse<OrganizationPropertyDetailViewModel>.SendResponse(data.Count(), data)));
        }
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] OrganizationPropertyDetailViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<OrganizationPropertyDetailViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<OrganizationPropertyDetailViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost("DeleteByID")]
        public async Task<ActionResult> DeleteLocations([FromBody] OrganizationPropertyDetailViewModel deleteModel)
        {

            var response = await this._Manager.DeleteByIdsAsync(deleteModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(response))).ConfigureAwait(false);
        }

        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] OrganizationPropertyDetailViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<OrganizationPropertyDetailViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(OrganizationPropertyDetailViewModel organizationPropertyDetailViewModel)
        {
            var Data = await this._Manager.GetAsync(organizationPropertyDetailViewModel.ID).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion
        #region Get Records from Organization Details
        [HttpPost("GetAllRecords")]
        public async Task<IActionResult> GetAllRecords([FromBody] OrganizationPropertyDetailViewModel requestCommonViewModel)
        {
            
            IEnumerable<OrganizationPropertyDetailViewModel> data = await this._Manager.GetOrganizationPropertyDetailsList(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<OrganizationPropertyDetailViewModel>
                    .SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        #region Get Organization Characteristics
        [HttpPost("GetOrganizationCharacteristics")]
        public async Task<IActionResult> GetOrganizationCharacteristics([FromBody] EntityPropertyViewModel entityPropertyViewModel)
        {

            IEnumerable<EntityPropertyViewModel> data = await this._Manager.GetOrganizationCharacteristics(entityPropertyViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<EntityPropertyViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
    }
}
