﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class PartographHistoryController : ControllerBase
    {

        private readonly IPartographHistoryManager partographHistoryManager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public PartographHistoryController (IPartographHistoryManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this.partographHistoryManager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }



        /// <summary>
        /// Save ChartHistoryViewModel data with comment 
        /// </summary>
        [HttpPost("List")]
        public async Task<ActionResult> Post([FromBody] ChartHistoryViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            
            List<ChartHistoryViewModel> ListchartHistory= await this.partographHistoryManager.GetPartographHistory(viewModel);
            
            if (ListchartHistory.Count>0)
            {
                return await Task.FromResult(Ok(UserResponse<List<ChartHistoryViewModel>>.SendResponse(ListchartHistory)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

       



       
    }
}