﻿namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;

   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MouldingController : ControllerBase
    {
        private readonly IMouldingManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public MouldingController(IMouldingManager dIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = dIManager;
            this._hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Get All List for Measurement_MouldingMeasurementValue Data List
        /// </summary>
        /// <returns> <placeholder>A <see cref="Task"/> representing the asynchronous operation.</placeholder></returns>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] MouldingViewModel flagViewModel)
        {
            var count = await this._Manager.CountAsync(flagViewModel);
            if (count > 0)
            {
                IEnumerable<MouldingViewModel> data = await this._Manager.RangeAsync(count, flagViewModel);
                return await Task.FromResult(this.Ok(UserResponse<MouldingViewModel>.SendResponse(count, data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count, null)));
            }
        }

        /// <summary>
        /// Save Measurement_MouldingMeasurementValue data with comment and media into system
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] MouldingViewModel viewModel)
        {

            if (viewModel.ClientId == 0 || viewModel.ClientId == null)
            {
                this.ModelState.AddModelError("ClientError", "Please send client id");
            }

            if (viewModel.PatientId == 0 || viewModel.PatientId == null)
            {
                this.ModelState.AddModelError("PatientError", "Please send patient id");
            }

            if (viewModel.PartographId == 0 || viewModel.PartographId == null)
            {
                this.ModelState.AddModelError("PartographError", "Please send Partograph id");
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            string role = string.Empty;
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            // viewModel.UpdatedBy = base.CurrentUserEmail;
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(result: this.Ok(UserResponse<MouldingViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        /// <summary>
        /// Update the Measurement_MouldingMeasurementValue data with comment and media also update the existing comment
        /// and media as well
        /// /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] MouldingViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            // viewModel.UpdatedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<MouldingViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        /// Delete (soft removal) existing Measurement_MouldingMeasurementValue data from system 
        ///
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(long id)
        {
            var data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            //var CurrentUserEmail = base.CurrentUserEmail;

            if (data != null)
            {
                await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<MouldingViewModel>.SendResponse(data))).ConfigureAwait(false);
            }
            return await Task.FromResult(this.Ok(UserResponse<string>.SendResponse("No records found"))).ConfigureAwait(false);
        }



        /// <summary>
        /// Get the Measurement_MouldingMeasurementValue Records from Existing System By Measurement_MouldingMeasurementValue ID
        /// if any comments and media exist then it records also avaialble 
        /// </summary>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID([FromBody] MouldingViewModel viewModel)
        {
            MouldingViewModel Data = await this._Manager.GetAsync(viewModel.Id);
            return await Task.FromResult(this.Ok(UserResponse<MouldingViewModel>.SendResponse(Data)));
        }
    }
}