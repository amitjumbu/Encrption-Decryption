﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Managers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft;
using Newtonsoft.Json.Linq;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ChartMeasurmentValueController : ControllerBase
    {
        
        private readonly IChartMeasurementValueManager chartMeasurementValueManager;
       
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public ChartMeasurmentValueController(IChartMeasurementValueManager _chartMeasurementValueManager, IHostingEnvironment hostingEnvironment)
        {
            this.chartMeasurementValueManager = _chartMeasurementValueManager;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpPost]
        public async Task<ActionResult> SaveChartData([FromBody] ChartMeasurementValueViewModel chartMeasurementViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.chartMeasurementValueManager.AddAsync(chartMeasurementViewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<ChartMeasurementValueViewModel>.SendResponse(chartMeasurementViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }



        [HttpPost]
        public async Task<ActionResult> SavePageChartData([FromBody] List<ChartMeasurementValueViewModel> chartMeasurementViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.chartMeasurementValueManager.AddAllAsync(chartMeasurementViewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<List<ChartMeasurementValueViewModel>>.SendResponse(chartMeasurementViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        [HttpGet]
        public async Task<ActionResult> GetAll([FromBody] ChartMeasurementValueViewModel chartMeasurementViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.chartMeasurementValueManager.GetAllAsync(1000,chartMeasurementViewModel);

            return await Task.FromResult(this.Ok(UserResponse<IEnumerable<ChartMeasurementValueViewModel>>.SendResponse(data)));
        }

        [HttpGet]
        public async Task<ActionResult> GetByID(int id)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.chartMeasurementValueManager.GetAsync(id);

            return await Task.FromResult(this.Ok(UserResponse<ChartMeasurementValueViewModel>.SendResponse(data)));
        }



        [HttpPost]
        public async Task<IActionResult> UpdateChartData([FromBody]ChartMeasurementValueViewModel chartMeasurementViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.chartMeasurementValueManager.UpdateAsync(chartMeasurementViewModel);
            if (result)
            {
                return await Task.FromResult(this.Ok(UserResponse<ChartMeasurementValueViewModel>.SendResponse(chartMeasurementViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        [HttpPost]
        public async Task<IActionResult> Delete([FromBody]EntityRecordRemoveRequestPacket chartMeasurementRequestPacket)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.chartMeasurementValueManager.Delete(chartMeasurementRequestPacket);
            if (result)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }



    }
}