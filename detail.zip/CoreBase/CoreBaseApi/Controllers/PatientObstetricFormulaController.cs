﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class PatientObstetricFormulaController : ControllerBase
    {
        private readonly IPatientObstetricFormulaManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public PatientObstetricFormulaController(IPatientObstetricFormulaManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion
        
        #region List of records displayed
        // List of records displayed
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] PatientObstetricFormulaViewModel patientobstetricFormulaViewModel)
        {
            var Count = await this._Manager.CountAsync(patientobstetricFormulaViewModel);
            if (Count > 0)
            {
                IEnumerable<PatientObstetricFormulaViewModel> Data = await this._Manager.RangeAsync(Count, patientobstetricFormulaViewModel);
                return await Task.FromResult(Ok(UserResponse<PatientObstetricFormulaViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }
        #endregion

        #region Update the Record
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] PatientObstetricFormulaViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientObstetricFormulaViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }
        #endregion
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] PatientObstetricFormulaViewModel patientobstetricFormula)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this._Manager.AddAsync(patientobstetricFormula);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<PatientObstetricFormulaViewModel>.SendResponse(patientobstetricFormula)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }
        [HttpGet(Constants.Identifire.GetChoiceofBirthingPartner)]
        public async Task<ActionResult> GetChoiceofBirthingPartner()
        {
            //int ClientID = 100;
            //if (ClientID == 0)
            //{
            //    this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            //}

            var data = this._Manager.GetChoiceofBirthingPartner();
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<ChoiceOfBirthingPartnerViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
    }
}