﻿namespace CoreBaseAPI.Controllers
{
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    ///  Operates on Charge to Computation Method Mapping.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ChargeComputationMethodMappingController : ControllerBase
    {
        private readonly IChargeComputationMethodMappingManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeComputationMethodMappingController"/> class.
        /// </summary>
        /// <param name="manager">Charge Computation Method Manager with the help of DI.</param>
        public ChargeComputationMethodMappingController(IChargeComputationMethodMappingManager manager)
        {
            this.manager = manager;
        }

        /// <summary>
        /// Get List for all Charges to Computation Mapping along with details.
        /// </summary>
        /// <param name="viewModel"> Model should contain pageNo,pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<ActionResult> GetChargeCOmputationMethodMappingDetails([FromBody] ChargeComputationMethodMappingViewModel viewModel)
        {

            IEnumerable<ChargeComputationMethodMappingViewModel> data = await this.manager.GetChargeCompuationMethodMappingDetails(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeComputationMethodMappingViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Update Charges to Computation Mapping along with details.
        /// </summary>
        /// <param name="viewModel"> Model to be updated.</param>
        [HttpPost]
        public async Task<ActionResult> UpdateMappingDetails([FromBody] ChargeComputationMethodMappingViewModel viewModel)
        {

            var response = await this.manager.UpdateAsync(viewModel);
            if (response)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeComputationMethodMappingViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<ChargeComputationMethodMappingViewModel>.SendResponse(null)));
            }
        }

        /// <summary>
        /// this end point will get the ratetype of perticulare chagre.
        /// </summary>
        /// <param name="viewModel">chagreid and clientid must be send.</param>
        /// <returns>return list of mapped ratetype.</returns>
        [HttpPost(Constants.Identifire.GetRateTypeOfChargeID)]
        public async Task<ActionResult> GetRateTypeOfChargeID([FromBody] ChargeComputationMethodMappingViewModel viewModel)
        {
            if (viewModel.ClientID == null || viewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (viewModel.ChargeId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<ChargeComputationMethodMappingForOrderViewModel> data = await this.manager.GetChargeComputationMethodsForPerticularCharge(viewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<ChargeComputationMethodMappingForOrderViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
    }
}
