﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialGroupDetailController : ControllerBase
    {
        private readonly IMaterialGroupDetailsManager manager;

        public MaterialGroupDetailController(IMaterialGroupDetailsManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost("GetMaterialGroupDetailById")]
        public async Task<IActionResult> GetMaterialGroupDetailById([FromBody] MaterialGroupDetailsViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.GetMaterialGroupDetailById(viewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialGroupDetailsViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("CountTotalMGD")]
        public async Task<IActionResult> GetCountMGD([FromBody] MaterialGroupDetailsViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.CountMGDAsync(commonViewModel);

            if (finalResult != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }
    }
}
