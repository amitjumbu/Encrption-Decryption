﻿namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class UserAlertController : ControllerBase
    {
        private readonly IUserAlertManager manager;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly IMapper mapper;

        public UserAlertController(IUserAlertManager dIManager, IWebHostEnvironment hostingEnvironment)
        {
            this.manager = dIManager;
            this.hostingEnvironment = hostingEnvironment;
        }
        [HttpGet(Constants.Identifire.GetAll)]
        public async Task<ActionResult> GetAllAlert()
        {

            IEnumerable<UserAlertSPViewModel> data = await this.manager.GetAllAlerts(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<UserAlertSPViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Get All System Alerts.
        /// </summary>
        /// <param name="flagViewModel">View Model of System Alert, Which Will be use for filter purpose only.</param>
        /// <returns>list of system alert list.</returns>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] UserAlertViewModel flagViewModel)
        {
            var count = await this.manager.CountAsync(flagViewModel);
            IEnumerable<UserAlertSPViewModel> data = await this.manager.GetAllAlerts(flagViewModel);
            if (data != null && data.Count() > 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<UserAlertSPViewModel>.SendResponse(count, data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count, null)));
            }
        }

        /// <summary>
        /// this method use to save the useralerts into system.
        /// </summary>
        /// <param name="userAlertViewModel">User Alert view Model.</param>
        /// <returns>true on success and false on fail.</returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] UserAlertViewModel userAlertViewModel)
        {
            if (userAlertViewModel.ClientId == null || userAlertViewModel.ClientId == 0)
            {
                this.ModelState.AddModelError("InvalidClient", Constants.Errors.InvalidClient);
            }
            else if (userAlertViewModel.CreateDateTimeBrowser == null || userAlertViewModel.CreateDateTimeBrowser < DateTime.Now.AddDays(-2))
            {
                this.ModelState.AddModelError("InvalidCreatedDate", Constants.Errors.InvalidCreatedDate);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = this.manager.AddAsync(userAlertViewModel);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
        }


        /// <summary>
        /// this method use to update the useralerts into system.
        /// </summary>
        /// <param name="userAlertViewModel">User Alert view Model.</param>
        /// <returns>true on success and false on fail.</returns>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<ActionResult> Update([FromBody] UserAlertViewModel userAlertViewModel)
        {
            if (userAlertViewModel.ClientId == null || userAlertViewModel.ClientId == 0)
            {
                this.ModelState.AddModelError("InvalidClient", Constants.Errors.InvalidClient);
            }

            if (userAlertViewModel.Id == 0)
            {
                this.ModelState.AddModelError("InvalidID", Constants.Errors.InvalidID);
            }

            if (userAlertViewModel.UpdateDateTimeBrowser == null || userAlertViewModel.UpdateDateTimeBrowser < DateTime.Now.AddDays(-2))
            {
                this.ModelState.AddModelError("InvalidCreatedDate", Constants.Errors.InvalidCreatedDate);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = this.manager.UpdateAsync(userAlertViewModel);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
        }


        /// <summary>
        /// Activate the User Alerts.
        /// </summary>
        /// <param name="userAlertActive">List of Ids comma seprated.</param>
        /// <returns>true on success/false on fail.</returns>
        /// [HttpPost(Constants.Identifire.List)]
        [HttpPost(Constants.Identifire.ActiveAll)]
        public async Task<ActionResult> ActiveAll([FromBody] UserAlertActive userAlertActive)
        {
            var allIds = userAlertActive.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.ActivateUserAlert(allIds, userAlertActive.IsActive);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        /// <summary>
        /// Softly Delete the User Alerts.
        /// </summary>
        /// <param name="userAlertActive">List of Ids comma seprated.</param>
        /// <returns>true on success/false on fail.</returns>
        /// [HttpPost(Constants.Identifire.List)]
        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] UserAlertActive userAlertActive)
        {
            var allIds = userAlertActive.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        /// <summary>
        /// GetUserAlert Information on ID basis.
        /// </summary>
        /// <param name="userAlertViewModel">Get User Alert View Model.</param>
        /// <returns>return full detail view model.</returns>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<ActionResult> GetByID([FromBody] UserAlertViewModel userAlertViewModel)
        {
            if (userAlertViewModel.ClientId == null || userAlertViewModel.ClientId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (userAlertViewModel.Id == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var userAlertData = this.manager.GetAsync(userAlertViewModel.Id).Result;

            if (userAlertData != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<UserAlertViewModel>.SendResponse(userAlertData)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userAlertViewModel"></param>
        /// <returns></returns>
        [HttpPost(Constants.Identifire.GetDetail)]
        public async Task<ActionResult> GetDetail([FromBody] UserAlertViewModel userAlertViewModel)
        {
            if (string.IsNullOrEmpty(userAlertViewModel.Name))
            {
                this.ModelState.AddModelError("InvalidID", Constants.Errors.InvalidName);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var userAlertData = this.manager.ListAsync(userAlertViewModel).Result;

            if (userAlertData != null)
            {
                var selectedUserAlert = userAlertData.FirstOrDefault(p => p.Name.ToLower().Trim().Equals(userAlertViewModel.Name.ToLower().Trim()));
                if (selectedUserAlert != null)
                {
                    return await Task.FromResult(this.Ok(UserResponse<UserAlertViewModel>.SendResponse(selectedUserAlert)));
                }
                else
                {
                    return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
                }
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }
    }
}