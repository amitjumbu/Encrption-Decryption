﻿namespace CoreBaseApi.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class SystemAlertController : ControllerBase
    {
        private readonly ISystemAlertManager manager;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly IMapper mapper;

        public SystemAlertController(ISystemAlertManager dIManager, IWebHostEnvironment hostingEnvironment)
        {
            this.manager = dIManager;
            this.hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Get All System Alerts.
        /// </summary>
        /// <param name="flagViewModel">View Model of System Alert, Which Will be use for filter purpose only.</param>
        /// <returns>list of system alert list.</returns>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] SystemAlertViewModel flagViewModel)
        {
            var count = await this.manager.CountAsync(flagViewModel);
            IEnumerable<SystemAlertViewModel> data = await this.manager.RangeAsync(count, flagViewModel);
            if (data != null && data.Count() > 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<SystemAlertViewModel>.SendResponse(count, data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count, null)));
            }
        }
    }
}