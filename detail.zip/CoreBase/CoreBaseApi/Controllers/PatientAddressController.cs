﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PatientAddressController : ControllerBase
    {


        private readonly IPatientAddressValueManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;


        public PatientAddressController(IPatientAddressValueManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        ///User can get Retrieves data from Patient Address page wise.hi
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> getList([FromBody] PatientAddressValueViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<PatientAddressValueViewModel> goldenMaster = await this._Manager.RangeAsync(Count, flagViewModel);
            return await Task.FromResult(Ok(UserResponse<PatientAddressValueViewModel>.SendResponse(Count, goldenMaster)));
        }

        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> patientAddressPost_([FromBody] PatientAddressValueViewModel viewModel)
        {
            viewModel.CreateDateTimeServer = DateTime.UtcNow;
            viewModel.UpdateDateTimeServer = DateTime.UtcNow;
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientAddressValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        public async Task<ActionResult> patientAddressPost([FromBody] PatientAddressValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            viewModel.CreateDateTimeServer = DateTime.UtcNow;
            viewModel.UpdateDateTimeServer = DateTime.UtcNow;
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientAddressValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }



        /// <summary>
        /// update Patient Address data flag wise.
        /// </summary>
        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] PatientAddressValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientAddressValueViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        ///delete Patient Address behalf of id
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientAddressValueViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }

    }
}
