﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialHierarchyController : ControllerBase
    {
        private readonly IMaterialHierarchyManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="MaterialHierarchyController"/> class.
        /// </summary>
        /// <param name="manager">MaterialHierarchy Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public MaterialHierarchyController(IMaterialHierarchyManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<IActionResult> ListMaterialHierarchyAsync([FromBody] MaterialHierarchyViewModel requestCommonViewModel)
        {
            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<MaterialHierarchyViewModel> data = await this.manager.ListMaterialHierarchyAsync(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<MaterialHierarchyViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        #region Total Material Hierarchy Record Count

        [HttpPost("TotalMHRecordCount")]
        public async Task<ActionResult> GetRecordCount([FromBody] MaterialHierarchyViewModel viewModel)
        {
            var count = await this.manager.RecordCountAsync(viewModel);
            if (count != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }

        #endregion
    }
}
