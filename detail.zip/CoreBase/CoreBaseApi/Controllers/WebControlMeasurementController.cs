﻿namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Helpers.Enums;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;

   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class WebControlMeasurementController : ControllerBase
    {
        private readonly IWebControlTypeManager _Manager;
        private readonly IWebControlTypePossibleValueManager _ManagerPosibleValue;
        private readonly IDynamicMeasurementManager _ManagerDynamicMeasurement;
        private readonly IValidationManager _ManagerValidaion;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public WebControlMeasurementController(IValidationManager DIManagerValiation, IDynamicMeasurementManager DIManagerDynamicMeasurement, IWebControlTypePossibleValueManager DIManagerPosibleValue, IWebControlTypeManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            this._ManagerPosibleValue = DIManagerPosibleValue;
            this._ManagerDynamicMeasurement = DIManagerDynamicMeasurement;
            this._ManagerValidaion = DIManagerValiation;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        ///Get All List for BP Data List
        /// </summary>
        [HttpPost("GetWebControlType")]
        public async Task<ActionResult> GetWebControlType([FromBody] WebControlTypeViewModel flagViewModel)
            {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<WebControlTypeViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<WebControlTypeViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }

        [HttpPost("GetPossibleValues")]
        public async Task<ActionResult> GetPossibleValueList([FromBody] WebControlTypePossibleValueViewModel flagViewModel)
        {
            if (flagViewModel.WebControlTypeID == 0 || flagViewModel.WebControlTypeID == null)
            {
                this.ModelState.AddModelError("WebControlTypeID", "Please send WebControlTypeID");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var Count = await this._ManagerPosibleValue.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<WebControlTypePossibleValueViewModel> Data = await this._ManagerPosibleValue.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<WebControlTypePossibleValueViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }


        [HttpPost("GetDynamicMeasurementList")]
        public async Task<ActionResult> GetDynamicMeasurementList([FromBody] DynamicMeasurementViewModel flagViewModel)
        {
            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var Count = await this._ManagerDynamicMeasurement.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<DynamicMeasurementViewModel> Data = await this._ManagerDynamicMeasurement.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<DynamicMeasurementViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }


        [HttpPost("GetValidationMeasurement")]
        public async Task<ActionResult> GetValidationMeasurement([FromBody] ValidationViewModel flagViewModel)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var Count = await this._ManagerValidaion.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<ValidationViewModel> Data = await this._ManagerValidaion.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<ValidationViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }



        [HttpPost("GetDynamicWebcontrolParametersList")]
        public async Task<ActionResult> GetDynamicWebcontrolParametersList([FromBody] DynamicWebcontrolParameterViewModel viewModel)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            List<DynamicWebcontrolParameterViewModel> listData = await this._ManagerPosibleValue.GetDynamicWebcontrolParameterTable(viewModel);

            if (listData.Count > 0)
            {
                return await Task.FromResult(Ok(UserResponse<List<DynamicWebcontrolParameterViewModel>>.SendResponse(listData)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }



        [HttpPost("AddDynamicParameter")]
        public async Task<ActionResult> AddDynamicParameter([FromBody] AddDynamicMeasurementParameterViewModel viewModel)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            List<DynamicWebcontrolParameterViewModel> listData = await this._ManagerPosibleValue.SaveDynamicParameter(viewModel);

            if (listData.Count > 0)
            {
                return await Task.FromResult(Ok(UserResponse<List<DynamicWebcontrolParameterViewModel>>.SendResponse(listData)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }


        [HttpPost("AddDynamicParameterValues")]
        public async Task<ActionResult> AddDynamicParameterValues([FromBody] List<DynamicMeasurementParameterValueViewModel> viewModel)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            int Result = await this._ManagerPosibleValue.FinalSaveDynamicParameter(viewModel);

            if (Result > 0)
            {
                return await Task.FromResult(Ok(UserResponse<List<DynamicMeasurementParameterValueViewModel>>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }



    }
}