﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CriticalPatientMonitoringGridController : ControllerBase
    {
        private readonly ICriticalPatientMonitoringGridManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public CriticalPatientMonitoringGridController(ICriticalPatientMonitoringGridManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion
        
        #region List of records displayed
        // List of records displayed
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] CriticalPatientMonitoringGridViewModel criticalPatientMonitoringGrid)
        {
            var Count = await this._Manager.CountAsync(criticalPatientMonitoringGrid);
            if (Count > 0)
            {
                IEnumerable<CriticalPatientMonitoringGridViewModel> Data = await this._Manager.RangeAsync(Count, criticalPatientMonitoringGrid);
                return await Task.FromResult(Ok(UserResponse<CriticalPatientMonitoringGridViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
            //IEnumerable<object> goldenMaster = this._Manager.GetCriticalPatientGridRecords(criticalPatientMonitoringGrid);
            //return await Task.FromResult(Ok(UserResponse<object>.SendResponse(goldenMaster)));
        }
        #endregion

        [HttpPost(Constants.Identifire.GetAllCriticalpatientmonitoringList)]
        public async Task<IActionResult> GetAllCriticalpatientmonitoringList([FromBody] CriticalPatientMonitoringGridViewModel criticalpatientmonitoringViewModel)
        {
            if (criticalpatientmonitoringViewModel.PartogrpahId == null || criticalpatientmonitoringViewModel.PartogrpahId <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            

            var finalResult = await this._Manager.GetCriticalPatientMonitoringGridList(criticalpatientmonitoringViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<CriticalPatientMonitoringGridViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        #region Save list of records 
        // Save list of records 
        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<IActionResult> SaveAll(IEnumerable<CriticalPatientMonitoringGridViewModel> viewModel)
        {
            var data = await this._Manager.SaveAll(viewModel).ConfigureAwait(false);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }
        #endregion

        #region Update the Record
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] CriticalPatientMonitoringGridViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<CriticalPatientMonitoringGridViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }
        #endregion

    }
}