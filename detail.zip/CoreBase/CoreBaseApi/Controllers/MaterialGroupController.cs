﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialGroupController : ControllerBase
    {
        private readonly IMaterialGroupManager manager;

        public MaterialGroupController(IMaterialGroupManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<IActionResult> GetAllMaterialGroupData([FromBody] MaterialGroupViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetAllMaterialGroupData(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialGroupViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }
    }
}
