﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ShippingLocationDefaultPackagingMaterialController : ControllerBase
    {
        private readonly IShippingLocationDefaultPackagingMaterialManager _Manager;
        //private readonly ILocationManager Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public ShippingLocationDefaultPackagingMaterialController(IShippingLocationDefaultPackagingMaterialManager DIManager, IHostingEnvironment hostingEnvironment, IInstanseLogger instanceLogger)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
            this.instanceLogger = instanceLogger;
        }


        /// <summary>
        ///User can get Retrieves data from LocationContact by id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Get Default Pallet Data", Data);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///Get All List for Location Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] ShippingLocationDefaultPackagingMaterialViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<ShippingLocationDefaultPackagingMaterialViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                this.instanceLogger.AddInstanseLogger("List Of Default Pallet", Data);
                return await Task.FromResult(Ok(UserResponse<ShippingLocationDefaultPackagingMaterialViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="shippingLocationDefaultPackagingMaterialModel"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] ShippingLocationDefaultPackagingMaterialViewModel shippingLocationDefaultPackagingMaterialModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.AddAsync(shippingLocationDefaultPackagingMaterialModel);
            this.instanceLogger.AddInstanseLogger("Save Default Pallet", data);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<ShippingLocationDefaultPackagingMaterialViewModel>.SendResponse(shippingLocationDefaultPackagingMaterialModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }



        /// <summary>
        ///Update the LocationContact Data
        ///and media as well
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] ShippingLocationDefaultPackagingMaterialViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //viewModel.UpdatedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<ShippingLocationDefaultPackagingMaterialViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }



        


        /// <summary>
        ///User can get list by locatinId.
        /// </summary>
        [HttpGet(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID(int id)
        {
            IEnumerable<ShippingLocationDefaultPackagingMaterialViewModel> Data = await this._Manager.GetList(id);
            this.instanceLogger.AddInstanseLogger("Default List By Id", Data);
            return await Task.FromResult(Ok(UserResponse<ShippingLocationDefaultPackagingMaterialViewModel>.SendResponse(1, Data)));
        }


    
        /// <summary>
        ///Delete (soft removal) existing LocationContact data from system 
        ///
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Get Default Pallet By Id", Data);
            //var CurrentUserEmail = base.CurrentUserEmail;

            if (Data != null)
            {
                await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(Ok(UserResponse<ShippingLocationDefaultPackagingMaterialViewModel>.SendResponse(Data))).ConfigureAwait(false);
            }
            return await Task.FromResult(Ok(UserResponse<string>.SendResponse("No records found"))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteByID)]
        public async Task<ActionResult> DeleteDefaultPalletAsync([FromBody] ShippingLocationDefaultPackagingMaterialViewModel viewModel)
        {
            var data = await this._Manager.DeleteAllAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }





    }
}