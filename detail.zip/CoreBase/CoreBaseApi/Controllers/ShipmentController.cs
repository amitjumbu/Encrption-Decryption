﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity2;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ShipmentController : ControllerBase
    {
        private readonly IShipmentManager _Shipment;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public ShipmentController(IShipmentManager DIShipment, IHostingEnvironment hostingEnvironment)
        {
            this._Shipment = DIShipment;
            _hostingEnvironment = hostingEnvironment;
        }


        /// <summary>
        ///User can get Retrieves data from Shipment by id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Shipment.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///Get All List for Shipment Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] ShipmentViewModel flagViewModel)
        {
            var Count = await this._Shipment.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<ShipmentViewModel> Data = await this._Shipment.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<ShipmentViewModel>.SendResponse(Count, Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetShipmentOrders)]
        public async Task<IActionResult> GetShipmentOrders([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var Data = await this._Shipment.GetShipmentOrders(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetLoctionsForShipment)]
        public async Task<IActionResult> GetLoctionsForShipment(LocationForshipmentParameter viewmodel)
        {
            var Data = await this._Shipment.GetLoctionsForShipment(viewmodel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetTenderStatusForShipment)]
        public async Task<IActionResult> GetTenderStatusForShipment()
        {
            var Data = await this._Shipment.GetTenderStatusForShipment().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetShipmentDetails)]
        public async Task<IActionResult> GetShipmentDetails([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var Data = await this._Shipment.GetShipmentDetails(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetShipmentDetails)]
        public async Task<IActionResult> GetShipmentDetails()                                             
        {

            var Data = await this._Shipment.GetShipmentDetails().ConfigureAwait(false);
            // var Data = await this._Shipment.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetShipmentDetailsAll)]
        public async Task<ActionResult> GetShipmentDetailsAll([FromBody] ShipmentOrderDetailViewModel shipmentSaveDataViewModel)
        {
            IEnumerable<ShipmentOrderDetailViewModel> TotalData = await this._Shipment.GetShipmentAllDetailsCount(shipmentSaveDataViewModel);
            IEnumerable<ShipmentDetailsViewModel> data = await this._Shipment.GetShipmentAllDetails(shipmentSaveDataViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ShipmentDetailsViewModel>.SendResponse(TotalData.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetShipmentDetailsAllCount)]
        public async Task<ActionResult> GetShipmentDetailsAllCount([FromBody] ShipmentOrderDetailViewModel shipmentSaveDataViewModel)
        {

            IEnumerable<ShipmentOrderDetailViewModel> data = await this._Shipment.GetShipmentAllDetailsCount(shipmentSaveDataViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ShipmentOrderDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetApcharges)]
       // [Route("~/api/[controller]/GetApcharges/{Id}")]
        public async Task<IActionResult> GetApcharges([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var Data = await this._Shipment.GetApcharges(flagViewModel).ConfigureAwait(false);
            // var Data = await this._Shipment.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
  
        [HttpPost(Constants.Identifire.SaveShipment)]
        public async Task<IActionResult> SaveShipment(ShipmentSaveData shipmentsavedata)
        {     
            var data = await this._Shipment.SaveShipmentDetails(shipmentsavedata).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetShipmentOrdersDetails)]
        public async Task<IActionResult> GetShipmentOrdersDetails([FromBody] ShipmentCommonModel flagViewModel)
        {
            

            var Data = await this._Shipment.GetShipmentOrdersDetails(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        /// this end point send shipment detail into mas asynchornously.
        /// </summary>
        /// <param name="flagViewModel">view model which holds the information about shipment.</param>
        /// <returns>true</returns>
        [HttpPost(Constants.Identifire.ApproveSendShipmentToMAS)]
        public async Task<IActionResult> ApproveSendShipmentToMAS([FromBody] ShipmentCommonModel flagViewModel)
        {
            //if (flagViewModel.ClientID == 0)
            //{
            //    this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            //}

            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var result = await this._Shipment.ApproveSendShipmentToMAS(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result))).ConfigureAwait(false);
        }
        /// <summary>
        /// this end point send shipment order details for the selected shipment.
        /// </summary>
        /// <param name="flagViewModel">view model which holds the information about shipment.</param>
        /// <returns>true</returns>
        [HttpPost(Constants.Identifire.GetShipmentOrdersDetailsForShipmentId)]
        public async Task<IActionResult> GetShipmentOrdersDetailsForShipmentId([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var Data = await this._Shipment.GetShipmentOrdersDetailsForShipmentId(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetOrderAmountforAPCharges)]
        public async Task<IActionResult> GetOrderAmountforAPCharges([FromBody] apchargesInputModel apchargesInput)
        {
            var Data = await this._Shipment.GetOrderAmountforAPCharges(apchargesInput).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetOrderTypeForShipment)]
        public async Task<IActionResult> GetOrderTypeForShipment()
        {
            var Data = await this._Shipment.GetOrderTypeForShipment().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetShipmentStatusForShipment)]
        public async Task<IActionResult> GetShipmentStatusForShipment()
        {
            var Data = await this._Shipment.GetShipmentStatusForShipment().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetShipmentConditionForShipment)]
        public async Task<IActionResult> GetShipmentConditionForShipment()
        {
            var Data = await this._Shipment.GetShipmentConditionForShipment().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpGet(Constants.Identifire.GetModeForShipment)]
        public async Task<IActionResult> GetModeForShipment()
        {
            var Data = await this._Shipment.GetModeForShipment().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.Tonu)]
        public async Task<IActionResult> Tonu([FromBody] ShipmentUpdateModel TonuInput)
        {
            var Data = await this._Shipment.Tonu(TonuInput).ConfigureAwait(false);
            if (Data != null)
            {
               return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.Cancel)]
        public async Task<IActionResult> Cancel([FromBody] ShipmentUpdateModel TonuInput)
        {
            var Data = await this._Shipment.Cancel(TonuInput).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.SaveShipmentOrders)]
        public async Task<IActionResult> SaveShipmentOrders([FromBody] ShipmentOrdersSaveModel shipmentOrdersdetails)
        {
            var Data = await this._Shipment.SaveShipmentOrders(shipmentOrdersdetails).ConfigureAwait(false);
            if (Convert.ToInt32(Data) == 1)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
        }

        [HttpPost(Constants.Identifire.ShipSelectedShipment)]
        public async Task<IActionResult> ShipSelectedShipment([FromBody] ShipmentSaveData shipmentdetails)
        {
            var Data = await this._Shipment.ShipSelectedShipment(shipmentdetails).ConfigureAwait(false);

            if (Data != null)
            {

                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);

            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

      
        [HttpPost(Constants.Identifire.ReceiveSelectedShipment)]
        public async Task<IActionResult> ReceiveSelectedShipment([FromBody] ShipmentSaveData shipmentdetails)
        {
            var Data = await this._Shipment.ReceiveSelectedShipment(shipmentdetails).ConfigureAwait(false);
            if (Convert.ToInt32(Data) == 1)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
        }

        [HttpPost(Constants.Identifire.GetshipFromtypeAll)]
        public async Task<IActionResult> GetshipFromtypeAll([FromBody] ShipmentSaveData shipmentdetails)
        {
            var Data = await this._Shipment.GetshipFromtypeAll(shipmentdetails).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
        }

        [HttpPost(Constants.Identifire.GetshiptotypeAll)]
        public async Task<IActionResult> GetshiptotypeAll([FromBody] ShipmentSaveData shipmentdetails)
        {
            var Data = await this._Shipment.GetshiptotypeAll(shipmentdetails).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
        }

        [HttpPost(Constants.Identifire.GetshipFromAllData)]
        public async Task<IActionResult> GetshipFromAllData([FromBody] ShipmentSaveData shipmentdetails)
        {
            var Data = await this._Shipment.GetshipFromAllData(shipmentdetails).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
        }
        [HttpPost(Constants.Identifire.GetshipToAllData)]
        public async Task<IActionResult> GetshipToAllData([FromBody] ShipmentSaveData shipmentdetails)
        {
            var Data = await this._Shipment.GetshipToAllData(shipmentdetails).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
            }
        }

        [HttpPost(Constants.Identifire.GetChargetypeforApcharges)]
        public async Task<IActionResult> GetChargetypeforApcharges([FromBody] apchargesInputModel apchargesInput)
        {
            var Data = await this._Shipment.GetChargetypeforApcharges(apchargesInput).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        /// Get Nafta Report By Shipping Id
        /// </summary>
        [HttpGet("GetCciReportById/{shipmentId}")]
        public async Task<IActionResult> GetCciReportById(long shipmentId)
        {
            if (shipmentId == 0)
            {
                return BadRequest("Invalid shipping id.");
            }
            var data = await this._Shipment.GetCciReportById(shipmentId).ConfigureAwait(false);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, data))).ConfigureAwait(false);
            }
        }

        [HttpPost(Constants.Identifire.ReSendShipmentToMAS)]
        public async Task<IActionResult> ReSendShipmentToMAS([FromBody] ShipmentCommonModel flagViewModel)
        {
            var Data = await this._Shipment.ReSendSelectedShipmentToMAS(flagViewModel).ConfigureAwait(false);

            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);

            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


      
        [HttpPost(Constants.Identifire.TPQFailSendShipmentToMAS)]
        public async Task<IActionResult> TPQFailSendShipmentToMAS([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var Data = await this._Shipment.TPQFailSendShipmentToMAS(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        //manage custom filter
        [HttpPost(Constants.Identifire.CreateManageFilter)]
        public async Task<ActionResult> CreateManageFilter([FromBody] CreateFilter createFilter)
        {
            if (createFilter.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Shipment.SaveCreateManageFilter(createFilter);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpGet(Constants.Identifire.GetAllCustomManageFilters)]
        public async Task<ActionResult> GetAllCustomManageFilters(int clientId, int userId, string selectedTab)
        {
            var Data = await this._Shipment.GetAllCustomManageFiltersData(clientId, userId, selectedTab).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<IEnumerable<CreateFilter>>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        [HttpPost(Constants.Identifire.UpdateManageFilter)]
        public async Task<ActionResult> UpdateManageFilter(CreateFilter createFilter)
        {
            if (createFilter.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Shipment.UpdateManageFilters(createFilter);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpPost(Constants.Identifire.DeleteManageFilter)]
        public async Task<ActionResult> DeleteManageFilter(CreateFilter createFilter)
        {
            if (createFilter.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Shipment.DeleteManageFilters(createFilter);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }


        [HttpGet(Constants.Identifire.GetUOMforApcharespopup)]
        public async Task<IActionResult> GetUOMforApcharespopup()
        {
            var Data = await this._Shipment.GetUOMforApcharespopup().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        
   [HttpPost(Constants.Identifire.GetProformaInvoiceData)]
        public async Task<IActionResult> GetProformaInvoiceData([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var Data = await this._Shipment.GetProformaInvoiceData(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }




        [HttpPost(Constants.Identifire.ShipmentReCalculate)]
        public async Task<ActionResult> ShipmentReCalculate([FromBody] ShipmentViewModel shipmentViewModel)
        {

            if (shipmentViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var result = await this._Shipment.RecalculateShipment(shipmentViewModel);
            return await Task.FromResult(this.Ok(UserResponse<ValidationResponse>.SendResponse(result)));

        }


        [HttpPost(Constants.Identifire.GetProformaInvoiceOrganizationAddress)]
        public async Task<IActionResult> GetProformaInvoiceOrganizationAddress([FromBody] ShipmentCommonModel flagViewModel)
        {
            if (flagViewModel.ShipmentID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var Data = await this._Shipment.GetProformaInvoiceOrganizationAddress().ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }



        [HttpPost(Constants.Identifire.GetApchargesDuetoLocChange)]
        public async Task<IActionResult> GetApchargesDuetoLocChange([FromBody] ApchargeLocChangeModel apchargeLocChangeModel)
        {
            if (apchargeLocChangeModel.shipmentid == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var Data = await this._Shipment.GetApchargesDuetoLocChange(apchargeLocChangeModel).ConfigureAwait(false);
            // var Data = await this._Shipment.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

    }
}