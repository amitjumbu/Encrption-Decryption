﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class SalesOrderController : ControllerBase
    {
        private readonly ISalesOrderManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public SalesOrderController(ISalesOrderManager manager, IOptions<ConfigurationKeys> configurationKeys)
        //ISalesOrderManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = manager;
            // _hostingEnvironment = hostingEnvironment;
        }


        /// <summary>
        ///User can get Retrieves data from SalesOrder by id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(long Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///Get All List for SalesOrder Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] SalesOrderViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<SalesOrderViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<SalesOrderViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }


        /// <summary>
        /// Get List for all 
        /// </summary>
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<SalesOrderViewModel> data = await this._Manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<SalesOrderViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }



        /// <summary>
        /// Save All Salesorder data.
        /// </summary>
        /// <param name="AllSalesOrderViewModel">List Of sales order.</param>
        /// <returns>true/false on save success.</returns>
        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<IActionResult> SaveAll([FromBody] AllSalesOrderViewModel flagViewModel)
        {
            if (flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CPUOrder || flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Customer || flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerReturn || flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.CustomerToCustomer || flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.ChargeOrder)
            {
                var data = await this._Manager.SaveRegularOrder(flagViewModel).ConfigureAwait(false);
                //var data = await this._Manager.SaveAll(flagViewModel).ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
            }
            else if (flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.StockTransfer || flagViewModel.salesorder.OrderTypeCode == Constants.ModelEntityCodeValue.OrderType.Collections)
            {
                var data = await this._Manager.SaveAllStockTransfer(flagViewModel).ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null))).ConfigureAwait(false);
        }




        /// <summary>
        ///User can  Retrieves data from comment by contract
        /// </summary>
        [HttpPost(Constants.Identifire.GetComment)]
        public async Task<ActionResult> GetComment([FromBody] MaterialCommonModel flagViewModel)
        {
            CommentModel Data = await this._Manager.GetComment(flagViewModel).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CommentModel>.SendResponse(Data))).ConfigureAwait(false);

            }
            else
            {
                flagViewModel.ContractID = 0;
                CommentModel CData = await this._Manager.GetComment(flagViewModel).ConfigureAwait(false);
                return await Task.FromResult(Ok(UserResponse<CommentModel>.SendResponse(CData))).ConfigureAwait(false);

            }
        }

        /// <summary>
        ///User can  Retrieves data from SalesOrder by OrderId(With FromLocationId and OrderStatusId
        /// </summary>
        [HttpGet(Constants.Identifire.GetAllShipToDataList)]
        public async Task<ActionResult> GetAllShipToDataList(int id, int clientId, string SelectedTab)
        {

            var Data = await this._Manager.GetAllShipToData(id, clientId, SelectedTab).ConfigureAwait(false);

            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<IEnumerable<SalesOrderViewModel>>.SendResponse(Data))).ConfigureAwait(false);

            }
            else
            {
                id = 0;
                var CData = await this._Manager.GetAllShipToData(id, clientId, SelectedTab).ConfigureAwait(false);
                return await Task.FromResult(Ok(UserResponse<IEnumerable<SalesOrderViewModel>>.SendResponse(CData))).ConfigureAwait(false);

            }
        }

        /// <summary>
        /// Get List for all sales order along with details.
        /// </summary>   . 
        /// <param name="SalesOrderListViewModel"> Model should contain pageNo,pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetSalesOrderList)]
        public async Task<ActionResult> GetSalesOrderList([FromBody] SalesOrderListViewModel salesOrderViewModel)
        {
            // int TotalData = await this._Manager.GetAllSalesOrderListDataCount(salesOrderViewModel);
            int TotalData = 0; 
            IEnumerable<SalesOrderListViewModel> data = await this._Manager.GetAllSalesOrderList(salesOrderViewModel,ref TotalData);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<SalesOrderListViewModel>.SendResponse(TotalData, data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Get List for all Charges along with details.
        /// </summary>
        /// <param name="SalesOrderViewModel"> Model should contain pageNo,pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        //[HttpPost(Constants.Identifire.GetSalesOrderListDataCount)]
        //public async Task<ActionResult> GetSalesOrderListDataCount([FromBody] SalesOrderListViewModel salesOrderViewModel)
        //{

        //    IEnumerable<SalesOrderListViewModel> data = await this._Manager.GetAllSalesOrderListDataCount(salesOrderViewModel);
        //    if (data != null)
        //    {
        //        return await Task.FromResult(Ok(UserResponse<SalesOrderListViewModel>.SendResponse(data.Count(), data)));
        //    }
        //    else
        //    {
        //        return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
        //    }
        //}



        /// <summary>
        /// this end point sends the AR Charges to MAS.
        /// </summary>
        /// <param name="salesOrderViewModel">View Model which hold order id and other details</param>
        /// <returns>return true if sucess.</returns>
        [HttpPost(Constants.Identifire.SendARChargesToMAS)]
        public async Task<ActionResult> SendARChargesToMAS([FromBody] SalesOrderViewModel salesOrderViewModel)
        {
            if (salesOrderViewModel.ClientId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (salesOrderViewModel.Id == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.SendARChargesTOMASAsync(salesOrderViewModel);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }


        [HttpPost(Constants.Identifire.SaveSalesOrderLinkData)]
        public async Task<ActionResult> SaveSalesOrderLink([FromBody] CancelOrder saveOrder)
        {
            if (saveOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.SaveSalesLinkOrder(saveOrder.ClientID, saveOrder.OrderIdStr, saveOrder.UserName, saveOrder.ParentOrderId, saveOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        /// <summary>
        /// Save Bulk order data.
        /// </summary>
        /// <param name="flagViewModel">List Of sales order.</param>
        /// <returns>true/false on save success.</returns>
        [HttpPost(Constants.Identifire.SaveBulkOrder)]
        public async Task<IActionResult> SaveBulkOrder([FromBody] BulkOrderViewModel[] flagViewModel)
        {
            var data = await this._Manager.SaveBulkOrder(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }


        /// <summary>
        /// check equipment material properties are defined 3 of them 
        /// </summary>
        /// <param name="flagViewModel"></param>
        /// <returns></returns>
        [HttpPost(Constants.Identifire.GetVerifyEquipmentMaterialPropertyOrder)]
        public async Task<IActionResult> GetVerifyEquipmentMaterialPropertyOrder([FromBody] EditVerifyEquipmentMaterialProperty flagViewModel)
        {
            var data = await this._Manager.GetVerifyEquipmentMaterialPropertyOrder(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.CancelSelectedOrders)]
        public async Task<ActionResult> CancelSelectedOrders([FromBody] CancelOrder cancelOrder)
        {
            if (cancelOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.CancelSelectedOrdersAsync(cancelOrder.ClientID, cancelOrder.OrderIdStr, cancelOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpPost(Constants.Identifire.GetVerifyEquipmentMultipleMaterialPropertyOrder)]
        public async Task<IActionResult> GetVerifyEquipmentMultipleMaterialPropertyOrder([FromBody] RequestObjectMaterialProperties flagViewModel)
        {
            var data = await this._Manager.GetVerifyEquipmentForMultipleMaterialPropertyOrder(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteSelectedOrders)]
        public async Task<ActionResult> DeleteSelectedOrders([FromBody] CancelOrder deleteOrder)
        {
            if (deleteOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.DeleteSelectedOrdersAsync(deleteOrder.ClientID, deleteOrder.OrderIdStr, deleteOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }



        [HttpPost(Constants.Identifire.SaveUpdateVerifyEquipmentMaterial)]
        public async Task<IActionResult> SaveUpdateVerifyEquipmentMaterial([FromBody] SaveVerifyEquipmentMaterialProperty flagViewModel)
        {
            var data = await this._Manager.SaveUpdateVerifyEquipmentMaterial(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost("OrderList")]
        public async Task<ActionResult> OrderList([FromBody] CommonOrder flagViewModel)
        {
            var data = await this._Manager.OrderList(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost("GetListOrder")]
        public async Task<ActionResult> GetListOrder([FromBody] CommonOrder flagViewModel)
        {
            var data = await this._Manager.OrderListCount(flagViewModel).ConfigureAwait(false);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<SalesOrderViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.FindMissingMaterialPropertyOrder)]
        public async Task<IActionResult> FindMissingMaterialPropertyOrder([FromBody] RequestObjectMaterialProperties flagViewModel)
        {
            RegularOrderValidationResponse regularOrderValidationResponse = new RegularOrderValidationResponse();
            regularOrderValidationResponse.validationResponse = new ValidationResponse() { IsValid = true, Message = string.Empty };

            RequestObjectMaterialProperties requestObjectMaterialProperties = new RequestObjectMaterialProperties()
            {
                materialID = flagViewModel.materialID,
                equipmentTypeID = flagViewModel.equipmentTypeID,
            };
            var result = await this._Manager.FindMissingMateriaOrder(requestObjectMaterialProperties);
            if (result != null && result.Count > 0)
            {
                regularOrderValidationResponse.editVerifyEquipmentMaterialProperties = result;
                regularOrderValidationResponse.validationResponse.IsValid = false;
                regularOrderValidationResponse.validationResponse.Message = Constants.OrderManagementValidationMessage.Materialpropertymissing;
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result))).ConfigureAwait(false);
        }


        [HttpPost(Constants.Identifire.MoveUpDownOrderRouteSequence)]
        public async Task<ActionResult> MoveUpDownOrderRouteSequence([FromBody] CancelOrder moveOrder)
        {
            if (moveOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.MoveUpDownLinkOrder(moveOrder.ClientID, moveOrder.OrderId, moveOrder.SwapWithOrderId, moveOrder.RouteSequence, moveOrder.SwapWithRouteSequence, moveOrder.UserName, moveOrder.ShipWithOrderID, moveOrder.SwapWithShipWithOrderID);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }
        [HttpPost(Constants.Identifire.RemoveSelectedLinkOrder)]
        public async Task<ActionResult> RemoveSelectedLinkOrder([FromBody] CancelOrder removeOrder)
        {
            if (removeOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.RemoveSelectedLinkOrderRecord(removeOrder.ClientID, removeOrder.OrderId, removeOrder.ShipWithOrderID, removeOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpGet("{OrderId}/{ClientId}/{OrderType}")]
        public async Task<IActionResult> GetOrderDetailById(long OrderId, int ClientId, string OrderType)
        {
            var data = await this._Manager.GetOrderDetailById(OrderId, ClientId, OrderType).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }


        [HttpGet(Constants.Identifire.GetOrderDataByOrderIdForShipWithPopup)]
        public async Task<ActionResult> GetOrderDataByOrderIdForShipWithPopup(int ClientId, int OrderId, string InboundOutbound)
        {
            var Data = await this._Manager.GetOrderDataByOrderIdForShipWith(ClientId, OrderId, InboundOutbound).ConfigureAwait(false);

            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<IEnumerable<SalesOrderViewModel>>.SendResponse(Data))).ConfigureAwait(false);

            }
            else
            {
                OrderId = 0;
                var CData = await this._Manager.GetOrderDataByOrderIdForShipWith(ClientId, OrderId, InboundOutbound).ConfigureAwait(false);
                return await Task.FromResult(Ok(UserResponse<IEnumerable<SalesOrderViewModel>>.SendResponse(CData))).ConfigureAwait(false);

            }


            //IEnumerable<SalesOrderViewModel> data = await this._Manager.GetOrderDataByOrderIdForShipWith(salesOrderViewModel);
            //if (data != null)
            //{
            //    return await Task.FromResult(Ok(UserResponse<SalesOrderViewModel>.SendResponse(data.Count(), data)));
            //}
            //else
            //{
            //    return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            //}
        }

        [HttpPost("SetOverRideCreditLimit")]
        public async Task<IActionResult> SetOverRideCreditLimit([FromBody] SalesOrderViewModel salesOrderViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await this._Manager.SetOverRideCreditLimit(salesOrderViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<SalesOrderViewModel>.SendResponse(salesOrderViewModel))).ConfigureAwait(false);
        }

        [HttpPost("SaveCMComment")]
        public async Task<IActionResult> SaveCMComment([FromBody] SalesOrderViewModel salesOrderViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await this._Manager.SaveCMComment(salesOrderViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<SalesOrderViewModel>.SendResponse(salesOrderViewModel))).ConfigureAwait(false);
        }


        [HttpPost(Constants.Identifire.CopyOrders)]
        public async Task<ActionResult> CopyOrders([FromBody] CancelOrder CopyOrder)
        {
            if (CopyOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this._Manager.CopyOrdersAsync(CopyOrder.ClientID, CopyOrder.OrderIdStr, CopyOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));

        }
        [HttpGet(Constants.Identifire.GetAllInvoiceNo)]
        public async Task<ActionResult> GetAllInvoiceNo(int ClientId)
        {
            //var Data = await this._Manager.GetInvoiceNumberList(ClientId).ConfigureAwait(false);

            //if (Data != null)
            //{
            //    return await Task.FromResult(Ok(UserResponse<IEnumerable<SalesOrderViewModel>>.SendResponse(Data))).ConfigureAwait(false);

            //}
            //else
            //{
            //    return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            //}

            var data = await this._Manager.GetInvoiceNumberList(ClientId).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }
        [HttpGet(Constants.Identifire.GetAllSourceList)]
        public async Task<ActionResult> GetAllSourceList(int ClientId)
        {

            var data = await this._Manager.GetAllSource(ClientId).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetCheckStatusForSendtoMass)]
        public async Task<ActionResult> GetCheckStatusForSendtoMass([FromBody] CancelOrder CopyOrder)
        {
            if (CopyOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this._Manager.GetCheckStatusForSendtoMass(CopyOrder.ClientID, CopyOrder.OrderIdStr, CopyOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));

        }

        [HttpPost(Constants.Identifire.GetCheckStatusReSendtoMass)]
        public async Task<ActionResult> GetCheckStatusReSendtoMass([FromBody] CancelOrder CopyOrder)
        {
            if (CopyOrder.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = this._Manager.GetCheckStatusReSendtoMass(CopyOrder.ClientID, CopyOrder.OrderIdStr, CopyOrder.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));

        }


        [HttpPost(Constants.Identifire.SendARChargesToMASS)]
        public async Task<ActionResult> SendARChargesToMASS([FromBody] CancelOrder salesOrderViewModel)
        {
            if (salesOrderViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (salesOrderViewModel.OrderIdStr == "")
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.SendARChargesTOMAS(salesOrderViewModel.ClientID, salesOrderViewModel.OrderIdStr, salesOrderViewModel.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpPost(Constants.Identifire.ReSendARChargesToMASS)]
        public async Task<ActionResult> ReSendARChargesToMASS([FromBody] CancelOrder salesOrderViewModel)
        {
            if (salesOrderViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (salesOrderViewModel.OrderIdStr == "")
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidShippingTo, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.ReSendARChargesTOMAS(salesOrderViewModel.ClientID, salesOrderViewModel.OrderIdStr, salesOrderViewModel.SelectedTab);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpPost(Constants.Identifire.CreateManageFilter)]
        public async Task<ActionResult> CreateManageFilter([FromBody] CreateFilter createFilter)
        {
            if (createFilter.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.SaveCreateManageFilter(createFilter);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpGet(Constants.Identifire.GetAllCustomManageFilters)]
        public async Task<ActionResult> GetAllCustomManageFilters(int clientId, int userId, string selectedTab)
        {
            var Data = await this._Manager.GetAllCustomManageFiltersData(clientId, userId, selectedTab).ConfigureAwait(false);
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<IEnumerable<CreateFilter>>.SendResponse(Data))).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        [HttpPost(Constants.Identifire.UpdateManageFilter)]
        public async Task<ActionResult> UpdateManageFilter(CreateFilter createFilter)
        {
            if (createFilter.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.UpdateManageFilters(createFilter);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }
        [HttpPost(Constants.Identifire.DeleteManageFilter)]
        public async Task<ActionResult> DeleteManageFilter(CreateFilter createFilter)
        {
            if (createFilter.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            await this._Manager.DeleteManageFilters(createFilter);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));

        }

        [HttpGet(Constants.Identifire.ConvertCulture)]
        public async Task<ActionResult> ConvertCulture(string commentstring)
        {

            var strResult = this._Manager.ConvertTextEnglishToSpanish(commentstring);


            //return strResult;
            return await Task.FromResult(this.Ok(strResult));
        }




        [HttpPost(Constants.Identifire.RecalculateOrder)]
        public async Task<IActionResult> RecalculateOrder([FromBody] SalesOrderViewModel salesOrderViewModel)
        {
            var data = await this._Manager.RecalculateExistingOrders(salesOrderViewModel.Id, salesOrderViewModel.OrderTypeId.Value).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<ValidationResponse>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost("GetShipmentNumberDetails")]
        public async Task<ActionResult> GetShipmentNumberDetails([FromBody] ClaimFilter flagViewModel)
        {
            IEnumerable<object> Data = await this._Manager.GetShipmentNumberDetails(flagViewModel.ClientID, flagViewModel.shipdatefrom, flagViewModel.shipdateto);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, Data)));
        }

        [HttpPost("GetOrderNumberDetails")]
        public async Task<ActionResult> GetOrderNumberDetails([FromBody] ClaimFilter flagViewModel)
        {
            IEnumerable<object> Data = await this._Manager.GetOrderNumberDetails(flagViewModel.ClientID, flagViewModel.shipdatefrom, flagViewModel.shipdateto);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, Data)));
        }


        [HttpPost("GetShipmentNumberWithShipmentID")]
        public async Task<ActionResult> GetShipmentNumberWithShipmentID([FromBody] ClaimFilter flagViewModel)
        {
            IEnumerable<object> Data = await this._Manager.GetShipmentNumberWithShippmentID(flagViewModel.ClientID, flagViewModel.shipdatefrom, flagViewModel.shipdateto, flagViewModel.ShipmentID);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, Data)));
        }

        [HttpPost("GetOrderNumberWithShipmentID")]
        public async Task<ActionResult> GetOrderNumberWithShipmentID([FromBody] ClaimFilter flagViewModel)
        {
            IEnumerable<object> Data = await this._Manager.GetOrderNumberWithShippmentID(flagViewModel.ClientID, flagViewModel.shipdatefrom, flagViewModel.shipdateto, flagViewModel.ShipmentID);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, Data)));
        }
    }
}
