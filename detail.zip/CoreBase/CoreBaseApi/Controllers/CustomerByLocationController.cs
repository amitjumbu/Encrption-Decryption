﻿namespace CoreBaseApi.Controllers
{
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    [Route("api/[controller]")]
    [ApiController]
    public class CustomerByLocationController : ControllerBase
    {

        private readonly ICustomerByLocationManager manager;

        public CustomerByLocationController(ICustomerByLocationManager customerByLocationManager)
        {
            this.manager = customerByLocationManager;
        }

        /// <summary>
        /// Get List for all Customer By location.
        /// </summary>
        /// <param name="viewModel"> Model should contain pageNo, pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetByLocation)]
        public async Task<ActionResult> GetCustomerByLocation([FromBody] CustomerByLocationViewModel viewModel)
        {

            IEnumerable<CustomerByLocationViewModel> data =
                await this.manager.GetCustomerByLocation(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CustomerByLocationViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Update a Customer By location.
        /// </summary>
        /// <param name="editModel"> Model to uUpdatepdate Customer By Location.</param>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<ActionResult> UpdateCustomerByLocation([FromBody] CustomerByLocationEditModel editModel)
        {
            var data =
                await this.manager.UpdateCustomerByLocation(editModel);
            if (data)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }
        #region Change Location Active/ Inactive Status
        [HttpPost(Constants.Identifire.ActiveAll)]
        public async Task<ActionResult> ActiveAll([FromBody] CollectHospialIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.ActivateCustomerByLocation(allIds, collectHospialIDs.isActive);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion
    }
}
