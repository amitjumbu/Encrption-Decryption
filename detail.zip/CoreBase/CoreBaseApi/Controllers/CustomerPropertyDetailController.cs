﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerPropertyDetailController : ControllerBase
    {
        private readonly ICustomerPropertyDetailManager _Manager;
        //private readonly ILocationManager Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public CustomerPropertyDetailController(ICustomerPropertyDetailManager DIManager, IHostingEnvironment hostingEnvironment, IInstanseLogger instanceLogger)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
            this.instanceLogger = instanceLogger;
        }


        /// <summary>
        ///User can get Retrieves data from LocationContact by id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Get Preferred Material Data", Data);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///Get All List for Location Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] CustomerPropertyDetailViewModel flagViewModel)
        {
            
            IEnumerable<CustomerPropertyDetailViewModel> Data = await this._Manager.RangeAsyncList(flagViewModel);
            this.instanceLogger.AddInstanseLogger("Get Preferred Material Data List", Data);
            //return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(Count, Data)));
            if (Data != null)
            {
                return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(Data.Count(), Data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="locationContactModel"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CustomerPropertyDetailViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.InsertCustomerPropertyDetails(viewModel);
            this.instanceLogger.AddInstanseLogger("Save Preferred equipment Data", data);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }



        /// <summary>
        ///Update the LocationContact Data
        ///and media as well
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] CustomerPropertyDetailViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }



        



        /// <summary>
        ///User can get list by locatinId.
        /// </summary>
        [HttpGet(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID(int id)
        {
            IEnumerable<CustomerPropertyDetailViewModel> Data = await this._Manager.GetList(id);
            this.instanceLogger.AddInstanseLogger("Get Preferred Material List By Id", Data);
            return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(1, Data)));
        }


        

        /// <summary>
        ///Delete (soft removal) existing LocationContact data from system 
        ///
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            //var CurrentUserEmail = base.CurrentUserEmail;

            if (Data != null)
            {
                await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(Data))).ConfigureAwait(false);
            }
            return await Task.FromResult(Ok(UserResponse<string>.SendResponse("No records found"))).ConfigureAwait(false);
        }


        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<ActionResult> Update([FromBody] CustomerPropertyDetailViewModel viewModel)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            var data = await this._Manager.UpdateAsync(viewModel);
            this.instanceLogger.AddInstanseLogger("Update Preferred Material Data", data);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<CustomerPropertyDetailViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        [HttpPost(Constants.Identifire.DeleteByID)]
        public async Task<ActionResult> DeletePreferredMaterialAsync([FromBody] CustomerPropertyDetailViewModel viewModel)
        {
            var data = await this._Manager.DeleteAllAsync(viewModel).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Delete Preferred Equipent List", data);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost("GetMapForecastCustomerLocation")]
        public async Task<IActionResult> GetMapForecastCustomerLocation([FromBody] ForecastCustomerLocationViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this._Manager.GetMapForecastCustomerLocation(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<ForecastCustomerLocationViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetCountMapForecastCustomerLocation")]
        public async Task<IActionResult> GetCountMapForecastCustomerLocation([FromBody] ForecastCustomerLocationViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this._Manager.GetTotalCount(commonViewModel);

            if (finalResult != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }

        [HttpPost("GetCustomerLocationDropDownList")]
        public async Task<IActionResult> GetCustomerLocationDropDownList([FromBody] CustomerLocationDropdownViewModel commonViewModel)
        {
            if (commonViewModel.ClientID == null || commonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this._Manager.GetCustomerLocationDropDownList(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<CustomerLocationDropdownViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.UpdateAll)]
        public async Task<ActionResult> UpdateAll([FromBody] List<CustomerPropertyDetailViewModel> viewModels)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.MergeCustomerPropertyDetails(viewModels);
            this.instanceLogger.AddInstanseLogger("Save Preferred equipment Data", data);
            if (data)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }
    }
}