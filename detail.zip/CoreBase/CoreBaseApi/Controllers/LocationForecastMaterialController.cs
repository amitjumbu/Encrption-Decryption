﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using CoreBaseData;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationForecastMaterialController : ControllerBase
    {
        private readonly ILocationForecastMaterialManager _Manager;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public LocationForecastMaterialController(
            ILocationForecastMaterialManager dIManager,
            IInstanseLogger instanceLogger)
        {
            this._Manager = dIManager;
            this.instanceLogger = instanceLogger;
        }


        /// <summary>
        ///User can get Retrieves data from LocationContact by Location id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(long locationId)
        {
            var data = await this._Manager.GetListByLocationId(locationId).ConfigureAwait(false);
            this.instanceLogger.AddInstanseLogger("Get location Forcast  Material Data", data);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count(), data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null))).ConfigureAwait(false);
            }

        }

        /// <summary>
        ///Get All List for LocationForecastMaterial  Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] LocationForecastMaterialViewModel flagViewModel)
        {
            IEnumerable<LocationForecastMaterialViewModel> data = await this._Manager.ListAsync(flagViewModel);
            this.instanceLogger.AddInstanseLogger("Get Location Forecast Material Data List", data);
            if(data != null)
            {
                return await Task.FromResult(Ok(UserResponse<LocationForecastMaterialViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<LocationForecastMaterialViewModel>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Add Location Forecast Material.
        /// </summary>
        /// <param name="locationForecastMaterialViewModel"></param>
        /// <returns>Boolean of success or failure</returns>
        [HttpPost]
        public async Task<ActionResult> Add([FromBody] LocationForecastMaterialViewModel locationForecastMaterialViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(ModelState);
            }

            var data = await this._Manager.AddAsync(locationForecastMaterialViewModel);
            this.instanceLogger.AddInstanseLogger("Save Forecast Material Data", data);
            if (data)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        /// <summary>
        ///Delete (soft removal) existing Location Forecast Material  data from system 
        ///
        /// </summary>
        [HttpPost(Constants.Identifire.DeleteByID)]
        public async Task<IActionResult> Delete([FromBody] LocationDeleteModel deleteModel)
        {

            var response = await this._Manager.DeleteByIdsAsync(deleteModel.ids, deleteModel.deletedBy).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(response))).ConfigureAwait(false);

        }

        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<IActionResult> SaveAll(List<ForecastCustomerLocationViewModel> viewModel)
        {
            IEnumerable<ForecastCustomerLocationViewModel> data = await this._Manager.SaveAll(viewModel);
            this.instanceLogger.AddInstanseLogger("Save Forecast Customer Location to Material Data", data);
            return await Task.FromResult(this.Ok(UserResponse<ForecastCustomerLocationViewModel>.SendResponse(data.Count(), data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll(List<ForecastCustomerLocationViewModel> materialDeleteModel)
        {

            var result = await this._Manager.DeleteAllAsync(materialDeleteModel);
            if (result != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
    }
}