﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class FuelSurChargeIndxController : ControllerBase
    {
        private readonly IFuelSurchargeIndexManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public FuelSurChargeIndxController(IFuelSurchargeIndexManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        #region  Get Data by ID
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
        #endregion


        #region Get All by IDs
        [HttpPost("GetAllByID")]
        public async Task<IActionResult> GetAll([FromBody] CollectFuelchargeIndexIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            IEnumerable<FuelSurchargeIndexViewModel> data = await this._Manager.GetFuelSurchargeListByIDs(collectHospialIDs);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }
        #endregion
        //public async Task<IActionResult> GetFuelPriceType(int ClientId)
        //{
        //    FuelPriceTypeViewModel fuelPriceTypeViewModel = new FuelPriceTypeViewModel();
        //    fuelPriceTypeViewModel.ClientId = ClientId;
        //    if (fuelPriceTypeViewModel.ClientId == null || fuelPriceTypeViewModel.ClientId <= 0)
        //    {
        //        this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
        //    }



        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }

        //    var finalResult = await this._Manager.GetFuelPriceTypes(fuelPriceTypeViewModel);

        //    if (finalResult != null && finalResult != null)
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<IEnumerable<FuelPriceTypeViewModel>>.SendResponse(finalResult)));
        //    }
        //    else
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
        //    }
        //}

        #region MyRegion API for Bind Fuel Price Type in Drop box

        [HttpPost(Constants.Identifire.GetFuelPriceType)]
        public async Task<ActionResult> GetFuelPriceType(int ClientID)
        {
            if (ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }


            var data = this._Manager.GetFuelPriceType(ClientID);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<FuelPriceTypeViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
        #endregion


        #region API for ChargeRate UOM bind
        // API for ChargeRate UOM bind 
        [HttpPost(Constants.Identifire.ChargeRateUOM)]
        public async Task<ActionResult> ChargeRateUOM(int ClientID)
        {
            if (ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }


            var data = this._Manager.GetChargeRateUOM(ClientID);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<UOMViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
        #endregion

        #region List of records displayed
        // List of records displayed
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] FuelSurchargeIndexViewModel fuelsurchargeindexViewModel)
        {
            var Count = await this._Manager.CountAsync(fuelsurchargeindexViewModel);
            if (Count > 0)
            {
                IEnumerable<FuelSurchargeIndexViewModel> Data = await this._Manager.RangeAsync(Count, fuelsurchargeindexViewModel);
                return await Task.FromResult(Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }
        #endregion

        #region Save list of records 
        // Save list of records 
        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<IActionResult> SaveAll([FromBody] List<FuelSurchargeIndexViewModel> viewModel)
        {
            //var data = await this._Manager.SaveAll(viewModel).ConfigureAwait(false);
            IEnumerable<FuelSurchargeIndexViewModel> data = await this._Manager.SaveAll(viewModel);
            //return await Task.FromResult(this.Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(data))).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(data.Count(), data)));
        }
        #endregion
        [HttpPost(Constants.Identifire.Post)]
        public async Task<ActionResult> Post([FromBody] FuelSurchargeIndexViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            // var data = await this._Manager.AddData(viewModel);
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }
        [HttpPost("Count")]
        public async Task<ActionResult> Count([FromBody] FuelSurchargeIndexViewModel flagViewModel)
        {
            var count = await this._Manager.CountAsync(flagViewModel);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(count)));
        }
        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<ActionResult> GetFuelSurChargeindexList([FromBody] FuelSurchargeIndexViewModel ViewModel)
        {

            IEnumerable<FuelSurchargeIndexViewModel> data = await this._Manager.GetFuelSurChargeindexList(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #region Update the Record
        [HttpPost(Constants.Identifire.UpdateFuelIndex)]
        public async Task<IActionResult> UpdateFuelIndex([FromBody] FuelSurchargeIndexViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<FuelSurchargeIndexViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }
        #endregion
        #region Delete record
        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] CollectFuelchargeIndexIDs viewModelDelete)
        {
            var allIds = viewModelDelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        #endregion
    }
}