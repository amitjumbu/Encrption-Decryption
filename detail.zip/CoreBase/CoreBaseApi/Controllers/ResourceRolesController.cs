﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ResourceRolesController : ControllerBase
    {
        private readonly IResourceRolesManager manager;


        public ResourceRolesController(IResourceRolesManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost(Constants.Identifire.GetResourceRole)]
        public async Task<IActionResult> GetResourceRole([FromBody] ResourceRolesViewModel resourceRolesViewModel)
        {
            if (resourceRolesViewModel.ClientId == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }


            var data = this.manager.GetResourceRole(resourceRolesViewModel.ClientId);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<ResourceRolesViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        #region Get Resource Name on Resource Role Id to Bind on Physician Name in Patient Page
        [HttpPost(Constants.Identifire.GetResourceNameOnResourceRole)]
        public async Task<IActionResult> GetResourceNameOnResourceRole([FromBody] ResourceOnResourceRoleViewModel resourceOnResourceRoleViewModel)
        {
            if (resourceOnResourceRoleViewModel.ClientId == 0 && resourceOnResourceRoleViewModel.LocationID==0 && resourceOnResourceRoleViewModel.ResourceRoleID==0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }


            var data = this.manager.GetResourceNameOnResourceRole(resourceOnResourceRoleViewModel);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<List<ResourceOnResourceRoleViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }
        #endregion
    }
}
