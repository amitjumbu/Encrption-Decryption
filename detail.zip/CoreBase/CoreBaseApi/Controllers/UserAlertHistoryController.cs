﻿namespace CoreBaseApi.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class UserAlertHistoryController : ControllerBase
    {
        private readonly IUserAlertHistoryManager manager;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly IMapper mapper;

        public UserAlertHistoryController(IUserAlertHistoryManager dIManager, IWebHostEnvironment hostingEnvironment)
        {
            this.manager = dIManager;
            this.hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Get All System Alerts.
        /// </summary>
        /// <param name="flagViewModel">View Model of System Alert, Which Will be use for filter purpose only.</param>
        /// <returns>list of system alert list.</returns>
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<UserAlertHistoryViewModel> data = await this.manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<UserAlertHistoryViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetAllUserAlertHistory)]
        public async Task<ActionResult> GetAllUserAlertHistory([FromBody] UserAlertHistoryViewModel ViewModel)
        {

            IEnumerable<UserAlertHistoryViewModel> data = await this.manager.GetAllAlertHistory(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<UserAlertHistoryViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        [HttpPost(Constants.Identifire.GetSearchResult)]
        public async Task<ActionResult> GetSearchResult([FromBody] UserAlertHistoryViewModel ViewModel)
        {

            IEnumerable<UserAlertHistoryViewModel> data = await this.manager.GetAllSearchResult(ViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<UserAlertHistoryViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        /// <summary>
        /// this method use to save the useralerts into system.
        /// </summary>
        /// <param name="userAlertViewModel">User Alert view Model.</param>
        /// <returns>true on success and false on fail.</returns>
        //[HttpPost]
        //public async Task<ActionResult> Post([FromBody] UserAlertHistoryViewModel userAlertHistoryViewModel)
        //{
        //    if (userAlertHistoryViewModel.ClientId == null || userAlertHistoryViewModel.ClientId == 0)
        //    {
        //        this.ModelState.AddModelError("InvalidClient", Constants.Errors.InvalidClient);
        //    }
        //    else if (userAlertHistoryViewModel.CreateDateTimeBrowser == null || userAlertHistoryViewModel.CreateDateTimeBrowser < DateTime.Now.AddDays(-2))
        //    {
        //        this.ModelState.AddModelError("InvalidCreatedDate", Constants.Errors.InvalidCreatedDate);
        //    }

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }

        //    var finalResult = this.manager.AddAsync(userAlertHistoryViewModel);

        //    return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
        //}


        /// <summary>
        /// this method use to update the useralerts into system.
        /// </summary>
        /// <param name="userAlertViewModel">User Alert view Model.</param>
        /// <returns>true on success and false on fail.</returns>
        //[HttpPost(Constants.Identifire.Update)]
        //public async Task<ActionResult> Update([FromBody] UserAlertHistoryViewModel userAlertHistoryViewModel)
        //{
        //    if (userAlertHistoryViewModel.ClientId == null || userAlertHistoryViewModel.ClientId == 0)
        //    {
        //        this.ModelState.AddModelError("InvalidClient", Constants.Errors.InvalidClient);
        //    }

        //    if (userAlertHistoryViewModel.Id == 0)
        //    {
        //        this.ModelState.AddModelError("InvalidID", Constants.Errors.InvalidID);
        //    }

        //    if (userAlertHistoryViewModel.UpdateDateTimeBrowser == null || userAlertHistoryViewModel.UpdateDateTimeBrowser < DateTime.Now.AddDays(-2))
        //    {
        //        this.ModelState.AddModelError("InvalidCreatedDate", Constants.Errors.InvalidCreatedDate);
        //    }

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }

        //    var finalResult = this.manager.UpdateAsync(userAlertHistoryViewModel);

        //    return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(finalResult)));
        //}


        /// <summary>
        /// Activate the User Alerts.
        /// </summary>
        /// <param name="userAlertActive">List of Ids comma seprated.</param>
        /// <returns>true on success/false on fail.</returns>
        /// [HttpPost(Constants.Identifire.List)]
        //[HttpPost(Constants.Identifire.ActiveAll)]
        //public async Task<ActionResult> ActiveAll([FromBody] UserAlertActive userAlertActive)
        //{
        //    var allIds = userAlertActive.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

        //    if (allIds.Any())
        //    {
        //        var result = await this.manager.ActivateUserAlert(allIds, userAlertActive.IsActive);

        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
        //    }

        //    return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        //}

        /// <summary>
        /// Softly Delete the User Alerts.
        /// </summary>
        /// <param name="userAlertActive">List of Ids comma seprated.</param>
        /// <returns>true on success/false on fail.</returns>
        /// [HttpPost(Constants.Identifire.List)]
        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] UserAlertHistoryDelete userAlertHistoryDelete)
        {
            var allIds = userAlertHistoryDelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        /// <summary>
        /// GetUserAlert Information on ID basis.
        /// </summary>
        /// <param name="userAlertViewModel">Get User Alert View Model.</param>
        /// <returns>return full detail view model.</returns>
        //[HttpPost(Constants.Identifire.GetByID)]
        //public async Task<ActionResult> GetByID([FromBody] UserAlertHistoryViewModel userAlertHistoryViewModel)
        //{
        //    if (userAlertHistoryViewModel.ClientId == null || userAlertHistoryViewModel.ClientId == 0)
        //    {
        //        this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
        //    }

        //    if (userAlertHistoryViewModel.Id == 0)
        //    {
        //        this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
        //    }

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }

        //    var userAlertData = this.manager.GetAsync(userAlertHistoryViewModel.Id).Result;

        //    if (userAlertData != null)
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<UserAlertViewModel>.SendResponse(userAlertData)));
        //    }
        //    else
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
        //    }
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userAlertViewModel"></param>
        /// <returns></returns>
        //[HttpPost(Constants.Identifire.GetDetail)]
        //public async Task<ActionResult> GetDetail([FromBody] UserAlertHistoryViewModel userAlertHistoryViewModel)
        //{
        //    if (string.IsNullOrEmpty(userAlertHistoryViewModel.Name))
        //    {
        //        this.ModelState.AddModelError("InvalidID", Constants.Errors.InvalidName);
        //    }

        //    if (!this.ModelState.IsValid)
        //    {
        //        return this.BadRequest(this.ModelState);
        //    }

        //    var userAlertData = this.manager.ListAsync(userAlertHistoryViewModel).Result;

        //    if (userAlertData != null)
        //    {
        //        var selectedUserAlert = userAlertData.FirstOrDefault(p => p.Name.ToLower().Trim().Equals(userAlertHistoryViewModel.Name.ToLower().Trim()));
        //        if (selectedUserAlert != null)
        //        {
        //            return await Task.FromResult(this.Ok(UserResponse<UserAlertViewModel>.SendResponse(selectedUserAlert)));
        //        }
        //        else
        //        {
        //            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
        //        }
        //    }
        //    else
        //    {
        //        return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
        //    }
        //}
    }
}