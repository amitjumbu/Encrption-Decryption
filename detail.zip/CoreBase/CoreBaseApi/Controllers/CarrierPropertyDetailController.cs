﻿namespace CoreBaseApi.Controllers
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseData;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.AspNetCore.Mvc;

    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CarrierPropertyDetailController : ControllerBase
    {
        private readonly ICarrierPropertyDetailManager _Manager;
        //private readonly ILocationManager Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;
        private readonly IInstanseLogger instanceLogger;

        public CarrierPropertyDetailController(ICarrierPropertyDetailManager DIManager, IHostingEnvironment hostingEnvironment, IInstanseLogger instanceLogger)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
            this.instanceLogger = instanceLogger;
        }


        
        [HttpPost(Constants.Identifire.UpdateAll)]
        public async Task<ActionResult> UpdateAll([FromBody] List<CarrierPropertyDetailViewModel> viewModels)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this._Manager.MergeCarrierPropertyDetails(viewModels);
            this.instanceLogger.AddInstanseLogger("MergeCarrierPropertyDetails  Data", data);
            if (data)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        #region Delete  Existing Characterstics for a Carrier
        /// <summary>
        /// Delete  Existing Characterstics for a Carrier.
        /// </summary>
        /// <param name="carrierDeleteModel">Contains details of items to be deleted.</param>
        /// <returns>A success/Failure.</returns>
        [HttpPost("DeleteExistingCharacteristics")]
        public async Task<IActionResult> DeleteExistingCharacteristics([FromBody] LocationPropertyDeleteModel locationDeleteModel)
        {

            var data = await this._Manager.DeleteExistingCharacteristics(locationDeleteModel);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data)));
        }
        #endregion


        #region Get Existing Characterstics From CarrierPropertyDetail
        /// <summary>
        ///Get Existing Characterstics From CarrierPropertyDetail
        /// </summary>
        /// <param name="carrierPropertyDetailView"></param>
        /// <returns>List of Property Detail for Carrier.</returns>
        [HttpPost("GetExistingCharacteristics")]
        public async Task<IActionResult> GetExistingCharacteristics([FromBody] CarrierPropertyDetailViewModel carrierPropertyDetailView)
        {

            IEnumerable<CarrierPropertyDetailViewModel> data = 
                await this._Manager.GetExistingCarrierCharacteristics(carrierPropertyDetailView);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<CarrierPropertyDetailViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
    }
}