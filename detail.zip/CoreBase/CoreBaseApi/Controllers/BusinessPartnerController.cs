﻿namespace CoreBaseApi.Controllers
{
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    [Route("api/[controller]")]
    [ApiController]
    public class BusinessPartnerController : ControllerBase
    {

        private readonly IBusinessPartnerManager manager;

        public BusinessPartnerController(IBusinessPartnerManager businessPartnerManager)
        {
            this.manager = businessPartnerManager;
        }

        /// <summary>
        /// Get List for all Business Partner By location.
        /// </summary>
        /// <param name="viewModel"> Model should contain pageNo, pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetByLocation)]
        public async Task<ActionResult> GetBusinessPartnerByLocation([FromBody] BusinessPartnerByLocationViewModel viewModel)
        {

            IEnumerable<BusinessPartnerByLocationViewModel> data =
                await this.manager.GetBusinessPartnerByLocation(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<BusinessPartnerByLocationViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Get List for all Business Partner By location.
        /// </summary>
        /// <param name="viewModel"> Model to update.</param>
        [HttpPost(Constants.Identifire.GetByCarrier)]
        public async Task<ActionResult> GetBusinessPartnerByCarrier([FromBody] BusinessPartnerByCarrierViewModel viewModel)
        {

            IEnumerable<BusinessPartnerByCarrierViewModel> data =
                await this.manager.GetBusinessPartnerByCarrier(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<BusinessPartnerByCarrierViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Update Business Partner By location.
        /// </summary>
        /// <param name="viewModel"> Model to update.</param>
        [HttpPost(Constants.Identifire.Update + "/" + Constants.Identifire.BpByLocation)]
        public async Task<ActionResult> UpdateBusinessPartnerByLocation
            ([FromBody] BusinessPartnerByLocationViewModel editModel)
        {
            if (editModel.BusinessPartnerId < 1)
            {
                this.ModelState.AddModelError(
                    Constants.Errors.InvalidID,
                    Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var updateSuccessful =
                await this.manager.UpdateBusinessPartnerByLocation(editModel);
            if (updateSuccessful)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        /// <summary>
        /// Update Business Partner By location.
        /// </summary>
        /// <param name="viewModel"> Model should contain pageNo, pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.Update + "/" + Constants.Identifire.BpByCarrier)]
        public async Task<ActionResult> UpdateBusinessPartnerByCarrier([FromBody] BusinessPartnerByCarrierViewModel editModel)
        {

            if (editModel.BusinessPartnerId < 1)
            {
                this.ModelState.AddModelError(
                    Constants.Errors.InvalidID,
                    Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var updateSuccessful =
                await this.manager.UpdateBusinessPartnerByCarrier(editModel);
            if (updateSuccessful)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        /// <summary>
        /// Add  Carrier.
        /// </summary>
        /// <param name="addModel"> Model should contain businesspartnerName and scac value.</param>
        [HttpPost(Constants.Identifire.Add + "/" + Constants.Identifire.BpByCarrier)]
        public async Task<ActionResult> AddByCarrier([FromBody] BusinessPartnerByCarrierViewModel addModel)
        {

            if (string.IsNullOrWhiteSpace(addModel.BusinessPartnerName))
            {
                this.ModelState.AddModelError(
                    Constants.Errors.InvalidName,
                    Constants.Errors.InvalidName);
            }
            if (string.IsNullOrWhiteSpace(addModel.ScacValue))
            {
                this.ModelState.AddModelError(
                    Constants.Errors.InvalidCode,
                    Constants.Errors.InvalidCode);
            }


            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var addedSuccessful =
                await this.manager.AddCarrier(addModel);
            if (addedSuccessful)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        #region Change Location Active/ Inactive Status
        [HttpPost(Constants.Identifire.ActiveAll)]
        public async Task<ActionResult> ActiveAll([FromBody] CollectHospialIDs collectHospialIDs)
        {
            var allIds = collectHospialIDs.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.ActivateLocationBusinessPartner(allIds, collectHospialIDs.isActive);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion
        #region Change Carrier Active/ Inactive Status
        [HttpPost(Constants.Identifire.ActiveCarrier)]
        public async Task<ActionResult> ActiveCarrier([FromBody] CollectionCarrierID collectionCarrierID)
        {
            var allIds = collectionCarrierID.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.ActivateCarrier(allIds, collectionCarrierID.isActive);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
        #endregion

        #region Get Billing Entity
        [HttpPost(Constants.Identifire.GetBillingEntity)]
        public async Task<ActionResult> GetBillingEntity([FromBody] BusinessPartnerBilingEntityViewModel viewModel)
        {

            IEnumerable<BusinessPartnerBilingEntityViewModel> data =
                await this.manager.GetAllBillingEntity(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<BusinessPartnerBilingEntityViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        #region Get Billing Entity for Carrier
        [HttpPost(Constants.Identifire.GetBillingEntityCarrier)]
        public async Task<ActionResult> GetBillingEntityforCarrier([FromBody] BusinessPartnerBilingEntityViewModel viewModel)
        {

            IEnumerable<BusinessPartnerBilingEntityViewModel> data =
                await this.manager.GetAllBillingEntityforCarrier(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<BusinessPartnerBilingEntityViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
        #region Get Custom Billing Entity
        [HttpPost(Constants.Identifire.GetCustomBillingEntity)]
        public async Task<ActionResult> GetCustomBillingEntity([FromBody] BusinessPartnerBilingEntityViewModel viewModel)
        {

            IEnumerable<BusinessPartnerBilingEntityViewModel> data =
                await this.manager.GetAllCustomBillingEntity(viewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<BusinessPartnerBilingEntityViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
        #endregion
    }
}
