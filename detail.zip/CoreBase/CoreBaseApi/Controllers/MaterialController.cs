﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Math.EC.Rfc7748;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialController : ControllerBase
    {
        private readonly IMaterialManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public MaterialController(IMaterialManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }


        /// <summary>
        ///User can get Retrieves data from Material by id.
        /// </summary>
        [HttpGet(Constants.Identifire.Id)]
        public async Task<IActionResult> Get(int Id)
        {
            var Data = await this._Manager.GetAsync(Id).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///Get All List for Material Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] MaterialViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            if (Count > 0)
            {
                IEnumerable<MaterialViewModel> Data = await this._Manager.RangeAsync(Count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<MaterialViewModel>.SendResponse(Count, Data)));
            }

            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Count, null)));
            }
        }


        [HttpGet("TotalCount")]
        public async Task<ActionResult> GetCount()
        {
            int totalCount = await this._Manager.ListmaterialAsync(null);
            if (totalCount > 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(totalCount)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("ListMaterialCommodity")]
        public async Task<IActionResult> GetAllMaterialCommodityMapData([FromBody] MaterialCommodityMapViewModel matcomviewmodel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<MaterialCommodityMapViewModel> data = await this._Manager.GetAllMaterialCommodityMapData(matcomviewmodel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<MaterialCommodityMapViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        ///Get All List for Material Data List
        /// </summary>
        [HttpPost(Constants.Identifire.OrderMaterialList)]
        public async Task<ActionResult> OrderMaterialList([FromBody] OrderRequestedMaterialsViewModel flagViewModel)
        {
            if (flagViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            //if (flagViewModel.OrderID == 0)
            //{
            //    // this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            //}

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<MaterialViewModel> data = await this._Manager.GetOrderMaterial(flagViewModel);
            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        /// <summary>
        ///Get All List for Material Data List
        /// </summary>
        [HttpPost(Constants.Identifire.PalletList)]
        public async Task<ActionResult> PalletList([FromBody] OrderRequestedMaterialsViewModel flagViewModel)
        {
            if (flagViewModel.ClientID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (flagViewModel.OrderID == 0)
            {
                // this.ModelState.AddModelError(Constants.Errors.InvalidID, Constants.Errors.InvalidID);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<MaterialViewModel> data = await this._Manager.GetOrderMaterial(flagViewModel);

            data = data.Where(x => x.HierarchyCode != "F24").ToList();
            //data.ToList().RemoveAll(x => x.HierarchyCode == "F24");


            if (data != null && data.Any())
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialViewModel>>.SendResponse(data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        /// <summary>
        /// User can  Retrieves data from material with quantity.
        /// </summary>
        [HttpPost(Constants.Identifire.Materialquantity)]
        public async Task<ActionResult> Materialquantity([FromBody] MaterialQuantityRequestModel flagViewModel)
        {
            LocationMaterialModel Data = await this._Manager.Materialquantity(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<LocationMaterialModel>.SendResponse(Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///User can  Retrieves data from material by location.
        /// </summary>
        [HttpPost(Constants.Identifire.LocationMaterial)]
        public async Task<ActionResult> LocationMaterial([FromBody] MaterialCommonModel flagViewModel)
        {
            IEnumerable<LocationMaterialModel> Data = await this._Manager.LocationMaterial(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<LocationMaterialModel>.SendResponse(0, Data))).ConfigureAwait(false);
        }

        /// <summary>
        ///User can  Retrieves data from material by location.
        /// </summary>
        [HttpPost(Constants.Identifire.LocationShippingMaterial)]
        public async Task<ActionResult> LocationShippingMaterial([FromBody] MaterialCommonModel flagViewModel)
        {
            IEnumerable<LocationMaterialModel> Data = await this._Manager.LocationShippingMaterial(flagViewModel).ConfigureAwait(false);

            if (Data.Count() > 0)
            {
                return await Task.FromResult(Ok(UserResponse<LocationMaterialModel>.SendResponse(0, Data))).ConfigureAwait(false);

            }
            else
            {
                IEnumerable<LocationMaterialModel> DData = await this._Manager.DefaultPallet(flagViewModel).ConfigureAwait(false);

                return await Task.FromResult(Ok(UserResponse<LocationMaterialModel>.SendResponse(0, DData))).ConfigureAwait(false);
            }
         }

        /// <summary>
        /// User can  Retrieves data from material with quantity.
        /// </summary>
        [HttpPost(Constants.Identifire.AllMaterialquantity)]
        public async Task<ActionResult> AllMaterialquantity([FromBody] AllMaterialQuantityRequestModel flagViewModel)
        {    

            IEnumerable<ShippmentMaterialModel> Data = await this._Manager.AllMaterialquantity(flagViewModel).ConfigureAwait(false);

            var data1 = Data.ToList().GroupBy(x=>x.MaterialID).ToList();
            return await Task.FromResult(Ok(UserResponse<ShippmentMaterialModel>.SendResponse(0,Data))).ConfigureAwait(false);
        }

        /// <summary>
        /// User can  Retrieves data from material with Pallets Calculation.
        /// </summary>
        [HttpPost("GetMaterialPalletsCalculation")]
        public async Task<ActionResult> GetMaterialPalletsCalculation([FromBody] MaterialPalletsCalculation flagViewModel)
        {

            IEnumerable<MaterialPalletsCalculation> Data = await this._Manager.GetMaterialPalletsCalculation(flagViewModel).ConfigureAwait(false);


            return await Task.FromResult(Ok(UserResponse<MaterialPalletsCalculation>.SendResponse(0, Data))).ConfigureAwait(false);
        }


        /// <summary>
        /// User can  Retrieves data from material with Commodity.
        /// </summary>
        [HttpPost(Constants.Identifire.DefaultMaterialCommodity)]
        public async Task<ActionResult> GetDefaultMaterialCommodity([FromBody] MaterialCommodityRequestModel flagViewModel)
        {

            IEnumerable<MaterialViewModel> Data = await this._Manager.GetDefaultMaterialCommodity(flagViewModel).ConfigureAwait(false);

           
            return await Task.FromResult(Ok(UserResponse<MaterialViewModel>.SendResponse(0, Data))).ConfigureAwait(false);
        }


        /// <summary>
        /// User can  Retrieves Default material property.
        /// </summary>
        [HttpPost(Constants.Identifire.DefaultMaterialProperty)]
        public async Task<ActionResult> DefaultMaterialProperty([FromBody] MaterialQuantityRequestModel flagViewModel)
        {
            DefaultMaterialProperty Data = await this._Manager.DefaultMaterialProperty(flagViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<DefaultMaterialProperty>.SendResponse(Data))).ConfigureAwait(false);
        }

        [HttpPost("isMaterialExist")]
        public async Task<IActionResult> MaterialExist([FromBody] MaterialCommodityMapViewModel viewModel)
        {
            var code = viewModel.Code;
            var result = await this._Manager.getMaterial(code);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
        }

        [HttpPost("UpdateMaterialCommodity")]
        public async Task<IActionResult> UpdateMaterialCommodity([FromBody] List<MaterialCommodityMapViewModel> viewModel)
        {
            IEnumerable<MaterialCommodityMapViewModel> data = await this._Manager.UpdateMaterialCommodityAsync(viewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<MaterialCommodityMapViewModel>.SendResponse(data.Count(), data))).ConfigureAwait(false);
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] MaterialCommodityDeleteModel materialDeleteModel)
        {
            var allIds = materialDeleteModel.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this._Manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        [HttpPost(Constants.Identifire.GetHierarchyByMaterialID)]
        public async Task<IActionResult> GetAllMaterialWithHMaterialHierarchy([FromBody] MaterialCommodityDeleteModel materialCommodityDeleteModel)
        {
            var allIds = materialCommodityDeleteModel.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
            //IEnumerable<LocationViewModel> data = await this._Manager.GetHospitalListByIDs(collectHospialIDs);
            IEnumerable<MaterialCommodityMapViewModel> data = await this._Manager.GetAllMaterialWithHMaterialHierarchy(materialCommodityDeleteModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<MaterialCommodityMapViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }

        }



        /// <summary>
        ///User can  Retrieves data from material by Contract.
        /// </summary>
        [HttpPost(Constants.Identifire.ContractMaterial)]
        public async Task<ActionResult> ContractMaterial([FromBody] ContractMaterialModel ViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var Data = await this._Manager.ContractMaterial(ViewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<object>.SendResponse(Data))).ConfigureAwait(false);
        }
    }
}