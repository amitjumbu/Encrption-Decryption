﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    ///  Operates on ChargeType.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ChargeTypeController : ControllerBase
    {
        private readonly IChargeTypeManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeTypeController"/> class.
        /// </summary>
        /// <param name="manager">Charge Type Manager with the help of DI.</param>
        public ChargeTypeController(IChargeTypeManager manager)
        {
            this.manager = manager;
        }

        /// <summary>
        /// Get List of all ChargeTypes.
        /// </summary>
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<ChargeTypeViewModel> data = await this.manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeTypeViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }
    }
}
