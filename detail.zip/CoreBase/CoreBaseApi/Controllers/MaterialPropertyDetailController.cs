﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialPropertyDetailController : ControllerBase
    {
        private readonly IMaterialPropertyDetailManager manager;

        public MaterialPropertyDetailController(IMaterialPropertyDetailManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost("GetMaterialPropertyDetailByCode")]
        public async Task<IActionResult> GetMaterialPropertyDetailByCode([FromBody] MaterialPropertyDetailViewModel commonViewModel)
        {
            if (commonViewModel.ClientId == null || commonViewModel.ClientId <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetMaterialPropertyDetailByCode(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<MaterialPropertyDetailViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.SaveAll)]
        public async Task<ActionResult> SaveAll([FromBody] List<MaterialPropertyDetailViewModel> viewModel)
        {
            IEnumerable<MaterialPropertyDetailViewModel> data = await this.manager.SaveAll(viewModel);
            return await Task.FromResult(this.Ok(UserResponse<MaterialPropertyDetailViewModel>.SendResponse(data.Count(), data)));
        }

        [HttpPost("GetMaterialPropertyDetailFromSelectedMaterial")]
        public async Task<IActionResult> GetMaterialPropertyDetailFromSelectedMaterial([FromBody] MatPropDetailFromSelectedMatViewModel commonViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetMaterialPropertyDetailFromSelectedMaterial(commonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse< IEnumerable<MatPropDetailFromSelectedMatViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] MaterialPropertyDetailDeleteModel materialPropertyDetailDeleteModel)
        {
            var allIds = materialPropertyDetailDeleteModel.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
    }
}
