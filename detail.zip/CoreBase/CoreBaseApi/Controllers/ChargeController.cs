﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Order Calculation Controller Developed By Kapil Pandey.
    /// On : 17-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class ChargeController : ControllerBase
    {
        private readonly IChargeManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeController"/> class.
        /// </summary>
        /// <param name="manager">Charge Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public ChargeController(IChargeManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        /// <summary>
        /// this end point get all list of charge.
        /// </summary>
        /// <param name="chargeViewModel">Charge View Model for filter purpose.</param>
        /// <returns>list of charge.</returns>
        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<IActionResult> GetAll([FromBody] ChargeViewModel chargeViewModel)
        {
            if (chargeViewModel.ClientID == null || chargeViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetChageListForAdjustChageSection(chargeViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<ChargeViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        /// <summary>
        /// Get List for all Charges.
        /// </summary>
        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<ChargeViewModel> data = await this.manager.ListAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }


        /// <summary>
        /// Get List for all Charges along with details.
        /// </summary>
        /// <param name="chargeViewModel"> Model should contain pageNo,pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetChargeDetails)]
        public async Task<ActionResult> GetChargeDetails([FromBody] ChargeViewModel chargeViewModel)
        {

            IEnumerable<ChargeViewModel> data = await this.manager.GetAllChargeDetails(chargeViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Get List for all Charges along with details.
        /// </summary>
        /// <param name="chargeViewModel"> Model should contain pageNo,pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<ActionResult> GetChargeDetailsById([FromBody] ChargeViewModel chargeViewModel)
        {

            IEnumerable<ChargeViewModel> data = await this.manager.GetAllChargeDetails(chargeViewModel);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        /// <summary>
        /// Update list of Charges.
        /// </summary>
        /// <param name="chargeViewModels">List of Charge to be updated.</param>
        /// <returns> Returns the count of Charge which was updated successfully.</returns>
        [HttpPost(Constants.Identifire.Update)]
        public async Task<ActionResult> UpdateCharge([FromBody] List<ChargeViewModel> chargeViewModels)
        {
            IEnumerable<ChargeViewModel> data = await this.manager.UpdateModelsAsync(chargeViewModels);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<ChargeViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }


        /// <summary>
        /// Get List for all Charges by category.
        /// </summary>
        /// <param name="chargeViewModel"> Model should contain ClientID, Category</param>
        [HttpPost(Constants.Identifire.GetCharge)]
        public async Task<ActionResult> GetCharge([FromBody] ParameterModel parameterModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.manager.GetCharge(parameterModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);

        }
    }
}
