﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CoreBaseApi.Controllers
{
   // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CervixController : ControllerBase
    {
        private readonly ICervixManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public CervixController(ICervixManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            this._hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Get All List for Measurement_CervixMeasurementValue Data List
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] CervixViewModel flagViewModel)
        {
            var count = await this._Manager.CountAsync(flagViewModel);
            if (count > 0)
            {
                IEnumerable<CervixViewModel> data = await this._Manager.RangeAsync(count, flagViewModel);
                return await Task.FromResult(Ok(UserResponse<CervixViewModel>.SendResponse(count, data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(count, null)));
            }
        }

        /// <summary>
        /// Save Measurement_CervixMeasurementValue data with comment and media into system
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CervixViewModel viewModel)
        {

            if (viewModel.ClientId == 0 || viewModel.ClientId == null)
            {
                this.ModelState.AddModelError("ClientError", "Please send client id");
            }

            if (viewModel.PatientId == 0 || viewModel.PatientId == null)
            {
                this.ModelState.AddModelError("PatientError", "Please send patient id");
            }

            if (viewModel.PartographId == 0 || viewModel.PartographId == null)
            {
                this.ModelState.AddModelError("PartographError", "Please send Partograph id");
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            // viewModel.UpdatedBy = base.CurrentUserEmail;
            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<CervixViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        /// <summary>
        /// Update the Measurement_CervixMeasurementValue data with comment and media also update the existing comment
        /// and media as well
        /// </summary>
        [HttpPut]
        public async Task<IActionResult> Put([FromBody] CervixViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            // viewModel.UpdatedBy = this.CurrentUserEmail;
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(this.Ok(UserResponse<CervixViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        /// Delete (soft removal) existing Measurement_CervixMeasurementValue data from system 
        ///
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(long id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            // var CurrentUserEmail = base.CurrentUserEmail;

            if (Data != null)
            {
                await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
                return await Task.FromResult(this.Ok(UserResponse<CervixViewModel>.SendResponse(Data))).ConfigureAwait(false);
            }
            return await Task.FromResult(this.Ok(UserResponse<string>.SendResponse("No records found"))).ConfigureAwait(false);
        }



        /// <summary>
        /// Get the Measurement_CervixMeasurementValue Records from Existing System By Measurement_CervixMeasurementValue ID
        /// if any comments and media exist then it records also avaialble 
        /// </summary>
        [HttpPost(Constants.Identifire.GetByID)]
        public async Task<IActionResult> GetByID([FromBody] CervixViewModel viewModel)
        {
            CervixViewModel Data = await this._Manager.GetAsync(viewModel.Id);
            return await Task.FromResult(this.Ok(UserResponse<CervixViewModel>.SendResponse(Data)));
        }
    }
}