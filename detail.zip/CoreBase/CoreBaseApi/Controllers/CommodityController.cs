﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CommodityController : ControllerBase
    {
        private readonly ICommodityManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommodityController"/> class.
        /// </summary>
        /// <param name="manager">Commodity Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public CommodityController(ICommodityManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        /// <summary>
        /// this end point get all list of Commodity.
        /// Point No 82. In Tosca Order Requirement V2 Doccument.
        /// </summary>
        /// <param name="requestCommonViewModel">Commodity View Model for filter purpose.</param>
        /// <returns>list of Commodity.</returns>
        /// 
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CommodityViewModel commodityModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this.manager.AddAsync(commodityModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<CommodityViewModel>.SendResponse(commodityModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        [HttpPost(Constants.Identifire.Update)]
        public async Task<IActionResult> UpdateCommodity([FromBody] CommodityViewModel commodityModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await this.manager.UpdateAsync(commodityModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<CommodityViewModel>.SendResponse(commodityModel))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.GetDefaultCommodity)]
        public async Task<IActionResult> GetDefaultCommodity([FromBody] RequestCommonViewModel requestCommonViewModel)
        {
            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (requestCommonViewModel.ContractID == 0 && requestCommonViewModel.MaterialID == 0 && requestCommonViewModel.ShipToLocationID == 0)
            {
                this.ModelState.AddModelError(Constants.Errors.Formnotsubmit, Constants.Errors.Formnotsubmit);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.GetDefaultCommodity(requestCommonViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<CommodityViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpGet(Constants.Identifire.List)]
        public async Task<ActionResult> GetList()
        {
            IEnumerable<CommodityViewModel> data = await this.manager.ListCommodityAsync(null);
            if (data != null)
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(data.Count())));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetAllCom)]
        public async Task<IActionResult> GetAllCommodity([FromBody] CommodityViewModel requestCommonViewModel)
        {
            if (requestCommonViewModel.ClientID == null || requestCommonViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<CommodityViewModel> data = await this.manager.GetAllCommodity(requestCommonViewModel);

            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<CommodityViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost(Constants.Identifire.GetAll)]
        public async Task<IActionResult> GetAllCommodityType([FromBody] CommodityViewModel commoditytypeViewModel)
        {
            if (commoditytypeViewModel.ClientID == null || commoditytypeViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.ListAsync(commoditytypeViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<CommodityViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost("GetAllSegment")]
        public async Task<IActionResult> GetAllSegment([FromBody] DepartmentViewModel departmentViewModel)
        {
            //if (departmentViewModel.ClientId == null || departmentViewModel.ClientId <= 0)
            //{
            //    this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            //}

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.ListSegmentAsync(departmentViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<DepartmentViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] CommodityDelete commoditydelete)
        {
            var allIds = commoditydelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        [HttpPost("CheckCommodity")]
        public async Task<IActionResult> CommodityExist([FromBody] CommodityViewModel viewModel)
        {
            var code = viewModel.Code;
            var result = await this.manager.getCommodity(code);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
        }
    }
}
