﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CurrentMaterialOnhandController : ControllerBase
    {
        private readonly ICurrentMaterialOnhandManager manager;

        /// <summary>
        /// Initializes a new instance of the <see cref="CurrentMaterialOnhandController"/> class.
        /// </summary>
        /// <param name="manager">CurrentMaterialOnhand Manager with the help of DI.</param>
        /// <param name="configurationKeys">Configuratin settings.</param>
        public CurrentMaterialOnhandController(ICurrentMaterialOnhandManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        /// <summary>
        /// Get List for all inventory material along with details.
        /// </summary>
        /// <param name="CurrentMaterialOnhandViewModel"> Model should contain pageNo,pageSize, filterOn properties in order to have server side pagination and fiteration</param>
        [HttpPost("GetAllCurrentMaterialOnhand")]
        public async Task<ActionResult> GetAllCurrentMaterialOnhand([FromBody] CurrentMaterialOnhandViewModel inventoryViewModel)
        {
            if (inventoryViewModel.ClientID == null || inventoryViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            IEnumerable<CurrentMaterialOnhandViewModel> data = await this.manager.GetAllCurrentMaterialOnhand(inventoryViewModel);
            if (data != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<CurrentMaterialOnhandViewModel>.SendResponse(data.Count(), data)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0, null)));
            }
        }

        [HttpPost("TotalRecordsCount")]
        public async Task<ActionResult> GetRcordCount([FromBody] CurrentMaterialOnhandViewModel viewModel)
        {
            if (viewModel.ClientID == null || viewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var count = await this.manager.RcordCountAsync(viewModel);
            if (count != 0)
            {
                return await Task.FromResult(this.Ok(UserResponse<CurrentMaterialOnhandViewModel>.SendResponse(count, null)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<CurrentMaterialOnhandViewModel>.SendResponse(0, null)));
            }
        }

        [HttpPost("TotalSumQuantity")]
        public async Task<ActionResult> GetSumQuantity([FromBody] CurrentMaterialOnhandViewModel viewModel)
        {
            if (viewModel.ClientID == null || viewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var quantity = await this.manager.GetSumQuantity(viewModel);
            if (quantity != string.Empty)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(quantity)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(0)));
            }
        }

        [HttpPost("SaveCurrentMaterialOnhand")]
        public async Task<ActionResult> SaveCurrentMaterialOnhand([FromBody] CurrentMaterialOnhandViewModel viewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<CurrentMaterialOnhandViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        [HttpPost("UpdateComment")]
        public async Task<IActionResult> UpdateComment([FromBody] CurrentMaterialOnhandViewModel model)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.UpdateCommentAsync(model).ConfigureAwait(false);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<CurrentMaterialOnhandViewModel>.SendResponse(model)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        [HttpPost("UpdateCurrentMaterialOnhand")]
        public async Task<IActionResult> UpdateCurrentMaterialOnhand([FromBody] CurrentMaterialOnhandViewModel model)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var data = await this.manager.UpdateAsync(model).ConfigureAwait(false);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<CurrentMaterialOnhandViewModel>.SendResponse(model)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteAll([FromBody] InventoryDeleteModel deleteModel)
        {
            var allIds = deleteModel.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }
    }
}
