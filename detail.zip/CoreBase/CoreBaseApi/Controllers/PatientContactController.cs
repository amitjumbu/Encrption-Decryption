﻿using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Filters;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Helpers.Enums;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreBaseApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PatientContactController : ControllerBase
    {

        private readonly IPatientContactValueManager _Manager;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;


        public PatientContactController(IPatientContactValueManager DIManager, IHostingEnvironment hostingEnvironment)
        {
            this._Manager = DIManager;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        ///User can get Retrieves data from Patient Contact page wise.hi
        /// </summary>
        [HttpPost(Constants.Identifire.List)]
        public async Task<ActionResult> List([FromBody] PatientContactValueViewModel flagViewModel)
        {
            var Count = await this._Manager.CountAsync(flagViewModel);
            IEnumerable<PatientContactValueViewModel> goldenMaster = await this._Manager.RangeAsync(Count, flagViewModel);
            return await Task.FromResult(Ok(UserResponse<PatientContactValueViewModel>.SendResponse(Count, goldenMaster)));
        }

        /// <summary>
        ///add data .
        /// </summary>
        [HttpPost]
        public async Task<ActionResult> patientContactPost_Old([FromBody] PatientContactValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientContactValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        public async Task<ActionResult> patientContactPost([FromBody] PatientContactValueViewModel viewModel)
        {
           if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string role = "";
            if (role != string.Empty)
            {
                throw new CustomException(ResponseErrorMessage.GetErrorMessage(ErrorMessageType.UnAuthorizeEdit));
            }

            var data = await this._Manager.AddAsync(viewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<PatientContactValueViewModel>.SendResponse(viewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }




        /// <summary>
        /// update candidate data flag wise.
        /// </summary>
        [HttpPut(Constants.Identifire.Update)]
        public async Task<IActionResult> Put([FromBody] PatientContactValueViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this._Manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientContactValueViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        /// <summary>
        ///delete candidate record behalf of id
        /// </summary>
        [HttpDelete(Constants.Identifire.Id)]
        public async Task<IActionResult> Delete(int id)
        {
            var Data = await this._Manager.GetAsync(id).ConfigureAwait(false);
            await this._Manager.DeleteAsync(id, "admin@abc.com").ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<PatientContactValueViewModel>.SendResponse(Data))).ConfigureAwait(false);
        }
    }
}
