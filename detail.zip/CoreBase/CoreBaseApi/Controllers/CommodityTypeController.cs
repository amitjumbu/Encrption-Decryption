﻿namespace CoreBaseAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.Services;
    using CoreBaseBusiness.ViewModel;    
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;

    /// <summary>
    /// Commodity Controller Developed By Kapil Pandey.
    /// On : 19-Sep-2020.
    /// </summary>
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class CommodityTypeController : ControllerBase
    {
        private readonly ICommodityTypeManager manager;


        public CommodityTypeController(ICommodityTypeManager manager, IOptions<ConfigurationKeys> configurationKeys)
        {
            this.manager = manager;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] CommodityTypeViewModel commoditytypeViewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var data = await this.manager.AddAsync(commoditytypeViewModel);
            if (data == true)
            {
                return await Task.FromResult(Ok(UserResponse<CommodityTypeViewModel>.SendResponse(commoditytypeViewModel)));
            }
            else
            {
                return await Task.FromResult(Ok(UserResponse<object>.SendResponse(false)));
            }

        }

        [HttpPost(Constants.Identifire.GetAllCommodityType)]
        public async Task<IActionResult> GetAllCommodityType([FromBody] CommodityTypeViewModel commoditytypeViewModel)
        {
            if (commoditytypeViewModel.ClientID == null || commoditytypeViewModel.ClientID <= 0)
            {
                this.ModelState.AddModelError(Constants.Errors.InvalidClient, Constants.Errors.InvalidClient);
            }

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }

            var finalResult = await this.manager.ListAsync(commoditytypeViewModel);

            if (finalResult != null && finalResult != null)
            {
                return await Task.FromResult(this.Ok(UserResponse<IEnumerable<CommodityTypeViewModel>>.SendResponse(finalResult)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }

        [HttpPost(Constants.Identifire.UpdateAll)]
        public async Task<IActionResult> UpdateAll(IEnumerable<CommodityTypeViewModel> viewModel)
        {
            var data = await this.manager.UpdateAll(viewModel).ConfigureAwait(false);

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(data))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.Update)]
        public async Task<IActionResult> UpdateCommodityType([FromBody] CommodityTypeViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await this.manager.UpdateAsync(viewModel).ConfigureAwait(false);
            return await Task.FromResult(Ok(UserResponse<CommodityTypeViewModel>.SendResponse(viewModel))).ConfigureAwait(false);
        }

        [HttpPost(Constants.Identifire.DeleteAll)]
        public async Task<ActionResult> DeleteALl([FromBody] CommodityTypeDelete commoditytypedelete)
        {
            var allIds = commoditytypedelete.IDs.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();

            if (allIds.Any())
            {
                var result = await this.manager.DeleteAllAsync(allIds);

                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
            }

            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
        }

        [HttpPost("CheckCommodityType")]
        public async Task<IActionResult> CommodityTypeExist([FromBody] CommodityTypeViewModel viewModel)
        {
            var comTypCode = viewModel.Code;
            var result = await this.manager.getComTypExist(comTypCode);
            return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(result)));
        }
    }
}
