﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Helpers;
using CoreBaseBusiness.Managers;
using CoreBaseBusiness.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft;
using Newtonsoft.Json.Linq;

namespace CoreBaseApi.Controllers
{
    // [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ApplicationPermissionController : ControllerBase
    {
        
        private readonly IApplicationPermissionManager ApplicationPermissionManager;
       
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMapper mapper;

        public ApplicationPermissionController(IApplicationPermissionManager _applicationPermissionManager, IHostingEnvironment hostingEnvironment)
        {
            this.ApplicationPermissionManager = _applicationPermissionManager;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpPost]
        public async Task<ActionResult> SavePermission([FromBody] ApplicationPermissionViewModel applicationPermissionViewModel)
        {
            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var data = await this.ApplicationPermissionManager.AddAsync(applicationPermissionViewModel);
            if (data == true)
            {
                return await Task.FromResult(this.Ok(UserResponse<ApplicationPermissionViewModel>.SendResponse(applicationPermissionViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }

        }


        [HttpPost]
        public async Task<IActionResult> UpdatePermission([FromBody]ApplicationPermissionViewModel applicationPermissionViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.ApplicationPermissionManager.UpdateAsync(applicationPermissionViewModel);
            if (result)
            {
                return await Task.FromResult(this.Ok(UserResponse<ApplicationPermissionViewModel>.SendResponse(applicationPermissionViewModel)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(null)));
            }
        }


        [HttpPost]
        public async Task<IActionResult> GetApplicationPermission([FromBody] ApplicationPermissionViewModel applicationPermissionViewModel)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.ApplicationPermissionManager.GetElementPermission(applicationPermissionViewModel);

            return await Task.FromResult(this.Ok(UserResponse<ApplicationPermissionViewModel>.SendResponse(applicationPermissionViewModel)));
            
        }


        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] EntityRecordRemoveRequestPacket entityRecordRemoveRequestPacket)
        {

            if (!this.ModelState.IsValid)
            {
                return this.BadRequest(this.ModelState);
            }
            var result = await this.ApplicationPermissionManager.Delete(entityRecordRemoveRequestPacket);
            if (result)
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(true)));
            }
            else
            {
                return await Task.FromResult(this.Ok(UserResponse<object>.SendResponse(false)));
            }
        }



    }
}