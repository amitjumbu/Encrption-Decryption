﻿namespace CoreBaseApi
{
    using System.IO;
    using AutoMapper;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Managers;
    using CoreBaseData;
    using CoreBaseData.Repository.Implementation;
    using CoreBaseData.Repository.Interface;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;
    using CoreBaseData.Models.Entity2;
    using CoreBaseBusiness.ViewModel;
    using CoreBaseBusiness.Configuretion;
    using CoreBaseBusiness.Filters;
    using CoreBaseBusiness.Helpers;
    using Hangfire;
    using CoreBaseBusiness.Services;



    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();



            services.AddMvc(config =>
            {
                config.Filters.Add(typeof(ExceptionFilter));
            });

            //services.AddMvc(config =>
            //{
            //    config.Filters.Add(typeof(ExceptionFilter));
            //    //config.Filters.Add(typeof(ValidateModelStateAttribute));
            //})
            //    .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver())
            //    .SetCompatibilityVersion(CompatibilityVersion.Version_2_2);


            #region Enable CORS
            //services.AddCors(options =>
            //{
            //    options.AddPolicy("CorsPolicy",
            //        builder => builder.AllowAnyOrigin()
            //        .AllowAnyMethod()
            //        .AllowAnyHeader()
            //        .AllowCredentials());
            //});
            services.AddCors();
            #endregion

            #region SQL - connection
            //services.AddDbContext<EICDBContext>(opts => opts.UseSqlServer(Configuration["ConnectionString:AsrBookDb"]), b => b.MigrationsAssembly("ASR.Book.API"));
            //services.AddControllers();
            //options.UseSqlServer(connectionString,x => x.MigrationsAssembly("MyApp.Migrations"));

            //-----------------//
            var configuration = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json")
           .Build();
            //string dbConnectionString = configuration.GetConnectionString("AsrBookDb");
            string dbConnectionString = configuration["ConnectionString:CoreBaseDB"];
            string assemblyName = typeof(CoreDBContext).Namespace;

            services.AddDbContext<CoreDBContext>(options =>
               {
                   options.UseSqlServer(dbConnectionString, optionsBuilder =>
                         optionsBuilder.MigrationsAssembly("CoreBaseApi"));

               }, ServiceLifetime.Transient

           );



            string dbConnectionStringAdectec = configuration["ConnectionString:CoreBaseDB"];
            string assemblyNameAdectec = typeof(ADecTecCoreBaseDBContext).Namespace;

            services.AddDbContext<ADecTecCoreBaseDBContext>(options =>
            {
                options.UseSqlServer(dbConnectionStringAdectec,
                    optionsBuilder =>
                        optionsBuilder.MigrationsAssembly("CoreBaseApi")
                );
            }, ServiceLifetime.Transient

           );

            #endregion

            #region Swagger integration
            // Register the Swagger generator, defining one or more Swagger documents  
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Base API - v1", Version = "v1" });
            });
            #endregion

            #region AutoMapper configuration
            services.AddAutoMapper();//am => am.AddProfile(new MappingProfile()));
            #endregion

            // code for Hangfire service configuration
            services.AddHangfire(config =>
                 config.SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                 .UseSimpleAssemblyNameTypeSerializer()
                 .UseDefaultTypeSerializer()
                 .UseSqlServerStorage(configuration["ConnectionString:CoreBaseDB"]));
            services.AddScoped<IHangfireOperation, HangfireOperation>();

            // end hangfire service confirguration

            var notificationMetadata = configuration.GetSection("NotificationMetadata").Get<EmailConfigurationViewModel>();
            services.AddSingleton(notificationMetadata);
            services.AddScoped<IInstanseLogger, InstanseLogger>();

            services.AddTransient<ICreditSummaryContractManager, CreditSummaryContractManager>();
            services.AddTransient<IARInvoiceManager, ARInvoiceManager>();
            // services.AddTransient<IARInvoiceAgeDetailRepository, IARInvoiceAgeDetailRepository>();

            services.AddTransient<IFreightLaneManager, FreightLaneManager>();
            services.AddTransient<IFreightLaneRepository, FreightLaneRepository>();

            services.AddTransient<IFreightModeManager, FreightModeManager>();
            services.AddTransient<IFreightModeRepository, FreightModeRepository>();
            services.AddTransient<IMaterialGroupManager, MaterialGroupManager>();
            services.AddTransient<IMaterialGroupRepository, MaterialGroupRepository>();

            services.AddTransient<IMaterialGroupDetailsManager, MaterialGroupDetailsManager>();
            services.AddTransient<IMaterialGroupDetailsRepository, MaterialGroupDetailsRepository>();

            services.AddTransient<IMaterialHierarchyManager, MaterialHierarchyManager>();
            services.AddTransient<IMaterialHierarchyRepository, MaterialHierarchyRepository>();

            services.AddTransient<IMaterialPropertyManager, MaterialPropertyManager>();
            services.AddTransient<IMaterialPropertyRepository, MaterialPropertyRepository>();

            services.AddTransient<IResourceRoleListManager, ResourceRoleListManager>();
            services.AddTransient<IResourceRoleListRepository, ResourceRoleListRepository>();

            services.AddTransient<ICurrentMaterialOnhandManager, CurrentMaterialOnhandManager>();
            services.AddTransient<ICurrentMaterialOnhandRepository, CurrentMaterialOnhandRepository>();

            services.AddTransient<IMaterialHierarchyDetailManager, MaterialHierarchyDetailManager>();
            services.AddTransient<IMaterialPropertyDetailManager, MaterialPropertyDetailManager>();
            services.AddTransient<IMaterialPropertyDetailRepository, MaterialPropertyDetailRepository>();
            services.AddTransient<IEquipmentTypeMaterialPropertyDetailManager, EquipmentTypeMaterialPropertyDetailManager>();
            services.AddTransient<IEquipmentTypeMaterialPropertyDetailRepository, EquipmentTypeMaterialPropertyDetailRepository>();

            services.AddTransient<IFreightModeEquipTypeMapManager, FreightModeEquipTypeMapManager>();
            services.AddTransient<IFreightModeEquipmentTypeMapRepository, FreightModeEquipmentTypeMapRepository>();
            services.AddTransient<IPatientRepository, PatientRepository>();
            services.AddTransient<IPatientAddressRepository, PatientAddressRepository>();
            services.AddTransient<IPatientContactRepository, PatientContactRepository>();

            services.AddTransient<IOperatingLocationRepository, OperatingLocationRepository>();
            services.AddTransient<IOperatingLocationManager, OperatingLocationManager>();
            services.AddTransient<IOperatingLocationAddressRepository, OperatingLocationAddressRepository>();
            services.AddTransient<IOperatingLocationAddressManager, OperatingLocationAddressManager>();
            services.AddTransient<IOperatingLocationContactRepository, OperatingLocationContactRepository>();
            services.AddTransient<IOperatingLocationContactManager, OperatingLocationContactManager>();
            services.AddTransient<IPatientValueManager, PatientValueManager>();
            services.AddTransient<IPatientAddressValueManager, PatientAddressValueManager>();
            services.AddTransient<IPatientContactValueManager, PatientContactValueManager>();
            services.AddTransient<IBPRepository, BPRepository>();
            services.AddTransient<IAcetonRepository, AcetonRepository>();
            services.AddTransient<IBPManager, BPManager>();
            services.AddTransient<IAcetonManager, AcetonManager>();
            services.AddTransient<IAmnioticFluidRepository, AmnioticFluidRepository>();
            services.AddTransient<IAmnioticFluidManager, AmnioticFluidManager>();
            services.AddTransient<ICervixRepository, CervixRepository>();
            services.AddTransient<ICervixManager, CervixManager>();
            services.AddTransient<IContractionsPer10MinRepository, ContractionsPer10MinRepository>();
            services.AddTransient<IContractionsPer10MinManager, ContractionsPer10MinManager>();
            services.AddTransient<ICommentRepository, CommentRepository>();
            services.AddTransient<ICommentManager, CommentManager>();
            services.AddTransient<IDecentofHeadRepository, DecentofHeadRepository>();
            services.AddTransient<IDecentofHeadManager, DecentofHeadManager>();
            services.AddTransient<IDropsMinRepository, DropsMinRepository>();
            services.AddTransient<IDropsMinManager, DropsMinManager>();
            services.AddTransient<IDrugsGivenIVFluidsRepository, DrugsGivenIVFluidsRepository>();
            services.AddTransient<IDrugsGivenIVFluidsManager, DrugsGivenIVFluidsManager>();
            services.AddTransient<IFetalHeartRateRepository, FetalHeartRateRepository>();
            services.AddTransient<IFetalHeartRateManager, FetalHeartRateManager>();
            services.AddTransient<IMouldingRepository, MouldingRepository>();
            services.AddTransient<IMouldingManager, MouldingManager>();
            services.AddTransient<IOxytocinULRepository, OxytocinULRepository>();
            services.AddTransient<IOxytocinULManager, OxytocinULManager>();
            services.AddTransient<IPGEAlertPopUpRepository, PGEAlertPopUpRepository>();
            services.AddTransient<IPGEAlertPopUpManager, PGEAlertPopUpManager>();
            services.AddTransient<IProteinRepository, ProteinRepository>();
            services.AddTransient<IProteinManager, ProteinManager>();
            services.AddTransient<IPulseRepository, PulseRepository>();
            services.AddTransient<IPulseManager, PulseManager>();
            services.AddTransient<ITemperatureRepository, TemperatureRepository>();
            services.AddTransient<ITemperatureManager, TemperatureManager>();
            services.AddTransient<IVolumeRepository, VolumeRepository>();
            services.AddTransient<IVolumeManager, VolumeManager>();
            services.AddTransient<ICaputRepository, CaputRepository>();
            services.AddTransient<ICaputManager, CaputManager>();
            services.AddTransient<IPGERepository, PGERepository>();
            services.AddTransient<IPGEManager, PGEManager>();
            services.AddTransient<IThirdChartRepository, Measurement_ComplicationsMeasurementValueRepository>();
            services.AddTransient<IThirdChartManager, ThirdChartManager>();
            services.AddTransient<IBPCommentRepository, BPCommentRepository>();
            services.AddTransient<IAcetonCommentRepository, AcetonCommentRepository>();
            services.AddTransient<IVolumeCommentRepository, VolumeCommentRepository>();
            services.AddTransient<IProteinCommentRepository, ProteinCommentRepository>();
            services.AddTransient<IFetalHeartRateCommentRepository, FetalHeartRateCommentRepository>();
            services.AddTransient<IAmnioticFluidCommentRepository, AmnioticFluidCommentRepository>();
            services.AddTransient<ICervixCommentRepository, CervixCommentRepository>();
            services.AddTransient<ICervixManager, CervixManager>();
            services.AddTransient<IContractionsPer10MinCommentRepository, ContractionsPer10MinCommentRepository>();
            services.AddTransient<IDecentofHeadCommentRepository, DecentofHeadCommentRepository>();
            services.AddTransient<IDropsMinCommentRepository, DropsMinCommentRepository>();
            services.AddTransient<IDrugsGivenIVFluidsCommentRepository, DrugsGivenIVFluidsCommentRepository>();
            services.AddTransient<IDrugsGivenIVFluidsManager, DrugsGivenIVFluidsManager>();
            services.AddTransient<IMouldingCommentRepository, MouldingCommentRepository>();
            services.AddTransient<IOxytocinULCommentRepository, OxytocinULCommentRepository>();
            services.AddTransient<IPGEAlertPopUpCommentRepository, PGEAlertPopUpCommentRepository>();
            services.AddTransient<IPulseCommentRepository, PulseCommentRepository>();
            services.AddTransient<ICaputCommentRepository, CaputCommentRepository>();
            services.AddTransient<IPGECommentRepository, PGECommentRepository>();
            services.AddTransient<IMeasurement_ComplicationsMeasurementCommentRepository, Measurement_ComplicationsMeasurementCommentRepository>();
            services.AddTransient<IBPMediaRepository, BPMediaRepository>();
            services.AddTransient<IAcetonMediaRepository, AcetonMediaRepository>();
            services.AddTransient<IVolumeMediaRepository, VolumeMediaRepository>();
            services.AddTransient<IProteinMediaRepository, ProteinMediaRepository>();
            services.AddTransient<IFetalHeartRateMediaRepository, FetalHeartRateMediaRepository>();
            services.AddTransient<IAmnioticFluidMediaRepository, AmnioticFluidMediaRepository>();
            services.AddTransient<ICervixMediaRepository, CervixMediaRepository>();
            services.AddTransient<ICervixManager, CervixManager>();
            services.AddTransient<IContractionsPer10MinMediaRepository, ContractionsPer10MinMediaRepository>();
            services.AddTransient<IDecentofHeadMediaRepository, DecentofHeadMediaRepository>();
            services.AddTransient<IDropsMinMediaRepository, DropsMinMediaRepository>();
            services.AddTransient<IDrugsGivenIVFluidsMediaRepository, DrugsGivenIVFluidsMediaRepository>();
            services.AddTransient<IDrugsGivenIVFluidsManager, DrugsGivenIVFluidsManager>();
            services.AddTransient<IMouldingMediaRepository, MouldingMediaRepository>();
            services.AddTransient<IOxytocinULMediaRepository, OxytocinULMediaRepository>();
            services.AddTransient<IPGEAlertPopUpMediaRepository, PGEAlertPopUpMediaRepository>();
            services.AddTransient<IPulseMediaRepository, PulseMediaRepository>();
            services.AddTransient<ICaputMediaRepository, CaputMediaRepository>();
            services.AddTransient<IPGEMediaRepository, PGEMediaRepository>();
            services.AddTransient<IMeasurement_ComplicationsMeasurementMediaRepository, Measurement_ComplicationsMeasurementMediaRepository>();
            services.AddTransient<IGraphCommonCommentManager, GraphCommonCommentManager>();
            services.AddTransient<IGraphCommonMediaManager, GraphCommonMediaManager>();

            services.AddTransient<ISystemAlertManager, SystemAlertManager>();
            services.AddTransient<ISystemAlertRepository, SystemAlertRepository>();
            services.AddTransient<IUserAlertManager, UserAlertManager>();
            services.AddTransient<IUserAlertRepository, UserAlertRepository>();
            services.AddTransient<ISystemAlertCalendarManager, SystemAlertCalendarManager>();
            services.AddTransient<ISystemAlertCalendarRepository, SystemAlertCalendarRepository>();

            services.AddTransient<IPartographHistoryManager, PartographHistoryManager>();

            services.AddTransient<ILocationManager, LocationManager>();
            services.AddTransient<ILocationRepository, LocationRepository>();


            services.AddTransient<IFuelPriceManager, FuelPriceManager>();
            services.AddTransient<IFuelPriceRepository, FuelPriceRepository>();

            services.AddTransient<ILocationAverageShipFromMileMappingManager, LocationAverageShipFromMileMappingManager>();
            services.AddTransient<ILocationAverageShipFromMileMappingRepository, LocationAverageShipFromMileMappingRepository>();

            services.AddTransient<IOperatingLocationPropertyDetailRepository, OperatingLocationPropertyDetailRepository>();
            services.AddTransient<IPatientResourceListManager, PatientResourceListManager>();
            services.AddTransient<IPatientResourceListRepository, PatientResourceListRepository>();

            services.AddTransient<ILocationTypeManager, LocationTypeManager>();
            services.AddTransient<ILocationTypeRepository, LocationTypeRepository>();

            services.AddTransient<ILocationPreferredMaterialRepository, LocationPreferredMaterialRepository>();
            services.AddTransient<ILocationPreferredMaterialManager, LocationPreferredMaterialManager>();

            services.AddTransient<ICustomerPropertyDetailRepository, CustomerPropertyDetailRepository>();
            services.AddTransient<ICustomerPropertyDetailManager, CustomerPropertyDetailManager>();

            services.AddTransient<IShippingLocationDefaultPackagingMaterialRepository, ShippingLocationDefaultPackagingMaterialRepository>();
            services.AddTransient<IShippingLocationDefaultPackagingMaterialManager, ShippingLocationDefaultPackagingMaterialManager>();

            services.AddTransient<IMaterialManager, MaterialManager>();
            services.AddTransient<IMaterialRepository, MaterialRepository>();
            services.AddTransient<IOrganizationPropertyDetailManager, OrganizationPropertyDetailManager>();
            services.AddTransient<IOrganizationPropertyDetailRepository, OrganizationPropertyDetailRepository>();
            services.AddTransient<IFuelSurchargeIndexManager, FuelSurchargeIndexManager>();
            services.AddTransient<IFuelSurchargeIndexRepository, FuelSurchargeIndexRepository>();
            services.AddTransient<IMedicationChartGridManager, MedicationChartGridManager>();
            services.AddTransient<IMedicationChartGridRepository, MedicationChartGridRepository>();
            services.AddTransient<ICriticalPatientMonitoringGridManager, CriticalPatientMonitoringGridManager>();
            services.AddTransient<ICriticalPatientMonitoringRepository, CriticalPatientMonitoringRepository>();
            services.AddTransient<IPatientObstetricFormulaManager, PatientObstetricFormulaManager>();
            services.AddTransient<IPatientObstetricFormulaRepository, PatientObstetricFormulaRepository>();

            services.AddTransient<IWebControlTypeManager, WebControlTypeManager>();
            services.AddTransient<IWebControlTypeRepository, WebControlTypeRepository>();

            services.AddTransient<IWebControlTypePossibleValueManager, WebControlTypePossibleValueManager>();
            services.AddTransient<IWebControlTypePossibleValueRepository, WebControlTypePossibleValueRepository>();

            services.AddTransient<IDynamicMeasurementManager, DynamicMeasurementManager>();
            services.AddTransient<IDynamicMeasurementRepository, DynamicMeasurementRepository>();

            services.AddTransient<IValidationManager, ValidationManager>();
            services.AddTransient<IValidationRepository, ValidationRepository>();

            services.AddTransient<IOrderCalculationManager, OrderCalculationManager>();

            services.AddTransient<IChargeManager, ChargeManager>();
            services.AddTransient<IChargeTypeManager, ChargeTypeManager>();
            services.AddTransient<IChargeCategoryManager, ChargeCategoryManager>();
            services.AddTransient<IChargeComputationMethodManager, ChargeComputationMethodManager>();
            services.AddTransient<IChargeComputationMethodMappingManager, ChargeComputationMethodMappingManager>();

            services.AddTransient<ICommodityManager, CommodityManager>();
            services.AddTransient<ICommodityRepository, CommodityRepository>();
            services.AddTransient<IResourceRolesManager, ResourceRolesManager>();
            services.AddTransient<IPatientContraceptionHistoryManager, PatientContraceptionHistoryManager>();
            services.AddTransient<IPatientContraceptionHistoryRepository, PatientContraceptionHistoryRepository>();

            services.AddTransient<ICommodityTypeManager, CommodityTypeManager>();
            services.AddTransient<ICommodityTypeRepository, CommodityTypeRepository>();

            services.AddTransient<ISystemTypeManager, SystemTypeManager>();
            services.AddTransient<ISystemTypeRepository, SystemTypeRepository>();

            services.AddTransient<IShipmentManager, ShipmentManager>();
            services.AddTransient<IShipmentRepository, ShipmentRepository>();

            services.AddTransient<ISalesOrderManager, SalesOrderManager>();
            services.AddTransient<ISalesOrderRepository, SalesOrderRepository>();

            services.AddTransient<ISalesOrderDetailManager, SalesOrderDetailManager>();
            services.AddTransient<ISalesOrderDetailRepository, SalesOrderDetailRepository>();

            services.AddTransient<IPartographManager, PartographManager>();
            services.AddTransient<IPartographRepository, PartographRepository>();
            services.AddTransient<IPatientMensturalHistoryManager, PatientMensturalHistoryManager>();
            services.AddTransient<IPatientMensturalHistoryRepository, PatientMensturalHistoryRepository>();

            services.AddTransient<IPatientHistoryofPresentIllnessManager, PatientHistoryofPresentIllnessManager>();
            services.AddTransient<IPatientHistoryofPresentIllnessRepository, PatientHistoryofPresentIllnessRepository>();
            services.AddTransient<IPatientContracpetionHisotryMethodManager, PatientContracpetionHisotryMethodManager>();
            services.AddTransient<IPatientContracpetionHisotryMethodRepository, PatientContracpetionHisotryMethodRepository>();
            services.AddTransient<IPatientPersonalHistoryManager, PatientPersonalHistoryManager>();
            services.AddTransient<IPatientPersonalHistoryRepository, PatientPersonalHistoryRepository>();
            services.AddTransient<ICountryOfOriginOfMaterialRepository, CountryOfOriginOfMaterialRepository>();
            services.AddTransient<ICountryOfOriginOfMaterialManager, CountryOfOriginOfMaterialManager>();
            services.AddTransient<IUserAlertHistoryManager, UserAlertHistoryManager>();

            //services.AddTransient<IPatManager, SalesOrderDetailManager>();
            //services.AddTransient<ISalesOrderDetailRepository, SalesOrderDetailRepository>();

            services.AddTransient<IEmailSender, EmailSender>();

            services.AddTransient<IEquipmentTypeMaterialPropertyDetailRepository, EquipmentTypeMaterialPropertyDetailRepository>();
            services.AddTransient<IBusinessPartnerManager, BusinessPartnerManager>();
            services.AddTransient<ICustomerByLocationManager, CustomerByLocationManager>();

            services.AddTransient<IContractManager, ContractManager>();
            services.AddTransient<IShipmentNaftaReportDataRepository, ShipmentNaftaReportDataRepository>();
            services.AddTransient<IShipmentNaftaReportDataManager, ShipmentNaftaReportDataManager>();
            services.AddTransient<ILocationForecastMaterialManager, LocationForecastMaterialManager>();
            services.AddTransient<IBusinessPartnerPropertyDetailManager, BusinessPartnerPropertyDetailManager>();
            services.AddTransient<ICarrierPropertyDetailManager, CarrierPropertyDetailManager>();
            services.AddTransient<ICustomerContractPropertyDetailRepository, CustomerContractPropertyDetailRepository>();
            services.AddTransient<IBusinessPartnerContractPropertyDetailRepository, BusinessPartnerContractPropertyDetailRepository>();
            services.AddTransient<IForecastManager, ForecastManager>();
            services.AddTransient<ICalendarTypeManager, CalendarTypeManager>();
            services.AddTransient<IConvertEnglishToSpanish, ConvertEnglishToSpanish>();
            services.AddTransient<IClaimManager, ClaimManager>();

            services.AddHangfireServer();
            services.AddHttpClient();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            #region Enable CORS
            //app.UseCors("CorsPolicy");
            //app.UseCors(options => options.AllowAnyOrigin());
            app.UseCors(x => x
             .AllowAnyMethod()
             .AllowAnyHeader()
             .SetIsOriginAllowed(origin => true) // allow any origin
             .AllowCredentials()); // allow credentials
            #endregion

            #region Swagger Integration
            // Enable middleware to serve generated Swagger as a JSON endpoint.  
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.  
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "EY EIC - Base API - v1");
            });
            #endregion
            app.UseHttpsRedirection();

            app.UseMiddleware<RequestResponseMiddleware>();

            app.UseRouting();

            app.UseAuthorization();
            app.UseHangfireDashboard();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
