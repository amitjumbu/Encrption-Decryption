﻿using Microsoft.EntityFrameworkCore;

namespace CoreBaseData.Models.Entity2
{
    public partial class CoreBaseDBContext : DbContext
    {
        public CoreBaseDBContext()
        {
        }

        public CoreBaseDBContext(DbContextOptions<CoreBaseDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CurrentMaterialOnhand> CurrentMaterialOnhand { get; set; }
       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=10.1.10.16;database=ADecTecDBDEV;User ID=lamps;password=atlanta@2013");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");
            
            modelBuilder.Entity<CurrentMaterialOnhand>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Amount).HasColumnType("numeric(18, 4)");

                entity.Property(e => e.AmountUomid).HasColumnName("AmountUOMID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.CreateDateTimeBrowser).HasColumnType("datetime");

                entity.Property(e => e.CreateDateTimeServer)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CreatedBy).HasMaxLength(250);

                entity.Property(e => e.InventoryTypeId).HasColumnName("InventoryTypeID");

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.MaterialId).HasColumnName("MaterialID");

                entity.Property(e => e.Quantity).HasColumnType("numeric(18, 4)");

                entity.Property(e => e.QuantityUomid).HasColumnName("QuantityUOMID");

                entity.Property(e => e.SourceSystemId).HasColumnName("SourceSystemID");

                entity.Property(e => e.Status).HasMaxLength(250);

                entity.Property(e => e.UpdateDateTimeBrowser).HasColumnType("datetime");

                entity.Property(e => e.UpdateDateTimeServer)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UpdatedBy).HasMaxLength(250);
            });

        }
    }
}
