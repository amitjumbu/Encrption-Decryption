﻿using System;
using System.Collections.Generic;

namespace CoreBaseData.Models.Entity2
{
    public partial class CurrentMaterialOnhand
    {
        public long Id { get; set; }
        public long LocationId { get; set; }
        public long MaterialId { get; set; }
        public int? InventoryTypeId { get; set; }
        public decimal? Amount { get; set; }
        public int? AmountUomid { get; set; }
        public decimal Quantity { get; set; }
        public int? QuantityUomid { get; set; }
        public string Comment { get; set; }
        public string Status { get; set; }
        public bool IsDeleted { get; set; }
        public int? ClientId { get; set; }
        public int? SourceSystemId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdateDateTimeServer { get; set; }
        public DateTime? UpdateDateTimeBrowser { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreateDateTimeBrowser { get; set; }
        public DateTime CreateDateTimeServer { get; set; }
    }
}
