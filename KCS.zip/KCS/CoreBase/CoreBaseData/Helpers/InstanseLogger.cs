﻿namespace CoreBaseData
{
    using System.Collections.Generic;
    using System.Linq;
    using Newtonsoft.Json;

    public interface IInstanseLogger
    {
        void AddInstanseLogger(string entityName, object entity,bool isRetain = false);

        string InstanseLoggerString();
    }

    public class InstanseLogger : IInstanseLogger
    {
        Dictionary<string, string> instansCollection = null;
        Dictionary<string, string> instansCollectionPermanent = null;

        public InstanseLogger()
        {
            if (this.instansCollection == null)
            {
                this.instansCollection = new Dictionary<string, string>();
                this.instansCollectionPermanent = new Dictionary<string, string>();
            }
            else
            {
                this.instansCollection.Clear();
                this.instansCollectionPermanent.Clear();
            }

        }


        /// <summary>
        /// string this method add Instanse into stack logger.
        /// </summary>
        /// <param name="entityName">Name of object variable.</param>
        /// <param name="entity">value of object.</param>
        /// <param name="isRetain">True/False.</param>
        public void AddInstanseLogger(string entityName, object entity, bool isRetain = false)
        {
            if (entity != null)
            {
                if (isRetain == true)
                {
                    if (this.instansCollectionPermanent.ContainsKey(entityName))
                    {
                        if (entity is string)
                        {
                            this.instansCollectionPermanent[entityName] = entity.ToString();
                        }
                        else
                        {
                            this.instansCollectionPermanent[entityName] = JsonConvert.SerializeObject(entity);
                        }
                    }
                    else
                    {
                        if (entity is string)
                        {
                            this.instansCollectionPermanent.Add(entityName, entity.ToString());
                        }
                        else
                        {
                            this.instansCollectionPermanent.Add(entityName, JsonConvert.SerializeObject(entity));
                        }
                    }

                }
                else
                {
                    if (this.instansCollection.ContainsKey(entityName))
                    {
                        if (entity is string)
                        {
                            this.instansCollection[entityName] = entity.ToString();
                        }
                        else
                        {
                            this.instansCollection[entityName] = JsonConvert.SerializeObject(entity);
                        }
                    }
                    else
                    {
                        this.instansCollection.Clear();
                        if (entity is string)
                        {
                            this.instansCollection.Add(entityName, entity.ToString());
                        }
                        else
                        {
                            this.instansCollection.Add(entityName, JsonConvert.SerializeObject(entity));
                        }
                    }
                }
            }
        }

        /// <summary>
        /// this method convert stack variables into string format.
        /// </summary>
        /// <returns>string.</returns>
        public string InstanseLoggerString()
        {
            if (this.instansCollection != null && this.instansCollection.Count > 0 && this.instansCollectionPermanent != null && this.instansCollectionPermanent.Count > 0)
            {
                this.instansCollection.ToList().ForEach(x => this.instansCollectionPermanent.Add(x.Key, x.Value));

                return JsonConvert.SerializeObject(this.instansCollectionPermanent);
            }
            else if (this.instansCollection != null && this.instansCollection.Count > 0)
            {
                return JsonConvert.SerializeObject(this.instansCollection);
            }
            else if (this.instansCollectionPermanent != null && this.instansCollectionPermanent.Count > 0)
            {
                return JsonConvert.SerializeObject(this.instansCollectionPermanent);
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
