﻿namespace CoreBaseData.UnitOfWork
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.Repository.Implementation;
    using CoreBaseData.Repository.Interface;
    using Microsoft.EntityFrameworkCore;

    public class UnitOfWork
    {

        private CoreBaseDBContext _context;        
        public string ConnectionString { get; set; }

        private CurrentMaterialOnhandRepository currentMaterialOnhandRepository;
        
        public UnitOfWork(CoreBaseDBContext context)
        {
            this._context = context;
        }

        public CurrentMaterialOnhandRepository CurrentMaterialOnhandRepository
        {
            get
            {
                if (this.currentMaterialOnhandRepository == null)
                {
                    this.currentMaterialOnhandRepository = new CurrentMaterialOnhandRepository(this._context);
                }

                return this.currentMaterialOnhandRepository;
            }
        }

        public bool Save()
        {
            using (var transaction = this._context.Database.BeginTransaction())
            {
                try
                {
                    this._context.SaveChanges();
                    transaction.Commit();
                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return false;
                }
            }
        }

        /// <summary>
        /// this method execute the store procedure.
        /// </summary>
        /// <param name="procedureName">Name Of Procedure.</param>
        /// <param name="parameters">Parameter Key-Value Pair (key without @ and value as object).</param>
        /// <returns>Return Value of the SP. </returns>
        public Dictionary<string, object> ExecuteProcedureForResultValue(string procedureName, Dictionary<string, object> inputParameters = null
            , Dictionary<string, object> outputParameters = null)
        {
            Dictionary<string, object> result = new Dictionary<string, object>();
            using (SqlConnection con = new SqlConnection(string.IsNullOrEmpty(this.ConnectionString) ? this._context.Database.GetDbConnection().ConnectionString : this.ConnectionString))
            {
                try
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    using (SqlCommand cmd = new SqlCommand(procedureName, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (inputParameters != null)
                        {
                            foreach (var items in inputParameters)
                            {
                                cmd.Parameters.AddWithValue("@" + items.Key.ToString(), items.Value);
                            }
                        }

                        if (outputParameters != null)
                        {
                            foreach (var items in outputParameters)
                            {
                                SqlParameter outputParam = new SqlParameter("@" + items.Key.ToString(), items.Value);
                                outputParam.Direction = ParameterDirection.Output;
                                cmd.Parameters.Add(outputParam);
                            }
                        }

                        cmd.ExecuteNonQuery();
                        if (outputParameters != null)
                        {
                            foreach (var items in outputParameters)
                            {
                                result.Add(items.Key.ToString(), cmd.Parameters["@" + items.Key.ToString()].Value);
                            }
                        }
                        if (con.State == ConnectionState.Open) { con.Close(); }
                    }
                }
                catch (Exception ex)
                {
                    if (con.State == ConnectionState.Open) { con.Close(); }
                    return result;
                }
            }

            return result;
        }

        /// <summary>
        /// this method execute the store procedure.
        /// </summary>
        /// <param name="procedureName">Name Of Procedure.</param>
        /// <param name="parameters">Parameter Key-Value Pair (key without @ and value as object).</param>
        /// <returns>DataSet of result.</returns>
        public DataSet ExecuteProcedure(string procedureName, Dictionary<string, object> parameters = null, Dictionary<string, object> outParameterList = null)
        {
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataSet dsResult = new DataSet();

            using (SqlConnection con = new SqlConnection(string.IsNullOrEmpty(this.ConnectionString) ? this._context.Database.GetDbConnection().ConnectionString : this.ConnectionString))
            {
                try
                {
                    using (SqlCommand cmd = new SqlCommand(procedureName, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        if (parameters != null)
                        {
                            foreach (var items in parameters)
                            {
                                cmd.Parameters.AddWithValue("@" + items.Key.ToString(), items.Value);
                            }
                        }

                        if (outParameterList != null)
                        {
                            foreach (var items in outParameterList)
                            {
                                SqlParameter outParameter = new SqlParameter();
                                outParameter.Direction = ParameterDirection.Output;
                                outParameter.Value = items.Value;
                                outParameter.ParameterName = "@" + items.Key;
                                cmd.Parameters.Add(outParameter);
                            }
                        }
                        sqlDataAdapter.SelectCommand = cmd;
                        sqlDataAdapter.Fill(dsResult);
                    }
                }
                catch (Exception ex)
                {
                    return null;
                }
            }

            return dsResult;
        }

        public DataSet ExecuteUpdateProcedure(string procedureName, Dictionary<string, object> parameters = null, Dictionary<string, object> OutParameter = null)
        {
            int rs;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataSet dsResult = new DataSet();
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(procedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (parameters != null)
                    {
                        foreach (var items in parameters)
                        {
                            cmd.Parameters.AddWithValue("@" + items.Key.ToString(), items.Value);

                        }
                    }
                    if (OutParameter != null)
                    {
                        foreach (var items in OutParameter)
                        {
                            SqlParameter outParameter = new SqlParameter();
                            outParameter.Direction = ParameterDirection.Output;
                            outParameter.Value = items.Value;
                            outParameter.ParameterName = "@" + items.Key;

                            cmd.Parameters.Add(outParameter);
                        }
                    }
                    try
                    {
                        if (con.State == ConnectionState.Closed) { con.Open(); }

                        sqlDataAdapter.SelectCommand = cmd;
                        sqlDataAdapter.Fill(dsResult);
                        //rs = cmd.ExecuteNonQuery();
                        if (con.State == ConnectionState.Open) { con.Close(); }
                        rs = 1;
                    }
                    catch (Exception ex)
                    {
                        rs = 0;
                    }
                }
            }

            return dsResult;
        }


    }
}