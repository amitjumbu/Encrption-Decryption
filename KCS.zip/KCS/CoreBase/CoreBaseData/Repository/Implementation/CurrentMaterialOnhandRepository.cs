namespace CoreBaseData.Repository.Implementation
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using CoreBaseData.Models.Entity2;
    using CoreBaseData.Repository.Interface;
    using Microsoft.EntityFrameworkCore;

    public class CurrentMaterialOnhandRepository : BaseRepository<CurrentMaterialOnhand, CoreBaseDBContext>, ICurrentMaterialOnhandRepository
    {
        private readonly CoreBaseDBContext context;

        public CurrentMaterialOnhandRepository(CoreBaseDBContext context)
            : base(context)
        {
            this.context = context;
        }

        public async Task<int> RcordCountAsync(CurrentMaterialOnhand predicate)
        {
            return await Task.Run(() =>
            {
                return this.context.CurrentMaterialOnhand.Where(c => c.ClientId == predicate.ClientId && c.IsDeleted == false).Count<CurrentMaterialOnhand>();
            });
        }

        public async Task<decimal> GetSumQuantity(CurrentMaterialOnhand predicate)
        {
            return await Task.Run(() =>
            {
                return this.context.CurrentMaterialOnhand.Where(c => c.ClientId == predicate.ClientId && c.IsDeleted == false).Sum<CurrentMaterialOnhand>(c => c.Quantity);
            });
        }

        public async Task<bool> AddAsync(CurrentMaterialOnhand entity)
        {
            var entityExist = this.context.CurrentMaterialOnhand.Where(c => c.LocationId == entity.LocationId && c.MaterialId == entity.MaterialId && c.IsDeleted == false).AsNoTracking().FirstOrDefault();

            if (entityExist != null)
            {
                return false;
            }
            else
            {
                this.context.CurrentMaterialOnhand.Add(entity);
            }

            return true;
        }

        public async Task<bool> UpdateCommentAsync(CurrentMaterialOnhand entity)
        {
            var entityExist = this.context.CurrentMaterialOnhand.Where(c => c.Id == entity.Id && c.IsDeleted == false).AsNoTracking().FirstOrDefault();
            if (entityExist != null)
            {
                entityExist.Comment = entity.Comment;
                this.context.Entry(entityExist).State = EntityState.Modified;
            }
            else
            {
                return false;
            }

            return true;
        }

        public override async Task<bool> UpdateAsync(CurrentMaterialOnhand entity)
        {
            var entityExist = this.context.CurrentMaterialOnhand.Where(c => c.Id == entity.Id && c.IsDeleted == false).AsNoTracking().FirstOrDefault();
            if (entityExist != null)
            {
                var baseEntity = entityExist as CurrentMaterialOnhand;
                entityExist.Quantity = entity.Quantity;
                entityExist.QuantityUomid = entity.QuantityUomid;
                //entityExist.CreateDateTimeBrowser = entity.CreateDateTimeBrowser;
                //entityExist.CreateDateTimeServer = DateTime.UtcNow;
                entityExist.UpdatedBy = entity.UpdatedBy;
                entityExist.UpdateDateTimeServer = DateTime.Now;
                entityExist.UpdateDateTimeBrowser = entity.UpdateDateTimeBrowser;

                this.context.Entry(entityExist).State = EntityState.Modified;
            }
            else
            {
                return false;
            }

            return true;
        }

        public async virtual Task<bool> DeleteAsync(long id)
        {
            return await Task.Run(() =>
            {
                var entity = this.context.CurrentMaterialOnhand.Find(id);

                var baseEntity = entity as CurrentMaterialOnhand;
                this.context.Remove(baseEntity);
                return true;
            });
        }
    }
}