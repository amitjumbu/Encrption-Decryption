namespace CoreBaseData.Repository.Implementation
{
    using System.Threading.Tasks;
    using CoreBaseData.Models.Entity;

    public abstract class Repository
    {
        protected abstract Task<bool> AddAsync(BaseEntity entity);

        protected abstract Task<bool> UpdateAsync(BaseEntity entity); 
    } 
}