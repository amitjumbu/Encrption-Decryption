using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseData.Models.Entity;
using CoreBaseData.Repository.Interface;
using Microsoft.EntityFrameworkCore;

namespace CoreBaseData.Repository.Implementation
{
    public abstract class BaseRepository<T, TContext> : Repository, IBaseRepository<T>
    where T : class
     where TContext : DbContext
    {
        private readonly TContext _context;
        public BaseRepository(TContext context)
        {
            this._context = context; 
        }

        public async virtual Task<T> GetAsync(int id)
        {
            return await Task.Run(() =>
         {
             return this._context.Set<T>().Find(id);
         });

        }

        public async virtual Task<T> GetAsync(long id)
        {
            return await Task.Run(() =>
            {
                return this._context.Set<T>().Find(id);
            });

        }

        public async virtual Task<T> GetAsync(Expression<Func<T, bool>> predicate)
        {
            return await Task.Run(() =>
         {
             return this._context.Set<T>().Where(predicate).FirstOrDefault();
         });
        }

        public async virtual Task<IEnumerable<T>> ListAsync(Expression<Func<T, bool>> predicate)
        {
            return await Task.Run(() =>
         {
             return this._context.Set<T>().Where(predicate).AsEnumerable();
         });
        }

        public async virtual Task<bool> AddAsync(T entity)
        {
            return await this.AddAsync(entity as BaseEntity);
        }

        public async virtual Task<bool> UpdateAsync(T entity)
        {
            return await this.UpdateAsync(entity as BaseEntity);
        }

        public async virtual Task<bool> DeleteAsync(int id, string deletedBy)
        {
            return await Task.Run(() =>
         {
             var entity = this._context.Set<T>().Find(id);

             var baseEntity = entity as BaseEntity;
             baseEntity.UpdatedBy = deletedBy;
             baseEntity.UpdateDateTimeServer = DateTime.UtcNow;
             baseEntity.IsDeleted = true;

             this._context.SaveChanges();
             return true;
         });
        }

        protected async override Task<bool> AddAsync(BaseEntity entity)
        {
            return await Task.Run(() =>
            {
                entity.CreateDateTimeServer = DateTime.UtcNow;
                this._context.Set<BaseEntity>().Add(entity);
                this._context.SaveChanges();
                return true;
            });
        }
         
        protected async override Task<bool> UpdateAsync(BaseEntity entity)
        {
            return await Task.Run(() =>
            {
                entity.UpdateDateTimeServer = DateTime.UtcNow;
                this._context.Entry(entity).State = EntityState.Modified;
                this._context.SaveChanges();
                return true;
            });
        }

      public async virtual Task<int> CountAsync(Expression<Func<T, bool>> predicate)
        {
            return await Task.Run(() =>
            {
                return this._context.Set<T>().Where(predicate).Count();
            });
        }

        public async virtual Task<IEnumerable<T>> RangeAsync(int recordCount,int pageNo
                , int pageSize,Expression<Func<T, bool>> predicate,Expression<Func<T, string>> sortOrder)
        {
            return await Task.Run(() =>
            {
                if(pageSize>0)
                {
                    int currentCount = recordCount - (pageSize * (pageNo - 1));
                    int skipRecord = pageSize * (pageNo - 1);
                    if (pageSize > currentCount)
                    {
                        pageSize = currentCount;
                    }             
                           
                    return this._context.Set<T>().Where(predicate).OrderBy(sortOrder).Skip(skipRecord).Take(pageSize).AsEnumerable();
                }
                else
                {
                     return this._context.Set<T>().Where(predicate).OrderBy(sortOrder).AsEnumerable();
                }
            });
        }



        
    }
}