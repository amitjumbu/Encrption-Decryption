﻿namespace CoreBaseData.Repository.Interface
{
    using CoreBaseData.Models.Entity2;

    public interface ICurrentMaterialOnhandRepository : IBaseRepository<CurrentMaterialOnhand>
    {
    }
}
