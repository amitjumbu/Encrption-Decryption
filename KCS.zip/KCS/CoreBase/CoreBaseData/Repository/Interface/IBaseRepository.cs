﻿using System;
using System.Collections.Generic;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CoreBaseData.Repository.Interface
{
    public interface IBaseRepository<T> where T : class
    { 
        Task<T> GetAsync(int id);
        Task<T> GetAsync(Expression<Func<T, bool>> predicate);
        Task<IEnumerable<T>> ListAsync(Expression<Func<T, bool>> predicate);
        Task<bool> AddAsync(T entity); 
        Task<bool> UpdateAsync(T entity);
        Task<bool> DeleteAsync(int id, string deletedBy);
        Task<int> CountAsync(Expression<Func<T, bool>> predicate);
        Task<IEnumerable<T>> RangeAsync(int recordCount, int pageNo, int pageSize, Expression<Func<T, bool>> predicate, Expression<Func<T, string>> sortOrder);
    }
}
