using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.ViewModel;

namespace CoreBaseBusiness.Contracts
{
    public interface IBaseManager<TModel, TViewModel> where TModel : class where TViewModel : class
    {
        Task<TViewModel> GetAsync(int id);

        Task<TViewModel> GetAsync(long id);
        Task<TViewModel> GetAsync(TViewModel viewModel);
        Task<IEnumerable<TViewModel>> ListAsync(TViewModel viewModel);
        Task<bool> AddAsync(TViewModel viewModel);
        Task<bool> UpdateAsync(TViewModel viewModel);

        //Task<string> GetAuditAsync(AuditTrailViewModel viewModel); 
        Task<string> RangeAsync(TViewModel viewModel);
        Task<int> CountAsync(TViewModel viewModel);
        Task<IEnumerable<TViewModel>> RangeAsync(int recordCount, TViewModel viewModel);
        Task<IEnumerable<TViewModel>> RangeAsyncClientWise(int recordCount, TViewModel viewModel);


    }
}