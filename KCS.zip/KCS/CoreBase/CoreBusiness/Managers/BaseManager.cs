using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CoreBaseBusiness.Contracts;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Repository.Interface;
using Microsoft.Extensions.Configuration;

namespace CoreBaseBusiness.Managers
{
    public abstract class BaseManager<TModel, TViewModel> : IBaseManager<TModel, TViewModel>
       where TModel : class
       where TViewModel : class
    {

        public string BaseConnectionString
        {
            get
            {
                var configurationBuild = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
                return configurationBuild["ConnectionString:CoreBaseDB"];

            }
        }


        // private readonly IBaseRepository<TModel> _repository;
        public BaseManager()
        {
            //this._repository = repository;
        }
        public abstract Task<bool> AddAsync(TViewModel viewModel);
        public abstract Task<bool> UpdateAsync(TViewModel viewModel);
        public virtual Task<TViewModel> GetAsync(int id) { throw new NotImplementedException { }; }
        public virtual Task<TViewModel> GetAsync(TViewModel viewModel) { throw new NotImplementedException { }; }

        public virtual Task<TViewModel> GetAsync(long id) { throw new NotImplementedException { }; }
        public abstract Task<IEnumerable<TViewModel>> ListAsync(TViewModel viewModel);

        //public virtual Task<string> GetAuditAsync(AuditTrailViewModel viewModel) { throw new NotImplementedException { }; }
        public virtual Task<string> RangeAsync(TViewModel viewModel) { throw new NotImplementedException { }; }
        public virtual Task<int> CountAsync(TViewModel viewModel) { throw new NotImplementedException { }; }
        public virtual Task<IEnumerable<TViewModel>> RangeAsync(long recordCount, TViewModel viewModel) { throw new NotImplementedException { }; }

        public virtual Task<IEnumerable<TViewModel>> RangeAsync(int recordCount, TViewModel viewModel) { throw new NotImplementedException { }; }

        public virtual Task<IEnumerable<TViewModel>> RangeAsyncClientWise(int recordCount, TViewModel viewModel) { throw new NotImplementedException { }; }
    }
}