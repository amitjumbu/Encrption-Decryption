using AutoMapper;
using CoreBaseBusiness.ViewModel;
using CoreBaseData.Models.Entity;

using System.Collections.Generic;
using System.Linq;

namespace CoreBaseBusiness.Configuretion
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            
            this.CreateMap<CoreBaseData.Models.Entity2.CurrentMaterialOnhand, CurrentMaterialOnhandViewModel>().ReverseMap();
        }
    }
}