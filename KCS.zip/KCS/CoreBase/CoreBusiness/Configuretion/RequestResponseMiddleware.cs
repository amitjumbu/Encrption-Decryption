using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CoreSecurityBusiness.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using CoreBaseBusiness.Services;
using CoreBaseBusiness.Helpers.En_De;
using CoreBaseData.Helpers;
using CoreBaseData;

namespace CoreBaseBusiness.Configuretion
{
    public class RequestResponseMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ConfigurationKeys _configurationKeys;

        public RequestResponseMiddleware(RequestDelegate next, IOptions<ConfigurationKeys> configurationKeys)
        {
            this._next = next;
            this._configurationKeys = configurationKeys.Value;
        }

        public async Task Invoke(HttpContext context, IInstanseLogger instanseLogger)
        {
            // Do some request logic here.

            try
            {
                if (context.Request.ContentLength != null && context.Request.ContentLength > 0)
                {

                    context.Request.EnableBuffering();
                    string serverRequest = string.Empty;
                    if (context.Request.Method != "GET")
                    {
                        var stream = new StreamReader(context.Request.Body);
                        string jsonData = await stream.ReadToEndAsync();
                        stream.BaseStream.Seek(0, SeekOrigin.Begin);

                        if (!string.IsNullOrEmpty(jsonData))
                        {
                            instanseLogger.AddInstanseLogger("InitialRequest", jsonData, true);
                        }
                    }
                    else if (context.Request.Method == "GET")
                    {
                        var querystring = context.Request.QueryString;

                        if (querystring.HasValue && !string.IsNullOrEmpty(querystring.Value))
                        {
                            instanseLogger.AddInstanseLogger("InitialRequest", querystring.Value, true);
                        }
                    }
                }
            }
            catch (Exception ex) { }


            if (this._configurationKeys.EnforceApiDecryption)
            {
                //If request Path is starting with /api/ (i.e. it's a data api request, then only track and decode it) execute below code.
                if (!string.IsNullOrWhiteSpace(context.Request.Path.Value) && context.Request.Path.Value.StartsWith("/api/"))
                {
                    //This is to decrypt request Url.
                    var encryptedData = Regex.Replace(context.Request.Path.Value, @"^\/api\/?", "");
                    context.Request.Path = new PathString(string.Concat("/api/", encryptedData.Decrypt<string>()));
                }

                if (context.Request.ContentLength != null && context.Request.ContentLength > 0)
                {
                    //This is to decrypt request Body
                    string body = new StreamReader(context.Request.Body).ReadToEnd();

                    object decodedString = body.Decrypt<object>();

                    context.Request.ContentType = "application/json";
                    context.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(Convert.ToString(decodedString)));
                }
            }

            // Check whether is it target request whose response is to be encrypted
            if (this._configurationKeys.EnforceApiEncryption && !string.IsNullOrWhiteSpace(context.Request.Path.Value) && context.Request.Path.Value.StartsWith("/api/"))
            {
                // Copy a pointer to the original response body stream
                var originalBodyStream = context.Response.Body;

                // Create a new memory stream...
                using (var responseBody = new MemoryStream())
                {
                    // We set the response body to our stream so we can read after the chain of middlewares have been called.
                    context.Response.Body = responseBody;

                    // Continue down the Middleware pipeline, eventually returning to this class
                    await this._next.Invoke(context).ConfigureAwait(false);

                    // Read response body
                    context.Response.Body.Seek(0, SeekOrigin.Begin);
                    var body = await new StreamReader(context.Response.Body).ReadToEndAsync();

                    // Continue with encryption process
                    string encodedString = body.Encrypt().Serialize();

                    // Reset the body so nothing from the latter middlewares goes to the output.
                    //var bytes = Encoding.UTF8.GetBytes(encodedString);

                    context.Response.Body = originalBodyStream;
                    // Send our modified content to the response body.
                   await context.Response.WriteAsync(encodedString);
                }
            }
            else
            {
                // Continue down the Middleware pipeline, eventually returning to this class
                await this._next.Invoke(context).ConfigureAwait(false);
            }
            
            // Do some response logic here.
        }
    }
}