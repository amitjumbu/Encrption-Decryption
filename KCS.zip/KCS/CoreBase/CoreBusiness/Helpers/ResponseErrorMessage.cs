using CoreBaseBusiness.Helpers.Enums;
//using CoreBaseData.Helpers.Enums;

namespace CoreBaseBusiness.Helpers
{
    public class ResponseErrorMessage
    {
        //Get error message
        public static string GetErrorMessage(ErrorMessageType type)
        {
            string retMessage = "Oops. Something went wrong... Unable to fulfill the request.";
            switch (type)
            {
                case ErrorMessageType.RecordNotFound:
                    retMessage = "Record does not exists.";
                    break;
                case ErrorMessageType.RecordAlreadyExist:
                    retMessage = "Record already exists.";
                    break;
                case ErrorMessageType.UnAuthorizeAdd:
                    retMessage = "Unauthorize to add records.";
                    break;
                case ErrorMessageType.UnAuthorizeEdit:
                    retMessage = "Unauthorize to edit records.";
                    break;
                case ErrorMessageType.UnAuthorizeDelete:
                    retMessage = "Unauthorize to delete records."; 
                    break;
                case ErrorMessageType.UnAuthorizeGet:
                    retMessage = "Unauthorize to get records.";
                    break;
                case ErrorMessageType.GoldenKeyAlreadyExist:
                    retMessage = "Golden key already exists.";
                    break;
                case ErrorMessageType.GoldenSubKeyAlreadyExist:
                    retMessage = "Golden sub key already exists.";
                    break;
                case ErrorMessageType.GoldenKeyValueAlreadyExist:
                    retMessage = "Golden key and value already exists.";
                    break;
                case ErrorMessageType.FieldRequired:
                    retMessage = " should not be empty.";
                    break;
                case ErrorMessageType.RecordAlreadyExistWithName:
                    retMessage = " already exists.";
                    break;
                case ErrorMessageType.Other:
                    retMessage = "Something went wrong.. Please try again or later.";
                    break;
                case ErrorMessageType.FileNotSelected:
                    retMessage = "File should not be empty.";
                    break;
                case ErrorMessageType.ModuleUsed:
                    retMessage = "Module used in another process so cannot be deleted.";
                    break;
                case ErrorMessageType.StatusUsed:
                    retMessage = "Status used in another process so cannot be deleted.";
                    break;
                case ErrorMessageType.RoleUsed:
                    retMessage = "Role used in another process so cannot be deleted.";
                    break;
            }

            return retMessage;
        }
    }
}