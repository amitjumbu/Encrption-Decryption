using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CoreBaseData.Helpers
{
    public static class StringExtensions
    {
        public static T Deserialize<T>(this string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return default(T);
            return JsonConvert.DeserializeObject<T>(value);
        }

        public static string Serialize<T>(this T value)
        {
            if (value == null)
                return string.Empty;
            return JsonConvert.SerializeObject(value);
        }
        public static JObject ParseToJObject(this string value)
        {
            return JObject.Parse(value);
        }
    }
} 