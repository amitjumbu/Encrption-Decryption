﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreBaseBusiness.Helpers.En_De
{
    public static class RandomData
    {
        public static string CreateRandomPassword()
        {
            int PasswordLength = 10;
            string _allowedChars = Constants.Authentication.RandomKey;
            Random randNum = new Random();
            char[] chars = new char[PasswordLength];
            int allowedCharCount = _allowedChars.Length;
            for (int i = 0; i < PasswordLength; i++)
            {
                chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
            }
            return new string(chars);
        }
    }
} 
