﻿namespace CoreBaseBusiness.Helpers
{
    using CoreBaseBusiness.ViewModel;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    public class FilterResult<T> where T : class
    {

        public static IEnumerable<T> GetFilteredResult(IEnumerable<T> resultSet, string filterOn = null, int pageSize = 0, PaginationViewModel viewmodel = null)
        {
            var pageNo = viewmodel == null ? 0 : viewmodel.PageNo - 1;
            if (typeof(T).IsSubclassOf(typeof(BaseViewModel)) && !string.IsNullOrWhiteSpace(filterOn))
            {
                foreach (string filterString in filterOn.Trim().Split(' '))
                {
                    resultSet = resultSet
                    .Where(x => SearchStringOfObject(x).Contains(filterString, StringComparison.InvariantCultureIgnoreCase));
                }

                return resultSet.Skip(pageNo * pageSize)
                    .Take(pageSize < 1 ? 999999999 : pageSize);
            }

            return resultSet;
        }

        /// <summary>
        /// This uses reflection to create a search string from an object by joining all the values in the Object
        /// </summary>
        /// <param name="searchObject"></param>
        /// <returns></returns>
        public static string SearchStringOfObject(object searchObject)
        {
            if (searchObject == null)
            {
                return string.Empty;
            }
            // Get all properties of the Object
            PropertyInfo[] props = searchObject.GetType().GetProperties();
            string searchString = string.Empty;
            // recursively iterate through all the properties to create a search string
            var OrderNoWithVersion = string.Empty;
            var ShipmentNoWithVersion = string.Empty;
            foreach (PropertyInfo prp in props)
            {
                object value = prp.GetValue(searchObject, new object[] { });
                if (value != null && value.GetType().IsSubclassOf(typeof(BaseViewModel)))
                {
                    searchString = string.Join(',', new[] { searchString, SearchStringOfObject(value) });
                }
                //For search ship with column on order workbench screen by single textbox search filter
                if (prp.Name == "ShipWithOrderID")
                {
                    if (value == null)
                        searchString = string.Join(',', new[] { searchString, "no" });
                    else if (value != null && Convert.ToInt32(value) != 0)
                        searchString = string.Join(',', new[] { searchString, "yes" });
                }
                else if (value != null)
                {
                    searchString = string.Join(',', new[] { searchString, value.ToString() });

                    //For search order number with version on order workbench screen
                    if (prp.Name == "OrderNumber" && value != null)
                    {
                        OrderNoWithVersion = OrderNoWithVersion + value;
                    }
                    if (prp.Name == "OrderVersionNumber" && value != null)
                    {
                        OrderNoWithVersion = OrderNoWithVersion + '.' + value;
                        searchString = string.Join(',', new[] { searchString, value.ToString() + '.' + OrderNoWithVersion.ToString() });
                    }

                    //For search shipment number with version on shipment screen
                    if (prp.Name == "ShipmentNumber" && value != null)
                    {
                        ShipmentNoWithVersion = ShipmentNoWithVersion + value;
                    }
                    if (prp.Name == "ShipmentVersion" && value != null)
                    {
                        ShipmentNoWithVersion = ShipmentNoWithVersion + '.' + value;
                        searchString = string.Join(',', new[] { searchString, value.ToString() + '.' + ShipmentNoWithVersion.ToString() });
                    }

                }
            }
            return searchString;
        }
    }
}
