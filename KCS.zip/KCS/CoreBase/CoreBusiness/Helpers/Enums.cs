﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreBaseBusiness.Helpers.Enums
{
    public enum AuthMessages
    {

    }

    public enum ResponseMessages
    {
        None,
        Success,
        Error,
        InputDataNotFound,

        // Auth Messages
        UserNameAndPasswordAreRequired,
        UserDoesNotExists,
        InvalidUserNameOrPassword,
        RoleNotAssignedToUser,
        EmailIsRequired,
        InvalidUser,

         
        // User Messages
        UserExists,
        UsernameOrEmailRegistered
    }

    public enum LogLevel
    {
        Trace = 0,
        Debug = 1,
        Information = 2,
        Warning = 3,
        Error = 4
    }

    public enum GoldenMasterFormType
    {
        AddKeyValue = 0,
        AddKey = 1,
        AddSubKey = 2
    }

    public enum ErrorMessageType
    {
        None = 0,
        Other = 1,
        RecordNotFound = 2,
        RecordAlreadyExist = 3,
        UnAuthorizeAdd = 4,
        UnAuthorizeEdit = 5,
        UnAuthorizeDelete = 6,
        UnAuthorizeGet = 7,
        GoldenKeyAlreadyExist = 8,
        GoldenSubKeyAlreadyExist = 9,
        GoldenKeyValueAlreadyExist = 10,
        FieldRequired = 11,
        RecordAlreadyExistWithName = 12,
        FileNotSelected = 13,
        ModuleUsed = 14,
        StatusUsed = 15,
        RoleUsed = 16,

    }
}

