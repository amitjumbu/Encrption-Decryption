﻿namespace CoreBaseBusiness.ViewModel
{
    public class PaginationViewModel
    {
        public int PageNo { get; set; }

        public int PageSize { get; set; }

        public string FilterOn { get; set; }

        public string SortColumn { get; set; }

        public string SortOrder { get; set; }
    }

}
