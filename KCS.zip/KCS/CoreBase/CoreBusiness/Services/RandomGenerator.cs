using System;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;

namespace CoreBaseBusiness.Services
{
    public class RandomGenerator
    {
        // Generate a random number between two numbers    
        public static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
    }
}