﻿namespace CoreBaseBusiness.Services
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using CoreBaseBusiness.Contracts;
    using CoreBaseBusiness.Helpers;
    using CoreBaseBusiness.ViewModel;
    using Dapper;
    using Hangfire;
    using Microsoft.Extensions.Configuration;

    /// <summary>
    /// this class with the help of hangfire put the method into background job.
    /// </summary>
    public class HangfireOperation : IHangfireOperation
    {
        private IEmailSender emailSender;

        private string ConnectionString { get; set; }
        private IConvertEnglishToSpanish convertEnglishToSpanish;
        public HangfireOperation(IEmailSender emailSender, IConvertEnglishToSpanish convertEnglishToSpanish)
        {
            this.emailSender = emailSender;
            this.convertEnglishToSpanish = convertEnglishToSpanish;
            var configuration = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json")
           .Build();

            this.ConnectionString = configuration["ConnectionString:CoreBaseDB"];
        }

        public void SendEmailAsyn(string messageBody, string subject, string recipeint, string cc, string bcc, List<string> attachement)
        {
            var jobID = BackgroundJob.Enqueue(() => this.emailSender.SendEmailAsync(messageBody, subject, recipeint, cc, bcc, attachement));
        }

        public void SendForShippingOrder(long orderID, int OrderTypeID)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
            parameter.Add("OrderTypeID", OrderTypeID);

            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_VerifyOrderStautsSendForShippingAsync", parameter));
        }

        public void ARChargesTOMAS(long orderID)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
           

            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_OrderApproveAndSendTOMAS", parameter));
        }

        public IEnumerable<object> ExecuteProcedure(string procedureName, Dictionary<string, object> paramters)
        {
            IEnumerable<object> finalResult = null;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }

                    if (paramters.Count > 0)
                    {
                        DynamicParameters dyanmicParameter = new DynamicParameters();
                        foreach (var param in paramters)
                        {
                            if (param.Value is DataTable)
                            {
                                dyanmicParameter.Add("@" + param.Key, ((DataTable)param.Value).AsTableValuedParameter());
                            }
                            else
                            {
                                dyanmicParameter.Add("@" + param.Key, param.Value);
                            }

                        }

                        finalResult = con.Query<object>(procedureName, dyanmicParameter, commandType: CommandType.StoredProcedure);
                    }
                    else
                    {
                        finalResult = con.Query<object>(procedureName, null, commandType: CommandType.StoredProcedure);
                    }

                    con.Close();

                }
                catch (Exception ex) { }


            }

            return finalResult;
        }

        public string CreateOrderNumberAndSave(long orderID, int orderTypeId, bool isAsynchronous = true)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
            parameter.Add("OrderTypeID", orderTypeId);
            string procedureName = "SPO_CreateOrderNumberForNewOrder";
            if (isAsynchronous)
            {
                var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure(procedureName, parameter));
            }
            else
            {
                var result = this.ExecuteProcedure(procedureName, parameter);

                if (result != null && result.Count() > 0)
                {
                    var orderNumber = ((IDictionary<string, object>)result.FirstOrDefault())["OrderNumber"].ToString();
                    return orderNumber;
                }
            }

            return string.Empty;

        }

        public IEnumerable<object> SendShipmentTOMAS(long shipmentID)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("ShipmentID", shipmentID);
            // var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_ShipmentStatusUpdateSendToMAS", parameter));
           return  this.ExecuteProcedure("SPO_ShipmentStatusUpdateForSendToMAS", parameter);

        }

        public void CalculateARChargesAgain(long orderid)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderid);
            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_ARChargesForExistingOrder", parameter));
        }

        public void CalculateAPChargesAgain(long orderid,int ordertypeid)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderid);
            parameter.Add("OrderTypeID", ordertypeid);
            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_APChargesForExistingOrder", parameter));
        }

        public void SendAppointmentDetails(string pickup, string delivery, long orderid, int orderTypeID)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (!string.IsNullOrEmpty(pickup))
            {
                parameters.Add("PickupAppointment", pickup);
            }

            if (!string.IsNullOrEmpty(delivery))
            {
                parameters.Add("DeliveryAppointment", delivery);
            }

            parameters.Add("OrderID", orderid);
            parameters.Add("OrderTypeID", orderTypeID);
            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_SaveAndModifyAppointmentForOrder", parameters));

        }

        public void UpdateOrderFileFlag(AllSalesOrderViewModel viewModel)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            if (viewModel.salesorder.Id != 0)
            {
                parameters.Add("OrderId", viewModel.salesorder.Id);
                parameters.Add("OrderStatusId", viewModel.salesorder.OrderStatusId);
                parameters.Add("RequestedDeliveryDate", viewModel.salesorder.RequestedDeliveryDate);
                parameters.Add("ScheduledShipDate", viewModel.salesorder.ScheduledShipDate);
                parameters.Add("MustArriveByDate", viewModel.salesorder.MustArriveByDate);
                parameters.Add("ShipToLocationId", viewModel.salesorder.ToLocationId);
                parameters.Add("ShipFromLocationId", viewModel.salesorder.FromLocationId);
                parameters.Add("OrderTypeID", viewModel.salesorder.OrderTypeId);
                parameters.Add("CalendarStartDate", null);
                parameters.Add("CalendarEndDate", null);
                parameters.Add("IntResult", (SqlDbType)Convert.ToInt32("0"));
                //parameters["IntResult"].Direction = ParameterDirection.Output;
            } 
            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_ChangeOrderFileFlag_mmmm", parameters));

        }


        public void ARChargeTOMAS(long orderID,int OrderTypeID)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
            parameter.Add("OrderTypeID", OrderTypeID);

            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_OrderApproveAndSendTOMAS", parameter));
        }


        public void ARChargeTOMASS(string orderID, int isStockTransfer)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
            parameter.Add("IsStockTransfer", isStockTransfer);
            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_OrderApproveAndSendTOMAS", parameter));
        }

        public void REARChargeTOMAS(string orderID,int isStockTransfer)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
            parameter.Add("IsStockTransfer", isStockTransfer);
            var jobID = BackgroundJob.Enqueue(() => this.ExecuteProcedure("SPO_OrderReSendTOMAS", parameter));
        }


        public void UpdateEnglishToSpanishComment(long orderID,int OrderTypeId, string SpanishTransportationComment,string SpanishLoadingComment, string SpanishTransplaceOrderComment, string SpanishTransplaceDeliveryComment)
        {
            Dictionary<string, object> parameter = new Dictionary<string, object>();
            parameter.Add("OrderID", orderID);
            parameter.Add("OrderTypeId", OrderTypeId);
            parameter.Add("SpanishTransportationComment", SpanishTransportationComment);
            parameter.Add("SpanishLoadingComment", SpanishLoadingComment);
            parameter.Add("TransplaceOrderCommentSpanish", SpanishTransplaceOrderComment);
            parameter.Add("TransplaceDeliveryCommentSpanish", SpanishTransplaceDeliveryComment);
            this.ExecuteProcedure("SPO_UpdateOrderTransportationLoadingCommentToSpanish", parameter);
        }

        public void SaveOrderConvertLanguage(List<BulkOrderViewModel> result)
        {
            var jobID = BackgroundJob.Enqueue(() => this.SetSpanish(result));
        }

        public bool SetSpanish(List<BulkOrderViewModel> result)
        {
            if (result.Count > 0)
            {
                foreach (var orderViewModel in result)
                {
                    using (SqlConnection conn = new SqlConnection(this.ConnectionString))
                    {
                        SqlCommand cmd = conn.CreateCommand();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "SPO_GetOrderTransportationLoadingComment";
                        SqlParameter param = new SqlParameter();
                        param = cmd.Parameters.AddWithValue("@OrderNumber", orderViewModel.OrderNumber);
                        param = cmd.Parameters.AddWithValue("@OrderTypeId", orderViewModel.OrderTypeId);
                        conn.Open();
                        SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                        DataSet dsResult = new DataSet();
                        sqlDataAdapter.SelectCommand = cmd;
                        sqlDataAdapter.Fill(dsResult);
                        if (dsResult != null && dsResult.Tables != null && dsResult.Tables.Count > 0)
                        {
                            var SpanishTransportationComment = "";
                            var SpanishLoadingComment = "";
                            var SpanishTransplaceOrderComment = "";
                            var SpanishTransplaceDeliveryComment = "";
                            var ID = Convert.ToInt64(dsResult.Tables[0].Rows[0]["ID"].ToString());
                            var TransportationComment = dsResult.Tables[0].Rows[0]["TransportationComment"].ToString();
                            var LoadingComment = dsResult.Tables[0].Rows[0]["LoadingComment"].ToString();
                            var TransplaceOrderComment = dsResult.Tables[0].Rows[0]["TransplaceOrderComment"].ToString();
                            var TransplaceDeliveryComment = dsResult.Tables[0].Rows[0]["TransplaceDeliveryComment"].ToString();
                            if (TransportationComment != null || TransportationComment != "")
                            {
                                SpanishTransportationComment = this.convertEnglishToSpanish.ConvertTextEnglishToSpanish(TransportationComment).ConfigureAwait(true)
                               .GetAwaiter()
                               .GetResult();
                            }
                            if (LoadingComment != null || LoadingComment != "")
                            {
                                SpanishLoadingComment = this.convertEnglishToSpanish.ConvertTextEnglishToSpanish(LoadingComment).ConfigureAwait(true)
                               .GetAwaiter()
                               .GetResult();
                            }
                            if (TransplaceOrderComment != null || TransplaceOrderComment != "")
                            {
                                SpanishTransplaceOrderComment = this.convertEnglishToSpanish.ConvertTextEnglishToSpanish(TransplaceOrderComment).ConfigureAwait(true)
                               .GetAwaiter()
                               .GetResult();
                            }
                            if (TransplaceDeliveryComment != null || TransplaceDeliveryComment != "")
                            {
                                SpanishTransplaceDeliveryComment = this.convertEnglishToSpanish.ConvertTextEnglishToSpanish(TransplaceDeliveryComment).ConfigureAwait(true)
                               .GetAwaiter()
                               .GetResult();
                            }

                            this.UpdateEnglishToSpanishComment(ID, orderViewModel.OrderTypeId, SpanishTransportationComment, SpanishLoadingComment, SpanishTransplaceOrderComment, SpanishTransplaceDeliveryComment);
                        }

                        conn.Close();
                    }
                }
            }
            else
            {
                return false;
            }
            return true;
        }
    }
}
