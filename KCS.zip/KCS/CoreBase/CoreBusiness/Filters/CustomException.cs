using System;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;

namespace CoreBaseBusiness.Filters
{
   public class CustomException : Exception
    {
        public override string Message { get; }

        protected CustomException() 
        {
        }

        public CustomException(string code)
        {
            Message = code;
        }

        public CustomException(string message, params object[] args)
            : this(string.Empty, message, args)
        {
        }

        public CustomException(string code, string message, params object[] args)
            : this(null, code, message, args)
        {
        }

        public CustomException(Exception innerException, string message, params object[] args)
            : this(innerException, string.Empty, message, args)
        {
        }

        public CustomException(Exception innerException, string code, string message, params object[] args)
            : base(string.Format(message, args), innerException)
        {
            Message = code;
        }
    }
}

