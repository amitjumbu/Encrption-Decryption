using AutoMapper;
using CoreBaseBusiness.Configuretion;
using CoreBaseBusiness.Filters;
using CoreBaseData.Models.Entity2;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoreApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddMvc(config =>
            {
                config.Filters.Add(typeof(ExceptionFilter));
            });

            //services.AddMvc(config =>
            //{
            //    config.Filters.Add(typeof(ExceptionFilter));
            //    //config.Filters.Add(typeof(ValidateModelStateAttribute));
            //})
            //    .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver())
            //    .SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            #region Enable CORS
            //services.AddCors(options =>
            //{
            //    options.AddPolicy("CorsPolicy",
            //        builder => builder.AllowAnyOrigin()
            //        .AllowAnyMethod()
            //        .AllowAnyHeader()
            //        .AllowCredentials());
            //});
            services.AddCors();
            #endregion

            #region SQL - connection
            //services.AddDbContext<EICDBContext>(opts => opts.UseSqlServer(Configuration["ConnectionString:AsrBookDb"]), b => b.MigrationsAssembly("ASR.Book.API"));
            //services.AddControllers();
            //options.UseSqlServer(connectionString,x => x.MigrationsAssembly("MyApp.Migrations"));

            //-----------------//
            var configuration = new ConfigurationBuilder()
           .SetBasePath(Directory.GetCurrentDirectory())
           .AddJsonFile("appsettings.json")
           .Build();
            //string dbConnectionString = configuration.GetConnectionString("AsrBookDb");
            // string dbConnectionString = configuration["ConnectionString:CoreBaseDB"];
            // string assemblyName = typeof(CoreDBContext).Namespace;

            // services.AddDbContext<CoreDBContext>(options =>
            //    {
            //        options.UseSqlServer(dbConnectionString, optionsBuilder =>
            //              optionsBuilder.MigrationsAssembly("CoreBaseApi"));

            //    }, ServiceLifetime.Transient

            //);



            string dbConnectionStringAdectec = configuration["ConnectionString:CoreBaseDB"];
            string assemblyNameAdectec = typeof(CoreBaseDBContext).Namespace;

            services.AddDbContext<CoreBaseDBContext>(options =>
            {
                options.UseSqlServer(dbConnectionStringAdectec,
                    optionsBuilder =>
                        optionsBuilder.MigrationsAssembly("CoreBaseApi")
                );
            }, ServiceLifetime.Transient

           );

            #endregion

            #region Swagger integration
            // Register the Swagger generator, defining one or more Swagger documents  
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "Base API - v1", Version = "v1" });
            });
            #endregion

            #region AutoMapper configuration
            services.AddAutoMapper();//am => am.AddProfile(new MappingProfile()));
            #endregion

            // code for Hangfire service configuration
            //services.AddHangfire(config =>
            //     config.SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
            //     .UseSimpleAssemblyNameTypeSerializer()
            //     .UseDefaultTypeSerializer()
            //     .UseSqlServerStorage(configuration["ConnectionString:CoreBaseDB"]));
            //services.AddScoped<IHangfireOperation, HangfireOperation>();

            // end hangfire service confirguration

            //var notificationMetadata = configuration.GetSection("NotificationMetadata").Get<EmailConfigurationViewModel>();
            //services.AddSingleton(notificationMetadata);
            //services.AddScoped<IInstanseLogger, InstanseLogger>();



            //services.AddTransient<ICurrentMaterialOnhandManager, CurrentMaterialOnhandManager>();
            //services.AddTransient<ICurrentMaterialOnhandRepository, CurrentMaterialOnhandRepository>();

            //services.AddHangfireServer();
            services.AddHttpClient();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            #region Enable CORS
            //app.UseCors("CorsPolicy");
            //app.UseCors(options => options.AllowAnyOrigin());
            app.UseCors(x => x
             .AllowAnyMethod()
             .AllowAnyHeader()
             .SetIsOriginAllowed(origin => true) // allow any origin
             .AllowCredentials()); // allow credentials
            #endregion

            #region Swagger Integration
            // Enable middleware to serve generated Swagger as a JSON endpoint.  
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.  
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "EY EIC - Base API - v1");
            });
            #endregion
            app.UseHttpsRedirection();

            app.UseMiddleware<RequestResponseMiddleware>();

            app.UseRouting();

            app.UseAuthorization();
            //app.UseHangfireDashboard();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
